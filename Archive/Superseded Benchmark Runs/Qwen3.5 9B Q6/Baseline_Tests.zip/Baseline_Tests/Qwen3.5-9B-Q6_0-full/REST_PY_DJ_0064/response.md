```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing 'new_description' and 'new_title'.
        
    Returns:
        dict or None: The decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 200-299 range).
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "description": inputs["new_description"],
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"Failed to submit product. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json() if response.content else None
```