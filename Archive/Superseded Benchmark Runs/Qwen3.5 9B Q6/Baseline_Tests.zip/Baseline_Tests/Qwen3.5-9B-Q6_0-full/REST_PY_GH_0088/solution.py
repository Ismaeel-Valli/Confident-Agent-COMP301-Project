import requests

def solve(inputs):
    """
    Lists commits on a pull request using the GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - pull_number (int): The number that identifies the pull request.
            - page_size (int): The number of results per page (max 100).
            - credential (str): The caller-supplied credential (e.g., Bearer token or OAuth token).
    
    Returns:
        list | None: A list of decoded JSON responses for each page, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    pull_number = inputs["pull_number"]
    page_size = inputs["page_size"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pull_number}/commits"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    params = {
        "per_page": page_size
    }

    while True:
        response = requests.get(url, headers=headers, params=params)
        
        if response.status_code != 200:
            raise Exception(f"Failed to fetch commits: HTTP {response.status_code} - {response.text}")
        
        data = response.json()
        
        if not data:
            return None
        
        yield data
        
        # Check for pagination
        last_page = response.headers.get("Link", "")
        if "rel=\"next\"" in last_page:
            next_url_start = last_page.find("href=\"") + len("href=\"")
            next_url_end = last_page.find("\"", next_url_start)
            next_url = last_page[next_url_start:next_url_end]
            params["url"] = next_url
        else:
            break