import requests

def solve(inputs):
    """
    Creates a new label on a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository.
            - new_color (str): The hex color code for the label.
            - new_name (str): The name for the new label.
            - credential (str): The authentication token or string for the API request.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    new_color = inputs["new_color"]
    new_name = inputs["new_name"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/labels"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    data = {
        "name": new_name,
        "color": new_color
    }

    response = requests.post(url, json=data, headers=headers)
    
    if response.status_code == 201:
        return None
    elif response.status_code == 200:
        return response.json()
    else:
        raise requests.RequestException(f"Failed to create label. Status code: {response.status_code}, Response: {response.text}")