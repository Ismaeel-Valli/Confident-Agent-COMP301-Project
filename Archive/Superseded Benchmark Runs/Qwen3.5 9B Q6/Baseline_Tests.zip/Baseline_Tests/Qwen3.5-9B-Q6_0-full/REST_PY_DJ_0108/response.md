```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON using provided email and first name.
    
    Args:
        inputs (dict): Dictionary containing 'new_email' and 'new_firstName'.
        
    Returns:
        int or None: The ID of the created user, or None if response is empty/successful without ID.
        
    Raises:
        requests.exceptions.HTTPError: If the HTTP response status code indicates failure.
    """
    url = "https://dummyjson.com/users/add"
    
    payload = {
        "email": inputs.get("new_email"),
        "firstName": inputs.get("new_firstName")
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise requests.exceptions.HTTPError(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    # DummyJSON typically returns a dict with 'id' on success for this endpoint
    if "id" in data and data["id"] is not None:
        return data["id"]
    elif isinstance(data, dict) and len(data) == 0:
        return None
    else:
        # If response has content but no 'id' key or it's empty/None
        return None
```