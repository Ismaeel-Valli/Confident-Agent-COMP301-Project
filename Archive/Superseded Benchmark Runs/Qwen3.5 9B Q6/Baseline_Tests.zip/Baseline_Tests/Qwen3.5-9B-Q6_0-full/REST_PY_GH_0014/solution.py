import requests

def solve(inputs):
    """
    Lists forks for a given GitHub repository using the GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git extension).
            - 'credential' (str): The caller-supplied credential (e.g., token or Bearer token).
    
    Returns:
        list or None: A list of fork data dictionaries if forks exist, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code outside 200-299 range).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/forks"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if not (200 <= response.status_code < 300):
        raise Exception(f"Failed to list forks: HTTP {response.status_code} - {response.text}")
    
    data = response.json()
    
    return data if len(data) > 0 else None