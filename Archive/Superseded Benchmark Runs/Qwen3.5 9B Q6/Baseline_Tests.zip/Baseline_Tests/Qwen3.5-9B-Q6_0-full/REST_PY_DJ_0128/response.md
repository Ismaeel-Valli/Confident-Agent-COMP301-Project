```python
import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on skip count and sort field.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'results_to_skip' (int): Number of results to skip.
            - 'sort_field' (str): Field used for ordering.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty but successful.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    params = {
        'skip': inputs['results_to_skip'],
        '_sort': inputs['sort_field']
    }
    
    try:
        response = requests.get(base_url, params=params)
        
        if not response.ok:
            raise Exception(f"HTTP request failed with status code: {response.status_code}")
        
        data = response.json()
        
        if not data:
            return None
        
        return data
    
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request error occurred: {str(e)}")
```