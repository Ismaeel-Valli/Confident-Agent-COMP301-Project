```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post in DummyJSON and returns the title value.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (int): Identifier of the post to update.
            - new_title (str): The new title value for the post.
    
    Returns:
        str or None: The updated title if present in the response, otherwise None.
                     Returns None for a successful empty response.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_title = inputs['new_title']
    
    # Base URL for DummyJSON API (assuming standard structure)
    base_url = "https://dummyjson.com/posts"
    
    try:
        response = requests.put(
            f"{base_url}/{resource_id}",
            json={"title": new_title},
            timeout=10
        )
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (no content)
        if not response.text:
            return None
        
        # Parse the JSON response and extract the title
        data = response.json()
        return data.get('title')
    
    except requests.exceptions.RequestException as e:
        raise e
```