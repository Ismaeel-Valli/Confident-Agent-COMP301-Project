import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the user.
            - new_phone (str): New value for the phone attribute.
    
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get("resource_id")
    new_phone = inputs.get("new_phone")
    
    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {"phone": new_phone}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 201:
        return response.json()
    else:
        raise Exception(f"HTTP {response.status_code}: {response.text}")