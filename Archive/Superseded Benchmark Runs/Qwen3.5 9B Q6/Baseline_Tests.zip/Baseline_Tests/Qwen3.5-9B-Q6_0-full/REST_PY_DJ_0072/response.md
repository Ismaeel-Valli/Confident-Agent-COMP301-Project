```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON and returns the response's id value,
    or None if that attribute is absent or for a successful empty response.
    Raises an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the todo
            - new_completed (bool): Value for the completed attribute
    
    Returns:
        str or None: The ID from the response, or None if absent or empty response
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails
    """
    resource_id = inputs.get('resource_id')
    new_completed = inputs.get('new_completed')
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    payload = {
        "completed": new_completed
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update todo: HTTP {response.status_code}")
    
    data = response.json()
    
    # Check for successful empty response (no content)
    if not data or 'id' not in data:
        return None
    
    return data.get('id')
```