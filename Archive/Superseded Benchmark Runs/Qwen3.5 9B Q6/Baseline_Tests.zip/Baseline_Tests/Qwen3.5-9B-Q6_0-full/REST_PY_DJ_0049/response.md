```python
import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on pagination inputs.
    
    Args:
        inputs (dict): A dictionary containing 'results_to_skip' (int).
        
    Returns:
        list or None: The decoded JSON response as a list of users, or None if the response is empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://dummyjson.com/users"
    results_to_skip = inputs.get('results_to_skip', 0)
    
    # DummyJSON uses 'skip' and 'limit' for pagination
    params = {
        'skip': results_to_skip,
        'limit': 1  # Retrieve one page (one result) as implied by "one page" in this context
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP request failed with status code: {response.status_code}")
    
    data = response.json()
    
    # The 'users' key contains the list of users
    users_list = data.get('users', [])
    
    return users_list if users_list else None
```