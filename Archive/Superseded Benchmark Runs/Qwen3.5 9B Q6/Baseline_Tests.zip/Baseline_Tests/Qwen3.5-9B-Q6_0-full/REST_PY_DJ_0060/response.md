```python
import requests

def solve(inputs):
    """
    Deletes a todo by identifier from DummyJSON and returns the 'isDeleted' value.
    
    Args:
        inputs (dict): A dictionary containing 'resource_id' (the todo identifier).
        
    Returns:
        bool or None: The 'isDeleted' value from the response, or None if absent or on success with empty response.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    try:
        response = requests.delete(url)
        response.raise_for_status()
        
        # Check if the response is empty (successful deletion often returns 204 No Content)
        if response.status_code == 204 or not response.text:
            return None
            
        data = response.json()
        
        # Return 'isDeleted' if present, otherwise None
        return data.get('isDeleted')
        
    except requests.exceptions.HTTPError as e:
        raise RuntimeError(f"Failed to delete todo: {e}") from e
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Request failed: {e}") from e
```