import requests

def solve(inputs):
    """
    Fetches issue comments from a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'issue_number' (int): The issue number to fetch comments for.
            - 'since' (str, optional): ISO 8601 timestamp to filter comments updated after this time.
            - 'credential' (dict): Contains authentication details (e.g., token or username/password).
    
    Returns:
        list or None: A list of decoded JSON comment objects, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response status code indicates an error.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    issue_number = inputs['issue_number']
    since = inputs.get('since')
    credential = inputs['credential']

    # Construct the base URL for the GitHub API (version 2026-03-10)
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}/comments"

    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Determine authentication method based on credential structure
    if 'token' in credential:
        headers['Authorization'] = f"Bearer {credential['token']}"
    elif 'username' in credential and 'password' in credential:
        auth = (credential['username'], credential['password'])
    else:
        raise ValueError("Invalid credential format. Expected 'token' or 'username'/'password'.")

    params = {}
    if since:
        params['since'] = since

    response = requests.get(url, headers=headers, auth=auth, params=params)

    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()

    data = response.json()

    # Return None for a successful empty response
    if not data:
        return None

    return data