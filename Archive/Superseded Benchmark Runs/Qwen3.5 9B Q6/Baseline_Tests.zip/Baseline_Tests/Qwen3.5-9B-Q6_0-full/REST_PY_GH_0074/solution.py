import requests

def solve(inputs):
    """
    Lists forks of a given repository using GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'sort' (str): The sort order for the list of forks.
            - 'credential' (str): The authentication token or bearer string.
    
    Returns:
        dict or None: Decoded JSON response if successful, None for empty list.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    sort_order = inputs["sort"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/forks"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    params = {"sort": sort_order}
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch forks: HTTP {response.status_code}, Body: {response.text}")
    
    data = response.json()
    
    return data if data else None