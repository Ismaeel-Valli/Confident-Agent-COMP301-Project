```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_username'.
        
    Returns:
        int or None: The ID of the created user, or None if response is empty.
        
    Raises:
        requests.exceptions.RequestException: If HTTP request fails.
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "name": inputs["new_firstName"],
        "username": inputs["new_username"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. Status code: {response.status_code}")
    
    data = response.json()
    
    if not data:
        return None
    
    return data.get("id")
```