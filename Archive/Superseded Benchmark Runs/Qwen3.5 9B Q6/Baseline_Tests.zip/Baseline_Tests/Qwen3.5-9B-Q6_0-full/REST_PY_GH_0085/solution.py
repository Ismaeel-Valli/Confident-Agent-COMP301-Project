import requests

def solve(inputs):
    """
    Lists pull requests for a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'state' (str): Filter state ('open', 'closed', or 'all').
            - 'credential' (str): Bearer token for authentication.
    
    Returns:
        list or None: Decoded JSON response as a list, or None if the list is empty.
    
    Raises:
        Exception: If the HTTP response status code indicates an error.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    state = inputs['state']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls"
    params = {'state': state}
    headers = {
        'Accept': 'application/vnd.github+json',
        'Authorization': f'Bearer {credential}'
    }
    
    response = requests.get(url, params=params, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"GitHub API request failed with status code {response.status_code}: {response.text}")
    
    data = response.json()
    
    return None if not data else data