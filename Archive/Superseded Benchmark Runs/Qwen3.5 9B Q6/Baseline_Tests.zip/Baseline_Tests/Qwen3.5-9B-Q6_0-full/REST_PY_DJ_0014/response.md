```python
import requests

def solve(inputs):
    """
    Retrieves a post by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with the post identifier.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.exceptions.HTTPError: If HTTP response status code indicates failure.
    """
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/posts/{resource_id}"
    
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        return None if not data else data
    elif response.status_code in [404, 500]:
        raise requests.exceptions.HTTPError(f"Failed to retrieve post: {response.status_code}")
    else:
        raise requests.exceptions.HTTPError(f"Unexpected HTTP status code: {response.status_code}")
```