import requests

def solve(inputs):
    """
    Fetches a specific commit from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository.
            - 'page' (int): The page number of results to fetch.
            - 'ref' (str): The commit reference (e.g., branch name, tag, or SHA).
            - 'credential' (str): The authentication token for the API request.
    
    Returns:
        dict or None: The decoded JSON response if successful. Returns None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    page = inputs["page"]
    ref = inputs["ref"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/commits"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    params = {
        "page": page,
        "per_page": 1
    }

    response = requests.get(url, headers=headers, params=params)

    if response.status_code != 200:
        raise Exception(f"Failed to fetch commit. Status code: {response.status_code}, Response: {response.text}")

    data = response.json()

    # If the response is an empty list (e.g., no commits on this page), return None as per instructions for successful empty response
    if not data:
        return None

    return data