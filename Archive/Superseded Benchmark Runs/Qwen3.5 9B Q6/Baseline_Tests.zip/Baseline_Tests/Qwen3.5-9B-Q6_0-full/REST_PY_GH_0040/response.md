```python
import requests

def solve(inputs):
    """
    Lists commits on a pull request for a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'pull_number' (int): The pull request number.
            - 'credential' (str): The authentication token or string for API access.
    
    Returns:
        list or None: A list of commit objects if commits exist, otherwise None for an empty response.
    
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    pull_number = inputs['pull_number']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pull_number}/commits"
    
    headers = {
        'Authorization': f'token {credential}',
        'Accept': 'application/vnd.github+json'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to retrieve commits. Status code: {response.status_code}")
    
    data = response.json()
    
    return data if data else None
```