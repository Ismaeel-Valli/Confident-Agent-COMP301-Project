```python
import requests

def solve(inputs):
    """
    Submits a new todo to DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_completed: value for the completed attribute
            - new_todo: value for the todo attribute
            - new_user_identifier: value for the user Id attribute
    
    Returns:
        str or None: The response's id value, or None if that attribute is absent.
                     Returns None for a successful empty response.
    
    Raises:
        Exception: For an unsuccessful HTTP response.
    """
    url = "https://dummyjson.com/todos"
    
    payload = {
        "todo": inputs["new_todo"],
        "completed": inputs["new_completed"],
        "userId": inputs["new_user_identifier"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code != 201 and response.status_code != 200:
            raise Exception(f"Failed to submit todo. Status code: {response.status_code}")
        
        data = response.json()
        
        # Check for successful empty response (no todos returned)
        if not data.get("todos"):
            return None
        
        # Return the id of the newly created todo
        if "id" in data["todos"][0]:
            return data["todos"][0]["id"]
        else:
            return None
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```