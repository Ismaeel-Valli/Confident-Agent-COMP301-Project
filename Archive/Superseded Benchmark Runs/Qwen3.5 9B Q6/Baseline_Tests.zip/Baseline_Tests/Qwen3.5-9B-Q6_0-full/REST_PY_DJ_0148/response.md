```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON and returns the response's id value,
    or None if that attribute is absent or the response is empty. Raises an exception for unsuccessful HTTP responses.
    
    Args:
        inputs (dict): Contains 'resource_id', 'new_completed', and 'new_user_identifier'.
        
    Returns:
        str or None: The ID of the updated todo, or None if absent or response is empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    new_completed = inputs.get('new_completed')
    new_user_identifier = inputs.get('new_user_identifier')

    if not all([resource_id, new_completed is not None, new_user_identifier is not None]):
        raise ValueError("Missing required input fields.")

    url = f"https://dummyjson.com/todos/{resource_id}"
    payload = {
        "completed": new_completed,
        "userId": new_user_identifier
    }

    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}, Response: {response.text}")

    data = response.json()
    
    # DummyJSON returns an empty dict {} on success for PUT updates, not the updated object.
    if not data:
        return None
    
    return data.get('id')
```