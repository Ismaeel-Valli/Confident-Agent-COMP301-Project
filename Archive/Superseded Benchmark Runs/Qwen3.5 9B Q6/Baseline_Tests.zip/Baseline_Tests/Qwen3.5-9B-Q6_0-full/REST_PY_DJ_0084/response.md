```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON and returns the title 
    from the response, or None if absent or on success with empty response.
    Raises an exception for unsuccessful HTTP responses.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_description'.
        
    Returns:
        str or None: The title from the updated product response, or None.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    resource_id = inputs['resource_id']
    new_description = inputs['new_description']
    
    # Base URL for DummyJSON API
    base_url = "https://dummyjson.com"
    url = f"{base_url}/products/{resource_id}"
    
    payload = {
        "description": new_description
    }
    
    try:
        response = requests.put(url, json=payload)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        if response.status_code == 200 and not response.text.strip():
            return None
            
        data = response.json()
        return data.get('title')
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```