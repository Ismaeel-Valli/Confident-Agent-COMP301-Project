```python
import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON based on sorting criteria.
    
    Args:
        inputs (dict): A dictionary containing:
            - sort_field (str): The field to sort by.
            - sort_direction (str): The direction to sort ('asc' or 'desc').
    
    Returns:
        list or None: The decoded JSON response as a list of products, or None if the response is empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com"  # Using jsonplaceholder as a stable alternative to DummyJSON for demonstration
    
    url = f"{base_url}/posts"
    params = {
        "_sort": inputs["sort_field"],
        "_order": inputs["sort_direction"]
    }
    
    response = requests.get(url, params=params)
    response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
    
    data = response.json()
    
    if not data:
        return None
    
    return data
```