import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (product ID) and 'new_category' (new category value).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        Raises: Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_category = inputs.get('new_category')
    
    if not resource_id or new_category is None:
        raise ValueError("Missing required input fields: resource_id and new_category")

    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"category": new_category}
    
    try:
        response = requests.put(url, json=payload)
        
        if response.status_code not in [200, 201]:
            raise Exception(f"Failed to update product. Status code: {response.status_code}, Response: {response.text}")
        
        # For successful updates, DummyJSON typically returns the updated object or an empty response
        data = response.json()
        
        if isinstance(data, dict):
            return data.get('id')
        else:
            # If it's a list or other structure without 'id', return None for successful empty-like response
            return None
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")