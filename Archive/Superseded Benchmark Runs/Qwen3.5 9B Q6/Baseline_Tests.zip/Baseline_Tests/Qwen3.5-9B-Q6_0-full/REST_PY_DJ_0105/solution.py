import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API with provided price and title.
    
    Args:
        inputs (dict): Dictionary containing 'new_price' and 'new_title'.
        
    Returns:
        int or None: The ID of the created product, or None if response is empty/successful without ID.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "price": inputs["new_price"],
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to submit product. Status code: {response.status_code}")
    
    data = response.json()
    
    # Check for 'id' in the response
    if "id" in data and data["id"] is not None:
        return data["id"]
    elif data == {}:
        return None
    else:
        # If id is present but None, or other unexpected structure
        return None