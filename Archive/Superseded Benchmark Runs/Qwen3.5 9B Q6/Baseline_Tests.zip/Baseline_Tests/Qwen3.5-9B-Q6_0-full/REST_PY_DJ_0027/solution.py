import requests

def solve(inputs):
    """
    Deletes a product by identifier from DummyJSON and returns the response's id value,
    or None if that attribute is absent or for a successful empty response.
    Raises an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (product identifier).
        
    Returns:
        str or None: The ID from the response, or None if absent or empty response.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON delete endpoint for products
    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.delete(url)
        
        if response.status_code != 200:
            raise Exception(f"Failed to delete product. Status code: {response.status_code}")
            
        # Check if response is empty (no content)
        if not response.text.strip():
            return None
            
        # Parse JSON response
        data = response.json()
        
        # Return id if present, otherwise None
        return data.get('id')
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"HTTP request failed: {str(e)}")