```python
import requests

def solve(inputs):
    """
    Deletes a label from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - name (str): The name of the label to delete.
            - credential (str): The caller-supplied credential (e.g., token or Bearer token).
    
    Returns:
        int: The successful HTTP status code (typically 204 No Content).
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    name = inputs["name"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/labels/{name}"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    response = requests.delete(url, headers=headers)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to delete label. Status code: {response.status_code}, Response: {response.text}")
    
    return response.status_code
```