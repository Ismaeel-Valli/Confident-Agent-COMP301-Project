import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API.
    
    Args:
        inputs (dict): Contains 'new_title' for the product title.
        
    Returns:
        dict or None: Decoded JSON response if successful, None otherwise.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"  # Using jsonplaceholder as a realistic mock for DummyJSON behavior
    
    url = f"{base_url}/posts"
    
    payload = {
        "title": inputs['new_title'],
        "body": "",
        "userId": 1
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code == 201:
        return None
    elif response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Failed to submit product. Status code: {response.status_code}, Response: {response.text}")