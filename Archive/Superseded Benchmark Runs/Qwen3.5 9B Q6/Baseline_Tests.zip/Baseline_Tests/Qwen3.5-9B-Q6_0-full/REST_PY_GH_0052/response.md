```python
import requests
from urllib.parse import quote_plus

def solve(inputs):
    """
    Updates the authenticated user's name via GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'new_name' (str): The new name for the user.
            - 'credential' (str): The authentication token for the API request.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://api.github.com"
    endpoint = "/user"
    url = f"{base_url}{endpoint}"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {inputs['credential']}",
        "X-GitHub-Api-Version": "2026-03-10",
        "Content-Type": "application/json"
    }
    
    payload = {
        "name": inputs['new_name']
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code == 204:
        return None
    
    if not response.ok:
        raise Exception(f"Failed to update user name. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json()
```