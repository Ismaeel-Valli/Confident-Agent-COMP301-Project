import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'resource_id': Identifier of the todo (int)
            - 'new_todo': Value for the todo attribute (str)
    
    Returns:
        dict or None: The decoded JSON response if successful, None otherwise.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_todo = inputs['new_todo']
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    payload = {"todo": new_todo}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 204:
        return None
    else:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}, Response: {response.text}")