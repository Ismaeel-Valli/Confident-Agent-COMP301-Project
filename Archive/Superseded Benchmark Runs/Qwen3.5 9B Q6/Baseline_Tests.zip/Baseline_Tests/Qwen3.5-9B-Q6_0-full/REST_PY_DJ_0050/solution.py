import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the user
            - new_lastName (str): New value for the last name attribute
    
    Returns:
        None if successful (empty response), otherwise raises an exception.
    """
    # Base URL for DummyJSON API
    base_url = "https://dummyjson.com"
    
    # Extract inputs
    resource_id = inputs.get('resource_id')
    new_lastName = inputs.get('new_lastName')
    
    if not resource_id or new_lastName is None:
        raise ValueError("Missing required inputs: resource_id and new_lastName")
    
    # Construct the update payload
    payload = {
        "lastName": new_lastName
    }
    
    # Make PATCH request to update user
    response = requests.patch(
        f"{base_url}/users/{resource_id}",
        json=payload,
        headers={"Content-Type": "application/json"}
    )
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Return None for successful empty response
    if response.status_code == 204:
        return None
    
    # Return decoded JSON response for other success codes (e.g., 200)
    return response.json()