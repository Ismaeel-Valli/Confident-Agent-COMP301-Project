import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip.
    
    Returns:
        list or None: The decoded JSON response as a list of posts, or None if the response is empty.
    
    Raises:
        requests.exceptions.HTTPError: If the HTTP response status code indicates an error.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    params = {
        "_limit": inputs["result_limit"],
        "_skip": inputs["results_to_skip"]
    }
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None if the response is empty
        if not data:
            return None
        
        return data
    
    except requests.exceptions.HTTPError as http_err:
        raise http_err
    except Exception as err:
        # In case of any other unexpected error, re-raise it to be handled by the caller
        raise RuntimeError(f"An error occurred: {str(err)}") from err