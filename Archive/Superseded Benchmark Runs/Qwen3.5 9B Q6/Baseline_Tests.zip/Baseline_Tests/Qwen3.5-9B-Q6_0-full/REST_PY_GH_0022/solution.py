import requests
from urllib.parse import quote

def solve(inputs):
    """
    Updates a GitHub issue using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository.
            - issue_number (int): The issue number to update.
            - new_title (str): The new title for the issue.
            - credential (dict): A dictionary containing 'token' and optionally 'username'.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    new_title = inputs["new_title"]
    credential = inputs["credential"]

    # Construct the URL for updating an issue
    url = f"https://api.github.com/repos/{quote(owner)}/{quote(repo)}/issues/{issue_number}"

    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10",
        "Authorization": f"Bearer {credential['token']}"
    }

    # Prepare the payload
    data = {
        "title": new_title
    }

    try:
        response = requests.put(url, headers=headers, json=data)
        
        if response.status_code == 200 or response.status_code == 201:
            return response.json()
        elif response.status_code == 204:
            return None
        else:
            raise Exception(f"Failed to update issue. Status code: {response.status_code}, Response: {response.text}")

    except requests.exceptions.RequestException as e:
        raise Exception(f"A network error occurred: {str(e)}")