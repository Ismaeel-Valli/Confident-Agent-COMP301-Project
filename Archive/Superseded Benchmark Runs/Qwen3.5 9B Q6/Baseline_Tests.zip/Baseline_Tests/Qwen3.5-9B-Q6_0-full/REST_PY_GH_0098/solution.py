import requests

def solve(inputs):
    """
    Lists followers of a GitHub user using the GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - username (str): The handle for the GitHub user account.
            - page_size (int): The number of results per page (max 100).
            - credential (str): The caller-supplied credential (e.g., token or Bearer token).
    
    Returns:
        list or None: A list of decoded JSON response objects for followers, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    username = inputs["username"]
    page_size = inputs["page_size"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/users/{username}/followers"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    params = {
        "per_page": page_size
    }
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch followers for user '{username}': HTTP {response.status_code}")
    
    data = response.json()
    
    return None if not data else data