```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON and returns the title 
    from the response, or None if absent or on successful empty response.
    Raises an exception for unsuccessful HTTP responses.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_price'.
        
    Returns:
        str or None: The title of the updated product, or None.
        
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_price = inputs['new_price']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    data = {"price": new_price}
    
    try:
        response = requests.put(url, json=data)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        if response.status_code == 204:
            return None
        
        result = response.json()
        return result.get('title')
    
    except requests.RequestException as e:
        raise e
```