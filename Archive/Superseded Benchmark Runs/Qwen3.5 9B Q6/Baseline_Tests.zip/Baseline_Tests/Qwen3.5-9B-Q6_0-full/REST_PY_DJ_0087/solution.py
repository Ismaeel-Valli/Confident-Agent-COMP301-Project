import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_age' (new age value).
        
    Returns:
        int or None: The response's id value if present, otherwise None for successful empty response.
        Raises: Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_age = inputs['new_age']
    
    # Base URL for DummyJSON API
    base_url = "https://dummyjson.com"
    
    try:
        # Prepare the update payload
        payload = {
            "age": new_age
        }
        
        # Make PATCH request to update user
        response = requests.patch(
            f"{base_url}/users/{resource_id}",
            json=payload
        )
        
        # Raise exception for unsuccessful HTTP responses
        response.raise_for_status()
        
        # Check if response is empty (successful but no content)
        if not response.text:
            return None
        
        # Parse JSON response
        data = response.json()
        
        # Return the id from response if present, otherwise None
        return data.get('id')
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")