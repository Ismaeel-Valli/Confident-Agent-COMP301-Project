import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the user.
            - new_username (str): New value for the username attribute.
    
    Returns:
        dict or None: The decoded JSON response if successful (empty body returns None).
                      Raises an exception on unsuccessful HTTP response.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    new_username = inputs.get('new_username')
    
    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {
        "username": new_username
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user. Status code: {response.status_code}, Response: {response.text}")
    
    return None