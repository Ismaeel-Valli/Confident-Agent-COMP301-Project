```python
import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    new_title = inputs['new_title']
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    data = {"title": new_title}
    
    response = requests.patch(url, json=data)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update post. Status code: {response.status_code}")
    
    if response.text == "":
        return None
    
    response_data = response.json()
    return response_data.get('id')
```