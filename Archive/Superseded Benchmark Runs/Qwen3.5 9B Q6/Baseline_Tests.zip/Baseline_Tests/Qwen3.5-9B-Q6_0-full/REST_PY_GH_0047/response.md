```python
import requests

def solve(inputs):
    """
    Deletes a GitHub release using the provided credentials and repository details.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository.
            - 'release_id' (int): The unique identifier of the release to delete.
            - 'credential' (str): The authentication token for the API request.
    
    Returns:
        int: The successful HTTP status code (204 No Content).
    
    Raises:
        requests.RequestException: If the HTTP request fails or returns an unsuccessful status code.
    """
    repository_owner = inputs['repository_owner']
    repository_name = inputs['repository_name']
    release_id = inputs['release_id']
    credential = inputs['credential']

    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/releases/{release_id}"
    
    headers = {
        'Authorization': f'token {credential}',
        'Accept': 'application/vnd.github+json'
    }

    response = requests.delete(url, headers=headers)
    response.raise_for_status()
    
    return response.status_code
```