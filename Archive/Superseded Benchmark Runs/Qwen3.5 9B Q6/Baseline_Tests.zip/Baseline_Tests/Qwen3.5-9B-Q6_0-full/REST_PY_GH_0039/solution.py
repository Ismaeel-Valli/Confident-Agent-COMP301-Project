import requests

def solve(inputs):
    """
    Updates a pull request title on GitHub using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository.
            - pull_number (int): The number that identifies the pull request.
            - new_title (str): The new title for the pull request.
            - credential (dict): Caller-supplied credentials containing 'token'.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    pull_number = inputs["pull_number"]
    new_title = inputs["new_title"]
    token = inputs["credential"]["token"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pull_number}"
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    payload = {
        "title": new_title
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update pull request. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json() if response.content else None