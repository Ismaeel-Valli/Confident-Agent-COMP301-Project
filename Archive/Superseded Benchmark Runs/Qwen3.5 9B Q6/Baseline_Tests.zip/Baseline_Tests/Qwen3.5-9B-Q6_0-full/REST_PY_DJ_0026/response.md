```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON and returns the response's id value.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the product.
            - new_title (str): New value for the title attribute.
    
    Returns:
        str or None: The ID from the response if present, otherwise None for a successful empty response.
                     Raises an exception for unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_title = inputs.get('new_title')
    
    # Base URL for DummyJSON API (example)
    base_url = "https://dummyjson.com"
    url = f"{base_url}/products/{resource_id}"
    
    payload = {
        "title": new_title
    }
    
    try:
        response = requests.put(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (status code outside 200-299)
        response.raise_for_status()
        
        # Check if the response is empty (no content)
        if not response.text.strip():
            return None
        
        # Parse the JSON response and extract the 'id' field
        data = response.json()
        return data.get('id')
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```