```python
import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on the provided sort_field.
    
    Args:
        inputs (dict): A dictionary containing 'sort_field' for ordering users.
        
    Returns:
        list or None: The decoded JSON response as a list of users, or None if the response is empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/users"
    
    # Construct the URL with the sort parameter
    params = {
        "_sort": inputs.get("sort_field", "id"),
        "_limit": 10  # Retrieve one page (defaulting to 10 items as per typical API pagination)
    }
    
    url = f"{base_url}{endpoint}"
    
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None if the response is empty
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise SystemExit(e)
```