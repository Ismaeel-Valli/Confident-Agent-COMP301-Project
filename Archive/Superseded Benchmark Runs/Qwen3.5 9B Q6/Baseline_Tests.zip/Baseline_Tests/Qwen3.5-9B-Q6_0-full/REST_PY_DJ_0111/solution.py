import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip.
            - included_fields (str): Comma-separated list of fields to include.
    
    Returns:
        dict or None: Decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    todos_endpoint = f"{base_url}/todos"
    
    params = {
        "_limit": inputs.get("result_limit", 10),
        "_skip": inputs.get("results_to_skip", 0),
        "_fields": inputs.get("included_fields", "userId,title,completed")
    }
    
    response = requests.get(todos_endpoint, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP request failed with status code: {response.status_code}")
    
    data = response.json()
    
    # Return None for an empty successful response
    if not data:
        return None
    
    return data