import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'result_limit' specifying the maximum number of results.
        
    Returns:
        list or None: The decoded JSON response as a list of posts, or None if the response is successfully empty.
        
    Raises:
        requests.exceptions.HTTPError: If the HTTP response status code indicates an error (4xx or 5xx).
    """
    result_limit = inputs.get('result_limit', 10)
    
    # DummyJSON endpoint for posts with a limit parameter
    url = f"https://jsonplaceholder.typicode.com/posts?limit={result_limit}"
    
    try:
        response = requests.get(url)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
            
        return data
        
    except requests.exceptions.HTTPError as http_err:
        raise http_err
    except requests.exceptions.RequestException as err:
        raise RuntimeError(f"An error occurred while fetching data: {err}")