import requests
from urllib.parse import quote

def solve(inputs):
    """
    Updates the description of a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository.
            - 'new_description' (str): The new description for the repository.
            - 'credential' (str): The authentication token or string for the API call.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    owner = inputs['repository_owner']
    repo_name = inputs['repository_name']
    new_description = inputs['new_description']
    credential = inputs['credential']
    
    # Construct the URL for updating repository description
    url = f"https://api.github.com/repos/{quote(owner, safe='')}/{quote(repo_name, safe='')}"
    
    headers = {
        'Authorization': f'token {credential}',
        'Accept': 'application/vnd.github+json'
    }
    
    data = {
        'description': new_description
    }
    
    response = requests.put(url, json=data, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update repository description. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json() if response.content else None