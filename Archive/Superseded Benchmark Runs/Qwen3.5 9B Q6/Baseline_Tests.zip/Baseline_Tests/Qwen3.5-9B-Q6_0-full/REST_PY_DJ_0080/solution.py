import requests

def solve(inputs):
    """
    Updates selected fields of a post on DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_body' (new body content).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        Raises: Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_body = inputs.get('new_body')
    
    # Base URL for DummyJSON API
    base_url = "https://dummyjson.com/posts"
    
    # Prepare the update payload
    payload = {
        "body": new_body
    }
    
    # Send PATCH request to update the post
    response = requests.patch(f"{base_url}/{resource_id}", json=payload)
    
    # Raise exception for unsuccessful HTTP responses
    if not response.ok:
        raise Exception(f"Failed to update post. Status code: {response.status_code}, Response: {response.text}")
    
    # Check if the response is empty (successful but no content)
    if not response.content:
        return None
    
    # Try to extract the id from the response
    try:
        data = response.json()
        # DummyJSON typically returns the updated object directly for PATCH requests on items
        post_id = data.get('id')
        return post_id
    except (ValueError, KeyError):
        # If JSON parsing fails or 'id' is not found in expected structure
        return None