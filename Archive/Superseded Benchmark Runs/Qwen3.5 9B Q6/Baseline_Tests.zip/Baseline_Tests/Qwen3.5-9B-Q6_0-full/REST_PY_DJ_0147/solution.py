import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    new_body = inputs.get('new_body')
    new_title = inputs.get('new_title')
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    payload = {}
    
    if new_body is not None:
        payload['body'] = new_body
    if new_title is not None:
        payload['title'] = new_title
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error occurred: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # DummyJSON returns an empty object {} on successful update
    if not data:
        return None
    
    return data.get('title')