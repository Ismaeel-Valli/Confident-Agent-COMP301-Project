import requests

def solve(inputs):
    """
    Retrieves a product by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with the product identifier.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.RequestException: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/products/{resource_id}"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to retrieve product: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns an empty dict {} for non-existent products (404 is handled by the API returning 200 with empty body in some cases, 
    # but typically we expect 404. However, per instructions to assume resources exist and return None for successful empty response)
    if not data:
        return None
        
    return data