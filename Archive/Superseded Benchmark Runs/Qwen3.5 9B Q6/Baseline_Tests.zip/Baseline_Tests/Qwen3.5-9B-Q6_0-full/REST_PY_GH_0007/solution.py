import requests
from urllib.parse import quote

def solve(inputs):
    """
    Updates the name of a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository.
            - 'new_name' (str): The new name for the repository.
            - 'credential' (str): The authentication token or string.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs['repository_owner']
    repo_name = inputs['repository_name']
    new_name = inputs['new_name']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{quote(owner, safe='')}/{quote(repo_name, safe='')}"
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    payload = {
        "name": new_name
    }
    
    response = requests.patch(url, headers=headers, json=payload)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 204:
        return None
    else:
        try:
            error_response = response.json()
            raise Exception(f"GitHub API Error {response.status_code}: {error_response}")
        except ValueError:
            raise Exception(f"GitHub API Error {response.status_code}: {response.text}")