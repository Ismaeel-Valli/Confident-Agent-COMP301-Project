import requests
from typing import Dict, Any, Optional

def solve(inputs: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Lists repositories for a GitHub user based on the provided inputs.
    
    Parameters:
        inputs (dict): A dictionary containing:
            - 'username' (str): The GitHub username.
            - 'type' (str): The type of repository to filter by ('all', 'owner', or 'member').
            - 'credential' (str): The authentication token or header value for the API request.
    
    Returns:
        Optional[Dict[str, Any]]: The decoded JSON response if successful and non-empty, 
                                  None if the response is an empty list, or raises an exception on failure.
    """
    username = inputs['username']
    repo_type = inputs.get('type', 'all')
    credential = inputs['credential']

    # Construct the API URL for GitHub REST API version 2026-03-10
    base_url = "https://api.github.com"
    url = f"{base_url}/users/{username}/repos"

    # Build headers with the provided credential (assumed to be a Bearer token)
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Add query parameter for repository type if specified and not 'all'
    params = {}
    if repo_type != 'all':
        params['type'] = repo_type

    response = requests.get(url, headers=headers, params=params)

    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()

    data = response.json()

    # Return None for a successful empty response
    if not data:
        return None

    return data