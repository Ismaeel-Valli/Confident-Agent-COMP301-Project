```python
import requests

def solve(inputs):
    """
    Searches for products using the provided search term from DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing 'search_text' key with the search term.
        
    Returns:
        list or None: Decoded JSON response as a list of products, or None if empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/products/search"
    search_text = inputs.get('search_text', '')
    
    params = {
        'q': search_text
    }
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raises HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # DummyJSON returns a list in the 'products' key
        products = data.get('products', [])
        
        if not products:
            return None
            
        return products
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP request failed: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request error occurred: {e}")
    except ValueError as e:
        raise Exception(f"Failed to decode JSON response: {e}")
```