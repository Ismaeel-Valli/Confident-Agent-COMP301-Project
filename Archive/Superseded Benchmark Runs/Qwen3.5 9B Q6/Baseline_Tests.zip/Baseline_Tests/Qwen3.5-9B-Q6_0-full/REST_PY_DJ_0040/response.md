```python
import requests

def solve(inputs):
    """
    Retrieves a todo by identifier from DummyJSON and returns its 'id' value.
    
    Args:
        inputs (dict): Must contain 'resource_id' key with the todo identifier.
        
    Returns:
        int or None: The 'id' of the todo if found, None for successful empty response.
        
    Raises:
        requests.exceptions.HTTPError: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON endpoint to get a specific todo by ID
    url = f"https://jsonplaceholder.typicode.com/todos/{resource_id}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        if response.status_code == 200:
            data = response.json()
            # Check if the response is empty or doesn't have an 'id'
            if not data or 'id' not in data:
                return None
            return data['id']
        else:
            # This should ideally be caught by raise_for_status, but as a fallback
            return None
            
    except requests.exceptions.HTTPError as e:
        raise e
    except Exception:
        # In case of other unexpected errors during request
        raise
```