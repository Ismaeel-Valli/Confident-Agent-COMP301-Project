import requests

def solve(inputs):
    """
    Updates selected fields of a post in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (int): Identifier of the post to update.
            - new_title (str): The new value for the title attribute.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty (successful), 
                      raises an exception on unsuccessful HTTP response.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    resource_id = inputs['resource_id']
    new_title = inputs['new_title']
    
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    payload = {
        "title": new_title
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update post. Status code: {response.status_code}, Response: {response.text}")
    
    if response.content:
        return response.json()
    else:
        return None