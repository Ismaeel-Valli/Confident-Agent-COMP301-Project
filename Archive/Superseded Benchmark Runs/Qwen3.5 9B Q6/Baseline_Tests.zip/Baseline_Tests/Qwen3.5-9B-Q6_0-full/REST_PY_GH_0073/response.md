```python
import requests
import json

def solve(inputs):
    """
    Lists repository contributors from GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - anon (bool or int): Set to 1 or true to include anonymous contributors.
            - credential (str): The caller-supplied credential (e.g., Bearer token).
    
    Returns:
        list or None: A list of contributor objects if there are contributors, 
                      None if the response is successful but empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    anon = inputs.get("anon", False)
    credential = inputs["credential"]
    
    # Construct the API URL for version 2026-03-10
    url = f"https://api.github.com/repos/{owner}/{repo}/contributors"
    
    # Prepare headers with the provided credential
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    # Add query parameter for anonymous contributors if needed
    params = {}
    if anon:
        params["anon"] = True
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch contributors. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response
    if not data:
        return None
    
    return data
```