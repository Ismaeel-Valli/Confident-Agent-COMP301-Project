import requests

def solve(inputs):
    """
    Fetches a specific branch from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'branch' (str): The name of the branch to fetch.
            - 'credential' (str): The authentication token or header value.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    branch = inputs['branch']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/branches/{branch}"
    
    headers = {
        'Accept': 'application/vnd.github+json',
        'Authorization': f'Bearer {credential}'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch branch: HTTP {response.status_code} - {response.text}")
    
    return response.json()