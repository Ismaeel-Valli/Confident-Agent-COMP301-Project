import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON based on pagination inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip (for pagination).
    
    Returns:
        list or None: The decoded JSON response as a list of products, or None if the response is empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    base_url = "https://dummyjson.com/products"
    
    # Construct query parameters for pagination
    params = {
        "skip": inputs.get("results_to_skip", 0),
        "limit": inputs.get("result_limit", 10)
    }
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # DummyJSON returns a list directly in the root for this endpoint
        products = data.get("products", [])
        
        return products if products else None
        
    except requests.RequestException as e:
        raise e