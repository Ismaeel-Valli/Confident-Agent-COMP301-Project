```python
import requests
from urllib.parse import quote_plus

def solve(inputs):
    """
    Creates a new repository for the authenticated user via GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'new_name': str, name of the new repository
            - 'new_description': str, description of the new repository
            - 'credential': dict, containing 'token' and optionally 'host' for authentication
    
    Returns:
        None if successful (empty response), or the decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    # Extract inputs with defaults where appropriate
    new_name = inputs.get('new_name')
    new_description = inputs.get('new_description', '')
    credential = inputs.get('credential', {})
    
    # Determine the base URL (default to GitHub)
    host = credential.get('host', 'https://api.github.com')
    
    # Prepare headers for authentication
    headers = {
        'Authorization': f'token {credential.get("token", "")}',
        'Accept': 'application/vnd.github+json'
    }
    
    # Construct the API endpoint
    url = f"{host}/user/repos"
    
    # Prepare the payload
    payload = {
        'name': new_name,
        'description': new_description
    }
    
    # Make the POST request to create the repository
    response = requests.post(url, headers=headers, json=payload)
    
    # Check for successful HTTP status code (201 Created or 200 OK)
    if response.status_code in [200, 201]:
        return None
    
    # Raise an exception for unsuccessful responses
    response.raise_for_status()
```