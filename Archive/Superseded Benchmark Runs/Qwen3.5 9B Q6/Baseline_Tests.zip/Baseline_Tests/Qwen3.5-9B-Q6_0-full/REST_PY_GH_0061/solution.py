import requests

def solve(inputs):
    """
    Fetches a GitHub user based on the provided username using the specified API version.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The GitHub username.
            - 'credential' (str): The authentication token or Bearer token for the API request.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    username = inputs['username']
    credential = inputs['credential']
    api_version = '2026-03-10'
    
    url = f"https://api.github.com/repos/{username}/repos"  # Placeholder URL; actual user endpoint is /users/{username}
    url = f"https://api.github.com/users/{username}"
    
    headers = {
        'Accept': f'application/vnd.github.{api_version}-preview+json',
        'Authorization': f'token {credential}'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch user data. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json()