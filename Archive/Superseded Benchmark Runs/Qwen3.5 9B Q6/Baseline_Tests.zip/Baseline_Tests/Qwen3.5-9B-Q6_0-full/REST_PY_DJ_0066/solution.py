import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_lastName' (new last name).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        Raises: Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_last_name = inputs.get('new_lastName')
    
    if not resource_id or new_last_name is None:
        raise ValueError("Missing required input fields: resource_id and new_lastName")

    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {"lastName": new_last_name}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user. Status code: {response.status_code}, Response: {response.text}")
    
    # DummyJSON returns a dict with 'id' key on successful PUT for specific resources
    data = response.json()
    
    if isinstance(data, dict) and 'id' in data:
        return data['id']
    elif isinstance(data, dict):
        # If the response is empty or doesn't contain 'id', return None as per requirement
        return None
    else:
        # Fallback for unexpected successful responses
        return None