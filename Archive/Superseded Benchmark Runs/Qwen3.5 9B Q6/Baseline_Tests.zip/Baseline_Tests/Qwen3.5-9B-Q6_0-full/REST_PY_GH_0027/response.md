```python
import requests

def solve(inputs):
    """
    Fetches a specific label from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository.
            - 'name' (str): The name of the label to retrieve.
            - 'credential' (str): The authentication token or string for the API call.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None if the response is empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    repository_owner = inputs['repository_owner']
    repository_name = inputs['repository_name']
    name = inputs['name']
    credential = inputs['credential']

    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/labels/{name}"
    
    headers = {
        'Authorization': f'token {credential}',
        'Accept': 'application/vnd.github+json'
    }

    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to retrieve label. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json()
```