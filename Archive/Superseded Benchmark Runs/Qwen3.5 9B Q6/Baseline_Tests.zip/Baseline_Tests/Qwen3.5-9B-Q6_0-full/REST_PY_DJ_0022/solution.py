import requests

def solve(inputs):
    """
    Deletes a todo by identifier using DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (str) - Identifier of the todo.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.HTTPError: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    response = requests.delete(url)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 404:
        raise Exception(f"Todo with ID {resource_id} not found")
    else:
        response.raise_for_status()
        
    return response.json()