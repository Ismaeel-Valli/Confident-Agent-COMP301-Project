```python
import requests

def solve(inputs):
    """
    Lists stargazers for a given GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git extension).
            - 'credential' (str): The bearer token for authentication.
    
    Returns:
        list or None: A list of stargazer data dictionaries if there are results, 
                      or None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response status code indicates an error.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/stargazers"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch stargazers. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # GitHub API returns an empty list for no stargazers, not None.
    # The requirement says "Return None for a successful empty response".
    if len(data) == 0:
        return None
    
    return data
```