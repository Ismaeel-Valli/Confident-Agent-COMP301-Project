```python
import requests
from urllib.parse import quote

def solve(inputs):
    """
    Creates a fork of a repository on GitHub using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'new_name' (str): The new name for the forked repository.
            - 'credential' (str): The authentication token or username:password string.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs['repository_owner']
    repository_name = inputs['repository_name']
    new_name = inputs['new_name']
    credential = inputs['credential']
    
    # Construct the URL for creating a fork with a custom name
    url = f"https://api.github.com/repos/{quote(repository_owner, safe='')}/{quote(repository_name, safe='')}/forks"
    
    headers = {
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2026-03-10'
    }
    
    # Prepare the payload for renaming the fork
    params = {'name': new_name}
    
    # Determine authentication method
    if ':' in credential:
        username, password = credential.split(':', 1)
        auth = (username, password)
    else:
        auth = ('', credential)  # Token-only authentication
    
    response = requests.post(url, headers=headers, params=params, auth=auth)
    
    if response.status_code != 201 and response.status_code != 302:
        raise Exception(f"Failed to create fork. Status code: {response.status_code}, Response: {response.text}")
    
    # GitHub returns a redirect (302) for successful forks with custom names, 
    # or the JSON object directly (201). We decode if it's JSON.
    if response.headers.get('Content-Type') == 'application/json':
        return response.json()
    
    return None
```