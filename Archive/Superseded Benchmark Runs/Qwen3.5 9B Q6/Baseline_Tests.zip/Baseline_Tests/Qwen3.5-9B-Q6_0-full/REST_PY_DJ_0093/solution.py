import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - included_fields (str): Comma-separated list of fields to include in the response.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://dummyjson.com/products"
    
    # Parse included_fields into a list
    fields_list = [field.strip() for field in inputs["included_fields"].split(",")]
    
    params = {
        "limit": inputs["result_limit"],
        "skip": 0,  # Retrieve one page (first page)
        "select": ",".join(fields_list) if fields_list else None
    }

    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        data = response.json()
        
        # Check if the response is empty (no products found)
        if not data.get("products"):
            return None
            
        return data
    
    except requests.exceptions.RequestException as e:
        raise e