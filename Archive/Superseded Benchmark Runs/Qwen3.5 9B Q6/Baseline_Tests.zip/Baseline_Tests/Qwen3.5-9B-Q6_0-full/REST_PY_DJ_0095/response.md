```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API with provided price and title.
    
    Args:
        inputs (dict): Dictionary containing 'new_price' and 'new_title'.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.exceptions.RequestException: If HTTP response is unsuccessful.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "price": inputs["new_price"],
        "title": inputs["new_title"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code == 201:
            # Successful creation with empty response body
            return None
        elif response.status_code == 200:
            # Successful creation with data in response
            return response.json()
        else:
            raise Exception(f"Failed to create product. Status code: {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"HTTP request failed: {str(e)}")
```