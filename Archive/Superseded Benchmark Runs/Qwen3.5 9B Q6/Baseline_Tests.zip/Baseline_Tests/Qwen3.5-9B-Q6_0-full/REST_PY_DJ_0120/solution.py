import requests

def solve(inputs):
    """
    Updates selected fields of a post on DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_user_identifier' (new user ID).
        
    Returns:
        str or None: The title of the updated post, or None if successful but no title exists.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    new_user_identifier = inputs.get('new_user_identifier')
    
    if not resource_id or new_user_identifier is None:
        raise ValueError("Missing required input fields: resource_id and new_user_identifier")

    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    payload = {
        "userId": new_user_identifier
    }

    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update post. Status code: {response.status_code}, Response: {response.text}")

    data = response.json()
    
    # DummyJSON typically returns the updated object on PUT for this endpoint, 
    # but sometimes might return empty or just status depending on specific version/config.
    # We check if 'title' exists in the returned data.
    if isinstance(data, dict) and 'title' in data:
        return data['title']
    
    # If successful (200) but no title found in response body
    return None