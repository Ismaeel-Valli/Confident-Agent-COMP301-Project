```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the product to update.
            - new_brand (str): The new value for the brand attribute.
            
    Returns:
        dict or None: Decoded JSON response if successful, None for empty success response.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs['resource_id']
    new_brand = inputs['new_brand']
    
    # Base URL for DummyJSON API (assuming standard structure)
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/{resource_id}"
    
    # Prepare the payload with only the field to update
    payload = {
        "brand": new_brand
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.put(url, json=payload, headers=headers)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None if the response is empty (successful but no content)
        if not data:
            return None
            
        return data
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```