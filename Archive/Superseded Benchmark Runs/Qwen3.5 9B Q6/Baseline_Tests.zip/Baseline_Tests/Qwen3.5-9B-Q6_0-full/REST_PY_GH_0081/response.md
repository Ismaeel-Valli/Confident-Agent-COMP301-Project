```python
import requests
import json

def solve(inputs):
    """
    Updates a label in a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - name (str): The name of the label to update.
            - new_color (str): The new color value for the label.
            - credential (str): The caller-supplied credential (e.g., token).
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    name = inputs["name"]
    new_color = inputs["new_color"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/labels/{name}"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    data = {
        "color": new_color
    }

    response = requests.put(url, headers=headers, json=data)

    if response.status_code != 200:
        raise Exception(f"Failed to update label. Status code: {response.status_code}, Response: {response.text}")

    return response.json() if response.content else None
```