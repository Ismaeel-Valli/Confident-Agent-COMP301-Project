```python
import requests

def solve(inputs):
    """
    Deletes a user by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with user identifier.
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful deletion.
        
    Raises:
        requests.exceptions.HTTPError: If the HTTP response status code indicates an error.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON delete endpoint pattern
    url = f"https://dummyjson.com/users/{resource_id}"
    
    try:
        response = requests.delete(url)
        
        # Raise exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if response is empty (successful deletion often returns empty body)
        if not response.text.strip():
            return None
            
        # Try to parse JSON and extract id if present
        try:
            data = response.json()
            return data.get('id')
        except ValueError:
            # If response is not valid JSON but we got a successful status, return None
            return None
            
    except requests.exceptions.HTTPError as e:
        raise e
```