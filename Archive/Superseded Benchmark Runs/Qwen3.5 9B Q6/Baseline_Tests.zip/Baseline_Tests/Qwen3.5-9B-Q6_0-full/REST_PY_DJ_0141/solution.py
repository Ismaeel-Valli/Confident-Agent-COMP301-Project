import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON and returns the title 
    from the response, or None if absent or on empty success. Raises an exception 
    for unsuccessful HTTP responses.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_category'.
        
    Returns:
        str or None: The 'title' from the updated product response, or None.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    resource_id = inputs['resource_id']
    new_category = inputs['new_category']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    
    payload = {
        "category": new_category
    }
    
    try:
        response = requests.put(url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 204:
            return None
            
        data = response.json()
        return data.get('title')
        
    except requests.exceptions.HTTPError as e:
        raise RuntimeError(f"Failed to update product: {e}") from e
    except requests.RequestException as e:
        raise RuntimeError(f"Request failed: {e}") from e