```python
import requests

def solve(inputs):
    """
    Checks if a person is followed by the authenticated user via GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The handle for the GitHub user account to check.
            - 'credential' (str): The caller-supplied credential (e.g., Bearer token).
    
    Returns:
        int: The successful HTTP status code (typically 204 No Content if followed, 
             or 302 Found with a Location header pointing to the follow URL if not followed).
             Note: Based on GitHub API behavior for GET /users/{username}/following/{target},
             it returns 204 if followed and 302 if not. However, the problem asks to return 
             the successful HTTP status code. We'll interpret "successful" as the response 
             indicating the state exists (204) or redirecting appropriately (302). 
             But strictly speaking, 204 is the direct confirmation. Let's assume we want 
             the status code from a successful request that confirms the relationship.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    username = inputs['username']
    credential = inputs['credential']
    
    # GitHub API endpoint to check if authenticated user follows {username}
    url = f"https://api.github.com/users/{username}/following/me"
    
    headers = {
        'Authorization': f'Bearer {credential}',
        'Accept': 'application/vnd.github+json'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code >= 400:
        raise Exception(f"GitHub API request failed with status code: {response.status_code}")
    
    # If followed, GitHub returns 204 No Content.
    # If not followed, it returns 302 Found with a Location header to the follow URL.
    # Both are considered successful HTTP responses in this context as per problem statement 
    # ("successful HTTP status code"), but typically 204 is the direct confirmation.
    # We return the actual status code from the successful request.
    return response.status_code
```