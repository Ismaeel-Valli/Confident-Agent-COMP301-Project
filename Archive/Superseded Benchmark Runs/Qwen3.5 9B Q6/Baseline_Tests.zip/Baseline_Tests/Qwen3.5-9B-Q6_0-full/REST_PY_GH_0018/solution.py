import requests

def solve(inputs):
    """
    Fetches a specific issue comment from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository.
            - comment_id (int): The unique identifier of the comment.
            - credential (str): The caller-supplied authentication token (Bearer token).
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        requests.RequestException: If the HTTP request fails with an unsuccessful status code.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    comment_id = inputs["comment_id"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/issues/comments/{comment_id}"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to fetch issue comment. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json()