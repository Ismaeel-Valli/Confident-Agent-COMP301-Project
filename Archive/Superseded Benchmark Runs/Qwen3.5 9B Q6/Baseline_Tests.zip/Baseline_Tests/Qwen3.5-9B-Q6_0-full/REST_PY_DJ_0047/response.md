```python
import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    
    try:
        response = requests.delete(f"https://dummyjson.com/products/{resource_id}")
        
        if response.status_code != 200:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
        
        data = response.json()
        
        if data.get('title') is not None:
            return data['title']
        else:
            return None
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```