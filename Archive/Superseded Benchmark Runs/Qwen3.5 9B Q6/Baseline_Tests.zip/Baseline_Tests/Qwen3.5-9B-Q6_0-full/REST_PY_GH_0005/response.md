```python
import requests
from urllib.parse import quote

def solve(inputs):
    """
    Creates a repository in a GitHub organization using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization': str, the name of the organization.
            - 'new_name': str, the desired name for the new repository.
            - 'credential': dict, containing authentication details (e.g., token).
    
    Returns:
        None if the response is empty and successful.
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    org = inputs['organization']
    repo_name = inputs['new_name']
    credential = inputs['credential']
    
    # Construct the API URL for creating a repository in an organization
    base_url = "https://api.github.com"
    url = f"{base_url}/orgs/{quote(org)}/repos"
    
    # Prepare headers with authentication
    headers = {
        'Authorization': f"token {credential.get('token', '')}",
        'Accept': 'application/vnd.github+json'
    }
    
    # Payload for creating the repository
    payload = {
        "name": repo_name,
        "private": False  # Default to public; adjust if private is required
    }
    
    try:
        response = requests.post(url, headers=headers, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx and 5xx)
        response.raise_for_status()
        
        # Return None for a successful empty response
        if not response.text.strip():
            return None
        
        # Decode and return the JSON response
        return response.json()
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Failed to create repository: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```