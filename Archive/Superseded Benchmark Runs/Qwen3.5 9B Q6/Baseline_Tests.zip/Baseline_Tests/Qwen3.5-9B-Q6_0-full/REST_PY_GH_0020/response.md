```python
import requests

def solve(inputs):
    """
    Deletes a specific issue comment in a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository.
            - comment_id (int): The unique identifier of the comment to delete.
            - credential (str): The authentication token or string for the API request.
    
    Returns:
        int: The successful HTTP status code (typically 204).
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    comment_id = inputs["comment_id"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/issues/comments/{comment_id}"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    response = requests.delete(url, headers=headers)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to delete comment. Status code: {response.status_code}, Response: {response.text}")
    
    return response.status_code
```