import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (int): Identifier of the product.
            - new_price (float or int): New value for the price attribute.
    
    Returns:
        None if the response is successful and empty.
        The decoded JSON response otherwise (though DummyJSON typically returns 204 No Content).
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs['resource_id']
    new_price = inputs['new_price']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"price": new_price}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 204:
        return None
    
    response.raise_for_status()
    return response.json()