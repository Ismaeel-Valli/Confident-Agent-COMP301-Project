```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API using provided inputs.
    
    Args:
        inputs (dict): Contains 'new_description' and 'new_title'.
        
    Returns:
        str or None: The title from the response, or None if successful with empty response.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "description": inputs["new_description"],
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to submit product. Status code: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns the created product in the response body on success
    if "title" in data and data["title"]:
        return data["title"]
    
    return None
```