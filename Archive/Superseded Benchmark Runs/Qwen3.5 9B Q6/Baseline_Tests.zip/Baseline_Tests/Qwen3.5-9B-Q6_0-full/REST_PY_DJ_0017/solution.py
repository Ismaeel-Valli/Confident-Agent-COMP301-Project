import requests

def solve(inputs):
    """
    Searches posts using a search term from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'search_text' key with the search term.
        
    Returns:
        list or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/posts/search"
    search_text = inputs.get('search_text', '')
    
    params = {
        'q': search_text
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP request failed with status code: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns posts in the 'posts' key of the response
    return data.get('posts')