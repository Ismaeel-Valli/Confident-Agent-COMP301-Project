import requests

def solve(inputs):
    resource_id = inputs.get('resource_id')
    url = f"https://dummyjson.com/posts/{resource_id}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        if response.status_code == 200:
            data = response.json()
            # Check if the response is empty (e.g., no 'id' key or explicitly empty structure)
            if not data or 'id' not in data:
                return None
            return data.get('id')
        else:
            raise Exception(f"HTTP error occurred: {response.status_code}")
    
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")