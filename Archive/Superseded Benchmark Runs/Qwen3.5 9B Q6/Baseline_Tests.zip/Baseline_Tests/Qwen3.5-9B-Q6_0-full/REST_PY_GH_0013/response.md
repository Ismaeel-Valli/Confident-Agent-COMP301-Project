```python
import requests
import json

def solve(inputs):
    """
    Lists contributors for a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The Bearer token or OAuth token for authentication.
    
    Returns:
        list | None: A list of contributor dictionaries if contributors exist, 
                     None if the response is successful but empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails (non-2xx status).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    token = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/contributors"
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise requests.RequestException(f"GitHub API request failed with status code {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response as per instructions
    return data if data else None
```