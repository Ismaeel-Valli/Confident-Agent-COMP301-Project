import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on included_fields.
    
    Args:
        inputs (dict): A dictionary containing 'included_fields' as a comma-separated string.
        
    Returns:
        dict or None: The decoded JSON response, or None if the response is empty but successful.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    included_fields = inputs.get('included_fields', '')
    
    # Construct the URL with query parameters for fields
    url = "https://jsonplaceholder.typicode.com/posts"
    params = {}
    
    if included_fields:
        params['fields'] = included_fields
    
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # If the response is an empty list, return None as per requirement
        if isinstance(data, list) and len(data) == 0:
            return None
            
        return data
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")