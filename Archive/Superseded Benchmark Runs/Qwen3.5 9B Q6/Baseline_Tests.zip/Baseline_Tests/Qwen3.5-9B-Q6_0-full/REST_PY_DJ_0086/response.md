```python
import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on pagination inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip (offset).
    
    Returns:
        list or None: The decoded JSON response as a list of users, or None if the response is empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://dummyjson.com/users"
    
    params = {
        "limit": inputs.get("result_limit", 20),
        "skip": inputs.get("results_to_skip", 0)
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP request failed with status code: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns a list directly for the /users endpoint
    users = data.get("users", [])
    
    return users if users else None
```