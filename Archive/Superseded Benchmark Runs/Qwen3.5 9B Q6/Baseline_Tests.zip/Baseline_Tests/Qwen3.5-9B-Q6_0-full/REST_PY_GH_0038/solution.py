import requests

def solve(inputs):
    """
    Fetches a pull request from the GitHub REST API (version 2026-03-10).
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - pull_number (int): The number identifying the pull request.
            - credential (str): The caller-supplied credential (e.g., token or Bearer token).
    
    Returns:
        dict or None: The decoded JSON response, or None if the response is empty but successful.
    
    Raises:
        requests.exceptions.HTTPError: If the HTTP response status code indicates an error.
        Exception: For other unexpected errors during execution.
    """
    try:
        owner = inputs["repository_owner"]
        repo = inputs["repository_name"]
        pr_number = inputs["pull_number"]
        credential = inputs["credential"]

        # Construct the URL for the specific pull request
        url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}"

        headers = {
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {credential}",
            "X-GitHub-Api-Version": "2026-03-10"
        }

        response = requests.get(url, headers=headers)

        # Raise an exception for unsuccessful HTTP responses
        response.raise_for_status()

        # Decode the JSON response
        data = response.json()

        # Return None for a successful empty response (though GitHub PRs rarely return empty objects)
        if not data:
            return None

        return data

    except requests.exceptions.HTTPError as e:
        raise e
    except Exception as e:
        raise Exception(f"An error occurred while fetching the pull request: {e}")