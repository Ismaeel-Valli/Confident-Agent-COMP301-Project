import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API with provided price and title.
    
    Args:
        inputs (dict): Dictionary containing 'new_price' and 'new_title'.
        
    Returns:
        str or None: The title from the response if present, otherwise None for success.
        Raises: Exception for unsuccessful HTTP responses.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "price": inputs["new_price"],
        "title": inputs["new_title"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code != 200:
            raise Exception(f"Failed to submit product. Status code: {response.status_code}")
        
        # For successful submission, DummyJSON typically returns an empty body or minimal data
        # The requirement states to return None for a successful empty response
        if not response.text.strip():
            return None
            
        data = response.json()
        
        # Return the title from the response if it exists
        if "title" in data:
            return data["title"]
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")

# Do not execute the function here