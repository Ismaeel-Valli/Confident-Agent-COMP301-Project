```python
import requests
import json

def solve(inputs):
    """
    Lists milestones for a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The authentication token or bearer token for the API.
    
    Returns:
        list | None: A list of milestone objects if milestones exist, otherwise None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code outside 2xx range).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/milestones"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"GitHub API request failed with status code: {response.status_code}. Response body: {response.text}")
    
    data = response.json()
    
    # According to requirements: Return None for a successful empty response.
    if not data:
        return None
    
    return data
```