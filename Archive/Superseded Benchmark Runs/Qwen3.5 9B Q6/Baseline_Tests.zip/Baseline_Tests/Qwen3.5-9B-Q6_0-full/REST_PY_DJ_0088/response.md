```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API with provided age and first name.
    
    Args:
        inputs (dict): Dictionary containing 'new_age' and 'new_firstName'.
        
    Returns:
        int or None: The ID of the created user, or None if response is empty.
        
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    base_url = "https://dummyjson.com/users/add"
    
    payload = {
        "age": inputs.get("new_age"),
        "firstName": inputs.get("new_firstName")
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Check if the response content is empty
        if not response.text.strip():
            return None
            
        # Parse JSON and extract id
        data = response.json()
        return data.get("id")
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```