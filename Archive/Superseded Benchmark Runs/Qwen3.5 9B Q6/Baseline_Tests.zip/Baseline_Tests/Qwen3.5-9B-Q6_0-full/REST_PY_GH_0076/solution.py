import requests

def solve(inputs):
    """
    Creates an issue in a GitHub repository using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - new_body (str): The body content for the issue.
            - new_title (str): The title for the issue.
            - credential (str): The authentication token or bearer token.
    
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    new_body = inputs["new_body"]
    new_title = inputs["new_title"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/issues"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    payload = {
        "title": new_title,
        "body": new_body
    }

    response = requests.post(url, headers=headers, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create issue. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json()