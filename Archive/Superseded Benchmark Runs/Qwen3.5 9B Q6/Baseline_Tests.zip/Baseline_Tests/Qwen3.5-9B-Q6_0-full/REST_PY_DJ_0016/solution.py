import requests

def solve(inputs):
    """
    Deletes a post by identifier using DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (post identifier).
        
    Returns:
        None if deletion is successful (empty response), otherwise raises an exception.
        
    Raises:
        requests.HTTPError: If the HTTP response indicates failure.
    """
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/posts/{resource_id}"
    
    try:
        response = requests.delete(url)
        response.raise_for_status()
        
        if response.status_code == 200 and not response.text.strip():
            return None
            
        # If we get here, it's a successful HTTP status but with content (unexpected for DELETE on DummyJSON)
        # We'll treat non-empty body as an error based on the requirement "Return None for a successful empty response"
        raise Exception(f"Unexpected response body: {response.text}")
        
    except requests.HTTPError as e:
        raise e