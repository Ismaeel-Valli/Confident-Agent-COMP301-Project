import requests
import json

def solve(inputs):
    """
    Fetches an organization from the GitHub REST API (version 2026-03-10).
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The name of the organization.
            - 'credential' (str): The authentication token or header value.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is an empty list/object.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    org_name = inputs['organization']
    credential = inputs['credential']
    
    url = f"https://api.github.com/orgs/{org_name}"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch organization '{org_name}': HTTP {response.status_code}")
    
    data = response.json()
    
    # Return None for a successful empty response (e.g., empty list or object)
    if not data:
        return None
    
    return data