```python
import requests

def solve(inputs):
    """
    Checks if a repository is starred by the authenticated user via GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The Bearer token for authentication.
    
    Returns:
        int: The successful HTTP status code (204 No Content if starred, 302 Found otherwise).
    
    Raises:
        requests.exceptions.RequestException: If the request fails or returns an unsuccessful status.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    token = inputs['credential']
    
    url = f"https://api.github.com/user/starred/{owner}/{repo}"
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 204:
        return 204
    elif response.status_code == 302:
        # Redirect to the starred URL indicates not starred
        return 302
    else:
        raise requests.exceptions.RequestException(f"Failed to check star status. Status code: {response.status_code}")
```