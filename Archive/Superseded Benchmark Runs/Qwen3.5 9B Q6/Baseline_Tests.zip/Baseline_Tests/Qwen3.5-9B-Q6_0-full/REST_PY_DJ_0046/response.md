```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON and returns the title value.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the product.
            - new_title (str): New value for the title attribute.
    
    Returns:
        str or None: The updated title if present, otherwise None.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    new_title = inputs.get('new_title')

    if not resource_id or new_title is None:
        raise ValueError("Missing required input fields: resource_id and new_title.")

    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"title": new_title}

    response = requests.put(url, json=payload)
    response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)

    if response.status_code == 204:
        return None

    try:
        data = response.json()
        return data.get('title')
    except ValueError:
        raise requests.exceptions.RequestException("Failed to parse JSON response.")
```