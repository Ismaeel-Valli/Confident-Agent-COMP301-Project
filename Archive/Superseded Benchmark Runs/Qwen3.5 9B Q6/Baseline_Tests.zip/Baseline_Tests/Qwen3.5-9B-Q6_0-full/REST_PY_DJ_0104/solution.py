import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (product ID) and 'new_price'.
        
    Returns:
        int or None: The updated product's ID if present in response, 
                     None for successful empty response.
                     
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_price = inputs['new_price']
    
    # DummyJSON API endpoint for updating a product
    url = f"https://dummyjson.com/products/{resource_id}"
    
    payload = {
        "price": new_price
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product. Status code: {response.status_code}")
    
    data = response.json()
    
    # Check if the response contains an 'id' field (successful update with data)
    if 'id' in data:
        return data['id']
    
    # Return None for successful empty response
    return None