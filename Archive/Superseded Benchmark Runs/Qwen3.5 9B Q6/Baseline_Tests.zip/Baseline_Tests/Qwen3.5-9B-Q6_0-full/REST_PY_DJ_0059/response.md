```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the todo.
            - new_completed (bool): New value for the completed attribute.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty but successful.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    new_completed = inputs.get('new_completed')

    if not resource_id or new_completed is None:
        raise ValueError("Missing required inputs: 'resource_id' and 'new_completed'.")

    url = f"https://jsonplaceholder.typicode.com/todos/{resource_id}"
    
    payload = {
        "completed": new_completed
    }

    response = requests.put(url, json=payload)
    response.raise_for_status()

    if response.status_code == 204:
        return None
    
    try:
        return response.json()
    except ValueError:
        raise RuntimeError(f"Failed to decode JSON response for status code {response.status_code}")
```