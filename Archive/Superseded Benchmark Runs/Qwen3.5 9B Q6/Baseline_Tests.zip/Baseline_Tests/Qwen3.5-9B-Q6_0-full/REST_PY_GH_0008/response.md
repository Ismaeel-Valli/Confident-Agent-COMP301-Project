```python
import requests

def solve(inputs):
    """
    Deletes a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The authentication token or bearer token.
    
    Returns:
        int: The successful HTTP status code (typically 204 No Content).
    
    Raises:
        requests.exceptions.RequestException: If the request fails or returns an unsuccessful status code.
    """
    owner = inputs['repository_owner']
    repo_name = inputs['repository_name']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo_name}"
    headers = {
        'Accept': 'application/vnd.github+json',
        'Authorization': f'Bearer {credential}'
    }
    
    response = requests.delete(url, headers=headers)
    
    if response.status_code >= 400:
        raise requests.exceptions.RequestException(f"Failed to delete repository. Status code: {response.status_code}, Response: {response.text}")
    
    return response.status_code
```