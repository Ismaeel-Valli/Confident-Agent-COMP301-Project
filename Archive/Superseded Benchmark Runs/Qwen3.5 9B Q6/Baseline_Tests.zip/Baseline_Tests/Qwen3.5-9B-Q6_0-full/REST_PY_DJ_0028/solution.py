import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API using the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'new_title' for the product title.
        
    Returns:
        int or None: The ID of the created product, or None if successful with empty response.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "title": inputs.get("new_title")
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code == 201:
            # Check if the response body is empty or lacks an 'id' field
            data = response.json()
            if not data or 'id' not in data:
                return None
            return data['id']
        elif response.status_code == 400:
            # Bad request, might be due to missing fields but per instructions assume resources exist
            # We'll treat non-201 as unsuccessful for this specific task logic unless it's a known success code
            raise Exception(f"Failed to create product. Status Code: {response.status_code}")
        else:
            raise Exception(f"Failed to create product. Status Code: {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        raise e