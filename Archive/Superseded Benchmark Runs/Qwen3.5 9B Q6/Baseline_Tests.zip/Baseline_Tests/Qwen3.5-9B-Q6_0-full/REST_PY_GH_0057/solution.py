import requests
import json

def solve(inputs):
    """
    Creates a new repository for the authenticated user using GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'new_name' (str): The name for the new repository.
            - 'credential' (str): The authentication token or header value.
    
    Returns:
        dict or None: Decoded JSON response if successful, None for empty success response.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    new_name = inputs['new_name']
    credential = inputs['credential']
    
    url = "https://api.github.com/user/repos"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    payload = {
        "name": new_name
    }
    
    response = requests.post(url, headers=headers, json=payload)
    
    if response.status_code == 201:
        return None
    elif response.status_code == 202:
        return response.json()
    else:
        raise Exception(f"Failed to create repository. Status code: {response.status_code}, Response: {response.text}")