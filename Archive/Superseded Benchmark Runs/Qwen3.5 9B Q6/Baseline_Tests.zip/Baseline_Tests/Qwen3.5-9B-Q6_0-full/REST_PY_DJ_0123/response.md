```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the product.
            - new_category (str): New value for the category attribute.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty (successful).
    
    Raises:
        requests.exceptions.HTTPError: If the HTTP response status code indicates failure.
    """
    resource_id = inputs['resource_id']
    new_category = inputs['new_category']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    data = {
        "category": new_category
    }
    
    response = requests.put(url, json=data)
    
    if response.status_code != 200:
        raise requests.exceptions.HTTPError(f"HTTP {response.status_code}: {response.text}")
    
    return response.json() if response.content else None
```