import requests
from urllib.parse import quote_plus

def solve(inputs):
    """
    Creates a new repository in a GitHub organization using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization': str, The name of the organization.
            - 'new_name': str, The desired name for the new repository.
            - 'new_description': str, The description for the new repository.
            - 'credential': dict, Contains authentication details (e.g., token).
    
    Returns:
        None if the response is empty (success), or the decoded JSON response.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    # Extract inputs
    org_name = inputs['organization']
    repo_name = inputs['new_name']
    description = inputs['new_description']
    credential = inputs['credential']
    
    # Construct the API URL for creating a repository in an organization
    # GitHub API version 2026-03-10 (hypothetical future version, structure remains similar)
    base_url = "https://api.github.com"
    url = f"{base_url}/orgs/{quote_plus(org_name)}/repos"
    
    # Prepare headers with authentication
    # Assuming 'credential' contains a token under the key 'token' or similar. 
    # Adjusting based on common patterns; if structure differs, this might need adaptation.
    auth_token = credential.get('token') or credential.get('auth_token')
    
    if not auth_token:
        raise ValueError("No valid authentication token found in inputs['credential'].")

    headers = {
        "Authorization": f"Bearer {auth_token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10",
        "Content-Type": "application/json"
    }

    # Prepare the payload for creating the repository
    payload = {
        "name": repo_name,
        "description": description
    }

    try:
        response = requests.post(url, headers=headers, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx and 5xx)
        response.raise_for_status()
        
        # Return None for a successful empty response
        if not response.text.strip():
            return None
        
        # Return the decoded JSON response
        return response.json()
    
    except requests.exceptions.HTTPError as e:
        # Raise an exception for unsuccessful HTTP responses
        raise Exception(f"Failed to create repository. Status code: {response.status_code}, Response: {e.response.text}") from e
    except requests.exceptions.RequestException as e:
        raise Exception(f"A request error occurred: {str(e)}") from e