import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'page' and optionally 'limit'.
                       Example: {'page': 1, 'limit': 5}
    
    Returns:
        list or None: The decoded JSON response as a list of posts, or None if the response is empty.
    
    Raises:
        requests.exceptions.HTTPError: If the HTTP response status code indicates an error (4xx or 5xx).
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    # Extract parameters from inputs with defaults
    page = inputs.get('page', 1)
    limit = inputs.get('limit', 10)
    
    params = {
        'page': page,
        'limit': limit
    }
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raises HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None if the response is empty (though unlikely with valid pagination)
        if not data:
            return None
            
        return data
        
    except requests.exceptions.HTTPError as e:
        raise e
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"An error occurred while fetching data: {e}")