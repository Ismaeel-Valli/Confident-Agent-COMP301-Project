import requests

def solve(inputs):
    """
    Lists watchers for a GitHub repository using the specified API version.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The caller-supplied credential (e.g., token or Bearer token).
    
    Returns:
        list | None: Decoded JSON response as a list, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    repository_owner = inputs['repository_owner']
    repository_name = inputs['repository_name']
    credential = inputs['credential']

    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/network/updates"
    
    # Note: As of current GitHub API documentation, there is no direct "watchers" endpoint.
    # The closest equivalent for listing watchers is via the /repos/{owner}/{repo}/subscribers endpoint,
    # but that lists subscribers, not watchers. However, based on common interpretation and recent updates,
    # we assume the user wants the list of watchers which is available at:
    # https://api.github.com/repos/{owner}/{repo}/watchers
    
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/watchers"

    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }

    response = requests.get(url, headers=headers)

    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"GitHub API request failed with status code: {response.status_code}")

    data = response.json()

    # Return None for a successful empty response
    if not data:
        return None

    return data