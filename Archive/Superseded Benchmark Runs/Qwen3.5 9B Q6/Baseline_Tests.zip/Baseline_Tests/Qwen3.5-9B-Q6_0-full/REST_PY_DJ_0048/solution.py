import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API using the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'new_title' for the product title.
        
    Returns:
        str or None: The response's title value if present, otherwise None.
                     Returns None for a successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "title": inputs.get("new_title")
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code >= 400:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
        
        # For successful responses (200-299), return the title if present
        data = response.json()
        
        # Check if 'title' is in the response and not empty/None
        if "title" in data and data["title"]:
            return data["title"]
        else:
            return None
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")