import requests

def solve(inputs):
    """
    Fetches a specific issue from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'issue_number' (int): The issue number to fetch.
            - 'credential' (str): The authentication token or Bearer token for the API call.
    
    Returns:
        dict or None: The decoded JSON response if successful. Returns None if the response is empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails (non-2xx status code).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    issue_number = inputs['issue_number']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise requests.RequestException(f"Failed to fetch issue. Status code: {response.status_code}")
    
    data = response.json()
    
    # Return None for a successful empty response (though GitHub issues usually have content)
    if not data:
        return None
        
    return data