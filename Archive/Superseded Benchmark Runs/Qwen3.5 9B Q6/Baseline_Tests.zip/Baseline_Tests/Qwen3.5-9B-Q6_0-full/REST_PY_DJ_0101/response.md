```python
import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on skip count and included fields.
    
    Args:
        inputs (dict): Dictionary containing:
            - results_to_skip (int): Number of results to skip.
            - included_fields (str): Comma-separated list of fields to include.
    
    Returns:
        dict or None: Decoded JSON response, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com/todos"
    
    # Parse included_fields
    fields = [field.strip() for field in inputs['included_fields'].split(',')]
    
    params = {
        '_skip': inputs['results_to_skip'],
        '_limit': 1,
        '_fields': ','.join(fields)
    }
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None if the response is empty (e.g., no todos found after skipping)
        if not data:
            return None
        
        return data
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```