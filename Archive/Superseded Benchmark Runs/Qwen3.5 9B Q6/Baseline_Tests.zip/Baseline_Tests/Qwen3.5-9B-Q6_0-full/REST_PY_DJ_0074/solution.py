import requests

def solve(inputs):
    resource_id = inputs.get('resource_id')
    new_description = inputs.get('new_description')
    
    url = f"https://dummyjson.com/products/{resource_id}"
    headers = {
        "Content-Type": "application/json"
    }
    payload = {
        "description": new_description
    }
    
    try:
        response = requests.put(url, json=payload, headers=headers)
        response.raise_for_status()
        
        if response.status_code == 204:
            return None
        
        data = response.json()
        return data.get('id')
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")