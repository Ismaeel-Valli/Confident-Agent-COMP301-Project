import requests
from urllib.parse import quote

def solve(inputs):
    """
    Updates a label in a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'name' (str): The current name of the label to update.
            - 'new_new_name' (str): The new name for the label.
            - 'credential' (dict): Contains 'token' key with the GitHub token.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP request is unsuccessful.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    label_name = inputs['name']
    new_label_name = inputs['new_new_name']
    token = inputs['credential']['token']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/labels/{quote(label_name, safe='')}"
    headers = {
        'Authorization': f'token {token}',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2026-03-10'
    }
    
    payload = {
        "name": new_label_name
    }
    
    response = requests.put(url, headers=headers, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update label. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json() if response.json() else None