import requests

def solve(inputs):
    """
    Submits a new post to DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing:
            - new_body (str): Value for the body attribute.
            - new_title (str): Value for the title attribute.
            - new_user_identifier (str): Value for the user Id attribute.
            
    Returns:
        dict or None: The decoded JSON response if successful, None for an empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": inputs["new_title"],
        "body": inputs["new_body"],
        "userId": inputs["new_user_identifier"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code == 201:
            # DummyJSON typically returns an empty body for POST requests on this endpoint
            if not response.text.strip():
                return None
            return response.json()
        else:
            raise Exception(f"Failed to create post. Status code: {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")