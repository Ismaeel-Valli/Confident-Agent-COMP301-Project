import requests
from urllib.parse import quote

def solve(inputs):
    """
    Creates a pull request on GitHub using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository.
            - new_base (str): The base branch for the pull request.
            - new_head (str): The head branch for the pull request.
            - new_title (str): The title of the pull request.
            - credential (str): The authentication token or username:password string.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    new_base = inputs["new_base"]
    new_head = inputs["new_head"]
    new_title = inputs["new_title"]
    credential = inputs["credential"]
    
    # Construct the URL for creating a pull request
    url = f"https://api.github.com/repos/{quote(repository_owner, safe='')}/{quote(repository_name, safe='')}/pulls"
    
    # Prepare the payload
    payload = {
        "title": new_title,
        "head": new_head,
        "base": new_base
    }
    
    # Set up headers with authentication
    headers = {
        "Authorization": f"token {credential}" if credential.startswith("ghp_") or credential.startswith("xoxb_") else f"{credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Make the POST request to create the pull request
    response = requests.post(url, json=payload, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Return None for a successful empty response, otherwise return the decoded JSON
    if not response.text:
        return None
    
    return response.json()