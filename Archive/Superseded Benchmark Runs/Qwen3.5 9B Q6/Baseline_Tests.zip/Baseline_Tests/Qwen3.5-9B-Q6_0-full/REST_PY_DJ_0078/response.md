```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API with provided age and first name.
    
    Args:
        inputs (dict): Dictionary containing 'new_age' and 'new_firstName'.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    # Construct the payload from inputs
    payload = {
        "age": inputs["new_age"],
        "firstName": inputs["new_firstName"]
    }
    
    # Endpoint for adding a new user in DummyJSON
    url = "https://jsonplaceholder.typicode.com/users"
    
    try:
        response = requests.post(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # If the response is empty (204 No Content), return None
        if response.status_code == 204:
            return None
        
        # Decode and return the JSON response
        return response.json()
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```