import requests

def solve(inputs):
    """
    Updates selected fields of a post on DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id', 'new_body', and 'new_title'.
        
    Returns:
        str or None: The response's id value, or None if the response is empty/successful without id.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs['resource_id']
    new_body = inputs.get('new_body')
    new_title = inputs.get('new_title')
    
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    payload = {}
    if new_body is not None:
        payload['body'] = new_body
    if new_title is not None:
        payload['title'] = new_title
        
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
        
    data = response.json()
    
    if not data:
        return None
        
    return data.get('id')