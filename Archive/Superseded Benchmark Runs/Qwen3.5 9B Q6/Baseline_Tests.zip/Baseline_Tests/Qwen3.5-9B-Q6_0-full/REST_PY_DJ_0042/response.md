```python
import requests

def solve(inputs):
    """
    Deletes a todo by identifier from DummyJSON API and returns the response's id value,
    or None if that attribute is absent or for a successful empty response.
    Raises an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (identifier of the todo)
        
    Returns:
        str or None: The id value from the response, or None if absent or empty response
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON delete endpoint for todos
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    try:
        response = requests.delete(url)
        
        # Raise exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if response is empty
        if not response.text.strip():
            return None
        
        # Try to parse JSON and extract id
        try:
            data = response.json()
            return data.get('id')
        except (ValueError, KeyError):
            # If JSON parsing fails or 'id' key is missing
            return None
            
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Failed to delete todo: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```