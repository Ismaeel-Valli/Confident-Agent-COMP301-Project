import requests
from urllib.parse import quote

def solve(inputs):
    """
    Updates an organization's name via the GitHub REST API (version 2026-03-10).
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The organization name.
            - 'new_name' (str): The new name for the organization.
            - 'credential' (str): The authentication token or username/password string.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    organization = inputs['organization']
    new_name = inputs['new_name']
    credential = inputs['credential']
    
    # Construct the URL for updating an organization
    url = f"https://api.github.com/orgs/{quote(organization)}"
    
    # Prepare headers with authentication
    headers = {
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2026-03-10'
    }
    
    # Determine authentication method based on credential format
    if ':' in credential:
        username, password = credential.split(':', 1)
        auth = (username, password)
    else:
        auth = ('', credential)  # Token-based auth
    
    # Prepare the payload
    data = {
        'name': new_name
    }
    
    try:
        response = requests.put(url, headers=headers, auth=auth, json=data)
        
        if response.status_code == 204:
            return None
        
        if response.status_code >= 400:
            raise Exception(f"Failed to update organization: {response.status_code} - {response.text}")
        
        return response.json()
    
    except requests.exceptions.RequestException as e:
        raise e