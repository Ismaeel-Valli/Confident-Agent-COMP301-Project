```python
import requests

def solve(inputs):
    """
    Deletes a post by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (identifier of the post).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        
    Raises:
        requests.exceptions.HTTPError: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    
    # Base URL for DummyJSON API (posts endpoint)
    base_url = "https://dummyjson.com/posts"
    
    # Construct the delete URL
    delete_url = f"{base_url}/{resource_id}"
    
    try:
        response = requests.delete(delete_url)
        
        # Raise an exception for unsuccessful HTTP responses
        response.raise_for_status()
        
        # Return the id value if present in the response, otherwise None
        return response.json().get('id') if response.json() else None
        
    except requests.exceptions.HTTPError as e:
        raise e
```