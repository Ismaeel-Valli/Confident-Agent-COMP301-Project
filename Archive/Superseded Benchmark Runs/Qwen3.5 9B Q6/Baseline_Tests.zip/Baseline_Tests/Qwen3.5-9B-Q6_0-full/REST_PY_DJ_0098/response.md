```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON using the provided email and first name.
    
    Args:
        inputs (dict): A dictionary containing 'new_email' and 'new_firstName'.
        
    Returns:
        dict or None: The decoded JSON response if successful, otherwise None for an empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/users/add"
    
    payload = {
        "email": inputs["new_email"],
        "firstName": inputs["new_firstName"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        if response.status_code == 201:
            # Successful creation usually returns the created user object or an empty body depending on version/config
            # The prompt says "Return None for a successful empty response". 
            # If the response text is empty or the JSON decoded content is effectively null/empty, return None.
            data = response.json()
            if not data:
                return None
            return data
        elif response.status_code == 200:
             # Some versions might return 200 with an empty body for success
             data = response.json()
             if not data:
                 return None
             return data
        else:
            raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```