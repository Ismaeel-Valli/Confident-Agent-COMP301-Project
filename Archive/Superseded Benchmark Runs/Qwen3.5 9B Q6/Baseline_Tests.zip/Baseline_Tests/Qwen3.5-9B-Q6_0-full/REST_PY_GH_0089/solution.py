import requests

def solve(inputs):
    """
    Fetches the list of files changed in a specific pull request for a GitHub repository.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository.
            - pull_number (int): The number that identifies the pull request.
            - page_size (int): The number of results per page (max 100).
            - credential (str): The bearer token for authentication.
    
    Returns:
        list or None: A list of dictionaries representing the files, or None if the list is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (status code >= 400).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    pr_number = inputs["pull_number"]
    page_size = inputs["page_size"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}/files"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    params = {
        "per_page": page_size
    }
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code >= 400:
        raise Exception(f"GitHub API request failed with status code {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response as per instructions
    if not data:
        return None
        
    return data