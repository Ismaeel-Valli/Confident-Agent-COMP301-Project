```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (int): Identifier of the user to update.
            - new_firstName (str): The new value for the firstName attribute.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty (successful).
    
    Raises:
        requests.exceptions.HTTPError: If the HTTP response status code indicates failure.
    """
    resource_id = inputs.get('resource_id')
    new_firstName = inputs.get('new_firstName')

    if resource_id is None or new_firstName is None:
        raise ValueError("Missing required inputs: 'resource_id' and 'new_firstName'")

    url = f"https://dummyjson.com/users/{resource_id}"
    
    payload = {
        "firstName": new_firstName
    }

    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise requests.exceptions.HTTPError(f"Request failed with status code: {response.status_code}")
    
    # DummyJSON returns an empty body on successful PUT for this endpoint in some versions/configs
    # or the user object. The prompt says "Return None for a successful empty response".
    if len(response.text) == 0:
        return None
    
    return response.json()
```