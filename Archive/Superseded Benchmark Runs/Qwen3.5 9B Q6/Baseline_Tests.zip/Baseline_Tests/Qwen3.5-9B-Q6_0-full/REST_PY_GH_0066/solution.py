import requests
from requests.exceptions import RequestException, HTTPError

def solve(inputs):
    """
    Updates an organization's description via the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The name of the organization.
            - 'new_description' (str): The new description for the organization.
            - 'credential' (dict): Contains authentication details, assumed to have a 'token' key.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP request fails or returns an unsuccessful status code.
    """
    organization = inputs['organization']
    new_description = inputs['new_description']
    credential = inputs['credential']
    
    # Assuming the token is stored under 'token' in the credential dictionary
    headers = {
        'Authorization': f'token {credential["token"]}',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2026-03-10'
    }
    
    url = f"https://api.github.com/orgs/{organization}"
    
    payload = {
        "description": new_description
    }
    
    try:
        response = requests.put(url, json=payload, headers=headers)
        response.raise_for_status()
        
        # GitHub typically returns an empty body for successful PATCH/PUT updates on orgs
        if response.status_code == 200 and len(response.content) == 0:
            return None
        
        return response.json()
    
    except HTTPError as http_err:
        raise Exception(f"HTTP error occurred: {http_err}")
    except RequestException as err:
        raise Exception(f"Request failed: {err}")