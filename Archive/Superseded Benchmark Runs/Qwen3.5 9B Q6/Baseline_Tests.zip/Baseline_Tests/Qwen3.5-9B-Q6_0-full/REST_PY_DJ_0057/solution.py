import requests

def solve(inputs):
    """
    Submits a new post to DummyJSON API and returns the title of the created post.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'new_body': str, value for the body attribute
            - 'new_title': str, value for the title attribute
            - 'new_user_identifier': str, value for the user Id attribute
    
    Returns:
        str or None: The title of the created post if present in response, 
                     None if response is empty (successful but no data).
    
    Raises:
        requests.exceptions.RequestException: If HTTP request fails.
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": inputs['new_title'],
        "body": inputs['new_body'],
        "userId": inputs['new_user_identifier']
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create post. Status code: {response.status_code}")
    
    data = response.json()
    
    if not data:
        return None
    
    return data.get('title')