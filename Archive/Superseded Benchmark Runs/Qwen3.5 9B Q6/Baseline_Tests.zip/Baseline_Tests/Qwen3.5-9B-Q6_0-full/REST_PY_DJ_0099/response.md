```python
import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - included_fields (str): Comma-separated list of fields to include in the response.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None for an empty response.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    # Prepare query parameters
    params = {
        "_limit": inputs.get("result_limit", 10),
        "_fields": inputs.get("included_fields", "")
    }
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        data = response.json()
        
        # Return None if the response is empty (successful but no data)
        if not data:
            return None
            
        return data
    
    except requests.exceptions.RequestException as e:
        raise SystemExit(f"HTTP request failed: {e}")
```