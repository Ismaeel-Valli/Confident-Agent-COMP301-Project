import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on provided sorting parameters.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'sort_field' (str): The field to sort by.
            - 'sort_direction' (str): The direction to sort ('asc' or 'desc').
    
    Returns:
        list or None: The decoded JSON response as a list of posts, or None if the response is empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    # Construct query parameters
    params = {
        '_limit': 10,  # Retrieve one page (default size is 10)
        '_sort': inputs['sort_field'],
        '_order': inputs['sort_direction']
    }
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
            
        return data
    
    except requests.RequestException as e:
        raise e