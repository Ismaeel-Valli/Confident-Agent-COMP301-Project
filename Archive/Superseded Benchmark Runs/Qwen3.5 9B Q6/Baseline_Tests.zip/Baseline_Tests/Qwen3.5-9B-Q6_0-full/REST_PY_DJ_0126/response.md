```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_phone' (new phone number).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_phone = inputs['new_phone']
    
    url = f"https://dummyjson.com/users/{resource_id}"
    data = {"phone": new_phone}
    
    response = requests.put(url, json=data)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user: {response.status_code} - {response.text}")
    
    # DummyJSON returns the updated user object on PUT request
    result = response.json()
    
    return result.get('id')
```