import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON and returns the response's id value,
    or None if that attribute is absent or for a successful empty response.
    Raises an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Contains 'resource_id', 'new_todo', and 'new_user_identifier'.
        
    Returns:
        str or None: The ID of the updated todo, or None if absent/successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    new_todo = inputs.get('new_todo')
    new_user_identifier = inputs.get('new_user_identifier')
    
    # Base URL for DummyJSON API (assuming standard Todo endpoint)
    base_url = "https://dummyjson.com/todos"
    
    # Prepare the update payload
    payload = {
        "todo": new_todo,
        "userId": new_user_identifier
    }
    
    # Endpoint to update a specific todo by ID
    url = f"{base_url}/{resource_id}"
    
    try:
        response = requests.put(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (no content)
        if not response.text:
            return None
        
        # Try to parse the JSON response and extract the 'id' field
        try:
            data = response.json()
            return data.get('id')
        except ValueError:
            # If response is not valid JSON but we got content, return None as per "successful empty response" interpretation
            # or raise an exception if content was expected. Based on instructions, return None for successful empty response.
            # Since we have content but it's not JSON, let's assume it's an unexpected format and return None 
            # to be safe, or we could raise. The instruction says "Return only the response's id value, or None if that attribute is absent."
            # If parsing fails, 'id' is effectively absent in a usable form.
            return None
            
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")