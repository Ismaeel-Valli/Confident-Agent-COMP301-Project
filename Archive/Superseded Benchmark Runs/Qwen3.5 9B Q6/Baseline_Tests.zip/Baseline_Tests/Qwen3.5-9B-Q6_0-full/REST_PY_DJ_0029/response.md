```python
import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on the provided result_limit.
    
    Args:
        inputs (dict): A dictionary containing 'result_limit' key.
        
    Returns:
        list or None: The decoded JSON response as a list of users, or None if the response is empty.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    result_limit = inputs.get('result_limit', 10)
    
    # DummyJSON endpoint for users with limit parameter
    url = f"https://dummyjson.com/users?limit={result_limit}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # DummyJSON returns a list directly in the root for /users endpoint, 
        # but sometimes it might be wrapped. We assume standard behavior where 
        # the top-level is the list of users. However, to be safe against potential 
        # variations or if the API structure changes slightly, we check if the root 
        # is a list. If not, and it's a dict with 'users' key, we extract that.
        
        if isinstance(data, list):
            return data if len(data) > 0 else None
        elif isinstance(data, dict) and 'users' in data:
            users_list = data['users']
            return users_list if len(users_list) > 0 else None
        else:
            # Unexpected structure, treat as empty or error depending on strictness.
            # Given the instruction "Return None for a successful empty response", 
            # we'll return None if it's not a list of users but the request was successful.
            return None
            
    except requests.RequestException as e:
        raise e
```