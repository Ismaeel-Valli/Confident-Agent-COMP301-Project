import requests
import json

def solve(inputs):
    """
    Retrieves the authenticated user from the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing 'credential' with authentication details.
        
    Returns:
        dict or None: The decoded JSON response if successful, None for an empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    # Extract credentials from input
    credential = inputs["credential"]
    
    # Determine authentication method based on credential structure
    # Assuming 'credential' could be a tuple (token, base_url) or dict with 'token' and 'base_url'
    if isinstance(credential, tuple):
        token, base_url = credential
    elif isinstance(credential, dict):
        token = credential.get("token")
        base_url = credential.get("base_url", "https://api.github.com")
    else:
        raise ValueError("Invalid credential format. Expected tuple or dict with 'token' and 'base_url'.")
    
    # Set up headers for authentication
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Make the GET request to get the authenticated user
    response = requests.get(f"{base_url}/user", headers=headers)
    
    # Check if the response is successful
    if response.status_code == 200:
        data = response.json()
        return None if not data else data
    elif response.status_code == 401 or response.status_code == 403:
        raise Exception(f"Authentication failed. Status code: {response.status_code}")
    else:
        raise Exception(f"Unsuccessful HTTP response. Status code: {response.status_code}, Body: {response.text}")