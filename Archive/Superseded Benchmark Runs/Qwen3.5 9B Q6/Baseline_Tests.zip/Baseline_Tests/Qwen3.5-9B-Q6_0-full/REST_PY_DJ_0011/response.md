```python
import requests

def solve(inputs):
    """
    Searches for users using a search term from the inputs dictionary.
    
    Args:
        inputs (dict): A dictionary containing 'search_text' key with the search term.
        
    Returns:
        list or None: Decoded JSON response as a list of users, or None if successful but empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    search_text = inputs.get('search_text')
    
    if not search_text:
        raise ValueError("Search text is required in inputs.")

    url = "https://dummyjson.com/users/search"
    params = {'q': search_text}
    
    response = requests.get(url, params=params)
    response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
    
    data = response.json()
    
    if not data.get('users'):
        return None
        
    return data['users']
```