import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_firstName' (new first name).
        
    Returns:
        str or None: The response's 'id' value if present, otherwise None for successful empty responses.
        Raises: Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_first_name = inputs.get('new_firstName')
    
    if not resource_id or new_first_name is None:
        raise ValueError("Missing required input fields: resource_id and new_firstName")

    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {"firstName": new_first_name}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # DummyJSON returns the updated user object on PUT request
    if 'id' in data:
        return data['id']
    elif not data:  # Empty response
        return None
    else:
        # If id is missing but response is not empty, return None as per spec for absent attribute
        return None