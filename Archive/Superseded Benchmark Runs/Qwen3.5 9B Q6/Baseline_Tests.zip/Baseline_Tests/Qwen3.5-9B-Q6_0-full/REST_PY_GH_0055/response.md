```python
import requests

def solve(inputs):
    """
    Unfollows a GitHub user based on the provided username and credentials.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The handle for the GitHub user account to unfollow.
            - 'credential' (dict): Contains authentication details, expected to have 'token'.
    
    Returns:
        int: The successful HTTP status code (typically 204).
    
    Raises:
        requests.RequestException: If the HTTP request fails or returns an unsuccessful status code.
    """
    username = inputs['username']
    credential = inputs['credential']
    token = credential.get('token')

    if not token:
        raise ValueError("Missing 'token' in credentials.")

    url = f"https://api.github.com/user/{username}/following"
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    response = requests.delete(url, headers=headers)
    
    if response.status_code != 204:
        response.raise_for_status()

    return response.status_code
```