import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id', 'new_todo', and 'new_user_identifier'.
        
    Returns:
        dict or None: Decoded JSON response, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_todo = inputs['new_todo']
    new_user_identifier = inputs['new_user_identifier']
    
    # Base URL for DummyJSON API
    base_url = "https://dummyjson.com"
    
    # Construct the update payload
    payload = {
        "todo": new_todo,
        "userId": new_user_identifier
    }
    
    # Make the PUT request to update the todo
    response = requests.put(
        f"{base_url}/todos/{resource_id}",
        json=payload
    )
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Return None for a successful empty response
    if not response.text:
        return None
    
    # Decode and return the JSON response
    return response.json()