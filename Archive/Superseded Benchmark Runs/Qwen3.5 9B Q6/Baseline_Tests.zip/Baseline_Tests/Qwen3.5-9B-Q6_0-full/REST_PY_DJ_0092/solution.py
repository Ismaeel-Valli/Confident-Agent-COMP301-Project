import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON and returns the response's id value,
    or None if that attribute is absent or for a successful empty response.
    Raises an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the todo to update.
            - new_user_identifier (str): New value for the user Id attribute.
    
    Returns:
        str or None: The ID from the response, or None if absent or empty response.
    
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com"
    resource_id = inputs.get("resource_id")
    new_user_identifier = inputs.get("new_user_identifier")

    if not resource_id or new_user_identifier is None:
        raise ValueError("Missing required inputs: resource_id and new_user_identifier")

    url = f"{base_url}/todos/{resource_id}"
    
    payload = {
        "userId": new_user_identifier
    }

    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to update todo. Status code: {response.status_code}, Response: {response.text}")

    # Check if the response is empty (no content)
    if not response.content:
        return None

    data = response.json()
    
    # Return 'id' if present, otherwise None
    return data.get("id")