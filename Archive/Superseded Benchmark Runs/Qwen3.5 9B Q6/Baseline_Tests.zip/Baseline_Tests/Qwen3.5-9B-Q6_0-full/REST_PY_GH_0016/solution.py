import requests

def solve(inputs):
    """
    Lists issues for a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The Bearer token for authentication.
    
    Returns:
        list or None: A list of issue objects if issues exist, None if the response is empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    token = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/issues"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {token}",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to fetch issues. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response as per instructions
    return data if data else None