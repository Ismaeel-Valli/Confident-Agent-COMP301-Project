import requests
from urllib.parse import quote

def solve(inputs):
    """
    Creates a new label in a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - new_name (str): The name for the new label.
            - credential (str): The authentication token or string for the API call.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    label_name = inputs["new_name"]
    credential = inputs["credential"]
    
    # Construct the API URL for creating a label
    url = f"https://api.github.com/repos/{quote(owner)}/{quote(repo)}/labels"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Payload for creating the label
    payload = {
        "name": label_name
    }
    
    response = requests.post(url, headers=headers, json=payload)
    
    if response.status_code == 201:
        return None  # Successful creation often returns an empty body or just confirms success
    elif response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Failed to create label. Status code: {response.status_code}, Response: {response.text}")