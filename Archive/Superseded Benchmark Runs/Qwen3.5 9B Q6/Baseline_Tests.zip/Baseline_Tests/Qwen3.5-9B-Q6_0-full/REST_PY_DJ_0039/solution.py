import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'result_limit' specifying the maximum number of results.
        
    Returns:
        list or None: The decoded JSON response as a list of todos, or None if the response is empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    result_limit = inputs.get('result_limit', 10)
    
    # DummyJSON endpoint for retrieving todos with a limit
    url = f"https://jsonplaceholder.typicode.com/todos?limit={result_limit}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None if the response is empty, otherwise return the list of todos
        return data if data else None
        
    except requests.exceptions.RequestException as e:
        raise SystemExit(f"HTTP request failed: {e}")