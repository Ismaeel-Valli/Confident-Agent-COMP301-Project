```python
import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on included fields.
    
    Args:
        inputs (dict): A dictionary containing 'included_fields' as a comma-separated string.
        
    Returns:
        list or None: The decoded JSON response (list of todos) or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    included_fields = inputs.get('included_fields', '')
    
    # Construct the API URL with query parameters for fields
    url = "https://jsonplaceholder.typicode.com/todos"
    params = {}
    
    if included_fields:
        params['fields'] = included_fields
    
    response = requests.get(url, params=params)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    data = response.json()
    
    # Return None for a successful empty response
    if not data:
        return None
        
    return data
```