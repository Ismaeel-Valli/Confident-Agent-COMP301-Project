```python
import requests

def solve(inputs):
    """
    Lists repositories for a given GitHub organization based on specified types.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The name of the organization.
            - 'type' (str): The type of repositories to return (e.g., 'all', 'public', 'private').
            - 'credential' (str): The bearer token for authentication.
    
    Returns:
        list or None: A list of repository objects if successful, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    organization = inputs["organization"]
    repo_type = inputs["type"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/orgs/{organization}/repos"
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    params = {"type": repo_type}
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch repositories: {response.status_code} - {response.text}")
    
    data = response.json()
    
    return None if not data else data
```