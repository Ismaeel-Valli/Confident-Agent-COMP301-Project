```python
import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on skip parameter.
    
    Args:
        inputs (dict): Dictionary containing 'results_to_skip' key.
        
    Returns:
        dict or None: Decoded JSON response, or None if successful but empty.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    results_to_skip = inputs.get('results_to_skip', 0)
    
    # DummyJSON API endpoint for posts with pagination
    url = f"https://jsonplaceholder.typicode.com/posts?_skip={results_to_skip}&_limit=1"
    
    try:
        response = requests.get(url)
        
        if response.status_code != 200:
            raise Exception(f"HTTP request failed with status code: {response.status_code}")
        
        data = response.json()
        
        # Return None for successful empty response
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request error occurred: {str(e)}")
```