```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the user.
            - new_email (str): New value for the email attribute.
    
    Returns:
        dict or None: The decoded JSON response if successful (empty), otherwise raises an exception.
    
    Raises:
        requests.exceptions.HTTPError: If the HTTP response indicates failure.
    """
    resource_id = inputs.get('resource_id')
    new_email = inputs.get('new_email')
    
    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {"email": new_email}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise requests.exceptions.HTTPError(f"Request failed with status code {response.status_code}")
    
    return None
```