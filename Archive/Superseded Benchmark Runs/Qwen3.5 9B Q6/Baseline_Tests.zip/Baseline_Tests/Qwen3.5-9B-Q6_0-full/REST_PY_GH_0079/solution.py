import requests
from urllib.parse import quote

def solve(inputs):
    """
    Lists labels for a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'page_size' (int): Number of results per page (max 100).
            - 'credential' (str): Bearer token for authentication.
    
    Returns:
        list or None: Decoded JSON response as a list of labels, or None if empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    page_size = min(inputs['page_size'], 100)
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{quote(owner, safe='')}/{quote(repo, safe='')}/labels"
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    params = {"per_page": page_size}
    
    response = requests.get(url, headers=headers, params=params)
    response.raise_for_status()
    
    data = response.json()
    
    if not data:
        return None
    
    return data