```python
import requests

def solve(inputs):
    """
    Deletes a user by identifier using DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with the user identifier.
        
    Returns:
        None if deletion is successful (empty response).
        Decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    
    # DummyJSON delete endpoint for users
    url = f"https://dummyjson.com/users/{resource_id}"
    
    try:
        response = requests.delete(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        if response.status_code == 200 and not response.text.strip():
            return None
            
        return response.json()
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```