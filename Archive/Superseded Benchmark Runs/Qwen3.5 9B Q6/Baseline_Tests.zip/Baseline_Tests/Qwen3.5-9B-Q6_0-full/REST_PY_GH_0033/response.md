```python
import requests
import json

def solve(inputs):
    """
    Fetches a specific milestone from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'milestone_number' (int): The number identifying the milestone.
            - 'credential' (str): The authentication token or string for the API call.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    milestone_number = inputs['milestone_number']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/milestones/{milestone_number}"
    
    headers = {
        'Authorization': f'token {credential}',
        'Accept': 'application/vnd.github+json'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"GitHub API request failed with status code {response.status_code}: {response.text}")
    
    return response.json()
```