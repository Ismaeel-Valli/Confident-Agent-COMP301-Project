```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (todo ID) and 'new_todo' (value to update).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        Raises: Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_todo_value = inputs.get('new_todo')
    
    if resource_id is None or new_todo_value is None:
        raise ValueError("Missing required inputs: resource_id and new_todo")

    url = f"https://dummyjson.com/todos/{resource_id}"
    payload = {"todo": new_todo_value}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Check for id in the response (could be in 'id' or 'todo.id' depending on API structure)
    if 'id' in data and data['id'] is not None:
        return data['id']
    elif 'todo' in data and isinstance(data['todo'], dict) and data['todo'].get('id'):
        return data['todo']['id']
    
    # Return None for successful empty response or if id is absent
    return None
```