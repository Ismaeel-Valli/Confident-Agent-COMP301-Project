```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API using provided description and title.
    
    Args:
        inputs (dict): Dictionary containing 'new_description' and 'new_title'.
        
    Returns:
        int or None: The ID of the created product, or None if response is empty/successful without ID.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "description": inputs.get("new_description"),
        "title": inputs.get("new_title")
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to submit product. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # DummyJSON returns the created object in the response body on success
    if "id" in data:
        return data["id"]
    elif data == {}:
        return None
    else:
        # If there's a response but no 'id' key and it's not an empty dict, return None as per instruction for successful empty-like response
        return None
```