import requests

def solve(inputs):
    """
    Submit a new product to DummyJSON and return its title.
    
    Args:
        inputs (dict): Must contain 'new_category' and 'new_title'.
        
    Returns:
        str or None: The title of the created product, or None if response is empty.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/products/add"
    
    payload = {
        "category": inputs["new_category"],
        "title": inputs["new_title"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 201:
            data = response.json()
            return data.get("title")
        elif response.status_code == 200 and not data:
            return None
        else:
            raise Exception(f"Unexpected status code: {response.status_code}")
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")