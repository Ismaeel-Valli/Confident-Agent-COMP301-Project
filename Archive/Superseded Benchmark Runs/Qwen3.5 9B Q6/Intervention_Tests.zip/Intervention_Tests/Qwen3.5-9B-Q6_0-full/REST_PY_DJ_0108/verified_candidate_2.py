import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON using the provided email and first name.
    
    Args:
        inputs (dict): Must contain 'new_email' and 'new_firstName'.
        
    Returns:
        int or None: The ID of the created user, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    base_url = "https://dummyjson.com/users/add"
    
    payload = {
        "email": inputs["new_email"],
        "firstName": inputs["new_firstName"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Return the id from the response if present, otherwise None
        data = response.json()
        return data.get("id")
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")