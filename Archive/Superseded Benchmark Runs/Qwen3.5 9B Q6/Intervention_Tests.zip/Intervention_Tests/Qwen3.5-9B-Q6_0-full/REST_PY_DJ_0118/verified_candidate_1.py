import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON using the provided first name and phone number.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_firstName (str): First name for the new user
            - new_phone (str): Phone number for the new user
    
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/users"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "phone": inputs["new_phone"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. Status code: {response.status_code}")
    
    return response.json()