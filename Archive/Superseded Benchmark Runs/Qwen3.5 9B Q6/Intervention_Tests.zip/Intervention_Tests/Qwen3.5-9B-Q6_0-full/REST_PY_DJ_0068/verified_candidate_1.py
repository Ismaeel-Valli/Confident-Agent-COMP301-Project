import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - included_fields (str): Comma-separated list of fields to return
    
    Returns:
        dict or None: Decoded JSON response, or None for empty successful response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    # Base URL for DummyJSON posts
    base_url = "https://dummyjson.com/posts"
    
    # Parse included_fields from comma-separated string
    if 'included_fields' in inputs:
        fields = [f.strip() for f in inputs['included_fields'].split(',')]
    else:
        fields = []
    
    # Build query parameters
    params = {}
    if fields:
        params['fields'] = ','.join(fields)
    
    try:
        response = requests.get(base_url, params=params)
        
        # Check for unsuccessful HTTP response
        if response.status_code != 200:
            raise Exception(f"HTTP {response.status_code} error")
        
        # Decode JSON response
        data = response.json()
        
        # Return None for empty successful response
        if not data.get('posts') or len(data['posts']) == 0:
            return None
        
        return data
    
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")