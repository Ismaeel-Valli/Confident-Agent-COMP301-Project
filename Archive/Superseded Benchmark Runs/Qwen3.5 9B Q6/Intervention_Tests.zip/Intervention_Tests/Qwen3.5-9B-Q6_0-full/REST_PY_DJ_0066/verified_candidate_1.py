import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_lastName = inputs["new_lastName"]
    
    url = "https://dummyjson.com/users/" + str(resource_id)
    payload = {"lastName": new_lastName}
    
    response = requests.patch(url, json=payload)
    
    if response.status_code == 200:
        return None
    
    elif response.status_code == 201:
        data = response.json()
        return data.get("id")
    
    else:
        raise Exception(f"HTTP {response.status_code}: {response.text}")