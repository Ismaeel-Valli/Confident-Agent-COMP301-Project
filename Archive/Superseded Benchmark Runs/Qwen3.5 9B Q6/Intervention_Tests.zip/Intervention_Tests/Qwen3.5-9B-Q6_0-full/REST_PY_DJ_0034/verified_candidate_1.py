import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON with a limit on results.
    
    Args:
        inputs (dict): Must contain 'result_limit' (int).
        
    Returns:
        list or None: Decoded JSON response, or None if empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    result_limit = inputs.get('result_limit')
    
    if result_limit is None:
        raise ValueError("Missing required parameter: 'result_limit'")
    
    base_url = "https://dummyjson.com/posts"
    params = {
        "limit": result_limit,
        "skip": 0
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # DummyJSON returns a dict with 'posts' key; return the list directly
    return data.get('posts')