import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON.
    
    Args:
        inputs (dict): Must contain 'page' key with an integer value.
        
    Returns:
        dict or None: Decoded JSON response, or None if successful but empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    page = inputs.get('page')
    if page is None:
        raise ValueError("Missing 'page' in inputs")
    
    url = "https://dummyjson.com/posts"
    params = {'page': page}
    
    response = requests.get(url, params=params)
    response.raise_for_status()
    
    data = response.json()
    
    if not data:
        return None
    
    return data