import requests

def solve(inputs):
    """Submit a new product to DummyJSON."""
    base_url = "https://dummyjson.com/products/add"
    
    response = requests.post(base_url, json={"title": inputs["new_title"]})
    
    if response.status_code != 201:
        raise Exception(f"Failed to submit product. Status code: {response.status_code}")
    
    return None