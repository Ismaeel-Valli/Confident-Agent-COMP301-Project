import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON with pagination.
    
    Parameters:
        inputs (dict): Must contain:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip.
    
    Returns:
        list or None: Decoded JSON response as a list, or None if the response is empty.
    
    Raises:
        requests.exceptions.HTTPError: If the HTTP response status code indicates an error.
    """
    base_url = "https://dummyjson.com/posts"
    limit = inputs["result_limit"]
    skip = inputs["results_to_skip"]
    
    params = {
        "limit": limit,
        "skip": skip
    }
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()
    
    data = response.json()
    posts = data.get("posts", [])
    
    if not posts:
        return None
    
    return posts