import requests

def solve(inputs):
    """
    Update selected fields of a todo in DummyJSON.
    
    Parameters:
        inputs (dict): Must contain 'resource_id' and 'new_completed'.
        
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty body.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_completed = inputs['new_completed']
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    payload = {
        "completed": new_completed
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to update todo: HTTP {response.status_code}")
    
    return response.json() if response.content else None