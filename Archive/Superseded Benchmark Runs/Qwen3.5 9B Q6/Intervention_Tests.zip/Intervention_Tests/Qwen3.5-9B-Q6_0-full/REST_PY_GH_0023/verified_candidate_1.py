def solve(inputs):
    """
    List issue comments from GitHub REST API v2026-03-10.
    
    Args:
        inputs (dict): Contains repository_owner, repository_name, issue_number, and credential.
        
    Returns:
        list or None: Decoded JSON response as a list of comments, or None if empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    import requests
    
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    issue_num = inputs["issue_number"]
    auth_token = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_num}/comments"
    
    headers = {
        "Authorization": f"token {auth_token}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch issue comments. Status code: {response.status_code}")
    
    data = response.json()
    
    return data if data else None