import requests
import base64

def solve(inputs):
    """
    Create an organization repository on GitHub REST API v2026-03-10.
    
    Args:
        inputs (dict): Must contain:
            - organization (str): Organization name
            - new_name (str): Repository name
            - credential (str): Bearer token for authentication
    
    Returns:
        dict or None: Decoded JSON response, or None if empty response on success.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    org = inputs["organization"]
    repo_name = inputs["new_name"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/orgs/{org}/repos"
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    data = {
        "name": repo_name
    }
    
    response = requests.post(url, json=data, headers=headers)
    
    if response.status_code not in [201, 202]:
        response.raise_for_status()
    
    if response.status_code == 201:
        return response.json()
    else:
        return None