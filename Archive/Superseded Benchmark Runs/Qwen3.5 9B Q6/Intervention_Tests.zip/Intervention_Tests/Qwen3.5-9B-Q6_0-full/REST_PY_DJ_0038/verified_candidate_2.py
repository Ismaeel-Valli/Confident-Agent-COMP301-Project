import requests

def solve(inputs):
    """Submit a new post to DummyJSON and return the response's id."""
    url = "https://dummyjson.com/posts/add"
    payload = {
        "title": inputs["new_title"],
        "body": inputs["new_body"],
        "userId": inputs["new_user_identifier"]
    }
    
    try:
        response = requests.post(url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 201:
            data = response.json()
            return data.get("id")
        elif response.status_code == 200:
            # Some APIs return empty body on success
            return None
        else:
            raise Exception(f"Failed to create post. Status code: {response.status_code}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"HTTP error occurred: {e}")