import requests

def solve(inputs):
    """
    Get an issue comment from GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git)
            - comment_id (int): Unique identifier of the comment
            - credential (str): Caller-supplied authentication token
    
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    # Build the API URL for getting a specific issue comment
    base_url = "https://api.github.com"
    version = "2026-03-10"
    
    # Construct the full URL with the version prefix
    url = f"{base_url}/repos/{inputs['repository_owner']}/{inputs['repository_name']}/issues/comments/{inputs['comment_id']}"
    
    # Prepare headers with authentication
    headers = {
        "Accept": f"application/vnd.github.{version}-preview+json",
        "Authorization": f"token {inputs['credential']}"
    }
    
    # Make the GET request
    response = requests.get(url, headers=headers)
    
    # Check for unsuccessful HTTP response
    if response.status_code >= 400:
        raise Exception(f"GitHub API error: {response.status_code} - {response.text}")
    
    # Decode and return JSON response
    data = response.json()
    
    # Return None for empty response (though issue comments typically have content)
    if not data:
        return None
    
    return data