import requests

def solve(inputs):
    """
    Update selected fields of a post on DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id (int): ID of the post to update
            - new_user_identifier (str): New value for the user Id attribute
    
    Returns:
        str or None: The title from the response, or None if absent or empty.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/posts"
    resource_id = inputs["resource_id"]
    new_user_identifier = inputs["new_user_identifier"]
    
    payload = {
        "userId": new_user_identifier
    }
    
    response = requests.put(f"{base_url}/{resource_id}", json=payload)
    
    if response.status_code not in (200, 201):
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # DummyJSON update returns the updated post directly
    title = data.get("title")
    
    if title is None or title == "":
        return None
    
    return title