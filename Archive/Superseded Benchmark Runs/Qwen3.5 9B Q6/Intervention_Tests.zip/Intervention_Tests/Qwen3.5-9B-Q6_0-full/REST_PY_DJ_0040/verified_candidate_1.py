import requests

def solve(inputs):
    """Retrieve a todo by identifier from DummyJSON and return its id."""
    base_url = "https://dummyjson.com/todos"
    resource_id = inputs.get("resource_id")
    
    if resource_id is None:
        raise ValueError("Missing required input: resource_id")
    
    try:
        response = requests.get(f"{base_url}/{resource_id}")
        response.raise_for_status()  # Raises exception for unsuccessful HTTP status
        
        data = response.json()
        
        # Check if the response has an 'id' field
        if "id" in data and data["id"] is not None:
            return data["id"]
        else:
            # Empty response or no id attribute
            return None
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"HTTP request failed: {e}")