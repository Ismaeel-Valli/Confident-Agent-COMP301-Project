import requests

def solve(inputs):
    """
    Retrieve one page of products from DummyJSON with pagination.
    
    Args:
        inputs (dict): Must contain 'result_limit' and 'results_to_skip'.
        
    Returns:
        dict or None: Decoded JSON response, or None for empty successful response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    
    result_limit = inputs.get("result_limit")
    results_to_skip = inputs.get("results_to_skip")
    
    if result_limit is None or results_to_skip is None:
        raise ValueError("Missing required inputs: 'result_limit' and 'results_to_skip'")
    
    params = {
        "limit": result_limit,
        "skip": results_to_skip
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: status code {response.status_code}, reason: {response.reason}")
    
    data = response.json()
    
    # Return None for successful empty response (products array is empty)
    if not data.get("products"):
        return None
    
    return data