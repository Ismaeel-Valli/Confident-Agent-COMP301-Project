import requests

def solve(inputs):
    """Retrieve a post by identifier from DummyJSON and return its id."""
    try:
        response = requests.get(
            "https://dummyjson.com/posts/" + str(inputs["resource_id"]),
            timeout=10
        )
        response.raise_for_status()
        
        if response.status_code == 200:
            data = response.json()
            # DummyJSON returns {"posts": [...], "total": ..., ...} for list,
            # but for a single post by ID it returns the post object directly.
            return data.get("id")
        else:
            raise Exception(f"Unexpected status code: {response.status_code}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")