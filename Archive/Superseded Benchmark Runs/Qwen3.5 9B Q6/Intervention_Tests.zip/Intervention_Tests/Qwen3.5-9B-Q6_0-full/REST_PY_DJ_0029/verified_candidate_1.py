import requests

def solve(inputs):
    """
    Retrieve one page of users from DummyJSON with a limit on results.
    
    Args:
        inputs (dict): Must contain 'result_limit' (int).
        
    Returns:
        list or None: Decoded JSON response (list of users), or None if empty.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    limit = inputs.get('result_limit')
    if limit is None:
        raise ValueError("Missing 'result_limit' in inputs")
    
    base_url = "https://dummyjson.com/users"
    params = {'limit': limit}
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()
    
    data = response.json()
    users = data.get('users', [])
    
    return users if users else None