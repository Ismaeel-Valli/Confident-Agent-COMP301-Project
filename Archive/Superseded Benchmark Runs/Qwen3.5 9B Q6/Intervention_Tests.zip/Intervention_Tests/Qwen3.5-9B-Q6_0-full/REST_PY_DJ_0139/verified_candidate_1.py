import requests

def solve(inputs):
    """
    Update selected fields of a todo on DummyJSON.
    
    inputs:
        - resource_id: Identifier of the todo (int)
        - new_completed: value for the completed attribute (bool or None)
        - new_user_identifier: value for the user Id attribute (int or None)
    
    Returns:
        The decoded JSON response, or None if successful with empty response.
        Raises an exception for unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/todos"
    resource_id = inputs["resource_id"]
    new_completed = inputs.get("new_completed")
    new_user_identifier = inputs.get("new_user_identifier")

    payload = {}
    if new_completed is not None:
        payload["completed"] = new_completed
    if new_user_identifier is not None:
        payload["userId"] = new_user_identifier

    url = f"{base_url}/{resource_id}"
    response = requests.put(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    return response.json() if response.content else None