import requests

def solve(inputs):
    """Delete a user by identifier from DummyJSON and return the response's id or None."""
    base_url = "https://dummyjson.com/users"
    resource_id = inputs["resource_id"]
    
    try:
        response = requests.delete(f"{base_url}/{resource_id}")
        
        if response.status_code not in [200, 204]:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
        
        data = response.json()
        
        # For successful deletion, return the id from response or None if absent
        if "id" in data and data["id"] is not None:
            return data["id"]
        else:
            return None
            
    except requests.RequestException as e:
        raise Exception(f"Request failed: {e}")