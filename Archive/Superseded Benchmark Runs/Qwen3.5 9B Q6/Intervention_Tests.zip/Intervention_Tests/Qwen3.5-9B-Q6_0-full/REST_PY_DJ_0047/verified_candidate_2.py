import requests

def solve(inputs):
    """Delete a product by identifier from DummyJSON and return its title."""
    resource_id = inputs["resource_id"]
    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.delete(url)
        response.raise_for_status()
        
        data = response.json()
        if data.get("title") is not None:
            return data["title"]
        elif data == {}:
            return None
        else:
            return None
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")