import requests

def solve(inputs):
    """Submit a new product to DummyJSON and return its title."""
    base_url = "https://dummyjson.com/products/add"
    
    payload = {
        "title": inputs["new_title"],
        "price": inputs["new_price"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create product: HTTP {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns the created object directly in the response body
    title = data.get("title")
    
    return title if title is not None else None