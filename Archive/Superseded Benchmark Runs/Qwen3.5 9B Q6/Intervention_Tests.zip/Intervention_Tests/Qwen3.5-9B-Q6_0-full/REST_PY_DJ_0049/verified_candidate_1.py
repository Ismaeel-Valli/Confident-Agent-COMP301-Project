import requests

def solve(inputs):
    """
    Retrieve one page of users from DummyJSON, skipping a specified number of results.
    
    Args:
        inputs (dict): Must contain 'results_to_skip' (int).
        
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/users"
    skip = inputs.get("results_to_skip", 0)
    
    params = {
        "skip": skip,
        "limit": 1
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: status code {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns a dict with 'users' key and 'total' count.
    # If no users are returned, we return None as per spec for successful empty response.
    if not data.get("users"):
        return None
    
    return data