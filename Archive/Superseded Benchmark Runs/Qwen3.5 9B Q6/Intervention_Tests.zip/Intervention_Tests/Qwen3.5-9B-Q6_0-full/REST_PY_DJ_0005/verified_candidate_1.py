import requests

def solve(inputs):
    """Search products on DummyJSON using the provided search term."""
    base_url = "https://dummyjson.com/products/search"
    params = {"q": inputs["search_text"]}
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()  # Raises an exception for unsuccessful HTTP responses
    
    data = response.json()
    
    # If the search returns no results (empty array), return None
    if data["products"] is not None and len(data["products"]) == 0:
        return None
    
    return data