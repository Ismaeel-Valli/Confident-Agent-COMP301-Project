import requests

def solve(inputs):
    """
    Update selected fields of a todo on DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_todo'.
        
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_todo = inputs['new_todo']
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    try:
        response = requests.put(url, json={"todo": new_todo})
        
        if response.status_code >= 400:
            raise Exception(f"HTTP error {response.status_code}: {response.text}")
        
        data = response.json()
        
        # Check for id in different possible locations
        if 'id' in data:
            return data['id']
        elif 'todo' in data and isinstance(data['todo'], dict) and 'id' in data['todo']:
            return data['todo']['id']
        else:
            return None
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")