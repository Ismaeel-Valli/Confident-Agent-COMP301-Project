import requests

def solve(inputs):
    """Delete a post by identifier from DummyJSON and return isDeleted or None."""
    base_url = "https://dummyjson.com/posts"
    resource_id = inputs["resource_id"]
    
    try:
        response = requests.delete(f"{base_url}/{resource_id}")
        response.raise_for_status()
        
        if response.status_code == 200:
            # Successful deletion - check for isDeleted in response or return None
            data = response.json()
            if "isDeleted" in data and data["isDeleted"]:
                return data["isDeleted"]
            else:
                return None
        elif response.status_code == 204:
            # No content response - return None for successful empty response
            return None
        else:
            # Unsuccessful HTTP response - raise exception
            response.raise_for_status()
            
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Failed to delete post: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")