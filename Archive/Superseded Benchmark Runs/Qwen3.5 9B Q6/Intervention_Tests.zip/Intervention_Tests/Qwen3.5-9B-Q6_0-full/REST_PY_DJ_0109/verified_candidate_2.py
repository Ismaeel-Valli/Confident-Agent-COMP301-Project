import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON.
    
    inputs:
        result_limit (int): Maximum number of results to return.
        sort_field (str): Field used for ordering the results.
    
    Returns:
        list or None: Decoded JSON response, or None if successful but empty.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/posts"
    params = {
        "limit": inputs["result_limit"]
    }
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()
    
    data = response.json()
    posts = data.get("posts", [])
    
    if not posts:
        return None
    
    return posts