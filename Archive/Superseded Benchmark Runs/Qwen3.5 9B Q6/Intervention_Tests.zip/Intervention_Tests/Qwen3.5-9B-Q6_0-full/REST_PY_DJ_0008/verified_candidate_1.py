import requests

def solve(inputs):
    """
    Retrieve a user by identifier from DummyJSON.
    
    Args:
        inputs (dict): Must contain 'resource_id' (user ID).
        
    Returns:
        dict or None: Decoded JSON response, or None for empty successful response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs["resource_id"]
    url = f"https://dummyjson.com/users/{resource_id}"
    
    response = requests.get(url)
    response.raise_for_status()
    
    if response.status_code == 200:
        data = response.json()
        return data if data else None
    else:
        raise Exception(f"HTTP {response.status_code}: {response.text}")