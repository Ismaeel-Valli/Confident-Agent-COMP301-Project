import requests


def solve(inputs):
    """Submit a new product to DummyJSON and return its id, or None if absent."""
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/add"

    payload = {
        "category": inputs["new_category"],
        "title": inputs["new_title"]
    }

    response = requests.post(url, json=payload)
    response.raise_for_status()

    if response.status_code == 201:
        data = response.json()
        if "id" in data and data["id"] is not None:
            return data["id"]
        return None
    elif response.status_code == 200:
        # Some APIs return empty body on success
        return None
    else:
        raise Exception(f"Failed to create product. Status code: {response.status_code}")