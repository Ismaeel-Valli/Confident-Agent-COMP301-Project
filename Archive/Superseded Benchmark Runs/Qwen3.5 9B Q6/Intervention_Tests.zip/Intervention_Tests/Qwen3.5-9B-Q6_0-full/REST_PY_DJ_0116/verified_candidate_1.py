import requests

def solve(inputs):
    """
    Retrieve one page of users from DummyJSON with pagination and field filtering.
    
    Args:
        inputs (dict): Dictionary containing:
            - results_to_skip (int): Number of results to skip (for pagination)
            - included_fields (str): Comma-separated list of fields to include
    
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    base_url = "https://dummyjson.com/users"
    
    # Parse included_fields
    if inputs["included_fields"]:
        fields_list = [f.strip() for f in inputs["included_fields"].split(",")]
        params = {
            "skip": inputs["results_to_skip"],
            "limit": 1,  # Retrieve one page
            "select": ",".join(fields_list)
        }
    else:
        params = {
            "skip": inputs["results_to_skip"],
            "limit": 1
        }
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()
        
        if response.status_code == 200:
            data = response.json()
            # Return None for successful empty response (users array is empty)
            if not data.get("users"):
                return None
            return data
        else:
            raise Exception(f"HTTP error: {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")