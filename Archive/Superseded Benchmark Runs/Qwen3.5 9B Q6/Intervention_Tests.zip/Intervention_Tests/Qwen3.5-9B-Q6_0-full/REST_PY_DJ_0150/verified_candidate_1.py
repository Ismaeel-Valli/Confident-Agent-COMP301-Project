import requests

def solve(inputs):
    """
    Update selected fields of a product on DummyJSON.
    
    Args:
        inputs (dict): Must contain 'resource_id' and 'new_brand'.
        
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_brand = inputs['new_brand']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"brand": new_brand}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 204:
        return None
    else:
        raise Exception(f"Failed to update product. Status code: {response.status_code}, Response: {response.text}")