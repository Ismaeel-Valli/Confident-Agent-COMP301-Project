import requests

def solve(inputs):
    """
    Retrieve one page of products from DummyJSON with pagination and field filtering.
    
    Args:
        inputs (dict): Must contain:
            - result_limit (int): Maximum number of results to return
            - included_fields (str): Comma-separated list of fields to include
    
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    base_url = "https://dummyjson.com/products"
    
    # Parse included_fields
    if not inputs.get("included_fields"):
        raise ValueError("included_fields is required")
    
    fields_list = [f.strip() for f in inputs["included_fields"].split(",")]
    
    # Build query parameters
    params = {
        "limit": inputs["result_limit"],
        "select": ",".join(fields_list)
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for empty successful response
    if not data.get("products"):
        return None
    
    return data