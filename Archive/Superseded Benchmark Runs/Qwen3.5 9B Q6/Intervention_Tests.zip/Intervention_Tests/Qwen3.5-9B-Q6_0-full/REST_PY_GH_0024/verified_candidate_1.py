import requests

def solve(inputs):
    """
    Create an issue comment on GitHub using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git extension)
            - issue_number (int): Issue number to comment on
            - new_body (str): Body content for the comment
            - credential (str): Bearer token for authentication
    
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    # Build the API URL for creating an issue comment
    base_url = "https://api.github.com"
    url = f"{base_url}/repos/{inputs['repository_owner']}/{inputs['repository_name']}/issues/{inputs['issue_number']}/comments"
    
    # Prepare headers with authentication
    headers = {
        "Authorization": f"Bearer {inputs['credential']}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare the request payload
    payload = {
        "body": inputs['new_body']
    }
    
    # Make the POST request to create the comment
    response = requests.post(url, json=payload, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Return decoded JSON response, or None for successful empty response
    if response.status_code == 201:
        return response.json()
    elif response.status_code == 204:
        return None
    else:
        return response.json()