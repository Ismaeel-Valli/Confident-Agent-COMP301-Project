import requests

def solve(inputs):
    """
    Retrieve one page of products from DummyJSON with a limit on results.
    
    Args:
        inputs (dict): Must contain 'result_limit' (int).
        
    Returns:
        list or None: Decoded JSON response, or None if empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    limit = inputs.get("result_limit")
    
    params = {"limit": limit}
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()
    
    data = response.json()
    products = data.get("products", [])
    
    return products if products else None