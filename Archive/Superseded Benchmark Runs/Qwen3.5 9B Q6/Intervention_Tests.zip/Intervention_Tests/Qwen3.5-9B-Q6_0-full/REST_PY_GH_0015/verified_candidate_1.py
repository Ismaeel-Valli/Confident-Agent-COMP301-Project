import requests

def solve(inputs):
    """
    Create a fork of a GitHub repository using the GitHub REST API v2026-03-10.
    
    Args:
        inputs (dict): Contains:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git)
            - new_name (str): New name for the forked repository
            - credential (str): GitHub personal access token
    
    Returns:
        dict or None: Decoded JSON response. Returns None for successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    new_name = inputs["new_name"]
    token = inputs["credential"]
    
    # GitHub API endpoint for creating a fork with a custom name
    url = f"https://api.github.com/repos/{owner}/{repo}/forks"
    
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    params = {
        "name": new_name
    }
    
    response = requests.post(url, headers=headers, params=params)
    
    if response.status_code not in [200, 201]:
        raise Exception(f"Failed to create fork: HTTP {response.status_code} - {response.text}")
    
    # GitHub returns an empty body for successful fork creation with custom name
    # The actual fork details are available via a separate GET request
    if response.content == b"":
        return None
    
    return response.json()