import requests

def solve(inputs):
    """Delete a user by identifier from DummyJSON."""
    base_url = "https://dummyjson.com"
    resource_id = inputs["resource_id"]
    
    url = f"{base_url}/users/{resource_id}"
    response = requests.delete(url)
    
    if response.status_code == 204:
        return None
    
    if response.status_code >= 400:
        raise Exception(f"Failed to delete user: {response.status_code} - {response.text}")
    
    return response.json()