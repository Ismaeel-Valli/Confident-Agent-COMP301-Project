import requests

def solve(inputs):
    """Delete a user by identifier from DummyJSON and return isDeleted value."""
    resource_id = inputs["resource_id"]
    
    url = "https://dummyjson.com/users/{user_id}".format(user_id=resource_id)
    response = requests.delete(url)
    
    if response.status_code >= 400:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    if "isDeleted" in data:
        return data["isDeleted"]
    elif response.text == "":
        return None
    else:
        return None