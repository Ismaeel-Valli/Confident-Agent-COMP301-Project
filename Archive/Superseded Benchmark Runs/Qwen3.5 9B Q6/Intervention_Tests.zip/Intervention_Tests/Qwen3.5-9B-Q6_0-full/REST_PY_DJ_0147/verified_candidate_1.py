import requests

def solve(inputs):
    """
    Update selected fields of a post on DummyJSON.
    
    Inputs:
        - resource_id: Identifier of the post (int)
        - new_body: value for the body attribute (str)
        - new_title: value for the title attribute (str)
    
    Returns:
        - The response's title value if present, otherwise None.
        - None for a successful empty response.
        - Raises an exception for an unsuccessful HTTP response.
    """
    base_url = "https://dummyjson.com/posts"
    resource_id = inputs["resource_id"]
    new_body = inputs["new_body"]
    new_title = inputs["new_title"]
    
    url = f"{base_url}/{resource_id}"
    
    payload = {
        "body": new_body,
        "title": new_title
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to update post: HTTP {response.status_code}")
    
    data = response.json()
    
    # Check for title in the response
    if "title" in data and data["title"] is not None:
        return data["title"]
    elif "message" in data and data.get("message"):
        # Some successful responses might have a message instead of title
        return None
    else:
        return None