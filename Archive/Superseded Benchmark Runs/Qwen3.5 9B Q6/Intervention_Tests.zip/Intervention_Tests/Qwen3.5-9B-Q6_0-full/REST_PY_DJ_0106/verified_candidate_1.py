import requests

def solve(inputs):
    """
    Retrieve one page of users from DummyJSON with pagination support.
    
    Args:
        inputs (dict): Dictionary containing:
            - result_limit (int): Maximum number of results to return
            - sort_field (str): Field used for ordering
    
    Returns:
        list or None: Decoded JSON response as a list, or None if empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    base_url = "https://dummyjson.com/users"
    
    params = {
        "limit": inputs["result_limit"],
        "sort": inputs["sort_field"]
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error occurred: {response.status_code}")
    
    data = response.json()
    
    # Return the users list from the response
    return data.get("users")