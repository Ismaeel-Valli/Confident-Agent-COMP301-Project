import requests

def solve(inputs):
    """Submit a new product to DummyJSON and return its id, or None if absent."""
    base_url = "https://dummyjson.com/products/add"
    
    payload = {
        "title": inputs.get("new_title"),
        "description": inputs.get("new_description")
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create product. Status code: {response.status_code}")
    
    data = response.json()
    
    # Check for id in the response
    if "id" in data and data["id"] is not None:
        return data["id"]
    elif response.status_code == 201:
        # Successful empty response
        return None
    else:
        raise Exception(f"Unexpected response structure. Status code: {response.status_code}")