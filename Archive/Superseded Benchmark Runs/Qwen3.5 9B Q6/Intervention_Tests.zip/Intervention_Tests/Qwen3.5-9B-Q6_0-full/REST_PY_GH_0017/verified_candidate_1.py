import requests
import json


def solve(inputs):
    """
    Create a GitHub issue in the specified repository.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git)
            - new_title (str): Title for the new issue
            - credential (str): Bearer token for authentication
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    title = inputs["new_title"]
    credential = inputs["credential"]
    
    # GitHub API v3 endpoint for creating an issue
    url = f"https://api.github.com/repos/{owner}/{repo}/issues"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    data = {
        "title": title
    }
    
    response = requests.post(url, json=data, headers=headers)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create issue. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json()