import requests

def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON, skipping a specified number of results.
    
    Args:
        inputs (dict): Must contain 'results_to_skip' (int).
        
    Returns:
        dict or None: Decoded JSON response if successful and non-empty, 
                      None if successful but empty response.
                      
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/todos"
    
    # Validate inputs
    if 'results_to_skip' not in inputs:
        raise ValueError("Missing required key: results_to_skip")
    
    skip = inputs['results_to_skip']
    if not isinstance(skip, int) or skip < 0:
        raise ValueError("results_to_skip must be a non-negative integer")
    
    params = {
        'skip': skip,
        'limit': 1  # Retrieve one page (one result)
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: status code {response.status_code}, body: {response.text}")
    
    data = response.json()
    
    # Return None for successful empty response (empty todos list)
    if not data.get('todos'):
        return None
    
    return data