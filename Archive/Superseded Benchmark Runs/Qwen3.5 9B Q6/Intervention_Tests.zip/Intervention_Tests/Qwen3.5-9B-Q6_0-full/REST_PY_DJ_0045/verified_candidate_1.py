import requests

def solve(inputs):
    """
    Retrieve a product by identifier from DummyJSON and return its title.
    
    Args:
        inputs (dict): Must contain 'resource_id' key with the product ID.
        
    Returns:
        str or None: The product's title, or None if absent or response is empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    if resource_id is None:
        raise ValueError("Missing 'resource_id' in inputs")
    
    url = f"https://dummyjson.com/products/{resource_id}"
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error {response.status_code}: {response.text}")
    
    data = response.json()
    
    # DummyJSON product endpoint returns a single product object directly
    title = data.get('title')
    return title