import requests

def solve(inputs):
    """Delete a product by identifier from DummyJSON."""
    base_url = "https://dummyjson.com/products"
    resource_id = inputs["resource_id"]
    
    response = requests.delete(f"{base_url}/{resource_id}")
    
    if response.status_code == 200:
        return None
    elif response.status_code == 404:
        raise Exception(f"Product not found: {resource_id}")
    else:
        raise Exception(f"Failed to delete product: {response.status_code} - {response.text}")