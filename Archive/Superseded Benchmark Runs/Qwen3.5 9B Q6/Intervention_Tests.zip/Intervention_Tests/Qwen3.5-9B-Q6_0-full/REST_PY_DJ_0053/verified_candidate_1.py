import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON, skipping a number of results.
    
    Args:
        inputs (dict): Must contain 'results_to_skip' (int).
        
    Returns:
        dict or None: Decoded JSON response. Returns None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/posts"
    skip = inputs.get("results_to_skip", 0)
    
    params = {
        "skip": skip,
        "limit": 1
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns {"posts": [...], "total": int, ...}
    # If posts list is empty, return None as per spec for successful empty response
    if not data.get("posts"):
        return None
    
    return data