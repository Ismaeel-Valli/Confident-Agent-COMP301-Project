import requests

def solve(inputs):
    """Submit a new product to DummyJSON and return its id."""
    base_url = "https://dummyjson.com/products"
    
    try:
        response = requests.post(
            base_url,
            json={"title": inputs["new_title"]},
            timeout=10
        )
        
        if response.status_code != 201:
            raise Exception(f"Failed to create product. Status code: {response.status_code}")
        
        return None
    
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")