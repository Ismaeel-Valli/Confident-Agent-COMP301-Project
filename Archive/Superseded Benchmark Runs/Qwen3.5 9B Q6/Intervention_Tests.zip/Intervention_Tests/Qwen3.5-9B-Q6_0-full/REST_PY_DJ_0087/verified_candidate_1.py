import requests

def solve(inputs):
    """
    Update selected fields of a user on DummyJSON.
    
    inputs:
        - resource_id: Identifier of the user (int)
        - new_age: value for the age attribute (int)
    
    Returns:
        - The response's id value if present, or None if absent.
        - None for a successful empty response.
        - Raises an exception for unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/users"
    resource_id = inputs["resource_id"]
    new_age = inputs["new_age"]
    
    url = f"{base_url}/{resource_id}"
    payload = {"age": new_age}
    
    response = requests.put(url, json=payload)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"HTTP error {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Handle different possible response structures
    if isinstance(data, dict):
        # Check for 'id' in the top-level response or nested under 'user'
        user_id = data.get("id")
        if user_id is None:
            user_id = data.get("user", {}).get("id")
        
        # Return id if present, otherwise None
        return user_id
    
    elif isinstance(data, list):
        # If response is a list, check first item for 'id'
        if len(data) > 0:
            return data[0].get("id")
    
    # For empty responses or other cases where id is not found
    return None