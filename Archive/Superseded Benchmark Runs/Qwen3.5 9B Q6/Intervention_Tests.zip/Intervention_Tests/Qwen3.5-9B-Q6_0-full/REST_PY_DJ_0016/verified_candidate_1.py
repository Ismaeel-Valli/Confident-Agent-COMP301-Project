import requests

def solve(inputs):
    """Delete a post by identifier from DummyJSON."""
    resource_id = inputs["resource_id"]
    url = f"https://dummyjson.com/posts/{resource_id}"
    
    response = requests.delete(url)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    return response.json()