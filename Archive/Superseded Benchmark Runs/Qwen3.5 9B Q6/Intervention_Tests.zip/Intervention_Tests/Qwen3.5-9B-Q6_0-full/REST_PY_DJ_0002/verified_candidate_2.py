import requests

def solve(inputs):
    """
    Retrieve a product by identifier from DummyJSON.
    
    Args:
        inputs (dict): Must contain 'resource_id' (int) for the product ID.
        
    Returns:
        dict or None: Decoded JSON response, or None if empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    if resource_id is None:
        raise ValueError("Missing 'resource_id' in inputs")
    
    url = "https://dummyjson.com/products/get"
    params = {'id': int(resource_id)}
    
    response = requests.get(url, params=params)
    response.raise_for_status()
    
    data = response.json()
    
    if not data:
        return None
    
    return data