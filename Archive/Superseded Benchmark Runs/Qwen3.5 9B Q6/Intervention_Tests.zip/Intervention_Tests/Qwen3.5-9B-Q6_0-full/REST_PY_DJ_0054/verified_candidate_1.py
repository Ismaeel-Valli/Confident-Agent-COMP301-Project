import requests

def solve(inputs):
    """Retrieve a post by identifier from DummyJSON and return its title."""
    try:
        response = requests.get(
            "https://dummyjson.com/posts/get",
            params={"id": inputs["resource_id"]}
        )
        response.raise_for_status()
        
        if response.status_code == 200:
            data = response.json()
            # DummyJSON returns {"post": {...}} for get by ID
            if "post" in data and data["post"]:
                return data["post"].get("title")
            else:
                return None
        else:
            raise Exception(f"HTTP error {response.status_code}: {response.text}")
    except requests.RequestException as e:
        raise Exception(f"Request failed: {e}")