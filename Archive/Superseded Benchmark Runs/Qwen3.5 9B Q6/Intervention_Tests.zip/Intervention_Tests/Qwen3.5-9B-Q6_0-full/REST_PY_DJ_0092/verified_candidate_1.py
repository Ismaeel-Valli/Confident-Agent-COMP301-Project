import requests

def solve(inputs):
    """
    Update selected fields of a todo on DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id (int): Identifier of the todo to update
            - new_user_identifier (str): New value for the user Id attribute
    
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com"
    todo_id = inputs["resource_id"]
    new_user_id = inputs["new_user_identifier"]
    
    url = f"{base_url}/todos/{todo_id}"
    payload = {"userId": new_user_id}
    
    response = requests.put(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"HTTP error {response.status_code}: {response.text}")
    
    # Check for empty response
    data = response.json()
    if not data:
        return None
    
    # Return the id from the response
    return data.get("id")