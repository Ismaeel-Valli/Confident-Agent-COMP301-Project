import requests

def solve(inputs):
    """
    Update selected fields of a product on DummyJSON.
    
    Args:
        inputs (dict): Must contain 'resource_id' and 'new_price'.
        
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_price = inputs.get('new_price')
    
    if resource_id is None or new_price is None:
        raise ValueError("Missing required inputs: 'resource_id' and 'new_price'")
    
    url = "https://dummyjson.com/products"
    payload = {
        "id": resource_id,
        "price": new_price
    }
    
    response = requests.patch(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Check for id in different possible locations
    if 'id' in data:
        return data['id']
    elif 'product' in data and 'id' in data['product']:
        return data['product']['id']
    else:
        return None