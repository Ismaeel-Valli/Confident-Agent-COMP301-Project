import requests

def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON with pagination.
    
    Args:
        inputs (dict): Must contain:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip.
    
    Returns:
        list or None: Decoded JSON response as a list, or None if empty.
    
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/todos"
    limit = inputs.get("result_limit")
    skip = inputs.get("results_to_skip")
    
    params = {}
    if limit is not None:
        params["limit"] = limit
    if skip is not None:
        params["skip"] = skip
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()
    
    data = response.json()
    todos = data.get("todos", [])
    
    return todos if todos else None