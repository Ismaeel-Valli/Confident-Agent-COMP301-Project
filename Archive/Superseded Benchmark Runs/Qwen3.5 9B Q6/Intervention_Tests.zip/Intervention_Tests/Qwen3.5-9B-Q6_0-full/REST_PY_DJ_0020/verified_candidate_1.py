import requests

def solve(inputs):
    """Retrieve a todo by identifier from DummyJSON."""
    resource_id = inputs["resource_id"]
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    response = requests.get(url)
    response.raise_for_status()  # Raise exception for unsuccessful HTTP responses
    
    data = response.json()
    
    if data:
        return data
    else:
        return None