import requests
import json

def solve(inputs):
    """
    Delete a GitHub organization using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - 'organization' (str): The organization name to delete.
            - 'credential' (str): Bearer token for authentication.
    
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    org_name = inputs['organization']
    credential = inputs['credential']
    
    # GitHub API endpoint for deleting an organization
    url = f"https://api.github.com/orgs/{org_name}"
    
    headers = {
        'Authorization': f'Bearer {credential}',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2026-03-10'
    }
    
    # DELETE request to delete the organization
    response = requests.delete(url, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses
    if response.status_code not in [204, 200]:
        response.raise_for_status()
    
    # Decode JSON response
    try:
        data = response.json()
    except json.JSONDecodeError:
        # For successful empty responses (204), return None
        if response.status_code == 204:
            return None
        raise
    
    # Return decoded JSON, or None for successful empty response
    if response.status_code == 204:
        return None
    
    return data