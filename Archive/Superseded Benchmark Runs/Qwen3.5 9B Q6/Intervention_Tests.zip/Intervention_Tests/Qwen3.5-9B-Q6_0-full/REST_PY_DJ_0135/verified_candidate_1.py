import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_username = inputs["new_username"]
    
    url = "https://dummyjson.com/users/" + str(resource_id)
    payload = {"username": new_username}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 201:
        return response.json()
    else:
        raise Exception(f"Failed to update user: {response.status_code} - {response.text}")