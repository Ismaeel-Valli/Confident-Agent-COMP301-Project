import requests

def solve(inputs):
    """
    Update selected fields of a post on DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id (int): Identifier of the post to update.
            - new_body (str): New value for the body attribute.
            - new_title (str): New value for the title attribute.
    
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/posts"
    resource_id = inputs["resource_id"]
    new_body = inputs["new_body"]
    new_title = inputs["new_title"]
    
    url = f"{base_url}/{resource_id}"
    payload = {
        "body": new_body,
        "title": new_title
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Check for successful empty response or absence of 'id'
    if not data or "id" not in data:
        return None
    
    return data["id"]