import requests

def solve(inputs):
    """
    Delete a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): The account owner of the repository
            - repository_name (str): The name of the repository without .git extension
            - credential (str): The caller-supplied authentication token
    
    Returns:
        int: Successful HTTP status code (204)
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    auth_token = inputs["credential"]
    
    # GitHub API v3 endpoint for deleting a repository
    url = f"https://api.github.com/repos/{owner}/{repo}"
    
    headers = {
        "Authorization": f"token {auth_token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.delete(url, headers=headers)
    
    if response.status_code != 204:
        raise Exception(f"Failed to delete repository. Status code: {response.status_code}")
    
    return response.status_code