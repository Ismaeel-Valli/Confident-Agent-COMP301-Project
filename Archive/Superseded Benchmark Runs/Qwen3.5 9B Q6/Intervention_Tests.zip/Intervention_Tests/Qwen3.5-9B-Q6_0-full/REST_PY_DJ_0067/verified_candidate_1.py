import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON and return the response's id value,
    or None if that attribute is absent. Return None for a successful empty response.
    Raise an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Contains 'new_firstName' and 'new_lastName'.
        
    Returns:
        int | None: The user ID from the response, or None if absent or on empty response.
        
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/users"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "lastName": inputs["new_lastName"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 201:
            data = response.json()
            # Check if 'id' is present in the response
            if "id" in data and data["id"] is not None:
                return data["id"]
            else:
                return None
        elif response.status_code == 200:
            # Some APIs might return empty body on success
            return None
        else:
            raise requests.RequestException(f"Unexpected status code: {response.status_code}")
            
    except requests.RequestException as e:
        raise