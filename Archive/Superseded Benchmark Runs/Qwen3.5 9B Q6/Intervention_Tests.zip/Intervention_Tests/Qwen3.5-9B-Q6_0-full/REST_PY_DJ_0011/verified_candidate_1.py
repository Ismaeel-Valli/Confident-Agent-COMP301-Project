import requests

def solve(inputs):
    """
    Search users on DummyJSON using a search term.
    
    Args:
        inputs (dict): Must contain 'search_text' key with the search term.
        
    Returns:
        list or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/users/search"
    search_text = inputs.get("search_text")
    
    if not search_text:
        raise ValueError("Missing or empty 'search_text' in inputs.")
    
    params = {"q": search_text}
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()
    
    data = response.json()
    
    if "users" in data and len(data["users"]) == 0:
        return None
    
    return data