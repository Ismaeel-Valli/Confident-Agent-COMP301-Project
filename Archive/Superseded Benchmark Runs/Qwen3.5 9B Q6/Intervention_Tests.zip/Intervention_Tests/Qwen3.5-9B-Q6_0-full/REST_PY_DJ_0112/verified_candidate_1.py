import requests

def solve(inputs):
    """
    Update selected fields of a todo on DummyJSON.
    
    Inputs:
        - resource_id: Identifier of the todo (int)
        - new_completed: value for the completed attribute (bool or None)
        - new_todo: value for the todo attribute (str or None)
    
    Returns:
        - The response's id value if present, otherwise None
        - None for a successful empty response
        - Raises an exception for unsuccessful HTTP responses
    
    Assumptions:
        - Referenced resources and accounts exist
        - DummyJSON API is accessible at https://dummyjson.com/todos
    """
    base_url = "https://dummyjson.com"
    resource_id = inputs["resource_id"]
    new_completed = inputs.get("new_completed")
    new_todo = inputs.get("new_todo")
    
    # Build the update payload
    payload = {}
    if new_completed is not None:
        payload["completed"] = new_completed
    if new_todo is not None:
        payload["todo"] = new_todo
    
    url = f"{base_url}/todos/{resource_id}"
    
    try:
        response = requests.patch(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if the response is empty
        if not response.text.strip():
            return None
        
        # Try to parse JSON and extract id
        try:
            data = response.json()
            return data.get("id")
        except ValueError:
            # If response is not valid JSON, return None
            return None
            
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")