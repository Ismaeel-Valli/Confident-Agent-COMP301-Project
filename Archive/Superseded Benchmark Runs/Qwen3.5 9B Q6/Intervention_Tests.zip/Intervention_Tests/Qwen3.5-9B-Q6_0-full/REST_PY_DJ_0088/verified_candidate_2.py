import requests

def solve(inputs):
    """Submit a new user to DummyJSON and return the response's id, or None if absent."""
    url = "https://dummyjson.com/users/add"
    payload = {
        "age": inputs["new_age"],
        "firstName": inputs["new_firstName"]
    }
    
    try:
        response = requests.post(url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 201:
            data = response.json()
            return data.get("id")
        elif response.status_code == 200:
            # Some APIs return empty body on success
            return None
        else:
            raise Exception(f"Failed to create user: HTTP {response.status_code}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")