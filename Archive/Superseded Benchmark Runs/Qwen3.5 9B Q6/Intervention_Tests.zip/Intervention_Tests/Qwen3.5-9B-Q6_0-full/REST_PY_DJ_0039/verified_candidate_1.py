import requests

def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON with a limit on results.
    
    Args:
        inputs (dict): Must contain 'result_limit' (int).
        
    Returns:
        list or None: Decoded JSON response, or None for empty successful response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    result_limit = inputs.get('result_limit')
    
    if result_limit is None:
        raise ValueError("Missing required input: 'result_limit'")
    
    base_url = "https://dummyjson.com/todos"
    params = {
        "limit": result_limit
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code}")
    
    data = response.json()
    todos = data.get('todos', [])
    
    if not todos:
        return None
    
    return todos