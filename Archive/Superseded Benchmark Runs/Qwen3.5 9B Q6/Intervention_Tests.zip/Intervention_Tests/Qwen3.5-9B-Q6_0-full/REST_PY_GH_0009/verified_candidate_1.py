import requests

def solve(inputs):
    """
    List branches for a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): The account owner of the repository
            - repository_name (str): The name of the repository without .git extension
            - credential (str): Caller-supplied authentication token
    
    Returns:
        list or None: Decoded JSON response as a list of branches, or None for empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    credential = inputs["credential"]
    
    # GitHub API v2026-03-10 endpoint for listing branches
    url = f"https://api.github.com/repos/{owner}/{repo}/branches"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch branches: HTTP {response.status_code}")
    
    data = response.json()
    
    # Return None for empty response (empty list)
    if not data:
        return None
    
    return data