import requests

def solve(inputs):
    """
    Update selected fields of a product on DummyJSON.
    
    inputs:
        - resource_id: int, ID of the product to update
        - new_title: str, new title value
    
    Returns:
        - The response's 'id' field if present, otherwise None for successful updates.
        - Raises an exception for unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    resource_id = inputs["resource_id"]
    new_title = inputs["new_title"]
    
    payload = {
        "title": new_title
    }
    
    try:
        response = requests.put(
            f"{base_url}/{resource_id}",
            json=payload,
            timeout=10
        )
        
        if response.status_code not in (200, 201):
            raise Exception(f"HTTP {response.status_code}: {response.text}")
        
        return response.json().get("id")
    except requests.RequestException as e:
        raise Exception(f"Request failed: {e}")