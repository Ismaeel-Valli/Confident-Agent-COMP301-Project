import requests

def solve(inputs):
    """Delete a todo by identifier from DummyJSON and return its id or None."""
    base_url = "https://dummyjson.com/todos"
    resource_id = inputs["resource_id"]
    
    try:
        response = requests.delete(f"{base_url}/{resource_id}")
        
        if response.status_code == 204:
            # Successful deletion with empty response
            return None
        
        elif response.status_code == 200:
            # Response contains data, extract id
            data = response.json()
            return data.get("id")
        
        else:
            # Unsuccessful HTTP response
            raise Exception(f"Failed to delete todo. Status code: {response.status_code}")
            
    except requests.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")