import requests

def solve(inputs):
    """
    Retrieve a product by identifier from DummyJSON and return its id.
    
    Args:
        inputs (dict): Must contain 'resource_id' key with the product identifier.
        
    Returns:
        int or None: The product's id if present, None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    
    if resource_id is None:
        raise ValueError("Missing 'resource_id' in inputs")
    
    url = f"https://dummyjson.com/products/{resource_id}"
    
    response = requests.get(url)
    
    if response.status_code >= 400:
        raise Exception(f"HTTP error {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Check for id in the response
    if 'id' in data and data['id'] is not None:
        return data['id']
    
    # Return None for successful empty response or missing id
    return None