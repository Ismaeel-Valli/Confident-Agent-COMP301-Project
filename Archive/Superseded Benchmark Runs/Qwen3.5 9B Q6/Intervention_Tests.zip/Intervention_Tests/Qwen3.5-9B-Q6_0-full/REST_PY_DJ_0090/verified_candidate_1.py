def solve(inputs):
    """Update a post on DummyJSON and return its title."""
    import requests
    
    resource_id = inputs["resource_id"]
    new_body = inputs["new_body"]
    
    url = "https://dummyjson.com/posts/{id}".format(id=resource_id)
    
    payload = {"body": new_body}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    title = data.get("title")
    if title is None:
        return None
    
    return title