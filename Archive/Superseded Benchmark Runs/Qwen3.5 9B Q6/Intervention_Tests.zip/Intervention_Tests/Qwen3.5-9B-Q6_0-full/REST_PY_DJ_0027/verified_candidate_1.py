import requests

def solve(inputs):
    """Delete a product by identifier from DummyJSON and return its id."""
    base_url = "https://dummyjson.com/products"
    resource_id = inputs["resource_id"]
    
    url = f"{base_url}/{resource_id}"
    response = requests.delete(url)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to delete product: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON DELETE returns the deleted item in the response body
    if "id" in data:
        return data["id"]
    elif response.status_code == 200 and not data:
        return None
    else:
        return None