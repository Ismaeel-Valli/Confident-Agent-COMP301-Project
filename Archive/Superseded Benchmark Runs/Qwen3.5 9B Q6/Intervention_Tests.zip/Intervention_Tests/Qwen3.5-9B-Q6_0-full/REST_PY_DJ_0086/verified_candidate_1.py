def solve(inputs):
    """Retrieve one page of users from DummyJSON with pagination."""
    import requests
    
    result_limit = inputs.get("result_limit")
    results_to_skip = inputs.get("results_to_skip", 0)
    
    # DummyJSON uses /users endpoint with query parameters for pagination
    base_url = "https://dummyjson.com/users"
    
    params = {}
    if result_limit is not None:
        params["limit"] = result_limit
    if results_to_skip is not None:
        params["skip"] = results_to_skip
    
    response = requests.get(base_url, params=params)
    
    # Raise exception for unsuccessful HTTP response
    response.raise_for_status()
    
    data = response.json()
    
    # Return None for successful empty response (users array is empty)
    if not data.get("users"):
        return None
    
    return data