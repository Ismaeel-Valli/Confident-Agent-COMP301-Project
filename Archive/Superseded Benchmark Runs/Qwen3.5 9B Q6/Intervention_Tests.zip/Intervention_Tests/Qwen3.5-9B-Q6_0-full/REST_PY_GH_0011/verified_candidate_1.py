import requests
import json


def solve(inputs):
    """
    List commits from a GitHub repository using the REST API version 2026-03-10.
    
    Parameters:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - credential (str): The caller-supplied authentication token or credentials.
    
    Returns:
        list | None: A list of commit objects decoded from the JSON response, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    credential = inputs["credential"]
    
    # GitHub REST API v2026-03-10 endpoint for listing commits
    url = f"https://api.github.com/repos/{owner}/{repo}/commits"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses
    if not response.ok:
        raise Exception(f"GitHub API request failed with status code {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response
    if len(data) == 0:
        return None
    
    return data