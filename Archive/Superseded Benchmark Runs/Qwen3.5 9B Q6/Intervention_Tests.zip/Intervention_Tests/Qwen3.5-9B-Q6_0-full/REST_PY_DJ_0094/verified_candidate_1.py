import requests

def solve(inputs):
    """
    Update selected fields of a product in DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (int): Identifier of the product to update
            - new_price (float or int): New price value for the product
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    resource_id = inputs["resource_id"]
    new_price = inputs["new_price"]
    
    url = f"{base_url}/{resource_id}"
    
    payload = {
        "price": new_price
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 201 or response.status_code == 204:
        return None
    else:
        raise Exception(f"Failed to update product. Status code: {response.status_code}")