import requests

def solve(inputs):
    """
    Update selected fields of a post on DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id (int): Identifier of the post to update
            - new_user_identifier (str): New value for the user Id attribute
    
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/posts"
    resource_id = inputs["resource_id"]
    new_user_identifier = inputs["new_user_identifier"]
    
    payload = {
        "userId": new_user_identifier
    }
    
    response = requests.put(f"{base_url}/{resource_id}", json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update post: HTTP {response.status_code}")
    
    data = response.json()
    
    # Check for successful empty response (no 'id' in data or id is None)
    if "id" not in data or data["id"] is None:
        return None
    
    return data["id"]