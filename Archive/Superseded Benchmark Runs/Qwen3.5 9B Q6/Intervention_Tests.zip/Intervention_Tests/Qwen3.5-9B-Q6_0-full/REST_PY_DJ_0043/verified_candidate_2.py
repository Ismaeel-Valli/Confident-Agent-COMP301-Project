import requests

def solve(inputs):
    """
    Submit a new todo to DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_completed: value for the completed attribute
            - new_todo: value for the todo attribute
            - new_user_identifier: value for the user Id attribute
    
    Returns:
        int or None: The response's id value, or None if absent.
                     Returns None for a successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/todos/add"
    
    payload = {
        "todo": inputs["new_todo"],
        "completed": inputs["new_completed"],
        "userId": inputs["new_user_identifier"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create todo. Status code: {response.status_code}")
    
    data = response.json()
    
    # Check for empty response (no todos returned)
    if not data or "todos" not in data or len(data.get("todos", [])) == 0:
        return None
    
    # Return the id of the created todo
    if "id" in data["todos"][0]:
        return data["todos"][0]["id"]
    else:
        return None