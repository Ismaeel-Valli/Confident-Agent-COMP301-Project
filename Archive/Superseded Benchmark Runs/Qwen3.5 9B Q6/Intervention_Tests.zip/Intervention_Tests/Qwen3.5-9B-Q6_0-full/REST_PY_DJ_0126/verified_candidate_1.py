import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_phone = inputs["new_phone"]
    
    url = "https://dummyjson.com/users/" + str(resource_id)
    payload = {"phone": new_phone}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    if "id" in data and data["id"] is not None:
        return data["id"]
    elif response.status_code == 200:
        return None
    
    return None