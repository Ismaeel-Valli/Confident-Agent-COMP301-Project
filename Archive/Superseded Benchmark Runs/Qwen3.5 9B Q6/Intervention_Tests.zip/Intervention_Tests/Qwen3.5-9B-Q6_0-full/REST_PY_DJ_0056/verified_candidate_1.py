import requests

def solve(inputs):
    """Delete a post by identifier from DummyJSON and return the title or None."""
    base_url = "https://dummyjson.com/posts"
    resource_id = inputs["resource_id"]
    
    try:
        response = requests.delete(f"{base_url}/{resource_id}")
        
        if response.status_code == 200:
            data = response.json()
            return data.get("title")
        elif response.status_code == 204:
            return None
        else:
            raise Exception(f"Failed to delete post. Status code: {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")