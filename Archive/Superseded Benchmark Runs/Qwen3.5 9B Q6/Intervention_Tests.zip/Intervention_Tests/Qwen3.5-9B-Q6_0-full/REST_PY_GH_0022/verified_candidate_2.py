import requests

def solve(inputs):
    """
    Update a GitHub issue using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git)
            - issue_number (int): Issue number to update
            - new_title (str): New title for the issue
            - credential (str): Bearer token for authentication
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    new_title = inputs["new_title"]
    credential = inputs["credential"]
    
    # Construct the API URL for GitHub REST API v2026-03-10
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json"
    }
    
    # Prepare the update payload
    data = {
        "title": new_title
    }
    
    try:
        response = requests.patch(url, json=data, headers=headers)
        
        # Raise an exception for unsuccessful HTTP responses
        response.raise_for_status()
        
        # Return decoded JSON response
        if response.status_code == 204:
            return None
        
        return response.json()
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Failed to update issue: {e}")