import requests

def solve(inputs):
    """
    Submit a new post to DummyJSON using the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - new_body: value for the body attribute
            - new_title: value for the title attribute
            - new_user_identifier: value for the user Id attribute
    
    Returns:
        str or None: The response's title value, or None if that attribute is absent.
                     Returns None for a successful empty response.
    
    Raises:
        Exception: For an unsuccessful HTTP response.
    """
    base_url = "https://dummyjson.com"
    url = f"{base_url}/posts/add"
    
    payload = {
        "title": inputs["new_title"],
        "body": inputs["new_body"],
        "userId": inputs["new_user_identifier"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create post. Status code: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns the created post directly in the response body for POST requests
    title = data.get("title")
    
    return title if title is not None else None