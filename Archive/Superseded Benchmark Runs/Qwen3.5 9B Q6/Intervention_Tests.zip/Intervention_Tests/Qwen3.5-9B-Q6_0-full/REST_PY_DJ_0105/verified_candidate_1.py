import requests

def solve(inputs):
    """
    Submit a new product to DummyJSON and return the response's id value,
    or None if that attribute is absent. Return None for a successful empty response.
    Raise an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_price (float/int): Value for the price attribute
            - new_title (str): Value for the title attribute
    
    Returns:
        int or None: The id from the response, or None if absent or empty response
    
    Raises:
        requests.RequestException: For unsuccessful HTTP responses
    """
    base_url = "https://dummyjson.com/products"
    
    payload = {
        "title": inputs["new_title"],
        "price": inputs["new_price"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 201:
            data = response.json()
            return data.get("id")
        elif response.status_code == 200:
            # Empty response or different success code
            return None
        else:
            raise requests.RequestException(f"Unexpected status code: {response.status_code}")
            
    except requests.exceptions.HTTPError as e:
        raise requests.RequestException(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise requests.RequestException(f"Request failed: {e}")