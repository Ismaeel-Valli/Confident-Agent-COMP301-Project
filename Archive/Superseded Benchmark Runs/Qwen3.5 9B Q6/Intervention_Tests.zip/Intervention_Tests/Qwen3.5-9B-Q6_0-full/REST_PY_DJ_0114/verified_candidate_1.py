import requests

def solve(inputs):
    """
    Update selected fields of a product on DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_price'.
        
    Returns:
        str or None: The title from the response, or None if absent or empty.
    """
    resource_id = inputs['resource_id']
    new_price = inputs['new_price']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"price": new_price}
    
    try:
        response = requests.put(url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 200:
            data = response.json()
            title = data.get('title')
            return title if title is not None else None
        elif response.status_code == 204:
            return None
        else:
            raise Exception(f"Failed to update product: {response.status_code} - {response.text}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"HTTP error occurred: {e}")