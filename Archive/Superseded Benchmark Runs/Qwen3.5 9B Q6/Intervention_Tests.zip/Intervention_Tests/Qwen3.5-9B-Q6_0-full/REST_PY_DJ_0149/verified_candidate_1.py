import requests

def solve(inputs):
    """
    Retrieve one page of products from DummyJSON with pagination and field filtering.
    
    Args:
        inputs (dict): Dictionary containing:
            - result_limit (int): Maximum number of results to return
            - results_to_skip (int): Number of results to skip
            - included_fields (str): Comma-separated list of fields to include
    
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    base_url = "https://dummyjson.com/products"
    
    # Parse included_fields
    if inputs.get("included_fields"):
        fields_list = [f.strip() for f in inputs["included_fields"].split(",")]
        params = {
            "limit": inputs["result_limit"],
            "skip": inputs["results_to_skip"],
            "select": ",".join(fields_list)
        }
    else:
        params = {
            "limit": inputs["result_limit"],
            "skip": inputs["results_to_skip"]
        }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for successful empty response (products array is empty)
    if not data.get("products"):
        return None
    
    return data