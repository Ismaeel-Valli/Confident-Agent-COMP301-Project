import requests

def solve(inputs):
    """
    Update selected fields of a todo on DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_completed'.
        
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_completed = inputs['new_completed']
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    payload = {
        "completed": new_completed
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    return response.json().get('id')