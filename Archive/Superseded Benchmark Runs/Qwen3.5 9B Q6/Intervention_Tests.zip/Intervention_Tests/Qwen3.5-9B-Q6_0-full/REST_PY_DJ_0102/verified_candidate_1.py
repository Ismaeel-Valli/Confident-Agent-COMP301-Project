import requests

def solve(inputs):
    """
    Update selected fields of a todo on DummyJSON.
    
    inputs:
        resource_id (int): Identifier of the todo to update.
        new_completed (bool): New value for the completed attribute.
        new_todo (str): New value for the todo attribute.
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/todos"
    resource_id = inputs["resource_id"]
    new_completed = inputs["new_completed"]
    new_todo = inputs["new_todo"]
    
    payload = {
        "completed": new_completed,
        "todo": new_todo
    }
    
    response = requests.put(f"{base_url}/{resource_id}", json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    return response.json() if response.content else None