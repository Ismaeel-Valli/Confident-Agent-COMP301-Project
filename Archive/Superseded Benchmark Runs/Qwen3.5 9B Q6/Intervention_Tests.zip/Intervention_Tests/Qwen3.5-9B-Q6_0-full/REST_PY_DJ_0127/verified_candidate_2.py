import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON using provided firstName and phone.
    
    Args:
        inputs (dict): Must contain 'new_firstName' and 'new_phone'.
        
    Returns:
        int or None: The response's id if present, otherwise None for success.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/users/add"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "phone": inputs["new_phone"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # DummyJSON returns either a user object with 'id' or an empty dict/list for success
    if isinstance(data, dict) and "id" in data:
        return data["id"]
    elif isinstance(data, list):
        return None
    else:
        return None