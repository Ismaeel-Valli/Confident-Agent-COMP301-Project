import requests

def solve(inputs):
    """
    Update selected fields of a product on DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id (int): Identifier of the product to update.
            - new_description (str): New value for the description attribute.
    
    Returns:
        str or None: The title from the response, or None if absent or successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    resource_id = inputs["resource_id"]
    new_description = inputs["new_description"]
    
    url = f"{base_url}/{resource_id}"
    payload = {"description": new_description}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product: {response.status_code}")
    
    data = response.json()
    
    # Check for title in the response
    if "title" in data and data["title"] is not None:
        return data["title"]
    elif data.get("isEmpty") or data.get("empty"):
        return None
    else:
        return None