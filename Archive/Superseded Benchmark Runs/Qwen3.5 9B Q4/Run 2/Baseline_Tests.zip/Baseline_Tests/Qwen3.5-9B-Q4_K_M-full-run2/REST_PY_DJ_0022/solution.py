import requests

def solve(inputs):
    """
    Deletes a todo by identifier using DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (the todo identifier).
        
    Returns:
        None if the deletion was successful (empty response).
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    
    # DummyJSON delete endpoint structure
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    try:
        response = requests.delete(url)
        response.raise_for_status()
        
        # For successful deletion, DummyJSON returns an empty body with 204 No Content
        if response.status_code == 204:
            return None
            
        # If we get a success code but with content (unexpected for delete), return the decoded JSON
        return response.json()
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP Error occurred while deleting todo: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed while deleting todo: {e}")