```python
import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'result_limit' for pagination.
        
    Returns:
        list or None: The decoded JSON response as a list of users, or None if the response is empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com/users"
    
    # Note: DummyJSON doesn't have a direct 'result_limit' parameter in its standard API for users.
    # However, to adhere strictly to the prompt's instruction of using 'inputs', 
    # we will assume the user wants us to fetch up to 'result_limit' users.
    # Since the standard JSONPlaceholder /users endpoint returns 10 users per page by default 
    # and doesn't support a simple limit parameter for pagination in the same way,
    # we will fetch the first page (which is 10 users) and then slice it if a limit is provided.
    
    try:
        response = requests.get(base_url)
        response.raise_for_status()
        
        data = response.json()
        
        # Apply the result_limit if specified in inputs
        result_limit = inputs.get('result_limit', 10)
        return data[:result_limit]
        
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"HTTP request failed: {e}") from e
```