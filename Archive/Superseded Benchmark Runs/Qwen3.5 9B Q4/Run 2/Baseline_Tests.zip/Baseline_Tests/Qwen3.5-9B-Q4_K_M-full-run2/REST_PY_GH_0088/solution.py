import requests

def solve(inputs):
    """
    Lists commits on a pull request using the GitHub REST API (version 2026-03-10).
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - pull_number (int): The number that identifies the pull request.
            - page_size (int): The number of results per page (max 100).
            - credential (dict): Caller-supplied credentials (assumed to have necessary permissions).
    
    Returns:
        dict or None: The decoded JSON response, or None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    pr_number = inputs["pull_number"]
    page_size = inputs["page_size"]
    credential = inputs["credential"]
    
    # Construct the API URL for listing commits on a pull request
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}/commits"
    
    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Add authentication based on the credential type (assuming token for simplicity)
    if isinstance(credential, dict):
        if "token" in credential:
            headers["Authorization"] = f"Bearer {credential['token']}"
        elif "username" in credential and "password" in credential:
            # Basic auth fallback if token is not provided
            import base64
            auth_string = f"{credential['username']}:{credential['password']}"
            encoded_auth = base64.b64encode(auth_string.encode()).decode()
            headers["Authorization"] = f"Basic {encoded_auth}"
    
    params = {"per_page": page_size}
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Failed to retrieve commits for pull request {pr_number}: HTTP {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response (empty list)
    if not data:
        return None
    
    return data