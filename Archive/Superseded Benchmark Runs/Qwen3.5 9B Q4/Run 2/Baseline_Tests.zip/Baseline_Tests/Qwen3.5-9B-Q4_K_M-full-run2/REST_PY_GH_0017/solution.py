import requests

def solve(inputs):
    """
    Creates a new issue in a GitHub repository using the REST API.
    
    Parameters:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'new_title' (str): The title for the new issue.
            - 'credential' (dict): A dictionary containing authentication details, 
                                  expected to have a 'token' key for Bearer token auth.
    
    Returns:
        dict or None: The decoded JSON response from GitHub. Returns None if the response is empty (success).
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    title = inputs['new_title']
    credential = inputs['credential']
    
    # Construct the API URL for creating an issue
    url = f"https://api.github.com/repos/{owner}/{repo}/issues"
    
    # Prepare headers with Bearer token authentication
    headers = {
        "Authorization": f"Bearer {credential.get('token')}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare the payload for creating the issue
    data = {
        "title": title
    }
    
    # Send POST request to create the issue
    response = requests.post(url, headers=headers, json=data)
    
    # Check if the request was successful
    if response.status_code == 201:
        return None  # Success with empty body
    elif response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Failed to create issue. Status code: {response.status_code}, Response: {response.text}")