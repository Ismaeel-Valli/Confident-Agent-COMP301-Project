```python
import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON based on sorting criteria.
    
    Args:
        inputs (dict): A dictionary containing:
            - sort_field (str): Field used for ordering.
            - sort_direction (str): Ordering direction ('asc' or 'desc').
    
    Returns:
        list or None: The decoded JSON response as a list of products, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code outside 200-299).
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/products"
    
    # Construct query parameters for sorting
    params = {
        'sort': inputs['sort_field'],
        'order': inputs['sort_direction']
    }
    
    response = requests.get(f"{base_url}{endpoint}", params=params)
    
    if not (200 <= response.status_code < 300):
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for an empty successful response
    if not data:
        return None
    
    return data
```