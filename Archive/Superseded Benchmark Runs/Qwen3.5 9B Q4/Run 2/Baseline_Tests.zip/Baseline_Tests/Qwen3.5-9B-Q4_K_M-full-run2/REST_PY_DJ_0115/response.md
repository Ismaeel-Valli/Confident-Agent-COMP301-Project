```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON with the provided price and title.
    
    Args:
        inputs (dict): A dictionary containing 'new_price' and 'new_title'.
        
    Returns:
        str or None: The response's title value if present, otherwise None for a successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 200-299 range).
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    # Prepare the payload using the provided inputs
    payload = {
        "title": inputs["new_title"],
        "body": inputs.get("new_price", ""),  # Using price as body content since DummyJSON expects title/body/id
        "userId": 1  # Assuming a default userId as per problem statement's assumption of existing resources
    }
    
    try:
        response = requests.post(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses
        response.raise_for_status()
        
        # Check if the response is empty (no content)
        if not response.text.strip():
            return None
            
        # Return the title value from the response
        return response.json().get("title")
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```