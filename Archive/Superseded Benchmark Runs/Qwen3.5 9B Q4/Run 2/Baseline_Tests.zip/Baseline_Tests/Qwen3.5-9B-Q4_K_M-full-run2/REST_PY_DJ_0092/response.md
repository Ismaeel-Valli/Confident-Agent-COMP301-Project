```python
import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    new_user_identifier = inputs['new_user_identifier']
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    payload = {"userId": new_user_identifier}
    
    response = requests.patch(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update todo: {response.text}")
    
    data = response.json()
    
    if 'id' in data:
        return data['id']
    elif not data:
        return None
    else:
        return None
```