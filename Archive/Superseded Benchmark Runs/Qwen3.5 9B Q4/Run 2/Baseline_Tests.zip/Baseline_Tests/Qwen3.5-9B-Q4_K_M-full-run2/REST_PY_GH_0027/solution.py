import requests

def solve(inputs):
    """
    Fetches a specific label from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - name (str): The name of the label to fetch.
            - credential (str): The caller-supplied credential (e.g., Bearer token or OAuth token).
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    name = inputs["name"]
    credential = inputs["credential"]

    # Construct the API URL for fetching a label
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/labels/{name}"

    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json"
    }

    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        raise Exception(f"Failed to fetch label. Status code: {response.status_code}, Response: {response.text}")

    return response.json() if response.text else None