import requests
import json

def solve(inputs):
    """
    Submits a new post to DummyJSON API.
    
    Args:
        inputs (dict): Contains 'new_body', 'new_title', and 'new_user_identifier'.
        
    Returns:
        None if the response is empty (successful).
        The decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "body": inputs["new_body"],
        "title": inputs["new_title"],
        "userId": inputs["new_user_identifier"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create post. Status code: {response.status_code}")
    
    # DummyJSON returns an empty body on successful creation, so we return None for success
    if not response.text.strip():
        return None
    
    return response.json()