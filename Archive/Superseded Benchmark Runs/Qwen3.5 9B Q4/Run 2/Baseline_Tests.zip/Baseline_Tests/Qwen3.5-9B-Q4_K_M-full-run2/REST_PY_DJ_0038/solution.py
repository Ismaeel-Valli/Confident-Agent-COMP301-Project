import requests

def solve(inputs):
    """
    Submits a new post to DummyJSON API.
    
    Args:
        inputs (dict): Contains 'new_body', 'new_title', and 'new_user_identifier'.
        
    Returns:
        str or None: The response's id value, or None if the response is empty/successful with no content.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": inputs["new_title"],
        "body": inputs["new_body"],
        "userId": inputs["new_user_identifier"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    # DummyJSON typically returns the created object with an 'id' field.
    # However, the prompt says "Return None for a successful empty response."
    # We interpret this as if the JSON content is empty or lacks an 'id'.
    data = response.json()
    
    if not data:
        return None
    
    id_value = data.get("id")
    
    return id_value if id_value is not None else None