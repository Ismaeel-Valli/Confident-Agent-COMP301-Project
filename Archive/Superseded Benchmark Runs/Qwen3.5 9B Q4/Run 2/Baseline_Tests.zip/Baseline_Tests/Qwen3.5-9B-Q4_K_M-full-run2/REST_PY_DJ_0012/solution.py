import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing 'new_firstName' for the first name attribute.
        
    Returns:
        None if the response is empty (successful submission).
        The decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    url = "https://dummyjson.com/users"
    
    # Prepare the payload with at least a first name; DummyJSON typically expects other fields too,
    # but we'll construct a minimal valid user object based on common DummyJSON schema requirements.
    payload = {
        "firstName": inputs["new_firstName"],
        "lastName": "Doe",  # DummyJSON usually requires lastName as well
        "email": f"{inputs['new_firstName'].lower()}@example.com",
        "age": 30,
        "phone": "+1234567890",
        "image": "https://dummyjson.com/avatar"
    }

    headers = {
        "Content-Type": "application/json"
    }

    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. Status code: {response.status_code}, Response: {response.text}")
    
    # DummyJSON returns an empty body on successful POST for users (status 201)
    if not response.text.strip():
        return None
    
    return response.json()