import requests

def solve(inputs):
    resource_id = inputs.get('resource_id')
    
    url = f"https://dummyjson.com/users/{resource_id}"
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # Check for empty response (e.g., empty user list or null user)
    if not data or 'id' not in data:
        return None
    
    return data['id']