```python
import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON and returns the decoded JSON response.
    
    Args:
        inputs (dict): A dictionary containing API parameters, expected to have a 'page' key.
        
    Returns:
        dict or None: The decoded JSON response if successful. Returns None for an empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    url = f"{base_url}/users"
    
    params = {
        'page': inputs.get('page', 1)
    }
    
    try:
        response = requests.get(url, params=params)
        
        if response.status_code != 200:
            raise Exception(f"HTTP Error: Status code {response.status_code}")
            
        data = response.json()
        
        # Return None for an empty response (though unlikely for /users endpoint without filtering)
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```