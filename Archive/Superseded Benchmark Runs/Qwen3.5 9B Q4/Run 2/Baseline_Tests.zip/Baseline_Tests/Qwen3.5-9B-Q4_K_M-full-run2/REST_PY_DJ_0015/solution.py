import requests

def solve(inputs):
    """
    Updates selected fields of a post on DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the post to update.
            - new_title (str): New value for the title attribute.
            
    Returns:
        None if the HTTP response is successful and empty.
        The decoded JSON response otherwise (for non-empty responses).
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    resource_id = inputs.get('resource_id')
    new_title = inputs.get('new_title')
    
    url = f"https://httpbin.org/post/{resource_id}"
    
    payload = {
        "title": new_title
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to update post. Status code: {response.status_code}, Response: {response.text}")
        
    return None if response.text == "" else response.json()