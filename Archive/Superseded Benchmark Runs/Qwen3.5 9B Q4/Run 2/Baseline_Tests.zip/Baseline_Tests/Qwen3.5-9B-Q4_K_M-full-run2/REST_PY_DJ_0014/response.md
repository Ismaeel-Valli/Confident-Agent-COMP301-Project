```python
import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"Failed to retrieve post with ID {resource_id}: HTTP {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns an empty object {} for a successful empty response (no posts found or deleted)
    if not data:
        return None
    
    return data
```