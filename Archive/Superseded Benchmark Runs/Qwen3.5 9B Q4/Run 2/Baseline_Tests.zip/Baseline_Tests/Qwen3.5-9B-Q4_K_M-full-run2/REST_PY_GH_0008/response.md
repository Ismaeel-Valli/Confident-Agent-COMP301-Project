```python
import requests

def solve(inputs):
    """
    Deletes a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git extension).
            - 'credential' (str): The caller-supplied credential (e.g., token or auth string).
    
    Returns:
        int: The successful HTTP status code (typically 204 No Content).
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful operation.
    """
    owner = inputs['repository_owner']
    repo_name = inputs['repository_name']
    credential = inputs['credential']
    
    # Construct the API URL for deleting a repository
    url = f"https://api.github.com/repos/{owner}/{repo_name}"
    
    headers = {
        'Accept': 'application/vnd.github+json',
        'Authorization': f'Bearer {credential}' if credential.startswith('ghp_') or credential.startswith('xoxb_') else f'{credential}',
        'X-GitHub-Api-Version': '2026-03-10'
    }
    
    # GitHub typically expects a DELETE request for repository deletion
    response = requests.delete(url, headers=headers)
    
    if response.status_code == 204:
        return response.status_code
    else:
        raise Exception(f"Failed to delete repository. Status code: {response.status_code}, Response: {response.text}")
```