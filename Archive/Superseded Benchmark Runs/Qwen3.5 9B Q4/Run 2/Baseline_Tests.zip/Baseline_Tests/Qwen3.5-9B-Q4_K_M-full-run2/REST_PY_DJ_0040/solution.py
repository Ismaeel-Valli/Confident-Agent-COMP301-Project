import requests

def solve(inputs):
    """
    Retrieve a todo by identifier from DummyJSON and return its id or None.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with the todo identifier.
        
    Returns:
        str or None: The 'id' value of the todo if present, otherwise None for empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON endpoint to get a specific todo by ID
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    response = requests.get(url)
    
    # Raise exception for unsuccessful HTTP responses
    if response.status_code >= 400:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    # Check if the response is empty (no todos found or deleted)
    if not response.json():
        return None
    
    # Return the id value if present, otherwise None
    data = response.json()
    return data.get('id')