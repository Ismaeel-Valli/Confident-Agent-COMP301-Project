```python
import requests

def solve(inputs):
    """
    Checks if a repository is starred by the authenticated user using GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner': The account owner of the repository.
            - 'repository_name': The name of the repository without the .git extension.
            - 'credential': The caller-supplied credential (e.g., Bearer token or Authorization header value).
    
    Returns:
        int: The successful HTTP status code (typically 204 No Content for unstarred, 
             but GitHub returns 204 for success regardless of starred state when checking via DELETE/GET logic;
             however, to check if starred, we use GET /user/starred/{owner}/{repo}).
             Actually, the correct endpoint to check starring status is:
             GET /repos/{owner}/{name} with 'starred' field? No.
             
             Correct approach: 
             GitHub API does not have a direct "is starred" GET endpoint that returns just a boolean.
             However, we can use: GET /user/starred/{owner}/{repo} which returns 204 if starred (No Content) 
             and 404 if not starred? Actually, according to GitHub docs:
             
             "If the authenticated user has starred the repository, the response is a 204 status code."
             But wait, that's for DELETE. For GET, it returns the repository object if starred? 
             
             Correction: The endpoint GET /user/starred/{owner}/{repo} returns 204 No Content if the user has starred the repo,
             and 404 Not Found if they haven't? Actually, no. Let me recall properly.
             
             According to GitHub API docs (as of recent versions):
             To check if a repository is starred by the authenticated user:
             GET /user/starred/{owner}/{repo}
             - Returns 204 No Content if the user has starred the repository.
             - Returns 404 Not Found if the user has not starred the repository? 
               Actually, the docs say: "If the authenticated user has not starred the repository, the response is a 404 status code."
             
             However, some sources indicate that it returns 204 for starred and 404 for not starred.
             
             But wait, there's another endpoint: GET /repos/{owner}/{repo} does not directly tell us about starring.
             
             Let's stick to the official method: 
             Use GET /user/starred/{owner}/{repo} with authorization header.
             - If 204 -> starred
             - If 404 -> not starred
    
    Raises:
        Exception: For unsuccessful HTTP responses (non-204 and non-404, or if we consider 404 as failure? 
                   But the problem says "Raise an exception for an unsuccessful HTTP response". 
                   However, 404 in this context means not starred, which is a valid outcome. 
                   But the instruction says: "Return the successful HTTP status code. Raise an exception for an unsuccessful HTTP response."
                   And: "Assume referenced resources and accounts exist." -> So 404 should not happen due to missing repo/user.
                   Therefore, only 204 is success? But what if the API returns something else?
                   
                   Actually, the problem says: "Check if a repository is starred", implying we need to know the status.
                   However, the return value is specified as "the successful HTTP status code". 
                   This suggests that if the check is successful (i.e., the API call succeeded), we return the status code.
                   But which status code? 204 for starred, and what for not starred?
                   
                   Re-reading: "Return the successful HTTP status code." -> This might mean the status code of a successful request, 
                   but the request is successful even if the user hasn't starred (it's just a 404 meaning not starred). 
                   However, the problem says "Raise an exception for an unsuccessful HTTP response". 
                   So we must decide: is 404 considered unsuccessful?
                   
                   Given: "Assume referenced resources and accounts exist." -> So the repo exists. 
                   The only possible responses are:
                     - 204: starred
                     - 404: not starred (but this is a valid state, not an error in terms of resource existence)
                   
                   However, the GitHub API documentation states that GET /user/starred/{owner}/{repo} returns:
                     - 204 No Content if the user has starred the repository.
                     - 404 Not Found if the user has not starred the repository? Actually, no. 
                       According to https://docs.github.com/en/rest/activity/starring#get-a-repository-that-the-authenticated-user-has-starred:
                       "If the authenticated user has not starred the repository, the response is a 404 status code."
                   
                   So 404 here means "not starred", which is a valid outcome. But the problem says "Raise an exception for an unsuccessful HTTP response".
                   Does "unsuccessful" mean non-2xx? Then 404 would trigger an exception, but that would be wrong because not starred is a valid state.
                   
                   However, the problem says: "Return the successful HTTP status code." -> This implies that we only return a status code if the request was successful (i.e., 2xx), 
                   and for non-2xx, we raise an exception. But then how do we distinguish between starred (204) and not starred (404)?
                   
                   This is ambiguous. But note: the problem says "Check if a repository is starred", so we need to know the boolean result. 
                   However, the return value is specified as "the successful HTTP status code". 
                   
                   Alternative interpretation: Maybe the problem expects us to use an endpoint that returns 200 for starred and something else? 
                   But there isn't one.
                   
                   Let me check the actual GitHub API behavior (from memory and docs):
                   Endpoint: GET /user/starred/{owner}/{repo}
                   - If starred: 204 No Content
                   - If not starred: 404 Not Found
   
                   Given the instruction: "Raise an exception for an unsuccessful HTTP response", and assuming that "unsuccessful" means any non-2xx, 
                   then we would raise an exception on 404. But that would mean we never get a "not starred" result without an exception.
                   
                   However, the problem says: "Return the successful HTTP status code." -> This suggests that we only return when the request is successful (2xx), 
                   and for non-2xx, we raise. But then how can we tell if it's starred or not? We can't.
                   
                   This implies that the problem might be using a different endpoint or there's a misunderstanding.
                   
                   Another possibility: Use GET /repos/{owner}/{repo} and check the 'stargazers_count'? No, that doesn't tell about the current user.
                   
                   Or use the Activity API: 
                   There is no direct "is starred" boolean endpoint. The standard way is to use GET /user/starred/{owner}/{repo} and interpret 204 as starred and 404 as not starred.
                   
                   Given the ambiguity, but following common practice in such problems, I think the intended solution is:
                   - Make the request to GET /user/starred/{owner}/{repo}
                   - If status code is 204, then it's starred -> return 204
                   - If status code is 404, then it's not starred -> but the problem says "Raise an exception for an unsuccessful HTTP response", 
                     and 404 is considered unsuccessful? Then we would raise on 404. But that doesn't let us know it's not starred.
                   
                   However, the problem says: "Assume referenced resources and accounts exist." -> This might imply that the only possible responses are 204 (starred) and maybe 200? 
                   But GitHub docs say 404 for not starred.
                   
                   Let me read the problem again: "Return the successful HTTP status code." -> This might mean that we return the status code of a successful request, 
                   but if the request fails (non-2xx), we raise. However, in this context, the request is always successful in terms of being processed, 
                   but the response indicates the state.
                   
                   Given the confusion, I recall that in some versions of the GitHub API, they changed the behavior. But for version 2026-03-10 (which is future), 
                   we have to assume current behavior or standard behavior.
                   
                   Standard behavior: 
                     GET /user/starred/{owner}/{repo}
                     - 204: starred
                     - 404: not starred
   
                   But the problem says "Raise an exception for an unsuccessful HTTP response". If we consider 404 as unsuccessful, then we raise on 404. 
                   However, that would mean we never return a status code for the not-starred case.
                   
                   Alternative approach: Use the endpoint GET /repos/{owner}/{repo} and check if the user is in the stargazers? No, that's not efficient and not direct.
                   
                   Another idea: The problem might expect us to use the 'starred' field from the repository object? But that field is not present in the standard response.
                   
                   After re-examining GitHub docs (https://docs.github.com/en/rest/activity/starring):
                   "Get a repository that the authenticated user has starred" -> GET /user/starred/{owner}/{repo}
                   Response: 
                     - 204 No Content if the user has starred the repository.
                     - 404 Not Found if the user has not starred the repository.
                   
                   So, to check if starred, we do this request and then check the status code.
                   
                   Now, the problem says: "Return the successful HTTP status code." -> This is confusing because 404 is not a success code.
                   But note: the problem might consider the request as successful only if it returns 204 (starred) or maybe they want us to return 204 for starred and raise for not starred? 
                   That doesn't make sense because we need to know if it's starred or not.
                   
                   However, the problem says: "Check if a repository is starred", so the function should be able to tell. 
                   But the return value is specified as "the successful HTTP status code", which implies that we only return when the request was successful (2xx), 
                   and for non-2xx, we raise. But then how do we distinguish?
                   
                   This suggests that perhaps the problem expects us to use a different method. 
                   
                   Wait, there's another endpoint: 
                   GET /user/starred/{owner}/{repo} returns 204 if starred, but what if we want a boolean? 
                   Actually, the GitHub API does not provide a direct boolean. We have to infer from status code.
                   
                   Given the instruction "Raise an exception for an unsuccessful HTTP response", and assuming that "unsuccessful" means any non-2xx, 
                   then we would raise on 404. But that would mean we never get a "not starred" result without an exception.
                   
                   However, the problem says: "Assume referenced resources and accounts exist." -> This might be to avoid 404 for missing repo/user, 
                   but 404 for not starred is expected.
                   
                   I think there's a mistake in the problem statement interpretation. 
                   Let me look for similar problems: In many cases, for this specific check, we do:
                     response = requests.get(url, headers=headers)
                     if response.status_code == 204:
                         starred = True
                     elif response.status_code == 404:
                         starred = False
                   
                   But the problem says "Return the successful HTTP status code", which might mean that we return 204 if starred, and for not starred, 
                   we don't return a status code but raise? That doesn't make sense.
                   
                   Another possibility: The problem might be using an older API version where GET /user/starred/{owner}/{repo} returned 200 with the repo object if starred, 
                   and 404 if not. But current docs say 204 for starred.
                   
                   Given the future date (2026-03-10), we have to assume the API might change, but without specific info, we use current behavior.
                   
                   However, the problem says: "Return the successful HTTP status code." -> This might be a trick: 
                   The only successful response is 204 (for starred), and for not starred, it's 404 which is unsuccessful, so we raise. 
                   But then how do we know if it's starred or not? We can't return a boolean, but the problem doesn't ask for a boolean, 
                   it says "Return the successful HTTP status code", implying that if the request was successful (i.e., the user has starred), return 204, 
                   and if not, raise an exception. But that would mean we never get a "not starred" result without an exception.
                   
                   This is problematic. Let me read the problem once more: 
                   "Check if a repository is starred by the authenticated user." -> So we need to know the boolean state.
                   "Return the successful HTTP status code." -> This is confusing.
                   
                   Perhaps the problem means: return the status code of the response when the request is successful (i.e., 204 for starred), 
                   and if the request fails (non-2xx), raise an exception. But then for not starred, we get 404 which is non-2xx, so we raise. 
                   But that means we never return a status code for the not-starred case.
                   
                   However, the problem says: "Assume referenced resources and accounts exist." -> This might be to ensure that the only 404 is for not starred, 
                   but still, we have to handle it.
                   
                   Given the ambiguity, I think the intended solution is to use the endpoint and return 204 if starred, and raise an exception for any other status code (including 404). 
                   But that would mean we can't distinguish between "not starred" and "error", but the problem says "assume resources exist", so 404 only means not starred.
                   
                   However, the instruction says "Raise an exception for an unsuccessful HTTP response", and 404 is considered unsuccessful in HTTP terms (non-2xx). 
                   So we would raise on 404. But then the function would never return a status code for the not-starred case.
                   
                   This suggests that the problem might have a different expectation. 
                   
                   Alternative: Use the endpoint GET /repos/{owner}/{repo} and check if the user is in the list of stargazers? But that's not direct.
                   
                   After careful thought, I recall that there is no direct way to get a boolean from GitHub API for starring status without checking the status code of /user/starred/{owner}/{repo}.
                   
                   Given the problem constraints, I think we have to do:
                     - Make the request to GET /user/starred/{owner}/{repo}
                     - If status code is 204, return 204 (starred)
                     - If status code is 404, raise an exception because it's considered unsuccessful (per the problem's instruction), even though it means not starred.
                   
                   But that doesn't allow us to know if it's starred or not without raising on not starred.
                   
                   However, the problem says: "Check if a repository is starred", so the caller can catch the exception and know it's not starred? 
                   But the return value is specified as "the successful HTTP status code", which for starred is 204, and for not starred, we raise.
                   
                   So the function would:
                     - Return 204 if starred
                     - Raise an exception if not starred (because 404 is unsuccessful)
                   
                   But that seems odd because then we can't distinguish between "not starred" and "error", but the problem says "assume resources exist", so no other errors.
                   
                   Given the above, I'll implement it as:
                     - Request to GET /user/starred/{owner}/{repo}
                     - If status code is 204, return 204
                     - Else (including 404), raise an exception because it's not a successful response (non-2xx)
                   
                   However, this means we never return a status code for the not-starred case. But the problem says "Return the successful HTTP status code", 
                   which implies that we only return when the request was successful (i.e., 204), and otherwise raise.
                   
                   So the function will either return 204 or raise an exception.
                   
                   But wait, what if the API returns 200? According to docs, it's 204 for starred. 
                   
                   Let's code accordingly.

    However, note: The problem says "GitHub REST API version 2026-03-10", which is a future version. We don't have documentation for it, 
    so we assume current behavior (which might change). But without specific info, we use the standard method.

    Steps:
      1. Construct the URL: "https://api.github.com/user/starred/{owner}/{repo}"
      2. Set headers with Authorization using the credential from inputs["credential"]. 
         Typically, the credential is a Bearer token, so header: {"Authorization": f"Bearer {inputs['credential']}"}
      3. Make the GET request.
      4. Check status code:
          - If 204: return 204
          - Else: raise an exception (because it's not a successful response, per the problem's instruction)

    But note: The problem says "Raise an exception for an unsuccessful HTTP response", and 404 is unsuccessful in HTTP terms.

    However, there's a catch: the GitHub API might return 200 with the repository object in some versions? 
    But current docs say 204. We'll stick to 204.

    Let's code accordingly.
"""

def solve(inputs):
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    credential = inputs['credential']
    
    url = f"https://api.github.com/user/starred/{owner}/{repo}"
