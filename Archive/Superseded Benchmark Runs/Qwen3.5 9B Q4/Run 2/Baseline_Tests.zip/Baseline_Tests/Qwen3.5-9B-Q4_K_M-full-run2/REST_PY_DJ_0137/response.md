```python
import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'included_fields' (str): Comma-separated list of fields to include in the response.
            - 'sort_field' (str): Field name used for sorting the results.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/posts"
    
    # Parse included_fields from comma-separated string into a list
    included_fields = [f.strip() for f in inputs['included_fields'].split(',') if f.strip()]
    
    # Build query parameters
    params = {
        '_limit': 1,  # Retrieve one page (one post)
        '_sort': inputs['sort_field'],
        '_fields': ','.join(included_fields)
    }
    
    url = f"{base_url}{endpoint}"
    
    try:
        response = requests.get(url, params=params)
        
        if response.status_code != 200:
            raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
        
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
        
        return data
    
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```