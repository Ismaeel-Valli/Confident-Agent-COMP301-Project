```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the user.
            - new_firstName (str): New value for the first name attribute.
    
    Returns:
        None if the update is successful and response body is empty.
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    resource_id = inputs.get("resource_id")
    new_firstName = inputs.get("new_firstName")
    
    if not resource_id or not new_firstName:
        raise ValueError("Missing required fields in inputs.")

    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {"firstName": new_firstName}

    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: Update failed")

    return None
```