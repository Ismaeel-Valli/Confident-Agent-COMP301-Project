```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API using provided first name and username.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_username'.
        
    Returns:
        int or None: The ID of the newly created user, or None if response is empty.
        
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status).
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "name": inputs.get("new_firstName"),
        "username": inputs.get("new_username")
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. HTTP Status Code: {response.status_code}")
    
    data = response.json()
    
    if not data:
        return None
    
    return data.get("id")
```