import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on sorting criteria.
    
    Args:
        inputs (dict): A dictionary containing:
            - sort_field (str): Field used for ordering.
            - sort_direction (str): Ordering direction ('asc' or 'desc').
    
    Returns:
        list or None: The decoded JSON response as a list of users, or None if the response is empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/users"
    
    # Construct query parameters
    params = {
        "_sort": inputs["sort_field"],
        "_order": inputs["sort_direction"].lower()
    }
    
    response = requests.get(f"{base_url}{endpoint}", params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP request failed with status code {response.status_code}")
    
    data = response.json()
    
    # Return None for empty response
    return data if data else None