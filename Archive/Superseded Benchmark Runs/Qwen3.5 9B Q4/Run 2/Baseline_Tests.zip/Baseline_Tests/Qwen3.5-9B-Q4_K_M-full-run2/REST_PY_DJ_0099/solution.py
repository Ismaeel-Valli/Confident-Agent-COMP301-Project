import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - included_fields (str): Comma-separated list of fields to include in the response.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    params = {
        "_limit": inputs["result_limit"],
        "_fields": inputs["included_fields"]
    }
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        if response.status_code == 200:
            data = response.json()
            return None if not data else data
        else:
            raise Exception(f"Unexpected status code: {response.status_code}")
    
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")