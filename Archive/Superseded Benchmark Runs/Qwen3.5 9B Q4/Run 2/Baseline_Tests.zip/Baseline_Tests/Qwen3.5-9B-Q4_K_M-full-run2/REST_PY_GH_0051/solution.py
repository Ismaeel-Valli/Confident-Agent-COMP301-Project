import requests

def solve(inputs):
    """
    Retrieves the authenticated user from the GitHub REST API (version 2026-03-10).
    
    Args:
        inputs (dict): A dictionary containing 'credential' with authentication info.
        
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    credential = inputs["credential"]
    
    # Assuming 'credential' contains a token suitable for Bearer authentication
    headers = {
        "Authorization": f"Bearer {credential}"
    }
    
    url = "https://api.github.com/user"
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response (though GitHub /user endpoint rarely returns empty JSON object)
    if not data:
        return None
        
    return data