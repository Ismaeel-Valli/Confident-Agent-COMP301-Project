import requests

def solve(inputs):
    """
    Lists repositories for a given GitHub organization based on specified types.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The organization name.
            - 'type' (str): The type of repositories to return ('all', 'public', or 'private').
            - 'credential' (dict): Caller-supplied credential information (assumed valid).
    
    Returns:
        list|None: Decoded JSON response as a list of repositories, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    org = inputs["organization"]
    repo_type = inputs["type"]
    credential = inputs["credential"]

    # Construct the API URL for GitHub REST API version 2026-03-10
    url = f"https://api.github.com/orgs/{org}/repos"
    
    # Build query parameters
    params = {"type": repo_type}

    headers = {}
    if "token" in credential:
        headers["Authorization"] = f"Bearer {credential['token']}"
    elif "username" in credential and "password" in credential:
        # Basic auth as fallback if token is not provided
        import base64
        auth_string = f"{credential['username']}:{credential['password']}"
        encoded_auth = base64.b64encode(auth_string.encode()).decode()
        headers["Authorization"] = f"Basic {encoded_auth}"

    response = requests.get(url, params=params, headers=headers)

    if response.status_code != 200:
        raise Exception(f"Failed to retrieve repositories for organization '{org}': HTTP {response.status_code}")

    data = response.json()

    # Return None for an empty list of repositories
    return data if data else None