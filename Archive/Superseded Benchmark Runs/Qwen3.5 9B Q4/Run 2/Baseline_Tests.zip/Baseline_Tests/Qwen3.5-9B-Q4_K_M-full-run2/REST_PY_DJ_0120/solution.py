import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    new_user_identifier = inputs['new_user_identifier']
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    headers = {'Content-Type': 'application/json'}
    data = {"userId": new_user_identifier}
    
    response = requests.patch(url, json=data, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update post. Status code: {response.status_code}")
    
    if response.text.strip() == "":
        return None
    
    try:
        response_json = response.json()
        title = response_json.get('title')
        return title if title is not None else None
    except ValueError:
        return None