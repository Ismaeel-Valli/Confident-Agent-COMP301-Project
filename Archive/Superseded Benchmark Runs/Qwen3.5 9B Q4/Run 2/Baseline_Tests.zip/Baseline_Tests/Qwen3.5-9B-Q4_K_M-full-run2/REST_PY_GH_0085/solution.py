import requests

def solve(inputs):
    """
    Lists pull requests for a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - state (str): Filter by 'open', 'closed', or 'all'.
            - credential (dict): Caller-supplied credentials (e.g., token in header).
    
    Returns:
        list | None: Decoded JSON response as a list, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    state = inputs["state"]
    credential = inputs["credential"]

    # Construct the API URL for GitHub REST API version 2026-03-10
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls"

    # Prepare headers with authentication from the provided credential
    # Assuming 'credential' contains a token under key 'token' or similar structure.
    # Adjust based on actual expected format; here we assume a common pattern.
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # If credential contains a token, add it to headers
    if isinstance(credential, dict) and "token" in credential:
        headers["Authorization"] = f"Bearer {credential['token']}"
    
    params = {"state": state}

    response = requests.get(url, headers=headers, params=params)

    if response.status_code != 200:
        raise Exception(f"Failed to list pull requests. Status code: {response.status_code}, Response: {response.text}")

    data = response.json()
    
    # Return None for an empty successful response
    return data if data else None