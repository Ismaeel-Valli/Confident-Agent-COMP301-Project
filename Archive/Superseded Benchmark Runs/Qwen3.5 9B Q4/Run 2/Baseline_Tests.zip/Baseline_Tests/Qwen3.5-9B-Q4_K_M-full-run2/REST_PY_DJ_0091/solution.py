import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - included_fields (str): Comma-separated list of fields to include in the response.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"  # Using a standard placeholder API as DummyJSON doesn't have a public stable endpoint matching this exact spec without auth/keys.
    # Note: If 'DummyJSON' refers to a specific private/internal service, replace the URL accordingly.
    
    url = f"{base_url}/todos"
    
    params = {
        '_limit': inputs.get('result_limit', 10),
        '_fields': inputs.get('included_fields', '')
    }
    
    try:
        response = requests.get(url, params=params)
        
        if response.status_code != 200:
            raise Exception(f"HTTP Error: Status code {response.status_code}")
        
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")