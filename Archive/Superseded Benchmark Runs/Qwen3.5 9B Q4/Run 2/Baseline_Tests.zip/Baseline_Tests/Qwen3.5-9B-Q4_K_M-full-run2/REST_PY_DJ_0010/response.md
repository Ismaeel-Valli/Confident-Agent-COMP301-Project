```python
import requests

def solve(inputs):
    """
    Deletes a user by identifier using DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' as the user identifier.
        
    Returns:
        None if deletion is successful (empty response).
        Decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON delete endpoint pattern
    url = f"https://dummyjson.com/users/{resource_id}"
    
    try:
        response = requests.delete(url)
        
        if response.status_code == 200:
            return None  # Successful deletion with empty response
        
        elif response.status_code == 404:
            raise Exception(f"User with ID {resource_id} not found")
            
        else:
            response.raise_for_status()
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"HTTP request failed: {str(e)}")

# Example usage (not executed):
# inputs = {"resource_id": 1}
# result = solve(inputs)
```