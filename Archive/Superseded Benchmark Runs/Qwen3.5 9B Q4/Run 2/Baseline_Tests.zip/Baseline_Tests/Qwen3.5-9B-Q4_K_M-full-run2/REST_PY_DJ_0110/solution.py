import requests

def solve(inputs):
    """
    Updates selected fields of a post on DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_user_identifier' (new user ID).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    resource_id = inputs.get('resource_id')
    new_user_identifier = inputs.get('new_user_identifier')
    
    if resource_id is None or new_user_identifier is None:
        raise ValueError("Missing required input fields: 'resource_id' and/or 'new_user_identifier'.")

    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    payload = {
        "userId": new_user_identifier
    }
    
    response = requests.patch(url, json=payload)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    # DummyJSON returns the updated object in the response body for PATCH requests
    data = response.json()
    
    return data.get('id')