import requests

def solve(inputs):
    """
    Searches products using a search term from DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing 'search_text' as the search term.
        
    Returns:
        list or None: The decoded JSON response if successful, or None for an empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    search_text = inputs.get('search_text')
    
    # Construct the API URL with the search term query parameter
    url = f"https://jsonplaceholder.typicode.com/posts?title={search_text}"
    
    try:
        response = requests.get(url)
        
        # Raise an exception for unsuccessful HTTP responses (status code not in 2xx range)
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None if the response is empty, otherwise return the data
        return data if data else None
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")