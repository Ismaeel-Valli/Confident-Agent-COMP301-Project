```python
import requests
from requests.exceptions import RequestException, HTTPError

def solve(inputs):
    """
    Updates an organization's description via the GitHub REST API (version 2026-03-10).
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The name of the organization.
            - 'new_description' (str): The new description for the organization.
            - 'credential' (dict): Caller-supplied credentials, assumed to have necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty; None if the response is empty.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    org_name = inputs["organization"]
    new_description = inputs["new_description"]
    credential = inputs["credential"]

    # Construct the URL for updating an organization
    url = f"https://api.github.com/orgs/{org_name}"

    # Prepare headers with authentication using the provided credential
    headers = {
        "Authorization": f"token {credential.get('token', '')}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Prepare the payload for updating the organization description
    payload = {
        "description": new_description
    }

    try:
        response = requests.put(url, json=payload, headers=headers)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP status codes
        
        if response.status_code == 204:
            return None
        else:
            return response.json()
    
    except HTTPError as http_err:
        raise Exception(f"HTTP error occurred: {http_err}")
    except RequestException as req_err:
        raise Exception(f"Request error occurred: {req_err}")
```