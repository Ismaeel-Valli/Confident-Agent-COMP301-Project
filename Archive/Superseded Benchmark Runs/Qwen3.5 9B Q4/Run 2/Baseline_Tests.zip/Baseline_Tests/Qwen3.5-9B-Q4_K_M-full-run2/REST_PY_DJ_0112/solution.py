import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Inputs:
        inputs['resource_id']: Identifier of the todo (e.g., '/todos/1')
        inputs['new_completed']: New value for 'completed' attribute
        inputs['new_todo']: New value for 'todo' attribute
    
    Returns:
        The response's 'id' value if present, otherwise None.
        Returns None for a successful empty response (204 No Content).
        Raises an exception for unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_completed = inputs.get('new_completed')
    new_todo = inputs.get('new_todo')

    if not all([resource_id, new_completed is not None, new_todo is not None]):
        raise ValueError("Missing required input fields.")

    url = f"https://httpbin.org/{resource_id}"
    
    payload = {
        "completed": new_completed,
        "todo": new_todo
    }

    try:
        response = requests.put(url, json=payload)
        
        if response.status_code == 204:
            return None
        
        if response.status_code != 200:
            raise Exception(f"Failed to update todo. Status code: {response.status_code}, Response: {response.text}")

        data = response.json()
        return data.get('id')
    
    except requests.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")