import requests

def solve(inputs):
    """
    Creates a fork of a GitHub repository using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner': str, The account owner of the repository.
            - 'repository_name': str, The name of the repository without the .git extension.
            - 'new_name': str, The new name for the forked repository.
            - 'credential': dict, Caller-supplied credential (e.g., {'token': 'ghx_...'}).
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response indicates an error (status code >= 400).
    """
    owner = inputs['repository_owner']
    repo_name = inputs['repository_name']
    new_name = inputs['new_name']
    credential = inputs['credential']
    
    # Construct the API URL for creating a fork with a custom name
    url = f"https://api.github.com/repos/{owner}/{repo_name}/forks"
    
    headers = {
        'Accept': 'application/vnd.github+json',
        'User-Agent': 'GitHub-REST-API-Fork'
    }
    
    # Prepare the payload to rename the forked repository immediately upon creation
    data = {
        "name": new_name
    }
    
    # Add authentication header based on the provided credential
    if 'token' in credential:
        headers['Authorization'] = f"Bearer {credential['token']}"
    
    response = requests.post(url, json=data, headers=headers)
    
    if response.status_code >= 400:
        raise Exception(f"GitHub API Error: {response.status_code} - {response.text}")
    
    # Return decoded JSON response, or None if the response body is empty
    return response.json() if response.content else None