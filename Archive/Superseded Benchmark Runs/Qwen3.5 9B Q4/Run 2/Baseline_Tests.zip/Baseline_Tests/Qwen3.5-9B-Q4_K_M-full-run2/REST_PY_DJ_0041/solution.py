import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the todo to update.
            - new_todo (str): New value for the 'todo' attribute.
    
    Returns:
        str or None: The response's 'id' value if present, otherwise None.
                      Returns None for a successful empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not 200).
    """
    resource_id = inputs.get("resource_id")
    new_todo = inputs.get("new_todo")
    
    if not resource_id or new_todo is None:
        raise ValueError("Missing required inputs: resource_id and new_todo.")

    url = f"https://jsonplaceholder.typicode.com/todos/{resource_id}"
    
    # Prepare the payload to update only the 'todo' field
    payload = {"todo": new_todo}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update todo. HTTP Status Code: {response.status_code}, Response: {response.text}")
    
    # Check if the response is empty (no content)
    if not response.content:
        return None
    
    # Return the 'id' from the response if it exists
    data = response.json()
    return data.get("id")