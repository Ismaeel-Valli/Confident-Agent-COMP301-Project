import requests
import json

def solve(inputs):
    """
    Updates an organization's name via the GitHub REST API (version 2026-03-10).
    
    Args:
        inputs (dict): Contains 'organization', 'new_name', and 'credential'.
        
    Returns:
        None if the response is empty (successful update), otherwise returns decoded JSON.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    organization = inputs["organization"]
    new_name = inputs["new_name"]
    credential = inputs["credential"]
    
    # Construct the API URL for updating an organization
    url = f"https://api.github.com/orgs/{organization}"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    payload = {
        "name": new_name
    }
    
    response = requests.put(url, headers=headers, json=payload)
    
    if response.status_code == 204:
        # Successful update with empty body
        return None
    elif response.status_code == 200:
        # Some APIs might return the updated object with status 200
        try:
            return response.json()
        except json.JSONDecodeError:
            raise Exception(f"Failed to decode JSON response for status {response.status_code}: {response.text}")
    else:
        raise Exception(f"HTTP error occurred: Status code {response.status_code}, Response: {response.text}")