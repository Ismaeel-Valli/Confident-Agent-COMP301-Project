```python
import requests

def solve(inputs):
    """
    Submits a new todo to DummyJSON API.
    
    Args:
        inputs (dict): Contains 'new_completed', 'new_todo', and 'new_user_identifier'.
        
    Returns:
        str or None: The response's id if present, otherwise None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    url = "https://jsonplaceholder.typicode.com/todos"
    
    payload = {
        "userId": inputs["new_user_identifier"],
        "title": inputs["new_todo"],
        "completed": inputs["new_completed"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create todo. Status code: {response.status_code}")
    
    data = response.json()
    
    if "id" in data:
        return data["id"]
    else:
        return None
```