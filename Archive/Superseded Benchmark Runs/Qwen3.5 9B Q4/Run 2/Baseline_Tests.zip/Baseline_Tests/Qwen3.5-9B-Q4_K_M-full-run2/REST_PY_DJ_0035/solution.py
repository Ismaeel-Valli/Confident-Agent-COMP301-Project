import requests

def solve(inputs):
    resource_id = inputs.get('resource_id')
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"HTTP Error: {response.status_code}")
    
    data = response.json()
    
    # Check for successful empty response (e.g., {"posts": []})
    if 'posts' in data and len(data['posts']) == 0:
        return None
    
    # Return the id value, or None if absent
    return data.get('id')