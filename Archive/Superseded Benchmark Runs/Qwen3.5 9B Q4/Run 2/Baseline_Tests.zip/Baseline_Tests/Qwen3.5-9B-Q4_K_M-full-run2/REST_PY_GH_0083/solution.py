import requests
import json

def solve(inputs):
    """
    Creates a milestone in a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - new_state (str): Value for the state attribute (e.g., 'open', 'closed').
            - new_title (str): Value for the title attribute.
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    state = inputs["new_state"]
    title = inputs["new_title"]
    credential = inputs["credential"]
    
    # Construct the API URL for creating a milestone (GitHub v2026-03-10)
    url = f"https://api.github.com/repos/{owner}/{repo}/milestones"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10",
    }
    
    # Prepare the payload for creating a milestone
    payload = {
        "title": title,
        "state": state,
    }
    
    # If credential contains a token, add it to headers; otherwise assume other auth method
    if "token" in credential:
        headers["Authorization"] = f"Bearer {credential['token']}"
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code == 201:
        # GitHub typically returns a 201 Created with the created resource details
        return response.json()
    elif response.status_code == 204:
        # Some operations might return 204 No Content for success
        return None
    else:
        raise Exception(f"Failed to create milestone. Status code: {response.status_code}, Response: {response.text}")