import requests
import json


def solve(inputs):
    """
    Submits a new user to DummyJSON API with provided first name and username.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_username'.
        
    Returns:
        None if the response is empty (successful submission).
        The decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "name": inputs["new_firstName"],
        "username": inputs["new_username"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. Status code: {response.status_code}")
    
    if len(response.text.strip()) == 0:
        return None
    
    return response.json()