```python
import requests
from urllib.parse import quote

def solve(inputs):
    """
    Lists issue comments for a specific GitHub repository and issue.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - issue_number (int): The number that identifies the issue.
            - since (str, optional): Only show results that were last updated after the given time (ISO 8601 format).
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: For an unsuccessful HTTP response.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    since = inputs.get("since")
    credential = inputs["credential"]
    
    # Construct the API URL for listing issue comments
    url = f"https://api.github.com/repos/{quote(repository_owner)}/{quote(repository_name)}/issues/{issue_number}/comments"
    
    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "Authorization": f"Bearer {credential['token']}"
    }
    
    params = {}
    if since:
        params["since"] = since
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Failed to retrieve issue comments. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Return None for an empty response
    if not data:
        return None
    
    return data
```