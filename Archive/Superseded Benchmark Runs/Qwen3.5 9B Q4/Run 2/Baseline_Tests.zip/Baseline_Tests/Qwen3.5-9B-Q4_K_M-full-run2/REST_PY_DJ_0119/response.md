```python
import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON based on skip count and included fields.
    
    Args:
        inputs (dict): Dictionary containing:
            - results_to_skip (int): Number of results to skip.
            - included_fields (str): Comma-separated list of fields to return.
    
    Returns:
        dict or None: Decoded JSON response, or None if the response is empty but successful.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    # Parse included_fields
    fields = [f.strip() for f in inputs["included_fields"].split(",")]
    
    # Build query parameters
    params = {
        "_skip": inputs["results_to_skip"],
        "_limit": 1,  # Retrieve one page
        "_fields": ",".join(fields)
    }
    
    try:
        response = requests.get(base_url, params=params)
        
        if response.status_code != 200:
            raise Exception(f"HTTP error! status: {response.status_code}")
        
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
        
        return data
    
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```