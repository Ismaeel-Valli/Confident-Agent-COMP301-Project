```python
import requests

def solve(inputs):
    """
    Lists files changed in a pull request for GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - pull_number (int): The number that identifies the pull request.
            - page_size (int): The number of results per page (max 100).
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response, or None for a successful empty response.
    
    Raises:
        Exception: For an unsuccessful HTTP response.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    pull_number = inputs["pull_number"]
    page_size = inputs["page_size"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/pulls/{pull_number}/files"
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare authentication header based on credential type (assuming token for simplicity)
    if isinstance(credential, dict):
        token = credential.get("token") or credential.get("access_token")
        if token:
            headers["Authorization"] = f"Bearer {token}"
        else:
            raise ValueError("Credential must contain a 'token' or 'access_token'.")
    
    params = {"per_page": page_size}
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Failed to retrieve pull request files. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Return None for an empty list of files
    if not data:
        return None
    
    return data
```