import requests

def solve(inputs):
    """
    Retrieves a user by identifier from DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing 'resource_id' as the user identifier.
        
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON endpoint to get a user by ID
    url = f"https://dummyjson.com/users/{resource_id}"
    
    try:
        response = requests.get(url)
        
        if response.status_code != 200:
            raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
            
        data = response.json()
        
        # DummyJSON returns an empty object {} for a successful but empty user list or specific cases,
        # but typically get-user returns the user object. 
        # If the requirement is to return None for a successful empty response (e.g., if the API returned an empty dict),
        # we check here. However, standard DummyJSON get-user always returns a user object.
        # Assuming "successful empty response" means the JSON body is empty {}.
        if data == {}:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")