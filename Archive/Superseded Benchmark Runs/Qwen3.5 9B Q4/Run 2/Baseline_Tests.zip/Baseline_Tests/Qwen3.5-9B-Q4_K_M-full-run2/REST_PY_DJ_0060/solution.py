import requests

def solve(inputs):
    resource_id = inputs.get("resource_id")
    
    # Assuming a base URL like "https://dummyjson.com/todos" for deletion
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    try:
        response = requests.delete(url)
        
        if response.status_code != 200:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
        
        data = response.json()
        
        # Check for 'isDeleted' attribute first
        if "isDeleted" in data:
            return data["isDeleted"]
        
        # If 'isDeleted' is absent, check if the response is empty (successful deletion with no content)
        if not data:
            return None
            
        # If there's content but no 'isDeleted', treat as missing attribute per instructions? 
        # But the instruction says "Return only the response's isDeleted value, or None if that attribute is absent."
        # So if it's absent, we return None.
        return None
        
    except requests.exceptions.RequestException:
        raise Exception("Request failed")