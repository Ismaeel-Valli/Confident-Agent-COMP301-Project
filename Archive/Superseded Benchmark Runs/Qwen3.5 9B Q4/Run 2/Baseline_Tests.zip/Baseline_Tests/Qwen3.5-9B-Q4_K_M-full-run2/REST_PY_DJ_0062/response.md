```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the product.
            - new_description (str): New value for the description attribute.
    
    Returns:
        None if the HTTP response is successful and empty.
        The decoded JSON response otherwise (if non-empty).
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get("resource_id")
    new_description = inputs.get("new_description")
    
    url = f"https://dummyjson.com/products/{resource_id}"
    data = {
        "description": new_description
    }
    
    response = requests.put(url, json=data)
    
    if response.status_code == 200:
        return None
    else:
        raise Exception(f"Failed to update product: {response.text}")
```