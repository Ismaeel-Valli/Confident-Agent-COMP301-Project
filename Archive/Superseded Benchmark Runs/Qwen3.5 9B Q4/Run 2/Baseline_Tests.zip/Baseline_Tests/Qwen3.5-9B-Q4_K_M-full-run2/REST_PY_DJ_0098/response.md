```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON using the provided email and first name.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'new_email': The email address for the new user.
            - 'new_firstName': The first name for the new user.
    
    Returns:
        None if the request is successful (empty response body).
        The decoded JSON response if the server returns data.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "email": inputs["new_email"],
        "firstName": inputs["new_firstName"]
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. Status code: {response.status_code}, Response: {response.text}")
    
    # DummyJSON typically returns an empty body for POST /users with status 201
    if not response.text.strip():
        return None
    
    try:
        return response.json()
    except ValueError:
        raise Exception(f"Received non-JSON response from server: {response.text}")
```