```python
import requests

def solve(inputs):
    """
    Lists branches for a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository without the .git extension.
            - 'credential' (str): The caller-supplied credential (e.g., token or Bearer token).
    
    Returns:
        dict or None: The decoded JSON response if branches are found, or None for a successful empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/branches"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        return None if len(data) == 0 else data
    elif response.status_code >= 400:
        raise Exception(f"GitHub API request failed with status code {response.status_code}: {response.text}")
    
    raise Exception("Unexpected response from GitHub API")
```