```python
import requests

def solve(inputs):
    """
    Lists pull requests for a given GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The caller-supplied credential (e.g., token or Bearer string).
    
    Returns:
        dict|None: The decoded JSON response if items are found, None for a successful empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        return None if not data else data
    elif response.status_code in (401, 403):
        raise Exception(f"Authentication or permission error: {response.status_code} - {response.text}")
    else:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
```