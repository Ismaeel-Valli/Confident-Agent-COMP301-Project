```python
import requests

def solve(inputs):
    """
    Lists commits for a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The caller-supplied credential (e.g., token or Bearer string).
    
    Returns:
        dict or None: Decoded JSON response if commits exist, or None for a successful empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx/3xx range).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/commits"
    headers = {
        'Accept': 'application/vnd.github.v3+json',
        'Authorization': f'Bearer {credential}'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        return None if len(data) == 0 else data
    elif response.status_code in (401, 403):
        raise Exception(f"Authentication or permission error: {response.status_code} - {response.text}")
    elif response.status_code >= 400:
        raise Exception(f"Failed to list commits. Status code: {response.status_code}. Response: {response.text}")
    
    # Fallback for unexpected success codes (e.g., redirects)
    if response.status_code < 300:
        return None
    
    raise Exception(f"Unexpected HTTP status code: {response.status_code}")
```