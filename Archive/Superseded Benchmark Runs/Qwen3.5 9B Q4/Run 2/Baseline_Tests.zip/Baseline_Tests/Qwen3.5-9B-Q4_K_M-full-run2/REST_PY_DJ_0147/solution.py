import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    new_body = inputs['new_body']
    new_title = inputs['new_title']
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    payload = {
        "body": new_body,
        "title": new_title
    }
    
    response = requests.patch(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # DummyJSON returns an empty object {} on successful update for PATCH requests to specific resources
    if not data or (isinstance(data, dict) and len(data) == 0):
        return None
    
    return data.get('title')