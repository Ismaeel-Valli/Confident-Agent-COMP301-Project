import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_username'.
        
    Returns:
        str or None: The response's 'id' value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_username = inputs['new_username']
    
    url = f"https://httpbin.org/put"
    data = {
        "id": resource_id,
        "username": new_username
    }
    
    response = requests.put(url, json=data)
    
    if response.status_code != 200:
        raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
    
    # Return the id from the response if present, otherwise None
    return response.json().get("id")