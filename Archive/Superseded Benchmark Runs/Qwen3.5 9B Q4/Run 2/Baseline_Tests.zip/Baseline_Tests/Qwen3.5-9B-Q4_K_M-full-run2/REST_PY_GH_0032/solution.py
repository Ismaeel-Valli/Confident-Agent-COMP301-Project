import requests

def solve(inputs):
    """
    Creates a milestone in a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git extension).
            - new_title (str): The title for the new milestone.
            - credential (dict): Caller-supplied credentials (assumed to have necessary permissions).
    
    Returns:
        dict or None: The decoded JSON response from GitHub. Returns None on success with an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    title = inputs["new_title"]
    credential = inputs["credential"]
    
    # Construct the API URL for creating a milestone
    url = f"https://api.github.com/repos/{owner}/{repo}/milestones"
    
    # Prepare headers with authentication
    headers = {
        "Authorization": f"Bearer {credential.get('token', '')}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare the payload for creating a milestone
    payload = {
        "title": title
    }
    
    # Send POST request to create the milestone
    response = requests.post(url, headers=headers, json=payload)
    
    # Check if the request was successful
    if response.status_code == 201:
        return None  # Success with empty response
    elif response.status_code == 422:
        # Validation error (e.g., invalid title)
        raise Exception(f"Validation Error: {response.json().get('message', 'Unknown validation error')}")
    else:
        # Handle other errors
        try:
            error_message = response.json().get("message", "An unknown error occurred")
        except ValueError:
            error_message = response.text
        
        raise Exception(f"Failed to create milestone. Status code: {response.status_code}, Message: {error_message}")