import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the todo to update.
            - new_user_identifier (str): New value for the user Id attribute.
    
    Returns:
        None if the response is empty (successful update).
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response indicates an error (status code >= 400).
    """
    base_url = "https://jsonplaceholder.typicode.com"
    resource_id = inputs.get("resource_id")
    new_user_identifier = inputs.get("new_user_identifier")
    
    if not resource_id or not new_user_identifier:
        raise ValueError("Missing required input fields: resource_id and new_user_identifier.")

    url = f"{base_url}/todos/{resource_id}"
    payload = {"userId": new_user_identifier}

    response = requests.put(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}, Response: {response.text}")
    
    return None if not response.text else response.json()