```python
import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON using the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing at least 'baseUrl' and optionally 'params'.
                       Example: {'baseUrl': 'https://jsonplaceholder.typicode.com', 'params': {'page': 1}}
    
    Returns:
        dict or None: The decoded JSON response. Returns None if the response is empty (status 200 with no content).
    
    Raises:
        requests.exceptions.HTTPError: If the HTTP response status code indicates an error (e.g., 4xx, 5xx).
    """
    base_url = inputs.get('baseUrl')
    params = inputs.get('params', {})
    
    # Default to page 1 if not specified
    if 'page' not in params:
        params['page'] = 1
    
    response = requests.get(base_url, params=params)
    
    if response.status_code == 200:
        data = response.json()
        return data if data else None
    else:
        raise requests.exceptions.HTTPError(f"HTTP {response.status_code}: {response.text}")
```