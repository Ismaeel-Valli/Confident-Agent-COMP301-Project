import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the user to update.
            - new_age (int/float): New value for the age attribute.
    
    Returns:
        None if the response is empty (successful update).
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response indicates an error (status code >= 400).
    """
    resource_id = inputs.get("resource_id")
    new_age = inputs.get("new_age")
    
    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {
        "age": new_age
    }
    
    response = requests.patch(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to update user: {response.text}")
    
    return None if not response.json() else response.json()