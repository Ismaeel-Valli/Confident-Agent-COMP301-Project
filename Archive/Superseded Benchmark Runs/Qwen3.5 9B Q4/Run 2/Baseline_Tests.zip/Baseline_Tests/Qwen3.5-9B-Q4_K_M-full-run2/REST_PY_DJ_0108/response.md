```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON using the provided email and first name.
    
    Args:
        inputs (dict): A dictionary containing 'new_email' and 'new_firstName'.
        
    Returns:
        int or None: The ID of the newly created user if present in the response, 
                     None if the response is empty (successful creation without ID in body),
                     or raises an exception for unsuccessful HTTP responses.
                     
    Raises:
        requests.exceptions.HTTPError: If the HTTP status code indicates failure (4xx/5xx).
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "email": inputs["new_email"],
        "firstName": inputs["new_firstName"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code >= 400:
        raise requests.exceptions.HTTPError(f"HTTP Error: {response.status_code} - {response.text}")
        
    # DummyJSON typically returns the created object with an 'id' field.
    # However, the instruction says "Return None for a successful empty response."
    # We check if 'id' is present in the response JSON.
    data = response.json()
    
    if not data:
        return None
        
    if "id" in data:
        return data["id"]
    else:
        return None
```