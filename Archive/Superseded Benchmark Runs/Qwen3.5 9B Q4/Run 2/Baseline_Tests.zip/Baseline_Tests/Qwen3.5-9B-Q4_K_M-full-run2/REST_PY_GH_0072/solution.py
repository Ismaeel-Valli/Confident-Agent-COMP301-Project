import requests

def solve(inputs):
    """
    Fetches a specific commit from a GitHub repository using the GitHub REST API.
    
    Parameters:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - page (int): The page number of the results to fetch.
            - ref (str): The commit reference (e.g., branch name, tag, or SHA).
            - credential (dict): Caller-supplied credentials (assumed to have necessary permissions).
    
    Returns:
        dict or None: The decoded JSON response if successful. Returns None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    page = inputs["page"]
    ref = inputs["ref"]
    credential = inputs["credential"]

    # Construct the API URL for fetching a commit by SHA or ref
    url = f"https://api.github.com/repos/{owner}/{repo}/commits/{ref}"

    headers = {
        "Accept": "application/vnd.github+json"
    }

    # Add authentication header if credentials are provided (e.g., Bearer token)
    if credential and credential.get("token"):
        headers["Authorization"] = f"Bearer {credential['token']}"

    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        raise Exception(f"Failed to fetch commit. Status code: {response.status_code}, Response: {response.text}")

    return response.json() if response.text.strip() else None