```python
import requests

def solve(inputs):
    """
    Lists the people a GitHub user follows using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The handle for the GitHub user account.
            - 'credential' (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        list or None: Decoded JSON response as a list of followed users, or None if empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    username = inputs['username']
    credential = inputs['credential']
    
    # Construct the API URL for following users (GitHub v2026-03-10)
    url = f"https://api.github.com/users/{username}/following"
    
    headers = {
        'Accept': 'application/vnd.github.v3+json'
    }
    
    # Prepare authentication using the provided credential
    auth = requests.auth.HTTPBasicAuth(credential.get('login'), credential.get('password'))
    
    response = requests.get(url, headers=headers, auth=auth)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch followed users. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Return None for an empty list (successful but no following users)
    return None if len(data) == 0 else data
```