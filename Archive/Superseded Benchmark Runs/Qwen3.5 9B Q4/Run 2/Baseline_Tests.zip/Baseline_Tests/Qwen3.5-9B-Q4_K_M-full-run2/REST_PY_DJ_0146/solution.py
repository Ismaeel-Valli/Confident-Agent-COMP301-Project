import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on sorting criteria.
    
    Args:
        inputs (dict): A dictionary containing:
            - sort_field (str): Field used for ordering.
            - sort_direction (str): Ordering direction ('asc' or 'desc').
    
    Returns:
        list or None: The decoded JSON response as a list of posts, or None if the response is empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/posts"
    
    # Construct query parameters
    params = {
        "_limit": 1,  # Retrieve one page (one item)
        "_sort": inputs["sort_field"],
        "_order": inputs["sort_direction"]
    }
    
    url = f"{base_url}{endpoint}"
    
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
            
        return data
    
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Failed to retrieve posts: {e}") from e