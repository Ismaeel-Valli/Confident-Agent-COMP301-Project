```python
import requests
import json


def solve(inputs):
    """
    Submits a new user to DummyJSON using the provided first and last name.
    
    Args:
        inputs (dict): A dictionary containing 'new_firstName' and 'new_lastName'.
        
    Returns:
        None if the response is empty (successful submission).
        The decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "name": f"{inputs['new_firstName']} {inputs['new_lastName']}",
        "email": "test@example.com",
        "address": {
            "street": "Test Street",
            "suite": "Apt. 1234",
            "city": "New York",
            "zipcode": "10001",
            "geo": {
                "lat": "48.14963",
                "lng": "-123.75118"
            }
        },
        "phone": "1-202-555-5555",
        "website": "test-site.com"
    }

    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. Status code: {response.status_code}")
    
    return None
```