import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON based on the provided sort field.
    
    Args:
        inputs (dict): A dictionary containing 'sort_field' for ordering products.
        
    Returns:
        list or None: The decoded JSON response as a list of products, or None if the response is empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    sort_field = inputs.get('sort_field')
    
    # Construct the API URL with the sort parameter
    url = f"https://jsonplaceholder.typicode.com/products?sort={sort_field}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        data = response.json()
        
        # Return None if the response is empty (though typically this endpoint doesn't return empty lists)
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Failed to retrieve products: {str(e)}") from e