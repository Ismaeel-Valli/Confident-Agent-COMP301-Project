```python
import requests

def solve(inputs):
    """
    Deletes a label from a GitHub repository using the REST API.
    
    Parameters:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'name' (str): The name of the label to delete.
            - 'credential' (dict): Caller-supplied credentials with necessary permissions.
    
    Returns:
        int: The successful HTTP status code (e.g., 204 for No Content).
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs['repository_owner']
    repository_name = inputs['repository_name']
    label_name = inputs['name']
    credential = inputs['credential']

    # Construct the API URL for deleting a label
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/labels/{label_name}"

    # Prepare headers with authentication using the provided credential
    headers = {
        'Authorization': f'Bearer {credential.get("token", "")}',
        'Accept': 'application/vnd.github+json'
    }

    # Send DELETE request
    response = requests.delete(url, headers=headers)

    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()

    return response.status_code
```