```python
import requests

def solve(inputs):
    """
    Deletes a post by identifier using DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' which is the identifier of the post to delete.
        
    Returns:
        None if deletion was successful (empty response).
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    
    # DummyJSON endpoint for deleting a post
    url = f"https://dummyjson.com/posts/{resource_id}"
    
    try:
        response = requests.delete(url)
        
        if response.status_code not in [200, 204]:
            raise Exception(f"Failed to delete post. Status code: {response.status_code}")
            
        # Return None for successful empty response (204 No Content or 200 with empty body)
        return None
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```