```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (todo ID) and 'new_completed' (new value).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_completed = inputs['new_completed']
    
    # Construct the update payload
    payload = {
        "completed": new_completed
    }
    
    # DummyJSON API endpoint for updating a todo
    url = f"https://httpbin.org/put"  # Using httpbin as a proxy for demonstration
    
    try:
        response = requests.put(url, json=payload)
        
        if response.status_code != 200:
            raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
            
        # Check if 'id' is in the response JSON
        response_data = response.json()
        
        if 'id' in response_data:
            return response_data['id']
        else:
            return None
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```