import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing 'page' key for pagination.
        
    Returns:
        list or None: Decoded JSON response as a list, or None if the response is empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    page = inputs.get('page', 1)
    
    url = f"{base_url}/products?page={page}"
    
    try:
        response = requests.get(url, timeout=5)
        response.raise_for_status()
        
        data = response.json()
        
        # Return None for successful empty response
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Failed to retrieve products: {str(e)}")