import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on pagination inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip (for pagination).
    
    Returns:
        list or None: The decoded JSON response as a list of users, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code 4xx or 5xx).
    """
    base_url = "https://jsonplaceholder.typicode.com/users"
    
    # DummyJSON typically uses query parameters for pagination in similar contexts, 
    # but since the prompt specifies "DummyJSON" and standard JSONPlaceholder doesn't support 
    # 'skip'/'limit' directly via params in a single call without custom endpoints, 
    # we assume a hypothetical endpoint or behavior where these params are accepted.
    # However, to strictly follow common DummyJSON patterns (like jsonplaceholder), 
    # we'll construct the request assuming an endpoint that supports these params.
    
    # Note: Standard JSONPlaceholder does not support 'skip' and 'limit' in a single GET call for users.
    # But since the problem says "DummyJSON", we assume it has an endpoint like:
    # GET /users?result_limit={limit}&results_to_skip={skip}
    
    url = f"{base_url}?result_limit={inputs['result_limit']}&results_to_skip={inputs['results_to_skip']}"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # Return None for a successful empty response
    if not data:
        return None
    
    return data