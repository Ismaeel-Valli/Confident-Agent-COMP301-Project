```python
import requests

def solve(inputs):
    """
    Fetches a specific issue from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'issue_number' (int): The issue number to fetch.
            - 'credential' (dict): A dictionary containing authentication details, 
                                  expected to have 'token' and 'api_url'.
    
    Returns:
        dict or None: The decoded JSON response if successful. Returns None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    issue_number = inputs['issue_number']
    credential = inputs['credential']
    
    # Construct the API URL for fetching an issue
    # Format: https://api.github.com/repos/{owner}/{repo}/issues/{number}
    url = f"{credential['api_url']}/repos/{owner}/{repo}/issues/{issue_number}"
    
    headers = {
        'Accept': 'application/vnd.github.v3+json'
    }
    
    # Prepare authentication headers based on the provided credential structure
    # Assuming 'credential' contains a 'token' key for Bearer authentication
    auth_headers = {}
    if 'token' in credential:
        auth_headers['Authorization'] = f"Bearer {credential['token']}"
    
    response = requests.get(url, headers={**headers, **auth_headers})
    
    # Check for unsuccessful HTTP response
    if not response.ok:
        raise Exception(f"Failed to fetch issue. Status code: {response.status_code}, Response: {response.text}")
    
    # Decode the JSON response
    json_response = response.json()
    
    # Return None for a successful empty response
    if not json_response:
        return None
    
    return json_response
```