import requests
from requests.exceptions import RequestException, HTTPError

def solve(inputs):
    """
    Creates an issue comment on a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository without the .git extension.
            - 'issue_number' (int): The number that identifies the issue.
            - 'new_body' (str): The value for the body attribute of the comment.
            - 'credential' (dict): Caller-supplied credential information (e.g., token).
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs['repository_owner']
    repository_name = inputs['repository_name']
    issue_number = inputs['issue_number']
    new_body = inputs['new_body']
    credential = inputs['credential']

    # Construct the URL for creating an issue comment
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/issues/{issue_number}/comments"

    # Prepare headers with authentication
    headers = {
        "Authorization": f"token {credential.get('token', '')}",
        "Accept": "application/vnd.github.v3+json"
    }

    # Prepare the payload
    data = {
        "body": new_body
    }

    try:
        response = requests.post(url, headers=headers, json=data)
        
        if response.status_code == 201:
            # GitHub typically returns an empty body for successful POST to comments endpoint
            return None
        elif response.status_code >= 400:
            response.raise_for_status()
        else:
            response.raise_for_status()
            
    except HTTPError as http_err:
        raise Exception(f"HTTP error occurred: {http_err}")
    except RequestException as req_err:
        raise Exception(f"Request error occurred: {req_err}")

    # This part should theoretically not be reached given the logic above, but included for completeness
    return response.json() if response.status_code == 200 else None