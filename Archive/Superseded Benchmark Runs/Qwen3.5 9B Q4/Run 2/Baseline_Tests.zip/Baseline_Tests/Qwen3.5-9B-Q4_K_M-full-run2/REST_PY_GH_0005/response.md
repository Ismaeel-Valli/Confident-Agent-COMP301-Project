```python
import requests
import json

def solve(inputs):
    """
    Creates an organization repository on GitHub using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization': The organization name (string).
            - 'new_name': The desired name for the new repository (string).
            - 'credential': A dictionary with authentication details (e.g., token or username/password).
    
    Returns:
        dict or None: The decoded JSON response from the API. Returns None if the response is empty (success).
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    organization = inputs['organization']
    new_name = inputs['new_name']
    credential = inputs['credential']

    # Construct the API URL for creating a repository in an organization
    # GitHub REST API v2026-03-10 endpoint: POST /orgs/{org}/repos
    url = f"https://api.github.com/orgs/{organization}/repos"
    
    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Determine the authentication method based on the credential structure
    if 'token' in credential:
        auth_header = f"Bearer {credential['token']}"
    elif 'username' in credential and 'password' in credential:
        auth_header = requests.auth.HTTPBasicAuth(credential['username'], credential['password'])
    else:
        raise ValueError("Unsupported credential format. Expected 'token' or 'username/password'.")

    # Prepare the payload for creating the repository
    payload = {
        "name": new_name,
        "auto_init": False  # Optional: set to True if you want an initial README.md
    }

    try:
        response = requests.post(url, headers=headers, auth=auth_header, json=payload)
        
        # Check for successful HTTP status codes (200-299)
        if response.status_code < 300:
            decoded_response = response.json()
            # GitHub typically returns an empty object {} on success for this endpoint
            return None if decoded_response == {} else decoded_response
        else:
            # Raise an exception for unsuccessful responses
            raise Exception(f"Failed to create repository. Status code: {response.status_code}, Response: {response.text}")

    except requests.exceptions.RequestException as e:
        raise Exception(f"Network error occurred while creating repository: {str(e)}")
```