```python
import requests

def solve(inputs):
    """
    Lists commits on a pull request using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - pull_number (int): The number that identifies the pull request.
            - credential (dict): Caller-supplied credentials (e.g., token in 'token' key).
    
    Returns:
        list or None: A list of commit data dictionaries if commits exist, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    pr_number = inputs["pull_number"]
    credential = inputs["credential"]
    
    # Construct the API URL for GitHub version 2026-03-10 (URL structure remains consistent)
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}/commits"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare authentication based on common credential formats (e.g., token)
    auth_header = None
    if isinstance(credential, dict):
        if "token" in credential:
            auth_header = f"Bearer {credential['token']}"
        elif "username" in credential and "password" in credential:
            # Basic auth fallback if token is not provided
            auth_header = f"Basic {requests.utils.quote(f'{credential["username"]}:{credential["password"]}").encode("ascii").decode("utf-8")}"
    
    response = requests.get(url, headers=headers, auth=auth_header)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch commits: HTTP {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response (empty list)
    if not data:
        return None
    
    return data
```