```python
import requests

def solve(inputs):
    """
    Deletes a milestone from a GitHub repository using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'milestone_number' (int): The number identifying the milestone.
            - 'credential' (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        int: The successful HTTP status code (e.g., 204).
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful operation.
    """
    repository_owner = inputs['repository_owner']
    repository_name = inputs['repository_name']
    milestone_number = inputs['milestone_number']
    credential = inputs['credential']
    
    # Construct the API URL for deleting a milestone
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/milestones/{milestone_number}"
    
    headers = {
        'Accept': 'application/vnd.github+json'
    }
    
    # Prepare authentication if provided (assuming token in credential)
    auth_header = None
    if 'token' in credential:
        auth_header = {'Authorization': f'token {credential["token"]}'}
    
    response = requests.delete(url, headers=headers, auth=auth_header)
    
    if response.status_code == 204:
        return 204
    else:
        raise Exception(f"Failed to delete milestone. Status code: {response.status_code}, Response: {response.text}")
```