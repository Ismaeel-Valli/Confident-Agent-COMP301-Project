```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API with the provided first name.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' key.
        
    Returns:
        int or None: The ID of the created user, or None if response is empty.
        
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "name": inputs.get("new_firstName"),
        "email": "test@example.com",  # Dummy email as required by API
        "address": {
            "street": "Dummy Street",
            "suite": "Apt. 0",
            "city": "Dummytown",
            "zipcode": "12345",
            "geo": {
                "lat": "20.2129",
                "lng": "-166.7100"
            }
        },
        "phone": "1-11-1111111111",
        "website": "example.com",
        "company": {
            "name": "Dummy Corp",
            "catchPhrase": "Dummy phrase",
            "bs": "Dummy"
        }
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    if not data:
        return None
    
    return data.get("id")
```