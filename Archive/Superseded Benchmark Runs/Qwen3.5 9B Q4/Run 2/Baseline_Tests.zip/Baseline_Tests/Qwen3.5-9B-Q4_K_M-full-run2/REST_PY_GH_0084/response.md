```python
import requests

def solve(inputs):
    """
    Updates a milestone in a GitHub repository using the REST API.
    
    Parameters:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - milestone_number (int): The number identifying the milestone.
            - new_state (str): The new state for the milestone ('open' or 'closed').
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    milestone_number = inputs["milestone_number"]
    new_state = inputs["new_state"]
    credential = inputs["credential"]

    # Construct the API URL for updating a milestone
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/milestones/{milestone_number}"

    # Prepare headers with authentication
    headers = {
        "Authorization": f"token {credential['token']}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Payload to update the milestone state
    payload = {
        "state": new_state
    }

    response = requests.put(url, headers=headers, json=payload)

    if response.status_code == 200:
        return None  # Successful empty response
    elif response.status_code == 204:
        return None  # No content but success
    else:
        raise Exception(f"Failed to update milestone. Status code: {response.status_code}, Response: {response.text}")
```