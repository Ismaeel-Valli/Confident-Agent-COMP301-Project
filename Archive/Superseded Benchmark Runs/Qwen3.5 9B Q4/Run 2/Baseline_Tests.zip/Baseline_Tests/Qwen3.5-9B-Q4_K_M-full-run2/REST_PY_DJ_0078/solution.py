import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON using the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'new_age' and 'new_firstName'.
        
    Returns:
        None if the response is empty (successful submission).
        The decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "name": inputs.get("new_firstName"),
        "age": inputs.get("new_age")
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. Status code: {response.status_code}")
    
    # DummyJSON typically returns an empty body for POST requests on /users
    if not response.text.strip():
        return None
    
    return response.json()