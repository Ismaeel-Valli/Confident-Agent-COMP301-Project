import requests

def solve(inputs):
    """
    Submits a new todo to DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'new_completed': value for the completed attribute (bool)
            - 'new_todo': value for the todo attribute (str)
            - 'new_user_identifier': value for the user Id attribute (str)
            
    Returns:
        None if the response is successfully empty.
        The decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    url = "https://jsonplaceholder.typicode.com/todos"
    
    payload = {
        "userId": inputs["new_user_identifier"],
        "id": None,  # DummyJSON will auto-increment or handle this
        "title": inputs["new_todo"],
        "completed": inputs["new_completed"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create todo. Status code: {response.status_code}, Response: {response.text}")
    
    # DummyJSON returns an empty body on successful creation of a POST resource
    if not response.text.strip():
        return None
    
    return response.json()