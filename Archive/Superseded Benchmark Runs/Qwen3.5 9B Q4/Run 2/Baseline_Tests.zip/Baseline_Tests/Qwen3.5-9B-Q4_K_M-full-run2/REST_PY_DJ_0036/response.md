```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_title' (new title).
        
    Returns:
        str or None: The response's 'id' value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    new_title = inputs.get('new_title')
    
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    data = {"title": new_title}
    
    response = requests.put(url, json=data)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update post: {response.status_code} - {response.text}")
    
    # DummyJSON sometimes returns an empty body on successful PUT for this endpoint
    if not response.json():
        return None
    
    return response.json().get('id')
```