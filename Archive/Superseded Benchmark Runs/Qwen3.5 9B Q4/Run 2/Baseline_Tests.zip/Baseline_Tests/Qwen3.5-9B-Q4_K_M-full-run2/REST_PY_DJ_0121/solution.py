import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON.
    
    Inputs:
        inputs['resource_id']: Identifier of the todo (e.g., '/todos/1')
        inputs['new_todo']: New value for the 'todo' attribute
        inputs['new_user_identifier']: New value for the 'userId' attribute
    
    Returns:
        None if the response is empty (successful update).
        The decoded JSON response otherwise.
    
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_todo = inputs['new_todo']
    new_user_identifier = inputs['new_user_identifier']

    # Construct the URL for updating the specific todo
    url = f"https://jsonplaceholder.typicode.com{resource_id}"

    payload = {
        "todo": new_todo,
        "userId": new_user_identifier
    }

    response = requests.put(url, json=payload)

    if response.status_code != 200:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}, Response: {response.text}")

    # DummyJSON often returns an empty body on successful PUT/POST for updates
    if not response.text.strip():
        return None

    return response.json()