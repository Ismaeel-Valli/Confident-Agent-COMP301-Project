```python
import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"Failed to retrieve todo with ID {resource_id}: HTTP {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns {"todos": [], "count": 0, ...} for empty results or specific structure
    # Based on typical DummyJSON behavior for a single item:
    # If the todo exists, it returns the todo object.
    # If not found (404), we would have raised an exception above.
    # However, sometimes "empty response" might mean the data dict is empty or specific fields are missing.
    # The instruction says "Return None for a successful empty response".
    # Let's assume if the returned JSON object itself is effectively empty (e.g., no 'id' key or similar), return None.
    
    # A safer interpretation for DummyJSON single item endpoint:
    # It returns the todo object directly. If the list was empty and we asked for an ID, it would be 404.
    # But let's check if the response data is "empty" in a meaningful way.
    # Often, an empty response might look like {"todos": []} but that's for /todos endpoint.
    # For /todos/{id}, success returns the todo object.
    
    # Re-reading: "Return None for a successful empty response."
    # This likely means if the JSON body is empty (e.g., {}).
    
    if not data or len(data) == 0:
        return None
    
    return data
```