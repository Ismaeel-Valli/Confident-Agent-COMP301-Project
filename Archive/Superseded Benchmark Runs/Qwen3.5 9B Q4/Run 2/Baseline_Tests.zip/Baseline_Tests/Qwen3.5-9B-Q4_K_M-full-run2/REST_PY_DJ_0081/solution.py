import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on pagination parameters.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip (for pagination).
    
    Returns:
        list or None: The decoded JSON response as a list of todos, or None if the response is empty.
    
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/todos"
    
    params = {
        "_limit": inputs.get("result_limit"),
        "_skip": inputs.get("results_to_skip")
    }
    
    try:
        response = requests.get(f"{base_url}{endpoint}", params=params)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None if the response is empty
        if not data:
            return None
            
        return data
    
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Failed to retrieve todos: {e}") from e