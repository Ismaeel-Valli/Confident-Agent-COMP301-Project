import requests

def solve(inputs):
    resource_id = inputs.get("resource_id")
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    headers = {
        "Accept": "application/json"
    }
    
    response = requests.delete(url, headers=headers)
    
    if response.status_code not in [200, 204]:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    if "id" in data:
        return data["id"]
    elif response.status_code == 204:
        return None
    
    return None