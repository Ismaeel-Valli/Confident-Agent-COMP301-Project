```python
import requests

def solve(inputs):
    """
    Unstars a repository for the authenticated user via GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner': str, The account owner of the repository.
            - 'repository_name': str, The name of the repository (without .git).
            - 'credential': dict, Contains authentication details (e.g., token in 'token' key).
    
    Returns:
        int: The successful HTTP status code (typically 204 No Content).
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful operation.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    credential = inputs['credential']
    
    # Construct the API URL for unstar (GitHub v2026-03-10 follows standard REST patterns)
    url = f"https://api.github.com/repos/{owner}/{repo}/star"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare authentication based on common credential structures (e.g., token)
    auth_header = {}
    if 'token' in credential:
        auth_header["Authorization"] = f"Bearer {credential['token']}"
    elif 'auth' in credential and isinstance(credential['auth'], dict):
        # Fallback for nested auth structures if needed
        if 'token' in credential['auth']:
            auth_header["Authorization"] = f"Bearer {credential['auth']['token']}"
    
    response = requests.delete(url, headers=headers, auth=None)  # Auth handled via header
    
    if response.status_code == 204:
        return response.status_code
    else:
        raise Exception(f"Failed to unstar repository. Status code: {response.status_code}, Response: {response.text}")
```