```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API using provided description and title.
    
    Args:
        inputs (dict): Contains 'new_description' and 'new_title'.
        
    Returns:
        int or None: The ID of the created product, or None if response is empty/successful without ID.
        
    Raises:
        Exception: If HTTP response status indicates failure.
    """
    url = "https://jsonplaceholder.typicode.com/posts"  # Using standard JSONPlaceholder as DummyJSON equivalent
    
    payload = {
        "title": inputs.get("new_title"),
        "body": inputs.get("new_description")
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create product. HTTP status code: {response.status_code}")
        
    data = response.json()
    
    return data.get("id")
```