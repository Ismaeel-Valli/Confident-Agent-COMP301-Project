import requests

def solve(inputs):
    """
    Lists followers of a GitHub user using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The handle for the GitHub user account.
            - 'credential' (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        list or None: Decoded JSON response as a list of followers, or None if the list is empty.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    username = inputs['username']
    credential = inputs['credential']
    
    # Construct the API URL for listing followers
    url = f"https://api.github.com/users/{username}/followers"
    
    # Prepare headers with authentication using the provided credential
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential.get('token', '')}" if isinstance(credential, dict) else ""
    }
    
    response = requests.get(url, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    data = response.json()
    
    # Return None for a successful empty response
    return data if data else None