import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API with provided category and title.
    
    Args:
        inputs (dict): Dictionary containing 'new_category' and 'new_title'.
        
    Returns:
        int or None: The ID of the created product, or None if response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": inputs.get("new_title"),
        "body": inputs.get("new_category")  # Using category as body since DummyJSON posts require it
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create product. Status code: {response.status_code}")
    
    data = response.json()
    
    # If the response has an 'id' field, return it
    if "id" in data:
        return data["id"]
    
    # Return None for successful empty response (though unlikely with this API)
    return None