```python
import requests

def solve(inputs):
    """
    Lists followers of a GitHub user using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The GitHub username.
            - 'page_size' (int): Number of results per page (max 100).
            - 'credential' (str): Bearer token for authentication.
    
    Returns:
        dict or None: Decoded JSON response, or None if the response is empty but successful.
    
    Raises:
        Exception: If the HTTP response status code indicates an error.
    """
    username = inputs['username']
    page_size = inputs['page_size']
    credential = inputs['credential']
    
    url = f"https://api.github.com/users/{username}/followers"
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json"
    }
    
    params = {
        "per_page": page_size
    }
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch followers for user '{username}': HTTP {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # GitHub returns an empty list [] when there are no followers, which is a successful response.
    if not data:
        return None
    
    return data
```