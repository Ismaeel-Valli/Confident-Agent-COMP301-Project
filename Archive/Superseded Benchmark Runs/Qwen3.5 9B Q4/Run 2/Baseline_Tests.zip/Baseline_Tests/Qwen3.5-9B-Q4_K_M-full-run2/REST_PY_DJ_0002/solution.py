import requests

def solve(inputs):
    """
    Retrieves a product by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with the product identifier.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON endpoint to get a single product by ID
    url = f"https://jsonplaceholder.typicode.com/products/{resource_id}"
    
    try:
        response = requests.get(url)
        
        if response.status_code != 200:
            raise Exception(f"HTTP Error {response.status_code}: {response.text}")
        
        # Decode JSON response
        data = response.json()
        
        # Return None for empty response, otherwise return the data
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")