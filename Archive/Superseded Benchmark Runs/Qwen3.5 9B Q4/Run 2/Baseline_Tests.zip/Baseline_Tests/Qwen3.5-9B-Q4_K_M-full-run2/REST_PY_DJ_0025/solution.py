import requests

def solve(inputs):
    resource_id = inputs.get('resource_id')
    
    url = f"https://dummyjson.com/products/{resource_id}"
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # Check for successful empty response (id might be null or missing in some cases, but typically empty product list has no items)
    # However, the endpoint /products/{id} returns a single product object. 
    # If the product exists but has no attributes? The problem says "Return None for a successful empty response."
    # Assuming "empty response" means the JSON body is effectively empty or lacks an 'id'.
    
    if not data:
        return None
    
    id_value = data.get('id')
    
    if id_value is None:
        return None
        
    return id_value