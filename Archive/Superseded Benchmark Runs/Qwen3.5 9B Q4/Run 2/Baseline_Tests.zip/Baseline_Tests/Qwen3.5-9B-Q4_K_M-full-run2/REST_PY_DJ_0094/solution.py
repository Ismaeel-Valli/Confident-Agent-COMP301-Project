import requests

def solve(inputs):
    """
    Updates selected fields of a product using DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (product ID) and 'new_price' (new price value).
        
    Returns:
        None if the update is successful (empty response body).
        The decoded JSON response if there's an error message from the server.
        
    Raises:
        Exception for unsuccessful HTTP responses (non-2xx status codes).
    """
    resource_id = inputs['resource_id']
    new_price = inputs['new_price']
    
    # DummyJSON PATCH endpoint to update a product field
    url = f"https://dummyjson.com/products/{resource_id}"
    
    payload = {
        "price": new_price
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.patch(url, json=payload, headers=headers)
    
    if response.status_code == 204:
        # No content returned on success for this specific endpoint behavior
        return None
    elif response.status_code == 200:
        # If the server returns updated data
        return response.json()
    else:
        raise Exception(f"HTTP {response.status_code}: {response.text}")