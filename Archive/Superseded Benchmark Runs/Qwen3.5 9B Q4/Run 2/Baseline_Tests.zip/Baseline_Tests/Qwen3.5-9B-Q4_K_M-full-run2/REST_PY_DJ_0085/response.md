```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API using provided description and title.
    
    Args:
        inputs (dict): Contains 'new_description' and 'new_title'.
        
    Returns:
        str: The response's title value if present, otherwise None for empty success response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": inputs["new_title"],
        "body": inputs["new_description"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code != 201:
            raise Exception(f"Failed to create product. Status code: {response.status_code}")
            
        # DummyJSON returns the created object in the response body for POST/PUT operations
        data = response.json()
        
        return data.get("title")
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```