```python
import requests

def solve(inputs):
    """
    Fetches issue comments from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git extension).
            - issue_number (int): The number that identifies the issue.
            - credential (str): The caller-supplied credential (e.g., Bearer token or OAuth token).
    
    Returns:
        list|None: A list of decoded JSON responses for each comment, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}/comments"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to fetch issue comments. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    return None if not data else data
```