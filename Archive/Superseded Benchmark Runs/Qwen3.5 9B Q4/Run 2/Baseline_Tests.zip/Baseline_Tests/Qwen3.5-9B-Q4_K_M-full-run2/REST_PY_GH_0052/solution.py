import requests
from requests.exceptions import RequestException, HTTPError

def solve(inputs):
    """
    Updates the authenticated user's name via GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'new_name' (str): The new name for the authenticated user.
            - 'credential' (str): The authentication token or header value.
    
    Returns:
        None if the response is empty (success).
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    new_name = inputs['new_name']
    credential = inputs['credential']
    
    # GitHub API endpoint to update user info
    url = "https://api.github.com/user"
    
    headers = {
        'Authorization': f'token {credential}',
        'Accept': 'application/vnd.github+json'
    }
    
    payload = {
        'name': new_name
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code == 204:
        return None
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user: {response.status_code} - {response.text}")
    
    try:
        return response.json()
    except ValueError:
        # If JSON parsing fails but status is 200, return raw text as fallback
        return response.text