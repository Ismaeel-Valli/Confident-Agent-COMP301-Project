import requests

def solve(inputs):
    """
    Fetches a GitHub repository using the specified credentials and repository details.
    
    Parameters:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The caller-supplied credential (e.g., token or Bearer token).
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo_name = inputs["repository_name"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{owner}/{repo_name}"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json"
    }

    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        raise Exception(f"Failed to fetch repository: HTTP {response.status_code}, Body: {response.text}")

    return response.json() if response.text.strip() else None