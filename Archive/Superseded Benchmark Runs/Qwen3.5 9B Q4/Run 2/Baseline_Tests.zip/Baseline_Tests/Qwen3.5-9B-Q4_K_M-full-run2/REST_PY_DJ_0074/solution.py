import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_description'.
        
    Returns:
        str or None: The response's id value, or None if absent or for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_description = inputs['new_description']
    
    # Construct the payload for updating the product
    payload = {
        "description": new_description
    }
    
    # Endpoint to update a product (assuming standard DummyJSON structure)
    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.put(url, json=payload)
        
        if response.status_code == 200:
            # Check if the response is empty or doesn't contain an 'id'
            data = response.json()
            if not data:
                return None
            return data.get('id')
        elif response.status_code == 404:
            # Resource not found, but per instructions we assume resources exist.
            # However, if it happens, treat as unsuccessful.
            raise Exception(f"Resource not found: {resource_id}")
        else:
            raise Exception(f"Failed to update product: HTTP {response.status_code}, Response: {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Network error occurred: {str(e)}")