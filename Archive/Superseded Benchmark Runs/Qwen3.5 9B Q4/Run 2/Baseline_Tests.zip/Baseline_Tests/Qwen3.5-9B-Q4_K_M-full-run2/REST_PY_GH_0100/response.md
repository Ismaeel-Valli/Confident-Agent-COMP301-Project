```python
import requests
from typing import Any, Dict, Optional

def solve(inputs: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Lists repositories for a GitHub user based on the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The handle for the GitHub user account.
            - 'type' (str): Limit results to repositories of the specified type ('all', 'owner', or 'public').
            - 'credential' (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        Optional[Dict[str, Any]]: The decoded JSON response from the GitHub API. 
                                  Returns None for a successful empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    username = inputs["username"]
    repo_type = inputs["type"]
    credential = inputs["credential"]
    
    # Construct the URL for listing user repositories
    url = f"https://api.github.com/users/{username}/repos"
    
    # Prepare headers with authentication using the provided credential
    headers = {
        "Authorization": f"Bearer {credential.get('token', '')}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Add query parameter for repository type if specified and not 'all' (default)
    params = {}
    if repo_type != "all":
        params["type"] = repo_type
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Failed to list repositories for user '{username}'. HTTP Status Code: {response.status_code}")
    
    data = response.json()
    
    # Return None if the response is empty (successful but no repositories found)
    if not data:
        return None
    
    return data
```