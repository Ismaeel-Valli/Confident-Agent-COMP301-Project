import requests
from urllib.parse import quote

def solve(inputs):
    """
    Updates the name of a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - new_name (str): The new value for the name attribute.
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    new_name = inputs["new_name"]
    credential = inputs["credential"]
    
    # Construct the API URL for updating a repository name (GitHub REST API v2026-03-10)
    url = f"https://api.github.com/repos/{quote(repository_owner, safe='')}/{quote(repository_name, safe='')}'"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential['token']}" if credential.get("token") else "",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    payload = {
        "name": new_name
    }
    
    response = requests.patch(url, json=payload, headers=headers)
    
    if response.status_code == 200:
        return None  # Successful empty response
    elif response.status_code == 204:
        return None  # No content response is also considered successful
    else:
        raise Exception(f"Failed to update repository name. Status code: {response.status_code}, Response: {response.text}")