import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_category'.
        
    Returns:
        str or None: The title value from the response, or None if absent or empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_category = inputs['new_category']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {
        "category": new_category
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP request failed with status code: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns an empty object {} on successful update
    if not data or len(data) == 0:
        return None
    
    title = data.get('title')
    return title