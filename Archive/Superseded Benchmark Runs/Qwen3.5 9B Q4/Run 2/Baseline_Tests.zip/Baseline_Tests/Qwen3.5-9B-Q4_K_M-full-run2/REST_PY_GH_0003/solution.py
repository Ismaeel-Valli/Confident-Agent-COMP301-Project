import requests
from requests.exceptions import RequestException, HTTPError

def solve(inputs):
    """
    Deletes an organization using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The name of the organization to delete.
            - 'credential' (dict): Caller-supplied credentials with necessary permissions.
    
    Returns:
        None if the deletion is successful (empty response).
        The decoded JSON response if the API returns a non-empty response.
    
    Raises:
        Exception for unsuccessful HTTP responses or request errors.
    """
    organization = inputs['organization']
    credential = inputs['credential']
    
    # Construct the authentication header using the provided credentials
    # Assuming 'credential' contains 'token' for Bearer authentication
    auth_header = {
        "Authorization": f"Bearer {credential.get('token', '')}"
    }
    
    url = f"https://api.github.com/orgs/{organization}"
    
    try:
        response = requests.delete(url, headers=auth_header)
        
        # Raise an exception for any HTTP error status code (4xx, 5xx)
        response.raise_for_status()
        
        # If the response is empty (successful deletion), return None
        if not response.content:
            return None
        
        # Otherwise, return the decoded JSON response
        return response.json()
        
    except HTTPError as http_err:
        raise Exception(f"HTTP error occurred: {http_err}")
    except RequestException as req_err:
        raise Exception(f"A request error occurred: {req_err}")