import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (product ID) and 'new_title' (new title value).
        
    Returns:
        str or None: The response's title value if present, otherwise None for successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_title = inputs['new_title']
    
    # Construct the URL for updating a product (assuming standard DummyJSON structure)
    url = f"https://jsonplaceholder.typicode.com/products/{resource_id}"
    
    payload = {
        "title": new_title
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product. Status code: {response.status_code}, Response: {response.text}")
    
    # DummyJSON typically returns the updated object or an empty object on success
    data = response.json()
    
    title_value = data.get("title")
    
    if title_value is None and not data:  # If title is absent or response is empty
        return None
    
    return title_value