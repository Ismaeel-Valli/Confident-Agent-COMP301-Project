import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_lastName'.
        
    Returns:
        None if the response is empty (successful update).
        The decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_last_name = inputs['new_lastName']
    
    url = f"https://jsonplaceholder.typicode.com/users/{resource_id}"
    
    payload = {
        "lastName": new_last_name
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user. Status code: {response.status_code}, Response: {response.text}")
    
    return None