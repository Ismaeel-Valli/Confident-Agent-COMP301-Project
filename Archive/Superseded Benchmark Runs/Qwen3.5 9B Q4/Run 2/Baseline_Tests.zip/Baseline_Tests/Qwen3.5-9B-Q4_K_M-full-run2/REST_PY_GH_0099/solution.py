import requests

def solve(inputs):
    """
    Lists the people a GitHub user follows using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - username (str): The handle for the GitHub user account.
            - page_size (int): The number of results per page (max 100).
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response, or None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    username = inputs["username"]
    page_size = inputs["page_size"]
    credential = inputs["credential"]
    
    # Construct the API URL for following users (version 2026-03-10)
    url = f"https://api.github.com/users/{username}/following"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # If credential contains a token, add it to headers
    if isinstance(credential, dict) and "token" in credential:
        headers["Authorization"] = f"Bearer {credential['token']}"
    
    params = {"per_page": page_size}
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # Return None for a successful empty response
    if not data:
        return None
    
    return data