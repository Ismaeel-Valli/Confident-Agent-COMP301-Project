```python
import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'results_to_skip' (int).
        
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    todos_endpoint = f"{base_url}/todos?skip={inputs['results_to_skip']}&_limit=1"
    
    try:
        response = requests.get(todos_endpoint)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # If the response is empty, return None as per instructions
        if not data:
            return None
            
        return data
        
    except requests.exceptions.HTTPError as errh:
        raise Exception(f"HTTP Error: {errh}")
    except requests.exceptions.ConnectionError as errc:
        raise Exception(f"Connection Error: {errc}")
    except requests.exceptions.Timeout as errt:
        raise Exception(f"Timeout Error: {errt}")
    except requests.exceptions.RequestException as err:
        raise Exception(f"Request Error: {err}")
```