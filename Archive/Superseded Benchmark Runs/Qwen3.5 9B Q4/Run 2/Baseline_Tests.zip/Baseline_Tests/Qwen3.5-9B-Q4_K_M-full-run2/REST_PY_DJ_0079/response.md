```python
import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on the provided sort field.
    
    Args:
        inputs (dict): A dictionary containing 'sort_field' for ordering posts.
        
    Returns:
        list or None: The decoded JSON response as a list of posts, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    # Prepare the request parameters
    params = {
        '_limit': 1,  # Retrieve one page (one post)
        '_sort': inputs.get('sort_field', 'id')  # Use the provided sort field or default to 'id'
    }
    
    try:
        response = requests.get(base_url, params=params)
        
        # Raise an exception for unsuccessful HTTP responses
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None if the response is empty
        return data if data else None
        
    except requests.exceptions.HTTPError as http_err:
        raise Exception(f"HTTP error occurred: {http_err}")
    except requests.exceptions.RequestException as req_err:
        raise Exception(f"Request error occurred: {req_err}")
```