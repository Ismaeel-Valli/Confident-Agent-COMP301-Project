import requests
import json

def solve(inputs):
    """
    Lists files changed in a specific pull request for a GitHub repository.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - pull_number (int): The number that identifies the pull request.
            - credential (dict): Caller-supplied credentials (assumed to have necessary permissions).
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    pr_number = inputs["pull_number"]
    credential = inputs["credential"]
    
    # Construct the API URL for GitHub REST API version 2026-03-10
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}/files"
    
    headers = {
        "Accept": "application/vnd.github.v3+json",
        # Assuming credential contains 'token' or similar standard GitHub token key
        "Authorization": f"Bearer {credential.get('token', '')}" 
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response (e.g., no files changed)
    if not data:
        return None
    
    return data