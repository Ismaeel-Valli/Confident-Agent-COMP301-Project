```python
import requests
import json

def solve(inputs):
    """
    Fetches the latest release from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The authentication token or header value for the API call.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    credential = inputs['credential']

    url = f"https://api.github.com/repos/{owner}/{repo}/releases/latest"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json"
    }

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        return response.json()
    elif response.status_code == 404:
        raise Exception(f"Repository not found: {owner}/{repo}")
    else:
        raise Exception(f"Failed to fetch latest release. Status code: {response.status_code}, Response: {response.text}")
```