import requests
import json

def solve(inputs):
    """
    Lists forks for a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - sort (str): The sort order for the forks list.
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: Decoded JSON response, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    sort_order = inputs["sort"]
    credential = inputs["credential"]

    # Construct the API URL for listing forks
    url = f"https://api.github.com/repos/{owner}/{repo}/forks"
    
    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "Authorization": f"Bearer {credential['token']}"
    }

    params = {"sort": sort_order}

    response = requests.get(url, headers=headers, params=params)

    if response.status_code != 200:
        raise Exception(f"Failed to list forks. HTTP Status Code: {response.status_code}, Response: {response.text}")

    # Decode the JSON response
    json_response = response.json()

    # Return None for an empty successful response
    return None if len(json_response) == 0 else json_response