```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the user.
            - new_email (str): New value for the email attribute.
    
    Returns:
        None if the response is empty (successful update).
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response indicates an error (status code >= 400).
    """
    resource_id = inputs.get("resource_id")
    new_email = inputs.get("new_email")

    if not resource_id or not new_email:
        raise ValueError("Missing required fields in inputs.")

    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {"email": new_email}

    response = requests.patch(url, json=payload)

    if response.status_code >= 400:
        response.raise_for_status()

    return None if response.text == "" else response.json()
```