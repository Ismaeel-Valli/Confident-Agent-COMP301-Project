```python
import requests

def solve(inputs):
    resource_id = inputs.get('resource_id')
    new_email = inputs.get('new_email')
    
    url = f"https://dummyjson.com/users/{resource_id}"
    headers = {
        "Content-Type": "application/json"
    }
    data = {
        "email": new_email
    }
    
    response = requests.patch(url, json=data, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user: {response.text}")
    
    if not response.json():
        return None
    
    return response.json().get('id')
```