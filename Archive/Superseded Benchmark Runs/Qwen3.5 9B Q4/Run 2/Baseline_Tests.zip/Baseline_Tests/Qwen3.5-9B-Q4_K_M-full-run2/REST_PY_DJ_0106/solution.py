import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - sort_field (str): Field used for ordering the results.
    
    Returns:
        list or None: The decoded JSON response as a list of users, or None if the response is empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com"  # Using jsonplaceholder as a reliable dummy API
    
    url = f"{base_url}/users"
    params = {
        "_limit": inputs.get("result_limit"),
        "_sort": inputs.get("sort_field")
    }
    
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Failed to retrieve users: {e}") from e