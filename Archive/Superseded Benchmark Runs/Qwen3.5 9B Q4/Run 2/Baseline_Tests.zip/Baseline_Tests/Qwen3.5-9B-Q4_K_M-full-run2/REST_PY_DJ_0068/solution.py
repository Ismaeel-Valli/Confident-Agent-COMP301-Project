import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on included fields.
    
    Args:
        inputs (dict): A dictionary containing 'included_fields' as a comma-separated string.
        
    Returns:
        dict or None: The decoded JSON response, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    included_fields = inputs.get('included_fields', '')
    
    # Construct the URL with query parameters for included fields
    url = "https://jsonplaceholder.typicode.com/posts?_limit=1"
    params = {'include': ','.join([f.strip() for f in included_fields.split(',')]) if included_fields else ''}
    
    response = requests.get(url, params=params)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Decode the JSON response
    data = response.json()
    
    # Return None for a successful empty response
    if not data:
        return None
    
    return data