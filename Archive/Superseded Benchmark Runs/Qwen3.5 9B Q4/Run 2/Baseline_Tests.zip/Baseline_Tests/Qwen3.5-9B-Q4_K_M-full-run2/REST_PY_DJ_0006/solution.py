import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API with the provided title.
    
    Args:
        inputs (dict): A dictionary containing 'new_title' for the product title.
        
    Returns:
        None if the request is successful (empty response body).
        The decoded JSON response if the server returns data.
        
    Raises:
        Exception: If the HTTP response indicates an error status code.
    """
    url = "https://dummyjson.com/products"
    
    payload = {
        "title": inputs["new_title"]
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code != 201:
        raise Exception(f"Failed to submit product. Status code: {response.status_code}, Response: {response.text}")
    
    return None