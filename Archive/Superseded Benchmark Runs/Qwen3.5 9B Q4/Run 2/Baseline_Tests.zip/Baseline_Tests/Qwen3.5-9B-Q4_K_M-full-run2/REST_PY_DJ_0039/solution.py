import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'result_limit' for maximum number of results.
        
    Returns:
        list or None: The decoded JSON response as a list of todos, or None if the response is empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/todos"
    
    # Construct the URL with query parameters
    url = f"{base_url}{endpoint}"
    
    try:
        response = requests.get(url)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None if the response is empty
        if not data:
            return None
        
        return data
    
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"HTTP request failed: {e}") from e