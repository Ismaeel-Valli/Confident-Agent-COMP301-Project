import requests

def solve(inputs):
    """
    Fetches a GitHub user by username using the specified credentials.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The GitHub username to fetch.
            - 'credential' (dict): Contains authentication details (e.g., token).
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response indicates failure (non-2xx status code).
    """
    username = inputs['username']
    credential = inputs['credential']
    
    # Construct the API URL for GitHub REST API version 2026-03-10
    url = f"https://api.github.com/users/{username}"
    
    # Prepare headers with authentication using the provided credential
    # Assuming 'credential' contains a 'token' key for Bearer authentication
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential.get('token', '')}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        return None if not data else data
    elif response.status_code >= 400:
        raise Exception(f"Failed to fetch user {username}: HTTP {response.status_code} - {response.text}")
    
    # Fallback for unexpected success codes (though per problem statement, resources exist)
    data = response.json()
    return None if not data else data