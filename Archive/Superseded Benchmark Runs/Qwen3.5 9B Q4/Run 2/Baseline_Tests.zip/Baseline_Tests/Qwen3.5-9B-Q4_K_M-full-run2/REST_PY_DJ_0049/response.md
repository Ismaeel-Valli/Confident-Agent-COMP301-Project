```python
import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on the number of results to skip.
    
    Args:
        inputs (dict): A dictionary containing 'results_to_skip' key.
        
    Returns:
        list or None: The decoded JSON response as a list of users, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    results_to_skip = inputs.get('results_to_skip', 0)
    
    # DummyJSON API endpoint for users with pagination
    url = f"https://jsonplaceholder.typicode.com/users?skip={results_to_skip}&_limit=1"
    
    try:
        response = requests.get(url)
        
        if response.status_code != 200:
            raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
        
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```