import requests
from urllib.parse import quote

def solve(inputs):
    """
    Lists forks for a given GitHub repository using the specified API version.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The caller-supplied credential (e.g., Bearer token or API key).
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    owner = inputs['repository_owner']
    repo_name = inputs['repository_name']
    credential = inputs['credential']
    
    # Construct the API URL for listing forks
    # GitHub REST API v2026-03-10 endpoint structure remains consistent with current versions
    url = f"https://api.github.com/repos/{quote(owner)}/{quote(repo_name)}/forks"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to list forks for repository {owner}/{repo_name}. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response (e.g., no forks)
    if not data:
        return None
    
    return data