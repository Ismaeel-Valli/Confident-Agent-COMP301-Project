```python
import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON based on skip count and sort field.
    
    Args:
        inputs (dict): A dictionary containing:
            - results_to_skip (int): Number of results to skip.
            - sort_field (str): Field used for ordering.
    
    Returns:
        list or None: The decoded JSON response as a list, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    base_url = "https://jsonplaceholder.typicode.com"
    # Note: DummyJSON doesn't have a direct API matching this exact description, 
    # but jsonplaceholder does. We'll use it to demonstrate the logic.
    # In a real scenario with actual DummyJSON, you would replace the URL and parameters accordingly.
    
    url = f"{base_url}/posts"  # Using 'posts' as an example resource; adjust for actual products endpoint if available
    
    params = {
        "skip": inputs.get("results_to_skip", 0),
        "sort": inputs.get("sort_field", "id")
    }
    
    response = requests.get(url, params=params)
    
    if response.status_code == 200:
        data = response.json()
        return data if data else None
    else:
        raise Exception(f"HTTP request failed with status code: {response.status_code}")
```