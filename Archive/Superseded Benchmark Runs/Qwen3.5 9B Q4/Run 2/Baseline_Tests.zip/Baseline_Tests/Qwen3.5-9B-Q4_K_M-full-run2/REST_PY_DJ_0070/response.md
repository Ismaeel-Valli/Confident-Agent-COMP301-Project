```python
import requests

def solve(inputs):
    resource_id = inputs.get("resource_id")
    
    # Assuming a base URL; adjust as needed for DummyJSON or your specific setup
    url = f"https://dummyjson.com/posts/{resource_id}"
    
    try:
        response = requests.delete(url)
        response.raise_for_status()
        
        data = response.json()
        
        # If the response is empty (successful deletion often returns {}), return None
        if not data:
            return None
        
        # Return the 'isDeleted' value if present, otherwise None
        return data.get("isDeleted")
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
```