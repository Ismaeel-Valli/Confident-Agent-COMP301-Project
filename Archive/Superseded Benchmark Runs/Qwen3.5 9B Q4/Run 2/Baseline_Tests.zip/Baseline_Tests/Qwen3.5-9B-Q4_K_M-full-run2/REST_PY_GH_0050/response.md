```python
import requests
import json

def solve(inputs):
    """
    Lists repository tags for a given GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The caller-supplied credential (e.g., token or Bearer string).
    
    Returns:
        list | None: A list of tag objects if tags exist, decoded from JSON.
                     Returns None if the response is an empty list (successful but no tags).
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{owner}/{repo}/tags"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }

    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        raise Exception(f"Failed to fetch repository tags. Status code: {response.status_code}, Response: {response.text}")

    data = response.json()
    
    # GitHub returns an empty list [] when there are no tags, which is a successful response.
    if not data:
        return None
    
    return data
```