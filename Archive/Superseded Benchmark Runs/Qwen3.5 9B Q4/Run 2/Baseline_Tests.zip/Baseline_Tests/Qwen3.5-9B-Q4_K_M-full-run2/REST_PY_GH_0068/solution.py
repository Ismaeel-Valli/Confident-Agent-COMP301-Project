import requests
import json

def solve(inputs):
    """
    Creates an organization repository using GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization': The organization name (str)
            - 'new_name': The name for the new repository (str)
            - 'new_description': The description for the new repository (str)
            - 'credential': The caller-supplied credential (str, assumed to be a token or auth header value)
    
    Returns:
        dict or None: The decoded JSON response if successful. Returns None for an empty successful response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    org = inputs['organization']
    repo_name = inputs['new_name']
    description = inputs['new_description']
    credential = inputs['credential']
    
    # GitHub API endpoint for creating a repository in an organization
    url = f"https://api.github.com/orgs/{org}/repos"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    data = {
        "name": repo_name,
        "description": description
    }
    
    response = requests.post(url, json=data, headers=headers)
    
    if response.status_code == 201:
        # GitHub typically returns a JSON object with the created repository details for POST /orgs/{org}/repos
        return response.json()
    elif response.status_code == 204:
        # Some endpoints might return 204 No Content on success, though unlikely for repo creation
        return None
    else:
        raise Exception(f"Failed to create repository. Status code: {response.status_code}, Response: {response.text}")