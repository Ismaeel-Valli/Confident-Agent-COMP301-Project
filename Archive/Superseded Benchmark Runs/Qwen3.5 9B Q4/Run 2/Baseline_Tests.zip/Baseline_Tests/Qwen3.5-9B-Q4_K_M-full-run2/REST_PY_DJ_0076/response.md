```python
import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on the provided sort_field.
    
    Args:
        inputs (dict): A dictionary containing 'sort_field' for ordering users.
        
    Returns:
        list or None: The decoded JSON response as a list of users, or None if the response is empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    sort_field = inputs.get('sort_field')
    
    # Construct the URL with the sort parameter
    url = f"https://jsonplaceholder.typicode.com/users?sort={sort_field}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        data = response.json()
        
        # Return None if the response is empty (though JSONPlaceholder typically returns at least one user per page)
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise e
```