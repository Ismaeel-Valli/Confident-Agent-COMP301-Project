import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'resource_id': Identifier of the todo to update.
            - 'new_todo': The new value for the todo attribute.
    
    Returns:
        None if the HTTP response is successful and empty.
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    resource_id = inputs['resource_id']
    new_todo = inputs['new_todo']
    
    # Construct the payload for updating the todo
    payload = {
        "todo": new_todo
    }
    
    # Endpoint to update a specific todo by ID
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    response = requests.put(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}, Response: {response.text}")
    
    # If the response is empty (204 No Content), return None
    if not response.content:
        return None
    
    # Otherwise, return the decoded JSON response
    return response.json()