import requests

def solve(inputs):
    """
    Lists labels for a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - page_size (int): The number of results per page (max 100).
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response, or None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    page_size = inputs["page_size"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/labels"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare authentication based on credential type (assuming token or basic auth)
    if "token" in credential:
        headers["Authorization"] = f"Bearer {credential['token']}"
    elif "username" in credential and "password" in credential:
        auth = requests.auth.HTTPBasicAuth(credential["username"], credential["password"])
        response = requests.get(url, headers=headers, auth=auth)
    else:
        # Fallback to Bearer token if no specific type is identified but a string exists
        if "token" in str(credential):
            headers["Authorization"] = f"Bearer {credential['token']}"
        else:
            raise ValueError("Invalid credential format. Expected 'token' or 'username/password'.")

    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to retrieve labels for repository {repo}. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response
    if not data:
        return None
    
    return data