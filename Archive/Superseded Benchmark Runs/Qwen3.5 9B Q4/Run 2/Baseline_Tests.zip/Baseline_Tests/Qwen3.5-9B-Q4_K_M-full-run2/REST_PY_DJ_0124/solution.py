import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'new_category': string value for the category attribute
            - 'new_title': string value for the title attribute
    
    Returns:
        None if the request is successful (empty response body).
        The decoded JSON response if a non-empty response is received.
    
    Raises:
        Exception: If the HTTP response status code indicates an error.
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": inputs["new_title"],
        "body": inputs["new_category"]  # Using category as body content per typical DummyJSON structure for posts
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code != 201:
        raise Exception(f"Failed to submit product. HTTP Status Code: {response.status_code}, Response: {response.text}")
    
    # DummyJSON typically returns an empty body for POST requests on /posts
    if not response.text.strip():
        return None
    
    return response.json()