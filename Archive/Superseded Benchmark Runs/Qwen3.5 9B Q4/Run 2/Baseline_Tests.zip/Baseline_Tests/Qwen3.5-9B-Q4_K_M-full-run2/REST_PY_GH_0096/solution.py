import requests

def solve(inputs):
    """
    Lists repositories for the authenticated user using GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'credential': The caller-supplied credential (e.g., Bearer token or Authorization header value).
            - 'visibility' (optional): Limit results to repositories with the specified visibility ('public', 'private', or 'internal').
    
    Returns:
        list or None: A list of repository objects if there are results, or None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code (e.g., 4xx or 5xx).
    """
    url = "https://api.github.com/user/repos"
    
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    params = {}
    if inputs.get("visibility"):
        params["visibility"] = inputs["visibility"]

    response = requests.get(url, headers=headers, params=params)

    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")

    data = response.json()

    # GitHub API returns an empty list [] for no results, not null.
    # The requirement says return None for a successful empty response.
    if len(data) == 0:
        return None

    return data