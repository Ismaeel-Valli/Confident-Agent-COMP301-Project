```python
import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing 'email' key for authentication.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    
    # Extract email from inputs (assuming this is how DummyJSON auth works in this context)
    email = inputs.get('email', 'test@example.com')
    
    # Construct the API endpoint for todos
    url = f"{base_url}/todos?_email={email}"
    
    try:
        response = requests.get(url, timeout=10)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None if the response is empty
        if not data:
            return None
            
        return data
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```