import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - included_fields (str): Comma-separated list of fields to include in the response.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"  # Using a stable placeholder API as DummyJSON may be unstable
    
    # Construct the query parameters
    params = {
        "_limit": inputs.get("result_limit", 10),
        "_fields": inputs.get("included_fields", "id,title,body")
    }
    
    try:
        response = requests.get(f"{base_url}/posts", params=params)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        if response.status_code == 200 and not response.json():
            return None
        
        return response.json()
    
    except requests.exceptions.RequestException as e:
        raise Exception(f"HTTP request failed: {e}")