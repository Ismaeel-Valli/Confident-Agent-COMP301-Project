```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product using DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the product to update.
            - new_title (str): New value for the title attribute.
    
    Returns:
        None if the response is successful and empty.
        The decoded JSON response otherwise (if non-empty).
    
    Raises:
        Exception: If the HTTP response indicates an error (status code >= 400).
    """
    resource_id = inputs.get('resource_id')
    new_title = inputs.get('new_title')
    
    if not resource_id or not new_title:
        raise ValueError("Missing required fields: resource_id and new_title")

    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {
        "title": new_title
    }

    response = requests.patch(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to update product. Status code: {response.status_code}, Response: {response.text}")
    
    return None if response.status_code == 200 else response.json()
```