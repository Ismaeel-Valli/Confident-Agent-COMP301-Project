import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    new_title = inputs['new_title']
    
    # Construct the URL to update the post (assuming a base URL like 'https://jsonplaceholder.typicode.com/posts')
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    headers = {
        "Content-Type": "application/json"
    }
    
    payload = {
        "title": new_title
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
    
    # Check if the response is empty (no content)
    if not response.text.strip():
        return None
    
    # Return the title value from the response, or None if absent
    data = response.json()
    return data.get('title')