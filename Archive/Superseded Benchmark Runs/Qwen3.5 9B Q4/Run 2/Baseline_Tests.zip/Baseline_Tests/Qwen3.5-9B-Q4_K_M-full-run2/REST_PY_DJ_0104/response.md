```python
import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    new_price = inputs['new_price']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    headers = {
        "Content-Type": "application/json"
    }
    data = {
        "price": new_price
    }
    
    response = requests.patch(url, json=data, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product: {response.text}")
    
    result = response.json()
    
    if 'id' in result and result['id'] is not None:
        return result['id']
    elif result.get('statusCode') == 204 or (isinstance(result, dict) and len(result) == 0):
        return None
    else:
        return None
```