import requests
import json

def solve(inputs):
    """
    Lists contributors for a GitHub repository using the specified API version.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The caller-supplied credential (e.g., Bearer token or API key).
    
    Returns:
        list | None: A list of contributor dictionaries if contributors exist, 
                     None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    credential = inputs['credential']
    
    # GitHub REST API endpoint for contributors (using a future version date as specified)
    url = f"https://api.github.com/repos/{owner}/{repo}/contributors"
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "GitHub-Contributors-Lister"
    }
    
    # Note: For GitHub API v2026-03-10, authentication is still expected via header.
    # Assuming 'credential' is a Bearer token or similar auth string.
    if credential:
        headers["Authorization"] = f"Bearer {credential}"
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response (empty list)
    if not data:
        return None
    
    return data