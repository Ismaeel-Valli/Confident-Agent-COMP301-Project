import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Inputs:
        inputs['resource_id']: Identifier of the todo (e.g., '/todos/1')
        inputs['new_todo']: New value for the 'todo' attribute
        inputs['new_user_identifier']: New value for the 'userId' attribute
    
    Returns:
        The response's 'id' value if present, otherwise None.
        Returns None for a successful empty response (204 No Content).
    
    Raises:
        Exception for unsuccessful HTTP responses (non-2xx status codes).
    """
    resource_id = inputs['resource_id']
    new_todo = inputs['new_todo']
    new_user_identifier = inputs['new_user_identifier']
    
    # Construct the payload
    payload = {
        "todo": new_todo,
        "userId": new_user_identifier
    }
    
    # Make the PATCH request to DummyJSON API
    response = requests.patch(f"https://jsonplaceholder.typicode.com{resource_id}", json=payload)
    
    # Check for unsuccessful HTTP response
    if response.status_code != 200 and response.status_code != 204:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}, Response: {response.text}")
    
    # Return the id from the response if present, otherwise None
    return response.json().get('id') if response.status_code == 200 else None