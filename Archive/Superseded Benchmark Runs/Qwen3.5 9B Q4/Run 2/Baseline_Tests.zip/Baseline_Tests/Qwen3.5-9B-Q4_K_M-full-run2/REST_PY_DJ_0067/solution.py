import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API using provided first and last name.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_lastName'.
        
    Returns:
        str or None: The response's 'id' value if present, otherwise None for successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "name": f"{inputs['new_firstName']} {inputs['new_lastName']}",
        "email": "test@example.com",
        "address": {"street": "Test Street", "suite": "Apt. 1234", "city": "New York", "zipcode": "10001", "geo": {"lat": "48.22", "lng": "-121.5"}},
        "phone": "555-555-5555",
        "website": "example.com"
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    if response.json():
        return response.json().get('id')
    else:
        return None