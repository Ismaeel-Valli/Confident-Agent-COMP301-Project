import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on skip count and sort field.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'results_to_skip' (int): Number of results to skip.
            - 'sort_field' (str): Field used for ordering.
    
    Returns:
        list or None: The decoded JSON response as a list of posts, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    params = {
        "skip": inputs["results_to_skip"],
        "sort": inputs["sort_field"]
    }
    
    try:
        response = requests.get(base_url, params=params)
        
        if response.status_code < 200 or response.status_code >= 300:
            raise Exception(f"HTTP Error: {response.status_code} - {response.reason}")
        
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")