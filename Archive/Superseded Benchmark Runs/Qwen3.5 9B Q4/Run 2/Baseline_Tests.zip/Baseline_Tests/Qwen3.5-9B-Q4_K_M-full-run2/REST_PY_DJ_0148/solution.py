import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON and returns the response's id value,
    or None if that attribute is absent or for a successful empty response.
    Raises an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id: Identifier of the todo
            - new_completed: Value for the completed attribute
            - new_user_identifier: Value for the user Id attribute
            
    Returns:
        str or None: The updated todo's id, or None if absent or empty response
        
    Raises:
        requests.RequestException: If HTTP response is unsuccessful
    """
    resource_id = inputs.get('resource_id')
    new_completed = inputs.get('new_completed')
    new_user_identifier = inputs.get('new_user_identifier')
    
    # Prepare the payload for PATCH request
    payload = {
        'completed': new_completed,
        'userId': new_user_identifier
    }
    
    # Make the PATCH request to DummyJSON API
    response = requests.patch(
        f'https://jsonplaceholder.typicode.com/todos/{resource_id}',
        json=payload
    )
    
    # Raise exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Check if response is empty (no content)
    if not response.text:
        return None
    
    # Parse JSON response
    try:
        data = response.json()
    except ValueError:
        # If response is not valid JSON but we got a successful status
        return None
    
    # Return the id if present, otherwise None
    return data.get('id')