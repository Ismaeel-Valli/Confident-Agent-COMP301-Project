import requests

def solve(inputs):
    """Submit a new user to DummyJSON."""
    base_url = "https://dummyjson.com/users"
    url = f"{base_url}/add"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "username": inputs["new_username"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. Status code: {response.status_code}")
    
    return response.json()