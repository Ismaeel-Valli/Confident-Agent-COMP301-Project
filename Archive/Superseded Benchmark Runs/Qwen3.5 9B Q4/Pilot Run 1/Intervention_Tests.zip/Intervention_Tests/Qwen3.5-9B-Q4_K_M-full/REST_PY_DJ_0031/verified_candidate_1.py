def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_firstName = inputs["new_firstName"]
    
    url = "https://dummyjson.com/users/{0}".format(resource_id)
    headers = {"Content-Type": "application/json"}
    payload = {"firstName": new_firstName}
    
    response = requests.put(url, json=payload, headers=headers)
    response.raise_for_status()
    
    if response.status_code == 200:
        return response.json().get("id")
    elif response.status_code == 204:
        return None
    else:
        raise Exception(f"Failed to update user: {response.status_code} {response.text}")