import requests

def solve(inputs):
    result_limit = inputs.get("result_limit")
    
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}?limit={result_limit}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        
        data = response.json()
        
        if not data.get("products"):
            return None
        
        return data
    except requests.exceptions.RequestException as e:
        raise Exception(f"HTTP request failed: {e}")