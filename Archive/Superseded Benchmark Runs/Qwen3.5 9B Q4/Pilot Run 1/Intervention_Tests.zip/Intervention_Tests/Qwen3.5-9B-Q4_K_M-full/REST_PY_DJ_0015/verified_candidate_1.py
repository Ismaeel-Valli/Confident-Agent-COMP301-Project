def solve(inputs):
    """Update selected fields of a post on DummyJSON."""
    import requests
    
    resource_id = inputs["resource_id"]
    new_title = inputs["new_title"]
    
    url = "https://dummyjson.com/posts/{0}".format(resource_id)
    payload = {"title": new_title}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    return response.json()