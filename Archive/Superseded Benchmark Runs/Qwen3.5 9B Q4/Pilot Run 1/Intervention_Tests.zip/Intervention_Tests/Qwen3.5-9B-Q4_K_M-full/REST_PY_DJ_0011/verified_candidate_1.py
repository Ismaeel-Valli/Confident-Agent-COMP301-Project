import requests

def solve(inputs):
    search_text = inputs["search_text"]
    url = "https://dummyjson.com/users/search"
    response = requests.get(url, params={"q": search_text})
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    data = response.json()
    return data.get("users")