def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_brand = inputs["new_brand"]
    
    url = "https://dummyjson.com/products/{0}".format(resource_id)
    
    response = requests.put(url, json={"brand": new_brand})
    
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception("Failed to update product")