def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_phone = inputs["new_phone"]
    
    url = "https://dummyjson.com/users/" + str(resource_id)
    
    payload = {
        "phone": new_phone
    }
    
    response = requests.patch(url, json=payload)
    
    if response.status_code == 200:
        return None
    else:
        raise Exception(f"Failed to update user: {response.text}")