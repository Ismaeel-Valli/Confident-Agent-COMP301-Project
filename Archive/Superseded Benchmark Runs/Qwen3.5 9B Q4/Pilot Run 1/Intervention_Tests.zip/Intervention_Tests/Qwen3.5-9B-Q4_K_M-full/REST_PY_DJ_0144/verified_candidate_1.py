def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_username = inputs["new_username"]
    
    url = "https://dummyjson.com/users/{0}".format(resource_id)
    payload = {"username": new_username}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 200:
        return None
    
    data = response.json()
    return data.get("id")