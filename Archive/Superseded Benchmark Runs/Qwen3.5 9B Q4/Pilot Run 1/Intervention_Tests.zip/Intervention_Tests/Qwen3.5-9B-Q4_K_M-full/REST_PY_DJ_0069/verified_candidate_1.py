def solve(inputs):
    import requests
    resource_id = inputs["resource_id"]
    new_body = inputs["new_body"]
    url = f"https://dummyjson.com/posts/{resource_id}"
    payload = {"body": new_body}
    response = requests.put(url, json=payload)
    if response.status_code == 200:
        return None
    elif response.status_code == 201:
        return None
    else:
        raise Exception(f"Failed to update post: {response.status_code}")