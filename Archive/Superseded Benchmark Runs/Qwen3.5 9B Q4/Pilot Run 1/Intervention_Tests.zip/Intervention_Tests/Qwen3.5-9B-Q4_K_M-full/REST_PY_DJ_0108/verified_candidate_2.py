import requests

def solve(inputs):
    """Submit a new user to DummyJSON and return the response's id, or None if absent."""
    base_url = "https://dummyjson.com/users"
    url = f"{base_url}/add"
    
    payload = {
        "email": inputs["new_email"],
        "firstName": inputs["new_firstName"]
    }
    
    response = requests.post(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 201:
        data = response.json()
        return data.get("id")
    else:
        return None