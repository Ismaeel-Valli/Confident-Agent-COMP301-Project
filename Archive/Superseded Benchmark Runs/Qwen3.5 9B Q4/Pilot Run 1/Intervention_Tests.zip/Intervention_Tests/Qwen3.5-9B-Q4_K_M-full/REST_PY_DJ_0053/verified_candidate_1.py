import requests

def solve(inputs):
    results_to_skip = inputs.get("results_to_skip", 0)
    base_url = "https://dummyjson.com/posts"
    url = f"{base_url}?skip={results_to_skip}"
    
    response = requests.get(url)
    if response.status_code != 200:
        raise Exception(f"HTTP error {response.status_code}: {response.text}")
    
    data = response.json()
    return data.get("posts")