def solve(inputs):
    """
    Update a GitHub organization using the REST API v2026-03-10.
    
    Args:
        inputs (dict): Contains:
            - 'organization': str, the organization name
            - 'new_name': str, the new name for the organization
            - 'credential': str, caller-supplied credential (token)
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    import requests
    
    base_url = "https://api.github.com"
    org_name = inputs["organization"]
    new_name = inputs["new_name"]
    credential = inputs["credential"]
    
    # Construct the URL to update the organization
    url = f"{base_url}/orgs/{org_name}"
    
    # Prepare headers with authentication
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github.v3+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare the payload for updating the organization name
    payload = {
        "name": new_name
    }
    
    # Make the PATCH request to update the organization
    response = requests.patch(url, json=payload, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Return the decoded JSON response, or None if successful with empty response
    return response.json() if response.text else None