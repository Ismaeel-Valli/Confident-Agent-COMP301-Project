import requests

def solve(inputs):
    """
    Retrieve one page of users from DummyJSON, skipping a specified number of results.
    
    Args:
        inputs (dict): Must contain 'results_to_skip' (int).
        
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/users"
    params = {"skip": inputs["results_to_skip"]}
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()
        
        data = response.json()
        
        # DummyJSON returns a dict with 'users' key; return the whole decoded JSON as per spec
        return data
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")