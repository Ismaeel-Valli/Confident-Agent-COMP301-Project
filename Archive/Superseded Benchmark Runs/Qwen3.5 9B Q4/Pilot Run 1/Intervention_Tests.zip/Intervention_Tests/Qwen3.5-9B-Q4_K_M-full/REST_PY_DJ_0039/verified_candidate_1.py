def solve(inputs):
    import requests
    
    base_url = "https://dummyjson.com"
    endpoint = "/todos"
    
    params = {
        "limit": inputs["result_limit"]
    }
    
    response = requests.get(f"{base_url}{endpoint}", params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code}")
    
    data = response.json()
    
    if "todos" not in data or len(data["todos"]) == 0:
        return None
    
    return data["todos"]