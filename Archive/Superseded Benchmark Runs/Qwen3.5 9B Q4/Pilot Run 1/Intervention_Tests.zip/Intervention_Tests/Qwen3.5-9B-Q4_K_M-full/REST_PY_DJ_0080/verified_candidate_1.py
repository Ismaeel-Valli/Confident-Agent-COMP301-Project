import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_body = inputs["new_body"]
    
    url = "https://dummyjson.com/posts/" + str(resource_id)
    payload = {"body": new_body}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        data = response.json()
        if data.get("id") is not None:
            return data["id"]
        else:
            return None
    elif response.status_code == 404:
        return None
    else:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")