import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    url = "https://dummyjson.com/products/" + str(resource_id)
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        return None
    else:
        raise Exception(f"HTTP {response.status_code}: {response.text}")