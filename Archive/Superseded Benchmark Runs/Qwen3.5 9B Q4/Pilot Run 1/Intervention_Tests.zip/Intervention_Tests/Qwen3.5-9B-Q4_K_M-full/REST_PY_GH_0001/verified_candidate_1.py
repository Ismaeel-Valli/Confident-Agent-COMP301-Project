def solve(inputs):
    import requests
    import json
    
    org = inputs["organization"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/orgs/{org}"
    headers = {"Authorization": f"token {credential}"}
    
    resp = requests.get(url, headers=headers)
    if resp.status_code != 200:
        raise Exception(f"Failed to get organization: {resp.status_code}")
    
    data = resp.json()
    return data if data else None