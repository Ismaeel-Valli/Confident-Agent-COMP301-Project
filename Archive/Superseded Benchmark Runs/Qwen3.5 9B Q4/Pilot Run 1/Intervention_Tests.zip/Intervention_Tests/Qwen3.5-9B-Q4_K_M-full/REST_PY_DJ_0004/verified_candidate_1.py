import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    url = "https://dummyjson.com/products/{id}".format(id=resource_id)
    response = requests.delete(url)
    if response.status_code == 204:
        return None
    else:
        raise Exception(f"Failed to delete product: {response.status_code}")