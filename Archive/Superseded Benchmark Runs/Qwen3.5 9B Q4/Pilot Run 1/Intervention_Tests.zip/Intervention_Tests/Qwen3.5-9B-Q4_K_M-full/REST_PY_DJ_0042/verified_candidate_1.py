def solve(inputs):
    import requests
    
    resource_id = inputs.get("resource_id")
    
    url = "https://dummyjson.com/todos/" + str(resource_id)
    response = requests.delete(url)
    
    if response.status_code == 204:
        return None
    elif response.status_code == 404:
        raise Exception(f"Resource not found: {resource_id}")
    else:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")