import requests

def solve(inputs):
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}"
    
    payload = {
        "category": inputs["new_category"],
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload)
    response.raise_for_status()
    
    data = response.json()
    
    if "product" in data:
        return data["product"].get("title")
    else:
        return None