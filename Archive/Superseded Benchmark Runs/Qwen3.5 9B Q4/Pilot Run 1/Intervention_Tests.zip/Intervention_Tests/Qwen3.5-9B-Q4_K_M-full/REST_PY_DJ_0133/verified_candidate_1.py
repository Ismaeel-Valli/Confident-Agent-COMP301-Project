def solve(inputs):
    import requests
    
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/add"
    
    payload = {
        "category": inputs["new_category"],
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create product: HTTP {response.status_code}")
    
    data = response.json()
    
    if "product" in data and isinstance(data["product"], dict):
        return data["product"].get("id")
    elif "products" in data and isinstance(data["products"], list) and len(data["products"]) > 0:
        return data["products"][0].get("id")
    
    return None