def solve(inputs):
    import requests
    
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/add"
    
    payload = {
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create product: HTTP {response.status_code}")
    
    data = response.json()
    
    title = data.get("title")
    return title