def solve(inputs):
    """
    Update selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (int): Identifier of the todo to update.
            - new_completed (bool): New value for the 'completed' attribute.
            - new_todo (str): New value for the 'todo' attribute.
    
    Returns:
        dict or None: Decoded JSON response from the API, or None if successful with empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    import requests
    
    base_url = "https://dummyjson.com"
    endpoint = f"/todos/{inputs['resource_id']}"
    url = f"{base_url}{endpoint}"
    
    payload = {
        "completed": inputs["new_completed"],
        "todo": inputs["new_todo"]
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return response.json() if response.text else None
    elif response.status_code == 404:
        raise Exception(f"Resource not found: {inputs['resource_id']}")
    else:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}")