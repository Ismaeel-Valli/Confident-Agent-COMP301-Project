import requests

def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON, skipping a specified number of results.
    
    Args:
        inputs (dict): Dictionary containing 'results_to_skip' key with an integer value.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com"
    todos_endpoint = "/todos"
    
    results_to_skip = inputs.get("results_to_skip", 0)
    
    url = f"{base_url}{todos_endpoint}?skip={results_to_skip}"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    return data.get("todos", []) if data.get("todos") else None