import requests

def solve(inputs):
    """
    List organization repositories from GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - "organization": str, the organization name
            - "credential": str, caller-supplied credential with necessary permissions
    
    Returns:
        list or None: Decoded JSON response as a list of repositories, or None if empty.
    
    Raises:
        Exception: For unsuccessful HTTP responses (non-2xx status codes).
    """
    org = inputs["organization"]
    cred = inputs["credential"]
    
    url = "https://api.github.com/orgs/{org}/repos".format(org=org)
    headers = {"Authorization": f"token {cred}"}
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        return None if len(data) == 0 else data
    elif response.status_code in (401, 403):
        raise Exception(f"Authentication failed for organization '{org}': {response.status_code}")
    else:
        raise Exception(f"Failed to list repositories for organization '{org}': HTTP {response.status_code}, body={response.text}")