def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_category = inputs["new_category"]
    
    url = "https://dummyjson.com/products"
    payload = {"id": resource_id, "category": new_category}
    
    response = requests.patch(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    data = response.json()
    if "id" in data:
        return data["id"]
    return None