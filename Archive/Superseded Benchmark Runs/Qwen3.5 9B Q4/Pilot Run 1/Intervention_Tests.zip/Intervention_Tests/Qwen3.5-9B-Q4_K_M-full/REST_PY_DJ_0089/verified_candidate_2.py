import requests

def solve(inputs):
    result_limit = inputs.get("result_limit")
    results_to_skip = inputs.get("results_to_skip", 0)
    
    base_url = "https://dummyjson.com/posts"
    params = {"skip": results_to_skip, "limit": result_limit}
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()
    
    data = response.json()
    
    if not data.get("posts"):
        return None
    
    return data