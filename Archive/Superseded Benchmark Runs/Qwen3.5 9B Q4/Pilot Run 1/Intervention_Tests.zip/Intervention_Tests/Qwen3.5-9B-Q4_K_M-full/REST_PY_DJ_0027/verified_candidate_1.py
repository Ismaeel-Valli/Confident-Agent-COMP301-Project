import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    url = "https://dummyjson.com/products/{id}".format(id=resource_id)
    response = requests.delete(url)
    if response.status_code == 204:
        return None
    if response.status_code == 404:
        raise Exception(f"Resource not found: {response.json()}")
    if response.status_code == 500:
        raise Exception(f"Internal server error: {response.json()}")
    if response.status_code == 401:
        raise Exception(f"Unauthorized: {response.json()}")
    if response.status_code == 403:
        raise Exception(f"Forbidden: {response.json()}")
    if response.status_code == 429:
        raise Exception(f"Too many requests: {response.json()}")
    return response.json().get("id", None)