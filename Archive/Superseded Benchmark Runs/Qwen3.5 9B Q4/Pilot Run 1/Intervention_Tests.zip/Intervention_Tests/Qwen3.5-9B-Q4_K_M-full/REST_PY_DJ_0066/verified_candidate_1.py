def solve(inputs):
    resource_id = inputs["resource_id"]
    new_lastName = inputs["new_lastName"]
    
    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {"lastName": new_lastName}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    data = response.json()
    if "id" in data:
        return data["id"]
    return None