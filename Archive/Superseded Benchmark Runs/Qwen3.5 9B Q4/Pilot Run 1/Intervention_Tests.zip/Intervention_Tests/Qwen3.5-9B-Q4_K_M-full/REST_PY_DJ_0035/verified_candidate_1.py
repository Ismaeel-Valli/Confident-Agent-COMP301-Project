def solve(inputs):
    """Retrieve a post by identifier from DummyJSON and return its id or None."""
    import requests
    
    resource_id = inputs.get("resource_id")
    
    # Construct the URL for fetching a post by ID
    url = f"https://dummyjson.com/posts/{resource_id}"
    
    try:
        response = requests.get(url)
        
        if response.status_code != 200:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
        
        data = response.json()
        
        # Return the id value if present, otherwise None for empty response
        if "id" in data and data["id"] is not None:
            return data["id"]
        else:
            return None
            
    except requests.RequestException as e:
        raise Exception(f"Request failed: {e}")