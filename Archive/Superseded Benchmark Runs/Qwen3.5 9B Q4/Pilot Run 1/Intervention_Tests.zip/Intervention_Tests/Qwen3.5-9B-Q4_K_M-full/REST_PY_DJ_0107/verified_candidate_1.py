import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_email = inputs["new_email"]
    
    url = "https://dummyjson.com/users/{0}".format(resource_id)
    headers = {"Content-Type": "application/json"}
    payload = {"email": new_email}
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        return data.get("id")
    elif response.status_code == 204:
        return None
    else:
        raise Exception(f"Failed to update user: {response.status_code} {response.text}")