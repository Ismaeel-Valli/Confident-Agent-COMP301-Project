import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_title = inputs["new_title"]
    
    url = "https://dummyjson.com/posts/" + str(resource_id)
    payload = {"title": new_title}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        data = response.json()
        return data.get("title")
    elif response.status_code == 204:
        return None
    else:
        raise Exception(f"Failed to update post: {response.status_code}")