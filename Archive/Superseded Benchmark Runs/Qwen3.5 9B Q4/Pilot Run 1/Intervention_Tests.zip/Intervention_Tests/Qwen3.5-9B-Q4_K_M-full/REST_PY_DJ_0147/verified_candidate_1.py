import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_body = inputs["new_body"]
    new_title = inputs["new_title"]
    
    url = "https://dummyjson.com/posts/{id}".format(id=resource_id)
    
    payload = {
        "body": new_body,
        "title": new_title
    }
    
    response = requests.patch(url, json=payload)
    
    if response.status_code == 200:
        data = response.json()
        return data.get("title")
    elif response.status_code == 204:
        return None
    else:
        raise Exception(f"Failed to update post: {response.status_code} {response.text}")