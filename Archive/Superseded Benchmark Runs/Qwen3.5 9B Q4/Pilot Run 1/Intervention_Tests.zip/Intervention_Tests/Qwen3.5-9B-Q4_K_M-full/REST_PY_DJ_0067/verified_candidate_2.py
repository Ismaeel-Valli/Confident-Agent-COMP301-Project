def solve(inputs):
    import requests
    
    base_url = "https://dummyjson.com/users/add"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "lastName": inputs["new_lastName"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user: HTTP {response.status_code}")
    
    data = response.json()
    
    if "user" in data and data["user"] is not None:
        return data["user"]["id"]
    elif "users" in data and len(data["users"]) > 0:
        return data["users"][0]["id"]
    else:
        return None