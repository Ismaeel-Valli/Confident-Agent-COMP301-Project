def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    url = f"https://dummyjson.com/users/{resource_id}"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}")
    
    data = response.json()
    
    if "user" in data and data["user"] is not None:
        return data["user"]["id"]
    elif "users" in data and len(data["users"]) > 0:
        return data["users"][0]["id"]
    else:
        return None