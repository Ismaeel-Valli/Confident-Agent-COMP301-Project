def solve(inputs):
    import requests
    resource_id = inputs["resource_id"]
    new_age = inputs["new_age"]
    
    url = "https://dummyjson.com/users/{0}".format(resource_id)
    payload = {"age": new_age}
    
    response = requests.patch(url, json=payload)
    response.raise_for_status()
    
    data = response.json()
    
    if "id" in data:
        return data["id"]
    else:
        return None