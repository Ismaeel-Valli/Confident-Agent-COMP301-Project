def solve(inputs):
    """Update selected fields of a post on DummyJSON and return the post's id."""
    import requests
    
    resource_id = inputs["resource_id"]
    new_user_identifier = inputs["new_user_identifier"]
    
    url = "https://dummyjson.com/posts/{0}".format(resource_id)
    headers = {"Content-Type": "application/json"}
    payload = {"userId": new_user_identifier}
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        if data.get("id") is not None:
            return data["id"]
        else:
            return None
    elif response.status_code == 204:
        return None
    else:
        raise Exception(f"HTTP {response.status_code}: {response.text}")