def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_completed = inputs["new_completed"]
    new_todo = inputs["new_todo"]
    
    base_url = "https://dummyjson.com"
    url = f"{base_url}/todos/{resource_id}"
    
    payload = {
        "completed": new_completed,
        "todo": new_todo
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update todo: {response.status_code} {response.text}")
    
    data = response.json()
    
    if "id" in data:
        return data["id"]
    elif response.status_code == 204:
        return None
    else:
        return None