def solve(inputs):
    import requests
    
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}"
    
    payload = {
        "title": inputs["new_title"],
        "price": inputs["new_price"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create product: {response.status_code}")
    
    data = response.json()
    
    if "product" in data and data["product"] is not None:
        return data["product"]["id"]
    elif "message" in data and data["message"] == "":
        return None
    else:
        return None