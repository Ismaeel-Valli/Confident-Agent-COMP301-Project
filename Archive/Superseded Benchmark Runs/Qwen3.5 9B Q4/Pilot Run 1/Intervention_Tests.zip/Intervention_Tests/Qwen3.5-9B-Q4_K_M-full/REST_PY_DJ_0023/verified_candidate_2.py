def solve(inputs):
    """
    Create a new todo on DummyJSON using requests.
    
    Args:
        inputs (dict): Dictionary containing:
            - 'new_completed': value for the completed attribute
            - 'new_todo': value for the todo attribute
            - 'new_user_identifier': value for the user Id attribute
    
    Returns:
        dict or None: The decoded JSON response, or None if empty.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    import requests
    
    base_url = "https://dummyjson.com"
    url = f"{base_url}/todos/add"
    
    payload = {
        "completed": inputs["new_completed"],
        "todo": inputs["new_todo"],
        "userId": inputs["new_user_identifier"]
    }
    
    response = requests.post(url, json=payload)
    response.raise_for_status()
    
    return response.json() if response.status_code == 201 else None