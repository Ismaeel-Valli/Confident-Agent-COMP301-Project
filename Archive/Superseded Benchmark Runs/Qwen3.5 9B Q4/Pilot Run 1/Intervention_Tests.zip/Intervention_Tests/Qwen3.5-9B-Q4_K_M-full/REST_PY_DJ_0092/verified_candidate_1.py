def solve(inputs):
    """
    Update selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the todo to update.
            - new_user_identifier (str): New value for the user Id attribute.
    
    Returns:
        str or None: The response's id value if present, otherwise None.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    import requests
    
    base_url = "https://dummyjson.com"
    url = f"{base_url}/todos/{inputs['resource_id']}"
    
    payload = {
        "userId": inputs["new_user_identifier"]
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    if response.status_code == 200:
        data = response.json()
        return data.get("id")
    elif response.status_code == 204:
        return None
    
    return None