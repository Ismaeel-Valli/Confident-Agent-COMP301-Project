import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_todo = inputs["new_todo"]
    new_user_identifier = inputs["new_user_identifier"]

    base_url = "https://dummyjson.com"
    url = f"{base_url}/todos/{resource_id}"

    payload = {
        "todo": new_todo,
        "userId": new_user_identifier
    }

    response = requests.put(url, json=payload)
    response.raise_for_status()

    if response.status_code == 204:
        return None

    data = response.json()
    id_value = data.get("id")
    return id_value