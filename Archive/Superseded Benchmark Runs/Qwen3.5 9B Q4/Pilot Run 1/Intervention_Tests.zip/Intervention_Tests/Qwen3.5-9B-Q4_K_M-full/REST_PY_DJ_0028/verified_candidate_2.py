def solve(inputs):
    import requests
    
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/add"
    
    payload = {
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 201:
        data = response.json()
        if "id" in data and data["id"] is not None:
            return data["id"]
        else:
            return None
    else:
        raise Exception(f"Failed to create product. Status code: {response.status_code}")