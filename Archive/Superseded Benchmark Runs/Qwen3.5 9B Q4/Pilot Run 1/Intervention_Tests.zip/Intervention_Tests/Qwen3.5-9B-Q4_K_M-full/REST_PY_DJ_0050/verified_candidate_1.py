def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_lastName = inputs["new_lastName"]
    
    url = "https://dummyjson.com/users/{id}/update".format(id=resource_id)
    payload = {"lastName": new_lastName}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    return response.json() if response.status_code != 204 else None