def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_lastName = inputs["new_lastName"]
    
    url = "https://dummyjson.com/users/{id}".format(id=resource_id)
    payload = {"lastName": new_lastName}
    
    response = requests.patch(url, json=payload)
    response.raise_for_status()
    
    return response.json() if response.status_code != 204 else None