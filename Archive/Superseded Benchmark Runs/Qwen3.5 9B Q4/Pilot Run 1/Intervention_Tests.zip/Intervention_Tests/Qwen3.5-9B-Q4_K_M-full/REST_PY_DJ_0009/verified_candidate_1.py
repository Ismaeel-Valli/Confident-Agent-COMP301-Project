import requests

def solve(inputs):
    base_url = "https://dummyjson.com"
    resource_id = inputs["resource_id"]
    new_firstName = inputs["new_firstName"]
    
    url = f"{base_url}/users/{resource_id}"
    payload = {"firstName": new_firstName}
    
    response = requests.patch(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    return response.json()