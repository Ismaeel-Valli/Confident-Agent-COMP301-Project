def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_user_identifier = inputs["new_user_identifier"]
    
    url = "https://dummyjson.com/todos/" + str(resource_id)
    
    headers = {
        "Content-Type": "application/json"
    }
    
    payload = {
        "userId": new_user_identifier
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error {response.status_code}: {response.text}")
    
    return response.json()