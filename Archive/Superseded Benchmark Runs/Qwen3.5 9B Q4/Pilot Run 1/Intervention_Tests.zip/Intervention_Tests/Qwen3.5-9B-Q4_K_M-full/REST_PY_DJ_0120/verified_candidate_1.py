def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_user_identifier = inputs["new_user_identifier"]
    
    url = "https://dummyjson.com/posts/{id}".format(id=resource_id)
    headers = {"Content-Type": "application/json"}
    payload = {"userId": new_user_identifier}
    
    response = requests.patch(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    if "title" in data and data["title"] is not None:
        return data["title"]
    elif data.get("statusCode") == 204 or (data.get("status") == "success" and data.get("message") == "Updated"):
        return None
    
    return None