import requests

def solve(inputs):
    """
    Get a repository from GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): Contains:
            - repository_owner (str): The account owner of the repository
            - repository_name (str): The name of the repository without .git extension
            - credential (str): Caller-supplied authentication token
    
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    owner = inputs["repository_owner"]
    repo_name = inputs["repository_name"]
    credential = inputs["credential"]
    
    # GitHub REST API v2026-03-10 endpoint for getting a repository
    url = "https://api.github.com/repos/{owner}/{repo}".format(owner=owner, repo=repo_name)
    
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "Authorization": f"token {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        return response.json()
    elif response.status_code == 204:
        return None
    else:
        raise Exception(f"GitHub API returned status code {response.status_code} for repository {owner}/{repo_name}")