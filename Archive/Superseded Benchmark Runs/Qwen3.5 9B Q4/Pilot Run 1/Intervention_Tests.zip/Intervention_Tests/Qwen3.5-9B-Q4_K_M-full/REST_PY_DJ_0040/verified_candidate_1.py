def solve(inputs):
    resource_id = inputs.get("resource_id")
    url = "https://dummyjson.com/todos/" + str(resource_id)
    response = requests.get(url)
    if response.status_code != 200:
        raise Exception(f"Failed to retrieve todo: {response.status_code}")
    data = response.json()
    if "id" in data:
        return data["id"]
    return None