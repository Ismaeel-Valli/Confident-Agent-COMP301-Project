import requests

def solve(inputs):
    base_url = "https://dummyjson.com/users"
    url = f"{base_url}?new_firstName={inputs['new_firstName']}&new_username={inputs['new_username']}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        
        if response.status_code == 201:
            data = response.json()
            return data.get('id')
        elif response.status_code == 200:
            return None
        else:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")