import requests

def solve(inputs):
    resource_id = inputs.get("resource_id")
    url = f"https://dummyjson.com/products/{resource_id}"
    response = requests.get(url)
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    data = response.json()
    return data.get("id")