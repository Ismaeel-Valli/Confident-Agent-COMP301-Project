import requests

def solve(inputs):
    """
    Retrieve one page of products from DummyJSON, skipping a specified number of results.
    
    Args:
        inputs (dict): Must contain 'results_to_skip' (int).
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    skip = inputs['results_to_skip']
    
    try:
        response = requests.get(base_url, params={'skip': skip})
        response.raise_for_status()
        
        data = response.json()
        
        if not data.get('products'):
            return None
        
        return data
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")