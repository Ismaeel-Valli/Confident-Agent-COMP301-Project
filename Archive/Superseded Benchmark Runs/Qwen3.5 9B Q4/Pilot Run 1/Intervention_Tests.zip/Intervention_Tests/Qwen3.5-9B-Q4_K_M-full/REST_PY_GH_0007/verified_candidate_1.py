import requests

def solve(inputs):
    """
    Update a repository name on GitHub using the REST API.
    
    Args:
        inputs (dict): Contains:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without .git extension.
            - new_name (str): The new name for the repository.
            - credential (str): Bearer token or OAuth token for authentication.
    
    Returns:
        None if successful (empty response), otherwise raises an exception.
    
    Raises:
        Exception: If the HTTP response indicates failure (non-2xx status).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    new_name = inputs["new_name"]
    credential = inputs["credential"]
    
    url = "https://api.github.com/repos/{owner}/{repo}/rename".format(owner=owner, repo=repo)
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    response = requests.post(url, json={"name": new_name}, headers=headers)
    
    if response.status_code == 204:
        return None
    
    response.raise_for_status()