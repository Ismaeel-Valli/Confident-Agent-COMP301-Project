def solve(inputs):
    """
    Update selected fields of a product in DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (int): Identifier of the product to update.
            - new_price (float): New value for the price attribute.
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response.
    
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    import requests
    
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/{inputs['resource_id']}"
    
    payload = {
        "price": inputs["new_price"]
    }
    
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 201:
        return response.json()
    else:
        raise Exception(f"Failed to update product: {response.status_code} - {response.text}")