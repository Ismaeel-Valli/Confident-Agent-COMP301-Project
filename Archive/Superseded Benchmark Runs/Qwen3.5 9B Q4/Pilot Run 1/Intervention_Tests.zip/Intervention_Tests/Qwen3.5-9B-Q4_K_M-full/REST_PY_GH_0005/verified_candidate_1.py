def solve(inputs):
    """
    Create an organization repository on GitHub using the REST API v2026-03-10.
    
    Args:
        inputs (dict): Must contain:
            - 'organization': str, the organization name
            - 'new_name': str, the name for the new repository
            - 'credential': str, the caller-supplied authentication token
    
    Returns:
        dict or None: The decoded JSON response. Returns None if the response is empty (201 Created with no body).
    
    Raises:
        Exception: If the HTTP response indicates failure (non-2xx status code).
    """
    import requests
    
    # Construct the API URL for creating a repository in an organization
    base_url = "https://api.github.com"
    org_name = inputs["organization"]
    repo_name = inputs["new_name"]
    auth_token = inputs["credential"]
    
    # GitHub REST API endpoint for creating a repository in an organization
    url = f"{base_url}/orgs/{org_name}/repos"
    
    headers = {
        "Authorization": f"token {auth_token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    payload = {
        "name": repo_name
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code == 201:
        # Successful creation; GitHub may return an empty body for some operations
        if len(response.content) == 0:
            return None
        return response.json()
    elif response.status_code in (400, 403, 404, 422):
        raise Exception(f"Failed to create repository. Status {response.status_code}: {response.text}")
    else:
        raise Exception(f"Unexpected error creating repository. Status {response.status_code}: {response.text}")