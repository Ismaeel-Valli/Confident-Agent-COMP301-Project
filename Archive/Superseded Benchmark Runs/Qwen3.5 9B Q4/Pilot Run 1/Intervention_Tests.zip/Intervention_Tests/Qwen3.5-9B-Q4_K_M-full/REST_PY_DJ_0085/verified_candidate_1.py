def solve(inputs):
    import requests
    
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}"
    
    payload = {
        "description": inputs["new_description"],
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload)
    response.raise_for_status()
    
    data = response.json()
    
    if "error" in data:
        raise Exception(f"Failed to create product: {data['error']}")
    
    title = data.get("title")
    if title is None:
        return None
    
    return title