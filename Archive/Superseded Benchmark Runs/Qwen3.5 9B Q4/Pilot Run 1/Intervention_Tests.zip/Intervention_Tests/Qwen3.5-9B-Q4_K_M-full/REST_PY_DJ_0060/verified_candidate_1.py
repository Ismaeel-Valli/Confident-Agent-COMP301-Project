def solve(inputs):
    """Delete a todo by identifier on DummyJSON and return isDeleted or None."""
    import requests
    
    resource_id = inputs["resource_id"]
    url = "https://dummyjson.com/todos/" + str(resource_id)
    
    response = requests.delete(url)
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    if "isDeleted" in data:
        return data["isDeleted"]
    else:
        return None