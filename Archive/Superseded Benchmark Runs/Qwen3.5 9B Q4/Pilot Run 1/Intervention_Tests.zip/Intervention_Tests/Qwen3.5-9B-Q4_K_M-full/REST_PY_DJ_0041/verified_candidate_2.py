import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_todo = inputs["new_todo"]
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    headers = {"Content-Type": "application/json"}
    payload = {"todo": new_todo}
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 201:
        return response.json().get("id")
    else:
        raise Exception(f"Failed to update todo: {response.status_code} - {response.text}")