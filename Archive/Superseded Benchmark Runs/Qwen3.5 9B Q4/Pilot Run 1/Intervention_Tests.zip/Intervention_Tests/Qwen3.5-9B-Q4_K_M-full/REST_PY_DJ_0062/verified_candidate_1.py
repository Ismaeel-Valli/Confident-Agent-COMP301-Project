import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_description = inputs["new_description"]
    
    url = "https://dummyjson.com/products/{id}".format(id=resource_id)
    headers = {"Content-Type": "application/json"}
    payload = {"description": new_description}
    
    response = requests.put(url, json=payload, headers=headers)
    response.raise_for_status()
    
    return None