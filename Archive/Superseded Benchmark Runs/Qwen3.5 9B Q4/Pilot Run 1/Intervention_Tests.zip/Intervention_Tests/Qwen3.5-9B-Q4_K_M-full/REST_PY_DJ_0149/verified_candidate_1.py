import requests

def solve(inputs):
    """
    Retrieve one page of products from DummyJSON with pagination and field filtering.
    
    Args:
        inputs (dict): Must contain:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip (for pagination).
            - included_fields (str): Comma-separated list of fields to include.
    
    Returns:
        dict or None: Decoded JSON response, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx).
    """
    base_url = "https://dummyjson.com/products"
    params = {
        "limit": inputs["result_limit"],
        "skip": inputs["results_to_skip"],
        "select": inputs["included_fields"]
    }
    
    response = requests.get(base_url, params=params)
    
    if not (200 <= response.status_code < 300):
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    return response.json()