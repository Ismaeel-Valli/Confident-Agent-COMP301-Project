def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_age = inputs["new_age"]
    
    url = "https://dummyjson.com/users/{id}".format(id=resource_id)
    payload = {"age": new_age}
    
    response = requests.patch(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    return response.json()