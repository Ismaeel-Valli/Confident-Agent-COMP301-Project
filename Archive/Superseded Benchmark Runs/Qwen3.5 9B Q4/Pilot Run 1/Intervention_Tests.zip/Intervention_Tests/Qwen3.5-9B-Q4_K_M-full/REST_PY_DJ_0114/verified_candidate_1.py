def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_price = inputs["new_price"]
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"price": new_price}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    data = response.json()
    
    if "title" in data:
        return data["title"]
    elif data.get("statusCode") == 204 or data.get("status") == 204:
        return None
    else:
        raise Exception(f"Unexpected response: {data}")