def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    
    url = "https://dummyjson.com/posts/{id}".format(id=resource_id)
    response = requests.delete(url)
    
    if response.status_code == 200:
        data = response.json()
        if data.get("deleted"):
            return None
        title = data.get("title")
        if title is not None:
            return title
        return None
    elif response.status_code == 404:
        raise Exception(f"Resource not found: {resource_id}")
    else:
        raise Exception(f"Failed to delete post: {response.status_code} - {response.text}")