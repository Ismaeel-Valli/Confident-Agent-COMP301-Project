import requests

def solve(inputs):
    """Retrieve a post by identifier from DummyJSON and return its id."""
    resource_id = inputs.get("resource_id")
    
    if resource_id is None:
        return None
    
    try:
        response = requests.get(
            "https://dummyjson.com/posts/" + str(resource_id),
            timeout=10
        )
        
        if response.status_code != 200:
            raise Exception(f"HTTP error: {response.status_code}")
        
        data = response.json()
        
        # DummyJSON returns {"post": {...}} for a single post
        if "post" in data and data["post"]:
            return data["post"].get("id")
        else:
            return None
            
    except requests.RequestException as e:
        raise Exception(f"Request failed: {e}")