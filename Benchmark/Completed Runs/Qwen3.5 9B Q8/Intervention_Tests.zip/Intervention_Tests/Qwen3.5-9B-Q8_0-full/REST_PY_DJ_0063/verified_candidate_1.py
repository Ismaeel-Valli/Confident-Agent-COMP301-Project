import requests

def solve(inputs):
    """Delete a product by identifier from DummyJSON and return isDeleted or None."""
    base_url = "https://dummyjson.com/products"
    resource_id = inputs["resource_id"]
    
    url = f"{base_url}/{resource_id}"
    
    response = requests.delete(url)
    
    if response.status_code >= 400:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    if "isDeleted" in data:
        return data["isDeleted"]
    elif response.status_code == 200 and not data:
        return None
    else:
        return None