import requests

def solve(inputs):
    """Delete a post by identifier from DummyJSON and return the title or None."""
    base_url = "https://dummyjson.com/posts"
    resource_id = inputs["resource_id"]
    
    try:
        response = requests.delete(f"{base_url}/{resource_id}")
        
        if response.status_code >= 400:
            raise Exception(f"Failed to delete post: {response.status_code} - {response.text}")
        
        data = response.json()
        
        # DummyJSON DELETE returns the deleted item in 'deleted' key or empty dict
        if "deleted" in data and data["deleted"]:
            return data["deleted"].get("title")
        elif "message" in data:
            return None
        
        return None
    except requests.RequestException as e:
        raise Exception(f"Request failed: {e}")