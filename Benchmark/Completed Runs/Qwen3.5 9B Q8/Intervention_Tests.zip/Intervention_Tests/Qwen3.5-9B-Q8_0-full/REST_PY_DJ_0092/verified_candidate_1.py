import requests

def solve(inputs):
    """
    Update selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (int): Identifier of the todo to update
            - new_user_identifier (str): New value for the user Id attribute
    
    Returns:
        int or None: The response's id value if present, otherwise None.
                      Returns None for a successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com"
    resource_id = inputs["resource_id"]
    new_user_identifier = inputs["new_user_identifier"]
    
    # Construct the update payload
    payload = {
        "userId": new_user_identifier
    }
    
    # Make PATCH request to update the todo
    response = requests.patch(
        f"{base_url}/todos/{resource_id}",
        json=payload
    )
    
    # Raise exception for unsuccessful HTTP responses
    if not response.ok:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    # Get the response JSON
    data = response.json()
    
    # Return the id value if present, otherwise None
    if "id" in data and data["id"] is not None:
        return data["id"]
    elif data == {}:
        return None
    else:
        return None