import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON using the provided email and first name.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_email (str): Email address for the new user.
            - new_firstName (str): First name for the new user.
            
    Returns:
        int or None: The ID of the newly created user, or None if the response is empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://dummyjson.com/users"
    
    payload = {
        "email": inputs["new_email"],
        "firstName": inputs["new_firstName"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. Status code: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns the created user in the 'user' field of the response
    if "user" in data and data["user"] is not None:
        return data["user"].get("id")
    elif "id" in data:
        return data["id"]
    else:
        return None