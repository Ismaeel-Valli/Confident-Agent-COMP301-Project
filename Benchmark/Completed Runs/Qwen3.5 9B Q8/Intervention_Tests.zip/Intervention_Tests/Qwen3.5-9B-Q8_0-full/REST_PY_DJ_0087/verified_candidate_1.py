import requests

def solve(inputs):
    """
    Update selected fields of a user on DummyJSON and return the response's id value,
    or None if that attribute is absent. Return None for a successful empty response.
    Raise an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the user to update.
            - new_age (int): New value for the age attribute.
    
    Returns:
        int or None: The id from the response, or None if absent or empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/users"
    resource_id = inputs["resource_id"]
    new_age = inputs["new_age"]
    
    url = f"{base_url}/{resource_id}"
    payload = {"age": new_age}
    
    response = requests.put(url, json=payload)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Check for empty response
    if not data:
        return None
    
    # Return id if present, else None
    return data.get("id")