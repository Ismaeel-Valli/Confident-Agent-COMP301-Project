import requests

def solve(inputs):
    """
    Delete a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without .git extension.
            - credential (str): The caller-supplied authentication token.
    
    Returns:
        int: The successful HTTP status code (typically 204).
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    credential = inputs["credential"]
    
    # Construct the API URL for deleting a repository
    url = f"https://api.github.com/repos/{owner}/{repo}"
    
    # Prepare headers with authentication
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Send DELETE request
    response = requests.delete(url, headers=headers)
    
    # Raise an exception for unsuccessful responses
    response.raise_for_status()
    
    return response.status_code