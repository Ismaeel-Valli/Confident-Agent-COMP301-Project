import requests

def solve(inputs):
    """Delete a post by identifier from DummyJSON and return isDeleted value."""
    base_url = "https://dummyjson.com/posts"
    resource_id = inputs["resource_id"]
    
    try:
        response = requests.delete(f"{base_url}/{resource_id}")
        
        if response.status_code >= 400:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
        
        data = response.json()
        
        # Check for isDeleted attribute in the response
        if "isDeleted" in data:
            return data["isDeleted"]
        elif response.status_code == 200 and not data:
            # Successful empty response
            return None
        else:
            # Attribute absent but not an empty successful response
            return None
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")