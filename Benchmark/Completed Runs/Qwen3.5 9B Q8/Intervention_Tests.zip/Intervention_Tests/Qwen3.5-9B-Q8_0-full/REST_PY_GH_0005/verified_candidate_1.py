import requests
import json


def solve(inputs):
    """
    Create an organization repository on GitHub using the REST API v2026-03-10.
    
    Args:
        inputs (dict): Must contain 'organization', 'new_name', and 'credential'.
        
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    org = inputs["organization"]
    repo_name = inputs["new_name"]
    token = inputs["credential"]
    
    url = f"https://api.github.com/orgs/{org}/repos"
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    payload = {
        "name": repo_name
    }
    
    response = requests.post(url, headers=headers, json=payload)
    
    if response.status_code == 201:
        return None
    elif response.status_code == 202:
        return None
    else:
        raise Exception(f"Failed to create repository. Status code: {response.status_code}, Response: {response.text}")