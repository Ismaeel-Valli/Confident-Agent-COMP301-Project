import requests

def solve(inputs):
    """
    Update selected fields of a user on DummyJSON.
    
    Inputs:
        - resource_id: Identifier of the user (int)
        - new_lastName: value for the last Name attribute (str)
    
    Returns:
        - The decoded JSON response, or None if successful with empty response.
        - Raises an exception for unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/users"
    resource_id = inputs["resource_id"]
    new_lastName = inputs["new_lastName"]
    
    url = f"{base_url}/{resource_id}"
    payload = {"lastName": new_lastName}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 201:
        return response.json()
    else:
        raise Exception(f"Failed to update user. Status code: {response.status_code}, Response: {response.text}")