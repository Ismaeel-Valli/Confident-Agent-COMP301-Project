import requests

def solve(inputs):
    """Delete a product by identifier from DummyJSON and return the title or None."""
    resource_id = inputs.get("resource_id")
    
    if resource_id is None:
        return None
    
    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.delete(url)
        response.raise_for_status()
        
        if response.status_code == 200:
            data = response.json()
            # DummyJSON returns an empty object on successful deletion
            return None
        
        elif response.status_code == 404:
            # Product not found
            raise Exception(f"Product with ID {resource_id} not found")
        
        else:
            # Unsuccessful HTTP response
            raise Exception(f"Failed to delete product: {response.status_code} - {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")