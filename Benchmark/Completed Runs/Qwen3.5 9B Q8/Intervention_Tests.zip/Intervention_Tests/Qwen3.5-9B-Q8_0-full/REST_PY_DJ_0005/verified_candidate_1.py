import requests

def solve(inputs):
    """
    Search products on DummyJSON using the provided search term.
    
    Args:
        inputs (dict): Dictionary containing 'search_text' key with the search term.
        
    Returns:
        list or None: Decoded JSON response as a list of products, or None if empty.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    base_url = "https://dummyjson.com/products/search"
    search_text = inputs["search_text"]
    
    params = {
        "q": search_text
    }
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()
    
    data = response.json()
    
    if not data.get("products"):
        return None
    
    return data["products"]