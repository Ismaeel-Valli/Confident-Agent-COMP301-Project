import requests

def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON, skipping specified results
    and including only specified fields.
    
    Args:
        inputs (dict): Dictionary containing:
            - results_to_skip (int): Number of results to skip
            - included_fields (str): Comma-separated list of fields to include
    
    Returns:
        dict or None: Decoded JSON response, or None for empty successful response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    base_url = "https://dummyjson.com/todos"
    
    # Parse included_fields - use _fields query parameter if provided
    fields_param = inputs.get("included_fields", "")
    
    params = {
        "skip": inputs["results_to_skip"],
        "limit": 1,  # Retrieve one page
    }
    
    # Only add _fields if it's not empty
    if fields_param:
        params["_fields"] = fields_param
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for empty successful response
    if not data.get("todos") or len(data["todos"]) == 0:
        return None
    
    return data