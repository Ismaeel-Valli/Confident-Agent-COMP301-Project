import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON using the provided first name.
    
    Args:
        inputs (dict): Must contain 'new_firstName' key with the first name value.
        
    Returns:
        int or None: The ID of the created user, or None if the response is empty.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    base_url = "https://dummyjson.com/users"
    
    payload = {
        "firstName": inputs["new_firstName"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 201 or response.status_code == 200:
            data = response.json()
            # DummyJSON returns the created user directly in the response body for POST /users
            if "id" in data and data["id"] is not None:
                return data["id"]
            elif data == {}:
                return None
            else:
                # If there's a response but no 'id' field, check if it's an empty object
                return None
        else:
            raise requests.RequestException(f"Unexpected status code: {response.status_code}")
            
    except requests.RequestException as e:
        raise