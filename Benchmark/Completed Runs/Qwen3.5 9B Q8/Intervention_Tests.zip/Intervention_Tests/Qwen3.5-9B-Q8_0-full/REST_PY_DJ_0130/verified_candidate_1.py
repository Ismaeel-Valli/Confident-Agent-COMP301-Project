import requests

def solve(inputs):
    """
    Update selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (int): Identifier of the todo to update
            - new_todo (str): New value for the 'todo' attribute
            - new_user_identifier (int): New value for the 'userId' attribute
    
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com"
    todo_id = inputs["resource_id"]
    new_todo_value = inputs["new_todo"]
    new_user_id = inputs["new_user_identifier"]
    
    # Construct the update payload
    payload = {
        "todo": new_todo_value,
        "userId": new_user_id
    }
    
    # Make PATCH request to update the todo
    response = requests.patch(
        f"{base_url}/todos/{todo_id}",
        json=payload
    )
    
    # Raise exception for unsuccessful HTTP responses
    if not response.ok:
        raise Exception(f"Failed to update todo: {response.status_code} - {response.text}")
    
    # Return the id from the response, or None if absent
    data = response.json()
    return data.get("id")