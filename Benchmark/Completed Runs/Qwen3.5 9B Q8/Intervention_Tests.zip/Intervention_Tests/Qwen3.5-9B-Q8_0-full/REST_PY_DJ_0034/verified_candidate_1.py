import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON.
    
    Args:
        inputs (dict): Must contain 'result_limit' (int).
        
    Returns:
        list or None: Decoded JSON response as a list, or None for empty success.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    result_limit = inputs.get("result_limit")
    
    if result_limit is None:
        raise ValueError("Missing required input: 'result_limit'")
    
    base_url = "https://dummyjson.com/posts"
    params = {"limit": result_limit}
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns a dict with 'posts' key; return the list directly
    return data.get("posts")