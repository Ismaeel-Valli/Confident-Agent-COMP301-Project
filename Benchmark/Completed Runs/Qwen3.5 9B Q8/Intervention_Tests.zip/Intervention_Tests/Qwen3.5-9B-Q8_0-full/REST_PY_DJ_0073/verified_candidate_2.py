import requests

def solve(inputs):
    """
    Retrieve one page of products from DummyJSON, sorted by sort_field.
    
    Args:
        inputs (dict): Must contain 'sort_field' key with a string value.
        
    Returns:
        dict or None: Decoded JSON response if successful. Returns None for empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    sort_field = inputs.get('sort_field')
    
    if not sort_field:
        raise ValueError("Missing required 'sort_field' in inputs")
    
    base_url = "https://dummyjson.com/products"
    params = {
        'skip': 0,
        'limit': 1
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code}")
    
    data = response.json()
    
    # Return None for successful empty response (products array is empty)
    if not data.get('products'):
        return None
    
    return data