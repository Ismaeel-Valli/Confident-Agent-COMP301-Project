import requests

def solve(inputs):
    """
    Update selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id (int): Identifier of the todo to update.
            - new_completed (bool): New value for the completed attribute.
            - new_todo (str): New value for the todo attribute.
    
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com"
    resource_id = inputs["resource_id"]
    new_completed = inputs["new_completed"]
    new_todo = inputs["new_todo"]
    
    # Construct the update payload
    payload = {
        "todo": new_todo,
        "completed": new_completed
    }
    
    # Make PATCH request to update the todo
    url = f"{base_url}/todos/{resource_id}"
    response = requests.patch(url, json=payload)
    
    # Raise exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Decode JSON response
    data = response.json()
    
    # Return None for successful empty response
    if not data:
        return None
    
    return data