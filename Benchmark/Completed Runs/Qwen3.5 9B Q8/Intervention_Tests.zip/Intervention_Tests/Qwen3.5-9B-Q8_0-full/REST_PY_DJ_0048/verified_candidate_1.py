import requests

def solve(inputs):
    """
    Submit a new product to DummyJSON and return the title from the response.
    
    Args:
        inputs (dict): Must contain 'new_title' key with the product title string.
        
    Returns:
        str or None: The title from the response, or None if absent or on empty success.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 200-299).
    """
    base_url = "https://dummyjson.com/products"
    
    payload = {
        "title": inputs["new_title"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # Check for empty response (e.g., {"error": "..."})
    if not data or (isinstance(data, dict) and not data):
        return None
    
    # Return title if present, otherwise None
    return data.get("title")