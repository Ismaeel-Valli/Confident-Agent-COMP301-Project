import requests

def solve(inputs):
    """Delete a post by identifier from DummyJSON and return the response's id or None."""
    resource_id = inputs["resource_id"]
    
    url = "https://dummyjson.com/posts/{id}".format(id=resource_id)
    response = requests.delete(url)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to delete post: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # DummyJSON DELETE returns an empty body on success, but the spec says return None for successful empty response.
    # However, we need to check if 'id' is present in the response.
    # According to DummyJSON docs, DELETE /posts/{id} returns 200 OK with an empty body.
    # So data will be {} or possibly {"success": true}. Let's handle both cases.
    
    if "id" in data:
        return data["id"]
    else:
        return None