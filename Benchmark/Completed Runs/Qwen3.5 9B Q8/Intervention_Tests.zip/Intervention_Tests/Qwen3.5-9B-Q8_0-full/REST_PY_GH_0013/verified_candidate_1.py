import requests

def solve(inputs):
    """
    List repository contributors from GitHub REST API v2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git)
            - credential (str): Bearer token for authentication
    
    Returns:
        list or None: Decoded JSON response, or None if empty
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    token = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/contributors"
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"GitHub API request failed with status code {response.status_code}")
    
    data = response.json()
    
    return None if len(data) == 0 else data