import requests


def solve(inputs):
    """
    Create a fork of a GitHub repository.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git)
            - new_name (str): New name for the forked repository
            - credential (str): Bearer token for authentication
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    # GitHub API version 2026-03-10 endpoint for creating a fork
    base_url = "https://api.github.com"
    
    # Construct the URL for creating a fork
    url = f"{base_url}/repos/{inputs['repository_owner']}/{inputs['repository_name']}/forks"
    
    # Prepare headers with authentication
    headers = {
        "Authorization": f"Bearer {inputs['credential']}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare parameters for the fork creation (name is a query parameter)
    params = {
        "name": inputs["new_name"]
    }
    
    # Make the POST request to create the fork
    response = requests.post(url, headers=headers, params=params)
    
    # Check if the response was successful
    if response.status_code not in [201, 202]:
        response.raise_for_status()
    
    # Decode the JSON response
    data = response.json()
    
    # Return None for successful empty responses (though forks typically return data)
    if not data:
        return None
    
    return data