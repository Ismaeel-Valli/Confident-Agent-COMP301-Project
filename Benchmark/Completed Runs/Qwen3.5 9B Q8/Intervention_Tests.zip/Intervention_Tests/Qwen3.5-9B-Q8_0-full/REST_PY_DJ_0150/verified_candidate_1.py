import requests

def solve(inputs):
    """
    Update selected fields of a product on DummyJSON.
    
    Args:
        inputs (dict): Must contain 'resource_id' and 'new_brand'.
        
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty body.
        
    Raises:
        requests.exceptions.RequestException: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_brand = inputs['new_brand']
    
    url = "https://dummyjson.com/products/{id}".format(id=resource_id)
    payload = {"brand": new_brand}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 200:
        return None
    else:
        return response.json()