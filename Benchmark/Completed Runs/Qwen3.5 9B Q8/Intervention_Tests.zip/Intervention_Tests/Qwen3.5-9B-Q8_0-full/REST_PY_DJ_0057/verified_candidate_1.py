import requests

def solve(inputs):
    """
    Submit a new post to DummyJSON using the provided inputs.
    
    Args:
        inputs (dict): Contains 'new_body', 'new_title', and 'new_user_identifier'.
        
    Returns:
        str or None: The title from the response, or None if absent or empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    url = "https://dummyjson.com/posts"
    
    payload = {
        "title": inputs["new_title"],
        "body": inputs["new_body"],
        "userId": inputs["new_user_identifier"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code >= 400:
            raise Exception(f"HTTP {response.status_code}: {response.text}")
        
        data = response.json()
        
        # DummyJSON returns the created post directly in the response body
        title = data.get("title")
        
        return None if title is None or title == "" else title
        
    except requests.RequestException as e:
        raise Exception(f"Request failed: {e}")