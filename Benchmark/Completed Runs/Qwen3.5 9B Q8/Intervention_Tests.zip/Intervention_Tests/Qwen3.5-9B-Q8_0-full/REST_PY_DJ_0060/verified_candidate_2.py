import requests

def solve(inputs):
    """Delete a todo by identifier from DummyJSON and return isDeleted or None."""
    resource_id = inputs["resource_id"]
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    response = requests.delete(url)
    
    if response.status_code != 200:
        raise Exception(f"Failed to delete todo: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Check for isDeleted in the response
    if "isDeleted" in data:
        return data["isDeleted"]
    elif response.text.strip() == "":
        return None
    else:
        return None