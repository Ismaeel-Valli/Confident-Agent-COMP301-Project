import requests

def solve(inputs):
    """
    Retrieve a user by identifier from DummyJSON.
    
    Args:
        inputs (dict): Must contain 'resource_id' (int) - the user ID.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.RequestException: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    
    # DummyJSON user endpoint: https://dummyjson.com/users/{id}
    url = f"https://dummyjson.com/users/{resource_id}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises HTTPError for unsuccessful responses
        
        data = response.json()
        
        # According to DummyJSON API, a successful GET returns the user object directly
        # An empty response would be {} or None-like, but the spec says return None for successful empty
        if not data:
            return None
            
        return data
        
    except requests.RequestException as e:
        raise