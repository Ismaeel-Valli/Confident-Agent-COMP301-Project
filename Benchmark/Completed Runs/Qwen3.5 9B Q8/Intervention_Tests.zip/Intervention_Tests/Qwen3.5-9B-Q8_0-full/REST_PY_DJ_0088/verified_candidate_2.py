import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON and return the response's id value,
    or None if that attribute is absent. Return None for a successful empty response.
    Raise an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_age (int): Value for the age attribute
            - new_firstName (str): Value for the first Name attribute
    
    Returns:
        int or None: The id from the response, or None if absent or empty response
    
    Raises:
        requests.RequestException: If HTTP response is unsuccessful
    """
    base_url = "https://dummyjson.com/users/add"
    
    payload = {
        "age": inputs["new_age"],
        "firstName": inputs["new_firstName"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        if response.status_code >= 400:
            raise requests.RequestException(f"Failed to create user: {response.status_code} - {response.text}")
        
        # Check if response is empty (no content)
        if not response.content:
            return None
        
        data = response.json()
        
        # Return id if present, otherwise None
        return data.get("id")
    
    except requests.RequestException as e:
        raise