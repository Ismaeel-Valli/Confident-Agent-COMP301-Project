import requests

def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - included_fields (str): Comma-separated list of fields to return
            
    Returns:
        dict or None: Decoded JSON response, or None for empty successful response
        
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    # Base URL for DummyJSON todos
    base_url = "https://dummyjson.com/todos"
    
    # Parse included_fields from comma-separated string
    if inputs.get("included_fields"):
        fields = [f.strip() for f in inputs["included_fields"].split(",")]
    else:
        fields = []
    
    # Build query parameters
    params = {}
    if fields:
        params["fields"] = ",".join(fields)
    
    try:
        # Make GET request to retrieve todos
        response = requests.get(base_url, params=params)
        
        # Raise exception for unsuccessful HTTP responses
        response.raise_for_status()
        
        # Decode JSON response
        data = response.json()
        
        # Return None for successful empty response (empty todos array)
        if not data.get("todos") or len(data["todos"]) == 0:
            return None
        
        return data
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")