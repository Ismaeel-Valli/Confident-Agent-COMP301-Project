import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON and return the response's id value,
    or None if that attribute is absent. Return None for a successful empty response.
    Raise an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_lastName'.
        
    Returns:
        int or None: The id of the created user, or None if absent or on empty response.
        
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/users"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "lastName": inputs["new_lastName"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 201:
            data = response.json()
            # DummyJSON returns the created user in 'user' key for POST
            if "user" in data and data["user"] is not None:
                return data["user"].get("id")
            elif data.get("status") == "success":
                return None  # Empty successful response
            else:
                return None  # Absent id attribute
        
        # For other successful status codes (e.g., 200), check for id
        if response.status_code in [200, 201]:
            data = response.json()
            if "id" in data and data["id"] is not None:
                return data["id"]
        
        # If we get here with a successful status but no clear id, return None
        return None
        
    except requests.RequestException as e:
        raise