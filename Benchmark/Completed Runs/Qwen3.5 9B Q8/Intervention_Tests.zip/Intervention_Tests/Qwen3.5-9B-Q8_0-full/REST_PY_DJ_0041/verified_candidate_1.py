import requests

def solve(inputs):
    """
    Update selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_todo'.
        
    Returns:
        int or None: The response's id value, or None if absent or empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_todo = inputs['new_todo']
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    try:
        response = requests.patch(url, json={"todo": new_todo})
        response.raise_for_status()
        
        if response.status_code == 200:
            data = response.json()
            return data.get('id')
        elif response.status_code == 204:
            return None
        else:
            raise Exception(f"Unexpected status code: {response.status_code}")
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")