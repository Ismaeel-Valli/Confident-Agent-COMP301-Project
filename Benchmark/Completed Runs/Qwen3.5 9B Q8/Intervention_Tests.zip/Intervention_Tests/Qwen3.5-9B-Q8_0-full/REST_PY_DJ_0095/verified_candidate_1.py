import requests

def solve(inputs):
    """
    Submit a new product to DummyJSON using the provided price and title.
    
    Args:
        inputs (dict): Must contain 'new_price' and 'new_title'.
        
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/products"
    
    payload = {
        "title": inputs["new_title"],
        "price": inputs["new_price"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code == 201:
        return None
    elif response.status_code in (200, 204):
        return response.json() if response.content else None
    else:
        raise Exception(f"Failed to create product. Status code: {response.status_code}, Response: {response.text}")