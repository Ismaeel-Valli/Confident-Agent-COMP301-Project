import requests
import json

def solve(inputs):
    """
    Delete a GitHub organization using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): Contains 'organization' (str) and 'credential' (str).
        
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    org_name = inputs["organization"]
    credential = inputs["credential"]
    
    # GitHub API endpoint for deleting an organization
    url = f"https://api.github.com/orgs/{org_name}"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.delete(url, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses
    if not response.ok:
        raise Exception(f"Failed to delete organization {org_name}: {response.status_code} - {response.text}")
    
    # Decode the JSON response
    try:
        data = response.json()
    except json.JSONDecodeError:
        data = None
    
    # Return None for successful empty response, otherwise return decoded JSON
    if response.status_code == 204:
        return None
    else:
        return data