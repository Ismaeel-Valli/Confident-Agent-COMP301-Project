import requests

def solve(inputs):
    """
    Submit a new product to DummyJSON and return the title from the response.
    
    Args:
        inputs (dict): Must contain 'new_description' and 'new_title'.
        
    Returns:
        str or None: The title from the response, or None if absent or on empty success.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    base_url = "https://dummyjson.com/products/add"
    
    payload = {
        "description": inputs["new_description"],
        "title": inputs["new_title"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        if response.status_code >= 400:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
        
        data = response.json()
        
        # DummyJSON POST to /products/add returns the created product directly
        title = data.get("title")
        
        return title if title is not None else None
        
    except requests.RequestException as e:
        raise Exception(f"Request failed: {e}")