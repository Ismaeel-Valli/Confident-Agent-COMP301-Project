import requests

def solve(inputs):
    """
    Retrieve a post by identifier from DummyJSON.
    
    Args:
        inputs (dict): Must contain 'resource_id' (int) - the post ID.
        
    Returns:
        dict or None: The decoded JSON response, or None if empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/posts/{resource_id}"
    
    response = requests.get(url)
    response.raise_for_status()  # Raise exception for unsuccessful HTTP status codes
    
    data = response.json()
    
    if not data:
        return None
        
    return data