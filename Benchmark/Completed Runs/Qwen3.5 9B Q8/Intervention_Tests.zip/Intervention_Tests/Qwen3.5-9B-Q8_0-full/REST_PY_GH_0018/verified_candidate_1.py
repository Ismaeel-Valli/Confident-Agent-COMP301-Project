import requests

def solve(inputs):
    """
    Retrieve a GitHub issue comment using the REST API v2026-03-10.
    
    Args:
        inputs (dict): Contains repository_owner, repository_name, comment_id, and credential.
        
    Returns:
        dict or None: Decoded JSON response. Returns None for successful empty responses.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    comment_id = inputs["comment_id"]
    credential = inputs["credential"]
    
    # Construct the API URL for GitHub v2026-03-10
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/comments/{comment_id}"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        return data if data else None
    elif response.status_code == 404:
        # Comment not found or repository does not exist
        return None
    else:
        raise Exception(f"Failed to retrieve issue comment. Status code: {response.status_code}, Response: {response.text}")