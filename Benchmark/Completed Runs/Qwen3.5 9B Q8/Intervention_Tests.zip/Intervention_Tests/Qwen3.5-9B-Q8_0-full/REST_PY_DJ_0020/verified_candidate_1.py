import requests

def solve(inputs):
    """
    Retrieve a todo by identifier from DummyJSON.
    
    Args:
        inputs (dict): Must contain 'resource_id' (int) - the todo ID.
        
    Returns:
        dict or None: Decoded JSON response, or None if empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs["resource_id"]
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        
        if response.status_code == 200:
            data = response.json()
            return data if data else None
        else:
            raise Exception(f"Unexpected status code: {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")