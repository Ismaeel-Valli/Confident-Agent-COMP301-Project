import requests

def solve(inputs):
    """Retrieve a post by identifier from DummyJSON and return its title."""
    try:
        response = requests.get(
            "https://dummyjson.com/posts/get",
            params={"id": inputs["resource_id"]}
        )
        response.raise_for_status()
        
        if not response.json():
            return None
        
        data = response.json()
        if "title" not in data:
            return None
            
        return data["title"]
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")