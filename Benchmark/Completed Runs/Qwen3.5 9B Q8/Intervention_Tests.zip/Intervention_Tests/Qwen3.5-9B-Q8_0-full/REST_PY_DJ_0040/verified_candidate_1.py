import requests

def solve(inputs):
    """
    Retrieve a todo by identifier from DummyJSON and return its id.
    
    Args:
        inputs (dict): Must contain 'resource_id' key with the todo ID.
        
    Returns:
        int or None: The todo's id, or None if absent or response is empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    
    if resource_id is None:
        return None
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        
        data = response.json()
        
        # Check if the response has an 'id' field
        if 'id' in data and data['id'] is not None:
            return data['id']
        else:
            return None
            
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")