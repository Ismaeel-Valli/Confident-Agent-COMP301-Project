import requests

def solve(inputs):
    """Submit a new product to DummyJSON and return its id."""
    base_url = "https://dummyjson.com/products/add"
    
    payload = {
        "title": inputs["new_title"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create product. Status code: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns the created item directly in the response body for POST
    if "id" in data:
        return data["id"]
    else:
        return None