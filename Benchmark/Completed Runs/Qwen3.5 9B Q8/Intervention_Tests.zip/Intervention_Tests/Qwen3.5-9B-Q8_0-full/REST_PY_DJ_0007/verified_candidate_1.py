import requests

def solve(inputs):
    """
    Retrieve one page of users from DummyJSON.
    
    Args:
        inputs (dict): Must contain 'page' key with an integer value.
        
    Returns:
        dict or None: Decoded JSON response, or None if successful but empty.
        
    Raises:
        requests.RequestException: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/users"
    page = inputs.get("page")
    
    if page is None:
        raise ValueError("Missing required parameter 'page' in inputs.")
    
    url = f"{base_url}?page={page}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        
        data = response.json()
        
        # Return None for successful empty response (empty users array)
        if not data.get("users"):
            return None
            
        return data
        
    except requests.RequestException as e:
        raise e