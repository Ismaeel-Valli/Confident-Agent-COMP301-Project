import requests

def solve(inputs):
    """
    Delete a GitHub issue comment using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git)
            - comment_id (int): Unique identifier of the comment to delete
            - credential (str): Caller-supplied authentication token
    
    Returns:
        int: Successful HTTP status code (204 for deletion)
    
    Raises:
        Exception: If the HTTP response is unsuccessful
    """
    # Build the API URL for deleting a comment
    # GitHub REST API v2026-03-10 endpoint for deleting comments
    base_url = "https://api.github.com"
    url = f"{base_url}/repos/{inputs['repository_owner']}/{inputs['repository_name']}/issues/comments/{inputs['comment_id']}"
    
    # Prepare headers with authentication
    headers = {
        "Authorization": f"token {inputs['credential']}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Send DELETE request
    response = requests.delete(url, headers=headers)
    
    # Raise exception for unsuccessful responses
    if response.status_code >= 400:
        raise Exception(f"Failed to delete comment. Status code: {response.status_code}, Response: {response.text}")
    
    return response.status_code