import requests

def solve(inputs):
    """
    Submit a new post to DummyJSON using the provided inputs.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_body: value for the body attribute
            - new_title: value for the title attribute
            - new_user_identifier: value for the user Id attribute
    
    Returns:
        int or None: The response's id value, or None if that attribute is absent.
                      Returns None for a successful empty response.
    
    Raises:
        Exception: For an unsuccessful HTTP response.
    """
    base_url = "https://dummyjson.com/posts/add"
    
    payload = {
        "title": inputs["new_title"],
        "body": inputs["new_body"],
        "userId": inputs["new_user_identifier"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if the response is empty
        if not response.text.strip():
            return None
        
        # Try to get the id from the response
        try:
            data = response.json()
            return data.get("id")
        except ValueError:
            # If JSON parsing fails, check if it's an empty string or whitespace
            if not response.text.strip():
                return None
            raise
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")