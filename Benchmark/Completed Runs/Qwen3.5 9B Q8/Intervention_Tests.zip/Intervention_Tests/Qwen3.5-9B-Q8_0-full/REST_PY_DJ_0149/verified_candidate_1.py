import requests

def solve(inputs):
    """
    Retrieve one page of products from DummyJSON with pagination and field filtering.
    
    Args:
        inputs (dict): Dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip (for pagination).
            - included_fields (str): Comma-separated list of fields to include.
    
    Returns:
        dict or None: Decoded JSON response, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/products"
    limit = inputs["result_limit"]
    skip = inputs["results_to_skip"]
    fields_str = inputs["included_fields"]
    
    # Build query parameters
    params = {
        "limit": limit,
        "skip": skip,
        "select": fields_str
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # If the response is empty (e.g., no products), return None
    if not data.get("products"):
        return None
    
    return data