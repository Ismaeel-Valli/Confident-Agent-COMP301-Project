import requests

def solve(inputs):
    """
    Update selected fields of a product on DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (int): Identifier of the product
            - new_description (str): Value for the description attribute
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response
    """
    base_url = "https://dummyjson.com/products"
    resource_id = inputs["resource_id"]
    new_description = inputs["new_description"]
    
    url = f"{base_url}/{resource_id}"
    
    payload = {
        "description": new_description
    }
    
    try:
        response = requests.put(url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 200 and not response.text.strip():
            return None
        
        return response.json()
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")