import requests

def solve(inputs):
    """
    Update a todo in DummyJSON with new_completed value.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_completed'.
        
    Returns:
        int or None: The response's id, or None if absent or empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_completed = inputs['new_completed']
    
    # Base URL for DummyJSON API
    base_url = "https://dummyjson.com"
    
    # Construct the update endpoint URL
    url = f"{base_url}/todos/{resource_id}"
    
    # Prepare the payload with only the field to update
    payload = {
        "completed": new_completed
    }
    
    try:
        response = requests.put(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if the response is empty
        if not response.text.strip():
            return None
        
        # Parse the JSON response
        data = response.json()
        
        # Return the id from the response, or None if absent
        return data.get('id')
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")