### Confidence Agent Report

**Decision:** deliver_with_flag
**EWCS:** 0.7308 (signed: 0.7308, applicable weight: 13)

| Layer | State | Tier | Weight | Factor | Positive | Signed |
|---|---|---|---|---|---|---|
| interface | verified_correct | tier_2 | 3 | 0.8 | 2.4 | 2.4 |
| identifier | verified_correct | tier_4 | 3 | 0.5 | 1.5 | 1.5 |
| access_point | verified_correct | tier_2 | 4 | 0.8 | 3.2 | 3.2 |
| input_contract | verified_correct | tier_2 | 2 | 0.8 | 1.6 | 1.6 |
| output_contract | verified_correct | tier_2 | 1 | 0.8 | 0.8 | 0.8 |
| contextual | not_applicable | none | 2 | 0 | 0 | 0 |

Scope: API-claim and static evidence only. EWCS is not a probability of correctness. Task behavior has not been independently checked by this verifier.

Policy 2026-09-25.1: thresholds 0.85/0.6, uncertainty gate on.

Evidence:

- interface: requests maps to requests (2.34.2). Installation/callables checked separately by Pyright.
- identifier: No identifier, attribute or API-call diagnostics in the configured environment (Pyright standard mode). A clean check does not establish REST contracts or task behavior.
- access_point: PUT https://dummyjson.com/todos/{resource_id} matches the declared server and operation PUT /todos/{id}. Noncritical: runtime path values are assumed to stay within one path segment.
- input_contract: Required inputs, locations and supported value constraints checked for call_31_19 (/todos/{id}). Noncritical: path.id: runtime value resource_id is not statically known; its value constraints are not checked; body.completed: runtime value inputs['new_completed'] is not statically known; its value constraints are not checked
- output_contract: Response path ["id"] is documented for call_31_19 (/todos/{id}).
- contextual: No authentication requirement for this operation. Unused security definitions are not requirements.

Flag: some checks rely on supporting static or package metadata evidence; the code was not executed.

```python
import requests

def solve(inputs):
    """
    Update a todo in DummyJSON with new_completed value.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_completed'.
        
    Returns:
        int or None: The response's id, or None if absent or empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_completed = inputs['new_completed']
    
    # Base URL for DummyJSON API
    base_url = "https://dummyjson.com"
    
    # Construct the update endpoint URL
    url = f"{base_url}/todos/{resource_id}"
    
    # Prepare the payload with only the field to update
    payload = {
        "completed": new_completed
    }
    
    try:
        response = requests.put(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if the response is empty
        if not response.text.strip():
            return None
        
        # Parse the JSON response
        data = response.json()
        
        # Return the id from the response, or None if absent
        return data.get('id')
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```