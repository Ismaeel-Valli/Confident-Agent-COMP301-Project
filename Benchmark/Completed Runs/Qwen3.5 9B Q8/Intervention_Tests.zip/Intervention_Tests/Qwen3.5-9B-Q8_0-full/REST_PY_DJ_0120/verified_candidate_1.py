import requests

def solve(inputs):
    """
    Update selected fields of a post on DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id (int): ID of the post to update.
            - new_user_identifier (str): New value for the user Id attribute.
    
    Returns:
        str or None: The title of the updated post, or None if absent.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/posts"
    resource_id = inputs["resource_id"]
    new_user_identifier = inputs["new_user_identifier"]
    
    url = f"{base_url}/{resource_id}"
    
    payload = {
        "userId": new_user_identifier
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # DummyJSON update returns the updated object directly in the response body
    title = data.get("title")
    
    return title