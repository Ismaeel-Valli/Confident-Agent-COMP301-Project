import requests

def solve(inputs):
    """
    Update selected fields of a todo on DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id (int): ID of the todo to update
            - new_completed (bool): New value for completed field
            - new_user_identifier (int): New value for userId field
    
    Returns:
        int or None: The response's id value, or None if absent.
                     Returns None for successful empty responses.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/todos"
    resource_id = inputs["resource_id"]
    new_completed = inputs["new_completed"]
    new_user_identifier = inputs["new_user_identifier"]
    
    payload = {
        "completed": new_completed,
        "userId": new_user_identifier
    }
    
    response = requests.put(f"{base_url}/{resource_id}", json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    return response.json().get("id")