import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON using the provided age and firstName.
    
    Args:
        inputs (dict): Must contain 'new_age' and 'new_firstName'.
        
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty body.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/users"
    
    payload = {
        "age": inputs["new_age"],
        "firstName": inputs["new_firstName"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 201:
            return None
        else:
            return response.json()
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")