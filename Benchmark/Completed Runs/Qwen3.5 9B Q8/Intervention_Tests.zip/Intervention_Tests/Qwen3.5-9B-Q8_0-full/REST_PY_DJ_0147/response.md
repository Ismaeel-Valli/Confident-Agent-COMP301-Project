### Confidence Agent Report

**Decision:** deliver_with_flag
**EWCS:** 0.7308 (signed: 0.7308, applicable weight: 13)

| Layer | State | Tier | Weight | Factor | Positive | Signed |
|---|---|---|---|---|---|---|
| interface | verified_correct | tier_2 | 3 | 0.8 | 2.4 | 2.4 |
| identifier | verified_correct | tier_4 | 3 | 0.5 | 1.5 | 1.5 |
| access_point | verified_correct | tier_2 | 4 | 0.8 | 3.2 | 3.2 |
| input_contract | verified_correct | tier_2 | 2 | 0.8 | 1.6 | 1.6 |
| output_contract | verified_correct | tier_2 | 1 | 0.8 | 0.8 | 0.8 |
| contextual | not_applicable | none | 2 | 0 | 0 | 0 |

Scope: API-claim and static evidence only. EWCS is not a probability of correctness. Task behavior has not been independently checked by this verifier.

Policy 2026-09-25.1: thresholds 0.85/0.6, uncertainty gate on.

Evidence:

- interface: requests maps to requests (2.34.2). Installation/callables checked separately by Pyright.
- identifier: No identifier, attribute or API-call diagnostics in the configured environment (Pyright standard mode). A clean check does not establish REST contracts or task behavior.
- access_point: PUT https://dummyjson.com/posts/{id} matches the declared server and operation PUT /posts/{id}. Noncritical: runtime path values are assumed to stay within one path segment.
- input_contract: Required inputs, locations and supported value constraints checked for call_27_15 (/posts/{id}). Noncritical: path.id: runtime value id is not statically known; its value constraints are not checked; body.body: runtime value inputs['new_body'] is not statically known; its value constraints are not checked; body.title: runtime value inputs['new_title'] is not statically known; its value constraints are not checked
- output_contract: Response path ["title"] is documented for call_27_15 (/posts/{id}).
- contextual: No authentication requirement for this operation. Unused security definitions are not requirements.

Flag: some checks rely on supporting static or package metadata evidence; the code was not executed.

```python
import requests

def solve(inputs):
    """
    Update selected fields of a post on DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id', 'new_body', 'new_title'.
        
    Returns:
        str or None: The title value from the response, or None if absent or empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_body = inputs['new_body']
    new_title = inputs['new_title']
    
    url = "https://dummyjson.com/posts/{id}".format(id=resource_id)
    
    payload = {
        "body": new_body,
        "title": new_title
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    title = data.get('title')
    return title if title is not None else None
```