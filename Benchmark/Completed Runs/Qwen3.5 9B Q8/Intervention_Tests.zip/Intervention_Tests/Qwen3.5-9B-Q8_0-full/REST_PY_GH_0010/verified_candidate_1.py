import requests

def solve(inputs):
    """
    Get a branch from GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git extension)
            - branch (str): Name of the branch
            - credential (str): Caller-supplied authentication token
    
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    branch = inputs["branch"]
    credential = inputs["credential"]
    
    # GitHub REST API v3 endpoint for getting a branch
    url = f"https://api.github.com/repos/{owner}/{repo}/branches/{branch}"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github.v3+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        # Return None for successful empty response (though branches typically have data)
        return data if data else None
    elif response.status_code == 404:
        raise Exception(f"Branch not found: {branch}")
    else:
        raise Exception(f"Failed to get branch. Status code: {response.status_code}, Response: {response.text}")