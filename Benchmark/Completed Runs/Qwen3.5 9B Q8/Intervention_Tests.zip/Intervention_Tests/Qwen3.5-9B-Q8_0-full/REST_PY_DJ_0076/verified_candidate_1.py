import requests

def solve(inputs):
    """
    Retrieve one page of users from DummyJSON, sorted by sort_field.
    
    Args:
        inputs (dict): Must contain 'sort_field' key.
        
    Returns:
        list or None: Decoded JSON response (list of users), or None if empty.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/users"
    
    # Validate required input
    if 'sort_field' not in inputs:
        raise ValueError("Missing required key: sort_field")
    
    sort_field = inputs['sort_field']
    
    params = {
        'limit': 1,
        'sort': sort_field
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for empty response (users array is empty)
    if not data.get('users'):
        return None
    
    return data['users']