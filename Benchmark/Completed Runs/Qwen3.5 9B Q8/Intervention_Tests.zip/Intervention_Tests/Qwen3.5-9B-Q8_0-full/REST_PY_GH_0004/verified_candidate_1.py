import requests
import json


def solve(inputs):
    """
    List organization repositories from GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - "organization" (str): The organization name.
            - "credential" (str): The caller-supplied credential (token).
    
    Returns:
        list or None: Decoded JSON response as a list of repositories, 
                      or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    org = inputs["organization"]
    token = inputs["credential"]
    
    url = "https://api.github.com/orgs/{org}/repos".format(org=org)
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch repositories: {response.status_code} - {response.text}")
    
    data = response.json()
    
    if not data:
        return None
    
    return data