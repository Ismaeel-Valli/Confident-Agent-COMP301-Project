import requests

def solve(inputs):
    """
    Retrieve one page of products from DummyJSON, sorted by sort_field in sort_direction.
    
    Args:
        inputs (dict): Must contain 'sort_field' and 'sort_direction'.
        
    Returns:
        dict or None: Decoded JSON response, or None if empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    
    # Validate inputs
    required_fields = ['sort_field', 'sort_direction']
    for field in required_fields:
        if field not in inputs:
            raise ValueError(f"Missing required input: {field}")
    
    sort_field = inputs['sort_field']
    sort_direction = inputs['sort_direction']
    
    # Build URL with query parameters
    params = {
        'limit': 1,
        'skip': 0,
        'sort_by': sort_field,
        'order': sort_direction
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Return None for empty products list
    if not data.get('products'):
        return None
    
    return data