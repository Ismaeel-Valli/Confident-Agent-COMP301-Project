import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON using the provided first name and phone number.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_phone'.
        
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/users/add"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "phone": inputs["new_phone"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to submit user. HTTP status code: {response.status_code}")
    
    return response.json()