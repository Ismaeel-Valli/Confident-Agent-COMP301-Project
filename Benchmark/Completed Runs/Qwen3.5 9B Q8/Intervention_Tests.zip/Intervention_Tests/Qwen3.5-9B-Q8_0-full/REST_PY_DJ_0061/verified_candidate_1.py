import requests

def solve(inputs):
    """
    Retrieve one page of products from DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - included_fields (str): Comma-separated list of fields to include
    
    Returns:
        dict or None: Decoded JSON response, or None for empty successful response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    # Base URL for DummyJSON products API
    base_url = "https://dummyjson.com/products"
    
    # Build query parameters from included_fields
    params = {}
    if inputs.get("included_fields"):
        fields = [f.strip() for f in inputs["included_fields"].split(",")]
        # Use the _include parameter to specify which fields to include
        params["_include"] = ",".join(fields)
    
    try:
        response = requests.get(base_url, params=params)
        
        # Raise exception for unsuccessful HTTP responses
        response.raise_for_status()
        
        # Decode JSON response
        data = response.json()
        
        # Return None for empty successful response (empty products array)
        if not data.get("products") or len(data["products"]) == 0:
            return None
        
        return data
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")