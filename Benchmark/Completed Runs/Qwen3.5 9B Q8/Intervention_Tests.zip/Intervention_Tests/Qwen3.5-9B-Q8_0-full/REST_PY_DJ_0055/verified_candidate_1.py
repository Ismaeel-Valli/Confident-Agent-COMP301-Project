import requests

def solve(inputs):
    """
    Update a post on DummyJSON with a new title and return the updated title.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (int): The ID of the post to update.
            - new_title (str): The new title for the post.
    
    Returns:
        str or None: The updated title from the response, or None if absent.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    base_url = "https://dummyjson.com/posts"
    resource_id = inputs["resource_id"]
    new_title = inputs["new_title"]
    
    payload = {
        "title": new_title
    }
    
    response = requests.put(f"{base_url}/{resource_id}", json=payload)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to update post: {response.status_code}")
    
    data = response.json()
    return data.get("title")