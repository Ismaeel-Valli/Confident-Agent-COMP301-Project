import requests

def solve(inputs):
    """
    Retrieve one page of users from DummyJSON with a limit on results.
    
    Args:
        inputs (dict): Must contain 'result_limit' (int).
        
    Returns:
        list or None: Decoded JSON response as a list, or None if empty.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/users"
    result_limit = inputs["result_limit"]
    
    params = {"limit": result_limit}
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    # DummyJSON returns a dict with 'users' key containing the list
    users_list = data.get("users", [])
    
    if not users_list:
        return None
    
    return users_list