import requests

def solve(inputs):
    """
    Update selected fields of a user on DummyJSON and return the response's id,
    or None if absent or for an empty successful response. Raise exception on failure.
    
    Args:
        inputs (dict): Must contain 'resource_id' (user ID) and 'new_firstName'.
    
    Returns:
        int or None: The updated user's id, or None if absent/empty response.
    
    Raises:
        Exception: If the HTTP response indicates failure (non-2xx status).
    """
    resource_id = inputs.get('resource_id')
    new_first_name = inputs.get('new_firstName')
    
    if resource_id is None or new_first_name is None:
        raise ValueError("Missing required input fields: 'resource_id' and/or 'new_firstName'")
    
    base_url = "https://dummyjson.com/users"
    url = f"{base_url}/{resource_id}"
    
    payload = {
        "firstName": new_first_name
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    # Check for empty response
    data = response.json()
    if not data:
        return None
    
    # Return the id from the response
    user_id = data.get('id')
    return user_id if user_id is not None else None