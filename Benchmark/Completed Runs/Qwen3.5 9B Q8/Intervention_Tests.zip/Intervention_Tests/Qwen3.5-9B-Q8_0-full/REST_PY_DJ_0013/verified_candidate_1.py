import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON.
    
    Args:
        inputs (dict): Must contain 'page' key with an integer value.
        
    Returns:
        dict or None: Decoded JSON response, or None if successful but empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/posts"
    page = inputs.get("page")
    
    if page is None:
        raise ValueError("Missing required 'page' parameter in inputs.")
    
    url = f"{base_url}?page={page}"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error occurred: {response.status_code}")
    
    data = response.json()
    
    # Return None for successful empty response (though DummyJSON posts endpoint doesn't return empty on success)
    if not data:
        return None
    
    return data