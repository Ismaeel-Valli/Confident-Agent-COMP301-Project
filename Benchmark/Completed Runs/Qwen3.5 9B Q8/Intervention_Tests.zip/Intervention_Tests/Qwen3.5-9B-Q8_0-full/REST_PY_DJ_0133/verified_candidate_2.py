import requests

def solve(inputs):
    """
    Submit a new product to DummyJSON and return the response's id value,
    or None if that attribute is absent. Return None for a successful empty response.
    Raise an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_category (str): Value for the category attribute
            - new_title (str): Value for the title attribute
    
    Returns:
        int or None: The id from the response, or None if absent or empty response
    
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful
    """
    base_url = "https://dummyjson.com/products/add"
    
    # Build the payload with required fields
    payload = {
        "category": inputs["new_category"],
        "title": inputs["new_title"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        # Raise exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if response is empty
        if not response.text.strip():
            return None
        
        # Parse JSON response
        data = response.json()
        
        # Return id if present, otherwise None
        return data.get("id")
    
    except requests.RequestException as e:
        raise