import requests

def solve(inputs):
    """
    Update selected fields of a product on DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_category'.
        
    Returns:
        str or None: The title from the response, or None if absent or empty.
    """
    resource_id = inputs['resource_id']
    new_category = inputs['new_category']
    
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/{resource_id}"
    
    payload = {
        "category": new_category
    }
    
    try:
        response = requests.put(url, json=payload)
        response.raise_for_status()
        
        data = response.json()
        
        if 'title' in data and data['title'] is not None and data['title'] != "":
            return data['title']
        else:
            return None
            
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")