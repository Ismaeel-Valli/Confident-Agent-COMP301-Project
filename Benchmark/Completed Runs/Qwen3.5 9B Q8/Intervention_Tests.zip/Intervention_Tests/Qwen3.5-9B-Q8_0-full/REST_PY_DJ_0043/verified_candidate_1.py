import requests

def solve(inputs):
    """
    Create a new todo on DummyJSON using the provided inputs.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_completed: value for the completed attribute
            - new_todo: value for the todo attribute
            - new_user_identifier: value for the user Id attribute
    
    Returns:
        int or None: The response's id value, or None if absent.
                     Returns None for a successful empty response.
    
    Raises:
        Exception: For an unsuccessful HTTP response.
    """
    base_url = "https://dummyjson.com"
    endpoint = "/todos"
    
    payload = {
        "completed": inputs["new_completed"],
        "todo": inputs["new_todo"],
        "userId": inputs["new_user_identifier"]
    }
    
    response = requests.post(f"{base_url}{endpoint}", json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create todo. Status code: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns the created item directly in the response body for POST requests
    if "id" in data:
        return data["id"]
    elif data == {}:
        return None
    else:
        # If response is not empty but has no id, return None as per spec
        return None