import requests
import json

def solve(inputs):
    """
    Update a GitHub issue using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): Contains:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git)
            - issue_number (int): Issue number to update
            - new_title (str): New title for the issue
            - credential (str): Bearer token for authentication
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    base_url = "https://api.github.com"
    
    # Construct the URL for updating an issue
    url = f"{base_url}/repos/{inputs['repository_owner']}/{inputs['repository_name']}/issues/{inputs['issue_number']}"
    
    # Prepare headers with Bearer token authentication
    headers = {
        "Authorization": f"Bearer {inputs['credential']}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare the payload with only the title field to update
    payload = {
        "title": inputs['new_title']
    }
    
    try:
        response = requests.put(url, json=payload, headers=headers)
        
        # Raise an exception for unsuccessful HTTP responses
        response.raise_for_status()
        
        # Return decoded JSON response
        if response.status_code == 204:
            return None
        
        return response.json()
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Failed to update issue: {e}")