import requests

def solve(inputs):
    """
    Retrieve one page of products from DummyJSON with pagination support.
    
    Args:
        inputs (dict): Dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - included_fields (str): Comma-separated list of fields to include.
    
    Returns:
        dict or None: Decoded JSON response, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/products"
    limit = inputs.get("result_limit", 10)
    fields = inputs.get("included_fields", "")
    
    # Build query parameters
    params = {"limit": limit}
    if fields:
        params["select"] = fields
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()
    
    data = response.json()
    
    # Return None for successful empty response
    if not data.get("products"):
        return None
    
    return data