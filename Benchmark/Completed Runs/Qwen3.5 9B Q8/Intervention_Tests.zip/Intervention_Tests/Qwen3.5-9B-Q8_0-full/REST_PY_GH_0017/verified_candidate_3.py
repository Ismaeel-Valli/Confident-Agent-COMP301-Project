import requests
import json

def solve(inputs):
    """
    Create a GitHub issue in the specified repository using the REST API v2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git extension)
            - new_title (str): Title for the issue
            - credential (str): Bearer token for authentication
    
    Returns:
        dict or None: Decoded JSON response. Returns None for successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    title = inputs["new_title"]
    credential = inputs["credential"]
    
    # GitHub API endpoint for creating an issue
    url = f"https://api.github.com/repos/{owner}/{repo}/issues"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    data = {
        "title": title
    }
    
    response = requests.post(url, json=data, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses
    if not response.ok:
        raise Exception(f"Failed to create issue. Status code: {response.status_code}, Response: {response.text}")
    
    # Return decoded JSON response
    return response.json()