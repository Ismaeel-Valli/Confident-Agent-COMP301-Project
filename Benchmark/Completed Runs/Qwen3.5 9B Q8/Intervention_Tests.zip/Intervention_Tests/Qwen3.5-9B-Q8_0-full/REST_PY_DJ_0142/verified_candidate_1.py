import requests

def solve(inputs):
    """
    Submit a new product to DummyJSON using the provided category and title.
    
    Args:
        inputs (dict): Dictionary containing 'new_category' and 'new_title'.
        
    Returns:
        str or None: The title from the response, or None if absent or empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/products"
    
    payload = {
        "category": inputs["new_category"],
        "title": inputs["new_title"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 201:
            data = response.json()
            # DummyJSON returns the created product in the response body for POST
            title = data.get("title")
            return title if title is not None else None
        elif response.status_code == 200:
            # Some endpoints might return 200 with empty body or different structure
            data = response.json()
            title = data.get("title")
            return title if title is not None else None
        else:
            raise Exception(f"Unexpected status code: {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")