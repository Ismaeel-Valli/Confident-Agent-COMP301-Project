import requests

def solve(inputs):
    """
    Update a todo item in DummyJSON using PATCH request.
    
    Args:
        inputs (dict): Contains:
            - resource_id (int): ID of the todo to update
            - new_todo (str): New value for the 'todo' field
            - new_user_identifier (int): New value for the 'userId' field
    
    Returns:
        dict or None: Decoded JSON response, or None if response is empty
    
    Raises:
        Exception: If HTTP response status indicates failure
    """
    base_url = "https://dummyjson.com/todos"
    
    # Construct PATCH payload
    payload = {
        "todo": inputs["new_todo"],
        "userId": inputs["new_user_identifier"]
    }
    
    # Make PATCH request to update the todo
    response = requests.patch(
        f"{base_url}/{inputs['resource_id']}",
        json=payload
    )
    
    # Raise exception for unsuccessful HTTP responses
    if response.status_code >= 400:
        raise Exception(f"Failed to update todo: {response.status_code} - {response.text}")
    
    # Decode JSON response
    try:
        data = response.json()
        
        # Return None for successful empty response (204 No Content)
        if not data:
            return None
        
        return data
    except ValueError:
        raise Exception(f"Invalid JSON response: {response.text}")