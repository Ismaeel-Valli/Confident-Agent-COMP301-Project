import requests

def solve(inputs):
    """
    Update a todo item in DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (int): The ID of the todo to update
            - new_completed (bool): The new value for the completed field
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response.
    
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/todos"
    resource_id = inputs["resource_id"]
    new_completed = inputs["new_completed"]
    
    payload = {
        "completed": new_completed
    }
    
    try:
        response = requests.put(
            f"{base_url}/{resource_id}",
            json=payload
        )
        
        if response.status_code >= 400:
            raise Exception(f"HTTP error: {response.status_code} - {response.text}")
        
        return response.json()
    except requests.RequestException as e:
        raise Exception(f"Request failed: {e}")