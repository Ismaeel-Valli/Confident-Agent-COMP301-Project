import requests

def solve(inputs):
    """
    Submit a new product to DummyJSON and return the title from the response,
    or None if absent. Raise an exception for unsuccessful HTTP responses.
    
    Args:
        inputs (dict): Must contain 'new_price' and 'new_title'.
        
    Returns:
        str or None: The title from the response, or None if absent.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    base_url = "https://dummyjson.com/products/add"
    
    payload = {
        "title": inputs["new_title"],
        "price": inputs["new_price"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create product. Status code: {response.status_code}")
    
    data = response.json()
    
    return data.get("title")