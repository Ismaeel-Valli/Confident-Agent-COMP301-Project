import requests

def solve(inputs):
    """
    Update selected fields of a product on DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (int): Identifier of the product.
            - new_price (float or int): New price value.
    
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    resource_id = inputs["resource_id"]
    new_price = inputs["new_price"]
    
    url = f"{base_url}/{resource_id}"
    payload = {"price": new_price}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 201:
        return response.json()
    else:
        raise Exception(f"Failed to update product. Status code: {response.status_code}")