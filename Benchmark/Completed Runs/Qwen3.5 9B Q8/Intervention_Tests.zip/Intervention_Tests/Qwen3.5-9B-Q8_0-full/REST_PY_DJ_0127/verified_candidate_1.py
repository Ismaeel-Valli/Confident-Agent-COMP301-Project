import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON using the provided firstName and phone.
    
    Args:
        inputs (dict): Must contain 'new_firstName' and 'new_phone'.
        
    Returns:
        int or None: The response's id if present, otherwise None for success.
                      Raises an exception on unsuccessful HTTP response.
    """
    base_url = "https://dummyjson.com/users"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "phone": inputs["new_phone"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 201:
            data = response.json()
            return data.get("id")
        else:
            # For other successful status codes (e.g., 200), check for id or return None
            data = response.json()
            return data.get("id") if "id" in data else None
            
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")