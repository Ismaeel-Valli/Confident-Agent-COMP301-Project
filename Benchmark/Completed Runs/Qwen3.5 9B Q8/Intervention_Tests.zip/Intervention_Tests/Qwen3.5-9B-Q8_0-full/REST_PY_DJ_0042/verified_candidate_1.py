import requests

def solve(inputs):
    """Delete a todo by identifier from DummyJSON and return its id or None."""
    resource_id = inputs["resource_id"]
    
    url = "https://dummyjson.com/todos"
    headers = {"Content-Type": "application/json"}
    payload = {"todoId": resource_id}
    
    try:
        response = requests.delete(url, json=payload, headers=headers)
        response.raise_for_status()
        
        if response.status_code == 200:
            return None
        
        data = response.json()
        if "id" in data:
            return data["id"]
        return None
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")