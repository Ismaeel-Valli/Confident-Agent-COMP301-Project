import requests

def solve(inputs):
    """
    Update selected fields of a post on DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id (int): Identifier of the post to update.
            - new_body (str): New value for the body attribute.
            - new_title (str): New value for the title attribute.
            
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/posts"
    
    try:
        response = requests.put(
            f"{base_url}/{inputs['resource_id']}",
            json={
                "title": inputs["new_title"],
                "body": inputs["new_body"]
            }
        )
        
        if response.status_code not in [200, 201]:
            raise Exception(f"HTTP {response.status_code}: {response.text}")
        
        data = response.json()
        
        # Check for id in different possible locations
        post_id = None
        
        # Direct id field
        if "id" in data:
            post_id = data["id"]
        # Nested in content (common pattern)
        elif "content" in data and isinstance(data["content"], dict):
            if "id" in data["content"]:
                post_id = data["content"]["id"]
        # Nested in posts array
        elif "posts" in data and isinstance(data["posts"], list) and len(data["posts"]) > 0:
            if "id" in data["posts"][0]:
                post_id = data["posts"][0]["id"]
        
        return post_id
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")