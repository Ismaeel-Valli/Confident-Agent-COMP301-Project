import requests

def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON with a limit on results.
    
    Args:
        inputs (dict): Must contain 'result_limit' (int).
        
    Returns:
        list or None: Decoded JSON response as a list, or None if empty.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/todos"
    result_limit = inputs.get("result_limit")
    
    params = {"limit": result_limit}
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    todos = data.get("todos", [])
    
    return todos if todos else None