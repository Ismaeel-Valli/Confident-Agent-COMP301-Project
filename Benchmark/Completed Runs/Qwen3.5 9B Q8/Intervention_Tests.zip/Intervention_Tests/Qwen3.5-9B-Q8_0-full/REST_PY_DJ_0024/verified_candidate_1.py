import requests

def solve(inputs):
    """
    Retrieve one page of products from DummyJSON with a limit on results.
    
    Args:
        inputs (dict): Must contain 'result_limit' (int).
        
    Returns:
        list or None: Decoded JSON response as a list, or None if empty.
        
    Raises:
        requests.RequestException: For unsuccessful HTTP responses.
    """
    limit = inputs.get('result_limit')
    if limit is None:
        raise ValueError("Missing required parameter: result_limit")
    
    base_url = "https://dummyjson.com/products"
    params = {'limit': limit}
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()
        
        data = response.json()
        products = data.get('products', [])
        
        if not products:
            return None
        
        return products
    except requests.RequestException as e:
        raise