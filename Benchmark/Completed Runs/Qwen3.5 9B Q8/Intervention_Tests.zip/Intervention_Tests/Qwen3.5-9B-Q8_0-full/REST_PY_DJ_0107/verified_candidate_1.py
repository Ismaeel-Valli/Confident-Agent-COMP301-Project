import requests

def solve(inputs):
    """
    Update selected fields of a user on DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_email' (email value).
        
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/users"
    user_id = inputs["resource_id"]
    new_email = inputs["new_email"]
    
    url = f"{base_url}/{user_id}"
    payload = {"email": new_email}
    
    response = requests.patch(url, json=payload)
    
    if response.status_code not in [200, 201]:
        raise Exception(f"Failed to update user: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON PATCH returns the updated user object directly for successful updates
    if "id" in data:
        return data["id"]
    elif response.status_code == 204:
        return None
    else:
        return None