import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_firstName (str): Value for the first name attribute
            - new_username (str): Value for the username attribute
    
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    url = "https://dummyjson.com/users/add"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "username": inputs["new_username"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code == 201:
            # Successful creation - return decoded JSON
            return response.json()
        elif response.status_code == 204:
            # No content - successful empty response
            return None
        else:
            # Unsuccessful HTTP response
            raise Exception(f"HTTP {response.status_code}: {response.text}")
            
    except requests.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")