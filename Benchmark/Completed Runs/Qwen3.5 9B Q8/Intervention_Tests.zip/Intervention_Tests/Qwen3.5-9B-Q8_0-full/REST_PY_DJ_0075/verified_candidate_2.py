import requests

def solve(inputs):
    """
    Submit a new product to DummyJSON and return the response's id value,
    or None if that attribute is absent. Return None for a successful empty response.
    Raise an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_description (str): Value for the description attribute
            - new_title (str): Value for the title attribute
    
    Returns:
        int or None: The id from the response, or None if absent or empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    base_url = "https://dummyjson.com/products/add"
    
    payload = {
        "description": inputs["new_description"],
        "title": inputs["new_title"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        # Raise exception for unsuccessful HTTP responses
        if not response.ok:
            raise Exception(f"HTTP {response.status_code}: {response.text}")
        
        # Return id if present in response
        data = response.json()
        if "id" in data and data["id"] is not None:
            return data["id"]
        
        # Return None for successful empty response or no id
        return None
        
    except requests.RequestException as e:
        raise Exception(f"Request failed: {e}")