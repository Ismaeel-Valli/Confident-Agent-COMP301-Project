```python
import requests

def solve(inputs):
    resource_id = inputs.get('resource_id')
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"Failed to retrieve todo: {response.status_code}")
    
    data = response.json()
    
    if not data:
        return None
    
    return data.get('id')
```