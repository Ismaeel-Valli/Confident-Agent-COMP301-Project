import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing 'page' key for pagination.
        
    Returns:
        dict: Decoded JSON response if successful and data exists.
        None: If successful but response is empty.
        
    Raises:
        requests.RequestException: For unsuccessful HTTP responses.
    """
    base_url = "https://jsonplaceholder.typicode.com/users"
    page = inputs.get('page', 1)
    
    try:
        response = requests.get(f"{base_url}?page={page}")
        response.raise_for_status()
        
        data = response.json()
        
        # Return None for successful empty response
        if not data:
            return None
            
        return data
        
    except requests.RequestException as e:
        raise e