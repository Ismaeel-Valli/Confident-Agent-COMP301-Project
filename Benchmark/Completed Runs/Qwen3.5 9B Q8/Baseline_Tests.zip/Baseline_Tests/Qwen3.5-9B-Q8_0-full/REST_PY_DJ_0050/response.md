```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the user.
            - new_lastName (str): New value for the last name attribute.
    
    Returns:
        dict or None: The decoded JSON response if successful, otherwise raises an exception.
                      Returns None if the response is empty (successful update).
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    new_lastName = inputs.get('new_lastName')
    
    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {"lastName": new_lastName}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 404:
        raise Exception(f"User with ID {resource_id} not found.")
    else:
        raise Exception(f"Failed to update user. Status code: {response.status_code}, Response: {response.text}")

# Example usage (not executed):
# inputs = {"resource_id": "1", "new_lastName": "Doe"}
# result = solve(inputs)
```