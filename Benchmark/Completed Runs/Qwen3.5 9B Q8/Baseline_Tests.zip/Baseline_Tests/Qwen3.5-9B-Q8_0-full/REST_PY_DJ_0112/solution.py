import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id', 'new_completed', and 'new_todo'.
        
    Returns:
        str or None: The response's id value, or None if successful with empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_completed = inputs.get('new_completed')
    new_todo = inputs.get('new_todo')
    
    # Construct the payload for PATCH request
    payload = {}
    if new_completed is not None:
        payload['completed'] = new_completed
    if new_todo is not None:
        payload['todo'] = new_todo
    
    url = f"https://jsonplaceholder.typicode.com/todos/{resource_id}"
    
    try:
        response = requests.patch(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # If the response is empty (204 No Content), return None
        if response.status_code == 204:
            return None
        
        # Return the id from the response JSON
        data = response.json()
        return data.get('id')
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")