import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'included_fields' (str): Comma-separated string of fields to include.
            - 'sort_field' (str): Field name for sorting the results.
    
    Returns:
        list or None: The decoded JSON response as a list of posts, or None if the response is empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    # Parse included_fields into a list
    included_fields = [field.strip() for field in inputs['included_fields'].split(',')]
    
    # Prepare query parameters
    params = {
        '_include': ','.join(included_fields),
        'sort': inputs['sort_field']
    }
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None if the response is empty
        if not data:
            return None
        
        return data
    
    except requests.exceptions.RequestException as e:
        raise SystemExit(e)