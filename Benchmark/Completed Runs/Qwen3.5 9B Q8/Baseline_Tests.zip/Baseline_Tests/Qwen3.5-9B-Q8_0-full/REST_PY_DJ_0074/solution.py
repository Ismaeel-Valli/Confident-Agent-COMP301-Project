import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (int): Identifier of the product
            - new_description (str): New value for the description attribute
    
    Returns:
        str or None: The response's id value if present, otherwise None.
                     Returns None for a successful empty response.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs['resource_id']
    new_description = inputs['new_description']
    
    # Base URL for DummyJSON API
    base_url = "https://dummyjson.com"
    url = f"{base_url}/products/{resource_id}"
    
    # Prepare the payload with only the field to update
    payload = {
        "description": new_description
    }
    
    try:
        response = requests.put(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if the response is empty
        if not response.text.strip():
            return None
        
        # Parse the JSON response
        data = response.json()
        
        # Return the id value if present, otherwise None
        return data.get('id')
    
    except requests.exceptions.HTTPError as e:
        raise e
    except requests.exceptions.RequestException as e:
        raise e