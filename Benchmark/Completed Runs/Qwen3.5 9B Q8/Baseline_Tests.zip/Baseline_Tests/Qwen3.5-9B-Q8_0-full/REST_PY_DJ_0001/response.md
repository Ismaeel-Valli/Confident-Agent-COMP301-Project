```python
import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing 'page' key for pagination.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.RequestException: If the HTTP request is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    page = inputs.get('page', 1)
    
    url = f"{base_url}/posts?page={page}"
    
    try:
        response = requests.get(url, timeout=5)
        
        if response.status_code != 200:
            raise Exception(f"HTTP request failed with status code: {response.status_code}")
        
        data = response.json()
        
        # Return None for successful empty response
        if not data:
            return None
            
        return data
        
    except requests.RequestException as e:
        raise e
```