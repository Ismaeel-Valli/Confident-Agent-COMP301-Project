import requests

def solve(inputs):
    """
    Retrieves a todo by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with the todo identifier.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.exceptions.RequestException: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise requests.exceptions.RequestException(f"Failed to retrieve todo: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns an empty object {} for non-existent todos (404), 
    # but the problem states to assume referenced resources exist.
    # However, if the endpoint returns 200 with empty content, we return None.
    if not data:
        return None
        
    return data