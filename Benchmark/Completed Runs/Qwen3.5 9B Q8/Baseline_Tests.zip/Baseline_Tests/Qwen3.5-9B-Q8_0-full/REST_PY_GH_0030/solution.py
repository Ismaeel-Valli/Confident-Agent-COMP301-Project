import requests

def solve(inputs):
    """
    Lists repository languages for GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository without the .git extension.
            - 'credential' (str): The caller-supplied credential (e.g., token).
    
    Returns:
        dict or None: The decoded JSON response. Returns None for a successful empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    token = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/languages"
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch repository languages. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # If the response is an empty dictionary (no languages), return None as per requirement
    if not data:
        return None
    
    return data