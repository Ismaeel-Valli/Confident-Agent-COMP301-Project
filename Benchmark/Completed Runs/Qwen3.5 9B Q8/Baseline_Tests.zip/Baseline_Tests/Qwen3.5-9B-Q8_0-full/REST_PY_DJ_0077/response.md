```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_age' (new age value).
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_age = inputs['new_age']
    
    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {"age": new_age}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user: {response.status_code} - {response.text}")
    
    if len(response.content) == 0:
        return None
    
    return response.json()
```