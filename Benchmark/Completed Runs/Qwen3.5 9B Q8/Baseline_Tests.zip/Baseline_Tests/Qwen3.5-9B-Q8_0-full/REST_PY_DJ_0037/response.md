```python
import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    headers = {
        "Accept": "application/json"
    }
    
    response = requests.delete(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to delete post. Status code: {response.status_code}")
    
    data = response.json()
    
    if 'id' in data:
        return data['id']
    elif not data:
        return None
    else:
        return None
```