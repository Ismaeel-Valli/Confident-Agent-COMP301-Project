import requests

def solve(inputs):
    """
    Updates an organization's description via the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The name of the organization to update.
            - 'new_description' (str): The new description for the organization.
            - 'credential' (dict): Contains authentication details, assumed to have a 'token' key.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        requests.RequestException: If the HTTP request fails or returns an unsuccessful status code.
    """
    organization = inputs['organization']
    new_description = inputs['new_description']
    credential = inputs['credential']
    
    # Construct the URL for updating the organization
    url = f"https://api.github.com/orgs/{organization}"
    
    # Prepare headers with Bearer token authentication
    headers = {
        'Authorization': f'Bearer {credential["token"]}',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2026-03-10'
    }
    
    # Prepare the payload for updating the description
    data = {
        'description': new_description
    }
    
    try:
        response = requests.put(url, headers=headers, json=data)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Return None for a successful empty response
        if not response.text:
            return None
        
        # Decode and return the JSON response
        return response.json()
    
    except requests.exceptions.HTTPError as e:
        raise e
    except requests.exceptions.RequestException as e:
        raise e