```python
import requests
from urllib.parse import quote_plus

def solve(inputs):
    """
    Updates the authenticated user's name via GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'new_name' (str): The new name for the user.
            - 'credential' (str): The authentication token or username/password pair.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    new_name = inputs['new_name']
    credential = inputs['credential']
    
    # Determine authentication method based on credential format
    # Assuming 'credential' is a token if it doesn't contain ':'
    if ':' in credential:
        username, password = credential.split(':', 1)
        auth = (username, password)
    else:
        auth = ('', credential)
    
    url = "https://api.github.com/user"
    headers = {
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2026-03-10'
    }
    
    payload = {
        'name': new_name
    }
    
    response = requests.put(url, headers=headers, auth=auth, json=payload)
    
    if response.status_code == 204:
        return None
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user: {response.status_code} - {response.text}")
    
    return response.json()
```