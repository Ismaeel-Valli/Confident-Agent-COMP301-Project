```python
import requests
import json

def solve(inputs):
    """
    Submits a new user to DummyJSON API using provided first and last name.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_lastName'.
        
    Returns:
        None if the response is empty (successful).
        Decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "name": f"{inputs['new_firstName']} {inputs['new_lastName']}",
        "username": inputs['new_firstName'].lower() + inputs['new_lastName'].lower(),
        "email": f"{inputs['new_firstName'].lower()}@example.com",
        "address": {
            "street": "123 Main St",
            "suite": "0 0",
            "city": "New York",
            "zipcode": "10001",
            "geo": {
                "lat": "70.15984",
                "lng": "-168.28769"
            }
        },
        "phone": "1-202-555-0134",
        "website": "example.com",
        "company": {
            "name": "Example Corp",
            "catchPhrase": "Example Corp",
            "bs": "hacking real-time markets"
        }
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. Status code: {response.status_code}, Response: {response.text}")
    
    if not response.json():
        return None
    
    return response.json()
```