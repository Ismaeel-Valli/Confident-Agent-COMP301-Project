import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API using provided first and last name.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_lastName'.
        
    Returns:
        int or None: The ID of the created user, or None if response is empty/successful without ID.
        Raises: Exception for unsuccessful HTTP responses.
    """
    url = "https://dummyjson.com/users/addNewUser"
    
    payload = {
        "firstName": inputs.get("new_firstName"),
        "lastName": inputs.get("new_lastName")
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. HTTP Status Code: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns the created user in 'user' key for POST /users/addNewUser
    if "user" in data and data["user"]:
        return data["user"].get("id")
    elif "id" in data:
        return data.get("id")
    else:
        return None