import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on provided sorting parameters.
    
    Args:
        inputs (dict): A dictionary containing:
            - sort_field (str): The field to sort by.
            - sort_direction (str): The direction to sort ('asc' or 'desc').
    
    Returns:
        list or None: The decoded JSON response as a list of users, or None if the response is empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    url = f"{base_url}/users"
    
    params = {
        '_sort': inputs['sort_field'],
        '_order': inputs['sort_direction']
    }
    
    response = requests.get(url, params=params)
    
    if not response.ok:
        raise requests.RequestException(f"HTTP request failed with status code: {response.status_code}")
    
    data = response.json()
    
    if not data:
        return None
    
    return data