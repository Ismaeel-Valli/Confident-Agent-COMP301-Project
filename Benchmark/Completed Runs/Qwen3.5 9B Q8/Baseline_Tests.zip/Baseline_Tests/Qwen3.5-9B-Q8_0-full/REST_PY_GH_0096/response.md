```python
import requests

def solve(inputs):
    """
    Lists repositories for the authenticated user using GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'credential' (str): The authentication token or header value.
            - 'visibility' (str, optional): Limit results to repositories with the specified visibility ('public', 'private', or 'internal').
    
    Returns:
        list | None: A list of repository objects if there are results, or None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response status code indicates an error (non-2xx).
    """
    url = "https://api.github.com/user/repos"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {inputs['credential']}"
    }
    
    params = {}
    if 'visibility' in inputs and inputs['visibility']:
        params['visibility'] = inputs['visibility']

    response = requests.get(url, headers=headers, params=params)

    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"GitHub API request failed with status code {response.status_code}: {response.text}")

    data = response.json()
    
    # GitHub typically returns an empty list [] for no results, not null.
    # The requirement says "Return None for a successful empty response".
    if data == []:
        return None
    
    return data
```