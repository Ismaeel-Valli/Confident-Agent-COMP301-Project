import requests
from urllib.parse import quote

def solve(inputs):
    """
    Lists issues for a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The caller-supplied credential (e.g., token or Bearer token).
    
    Returns:
        list | None: A list of decoded JSON issue objects, or None if the response is empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    credential = inputs["credential"]
    
    # Construct the API URL for version 2026-03-10
    url = f"https://api.github.com/repos/{quote(owner, safe='')}/{quote(repo, safe='')}/issues"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise requests.RequestException(f"Failed to fetch issues: Status code {response.status_code}")
    
    data = response.json()
    
    # Return None for a successful empty response (empty list)
    return data if data else None