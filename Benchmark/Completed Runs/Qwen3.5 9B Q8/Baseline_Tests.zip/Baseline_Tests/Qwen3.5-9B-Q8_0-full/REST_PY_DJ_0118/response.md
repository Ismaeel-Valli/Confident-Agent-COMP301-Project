```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API with firstName and phone.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_phone'.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "name": inputs["new_firstName"],
        "phone": inputs["new_phone"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. Status code: {response.status_code}, Response: {response.text}")
    
    if response.content == b"":
        return None
    
    return response.json()
```