```python
import requests
import json

def solve(inputs):
    """
    Submits a new user to DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_username'.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "name": inputs["new_firstName"],
        "username": inputs["new_username"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code == 201:
            # Successful creation
            if response.text.strip():
                return response.json()
            else:
                return None
        elif response.status_code == 400:
            raise Exception(f"Bad Request: {response.text}")
        elif response.status_code == 409:
            raise Exception(f"Conflict: Username may already exist")
        else:
            raise Exception(f"Failed to create user. Status code: {response.status_code}, Response: {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Network error occurred: {str(e)}")
```