```python
import requests

def solve(inputs):
    """
    Deletes a user by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with user identifier.
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    
    # Construct the delete URL
    url = f"https://dummyjson.com/users/{resource_id}"
    
    try:
        # Send DELETE request
        response = requests.delete(url)
        
        # Raise exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if response is empty (successful deletion often returns empty body)
        if not response.text.strip():
            return None
        
        # Try to parse JSON and extract id
        try:
            data = response.json()
            return data.get('id')
        except ValueError:
            # If response is not valid JSON but we got a non-empty body
            return None
            
    except requests.exceptions.HTTPError as e:
        raise e
    except requests.exceptions.RequestException as e:
        raise e
```