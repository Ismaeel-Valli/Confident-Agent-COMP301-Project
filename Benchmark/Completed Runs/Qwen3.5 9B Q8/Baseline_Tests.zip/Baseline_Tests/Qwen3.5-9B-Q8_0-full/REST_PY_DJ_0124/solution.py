import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API.
    
    Args:
        inputs (dict): Contains 'new_category' and 'new_title'.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "title": inputs["new_title"],
        "category": inputs["new_category"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to submit product. Status code: {response.status_code}, Response: {response.text}")
    
    if response.json():
        return response.json()
    return None