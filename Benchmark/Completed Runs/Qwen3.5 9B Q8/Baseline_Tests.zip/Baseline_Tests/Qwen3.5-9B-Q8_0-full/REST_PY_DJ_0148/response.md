```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON and returns the response's id value.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the todo to update.
            - new_completed (bool): New value for the 'completed' attribute.
            - new_user_identifier (str): New value for the 'userId' attribute.
    
    Returns:
        str or None: The 'id' from the response JSON if present, otherwise None.
                     Returns None for a successful empty response.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    resource_id = inputs.get("resource_id")
    new_completed = inputs.get("new_completed")
    new_user_identifier = inputs.get("new_user_identifier")

    if not all([resource_id is not None, new_completed is not None, new_user_identifier is not None]):
        raise ValueError("Missing required input fields: resource_id, new_completed, new_user_identifier")

    url = f"{base_url}/todos/{resource_id}"
    payload = {
        "completed": new_completed,
        "userId": new_user_identifier
    }

    response = requests.put(url, json=payload)
    response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)

    if response.status_code == 204:
        return None

    try:
        data = response.json()
        return data.get("id")
    except ValueError:
        # If the response is not valid JSON, treat as empty success per instructions
        return None
```