import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_email' (new email value).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs['resource_id']
    new_email = inputs['new_email']
    
    # Base URL for DummyJSON API (users endpoint)
    base_url = "https://dummyjson.com/users"
    
    # Prepare the update payload
    payload = {
        "email": new_email
    }
    
    try:
        response = requests.put(
            f"{base_url}/{resource_id}",
            json=payload,
            timeout=10
        )
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (no content)
        if not response.text:
            return None
        
        # Parse the JSON response
        data = response.json()
        
        # Return the id value if present, otherwise None
        return data.get('id')
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")