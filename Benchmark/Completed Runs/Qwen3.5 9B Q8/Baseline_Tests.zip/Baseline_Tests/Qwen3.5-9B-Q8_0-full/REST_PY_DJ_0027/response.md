```python
import requests

def solve(inputs):
    """
    Deletes a product by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (product identifier).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    if not resource_id:
        raise ValueError("Missing 'resource_id' in inputs")

    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.delete(url)
        response.raise_for_status()
        
        # Check if the response is empty (successful deletion often returns 204 No Content or empty body)
        if not response.text.strip():
            return None
            
        # Try to parse JSON and extract 'id'
        try:
            data = response.json()
            return data.get('id')
        except ValueError:
            # If response is not JSON but we got content, return None as per spec for successful empty-like responses
            return None
            
    except requests.RequestException as e:
        raise e
```