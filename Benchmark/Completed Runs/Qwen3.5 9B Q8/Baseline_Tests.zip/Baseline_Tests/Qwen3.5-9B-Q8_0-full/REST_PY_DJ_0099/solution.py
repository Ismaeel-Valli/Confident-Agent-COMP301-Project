import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - included_fields (str): Comma-separated list of fields to include in the response.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        requests.RequestException: If the HTTP request is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    # Parse included_fields into a list
    fields_list = [field.strip() for field in inputs['included_fields'].split(',')]
    
    params = {
        '_limit': inputs['result_limit'],
        '_fields': ','.join(fields_list)
    }
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None if the response is empty (successful but no data)
        if not data:
            return None
        
        return data
    
    except requests.RequestException as e:
        raise e