```python
import requests

def solve(inputs):
    """
    Lists repositories for a given GitHub organization using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The name of the organization.
            - 'type' (str): The type of repositories to return ('all', 'public', or 'private').
            - 'credential' (str): The bearer token for authentication.
    
    Returns:
        list | None: A list of repository objects if repositories are found, otherwise None for an empty response.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    organization = inputs["organization"]
    repo_type = inputs["type"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/orgs/{organization}/repos"
    params = {"type": repo_type}
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.get(url, params=params, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch repositories. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    return None if not data else data
```