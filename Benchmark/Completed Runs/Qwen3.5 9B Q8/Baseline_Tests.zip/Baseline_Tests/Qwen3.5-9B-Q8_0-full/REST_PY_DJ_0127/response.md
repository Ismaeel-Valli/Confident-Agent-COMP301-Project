```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API using provided first name and phone number.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_phone'.
        
    Returns:
        int or None: The ID of the created user, or None if response is empty/successful without ID.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    url = "https://dummyjson.com/users/addNewUser"
    
    payload = {
        "firstName": inputs.get("new_firstName"),
        "phone": inputs.get("new_phone")
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to create user. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Check for 'id' in the response (commonly found at top level or inside 'user' object)
    if "id" in data and data["id"]:
        return data["id"]
    elif "user" in data and isinstance(data["user"], dict) and "id" in data["user"]:
        return data["user"]["id"]
    
    # Return None for successful empty response or no ID found
    return None
```