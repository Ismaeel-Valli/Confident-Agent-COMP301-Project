import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API using provided inputs.
    
    Args:
        inputs (dict): Dictionary containing 'new_age' and 'new_firstName'.
        
    Returns:
        int or None: The ID of the created user, or None if response is empty/successful without ID.
        
    Raises:
        requests.exceptions.RequestException: If HTTP request fails.
    """
    url = "https://dummyjson.com/users/addNewUser"
    
    payload = {
        "firstName": inputs.get("new_firstName"),
        "age": inputs.get("new_age")
    }
    
    try:
        response = requests.post(url, json=payload)
        response.raise_for_status()  # Raises HTTPError for bad responses (4xx or 5xx)
        
        if response.status_code == 201:  # Created
            data = response.json()
            return data.get("id")
        elif response.status_code == 200:  # OK (sometimes used for empty success)
            return None
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"HTTP request failed: {e}")