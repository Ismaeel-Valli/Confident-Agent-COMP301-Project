```python
import requests

def solve(inputs):
    resource_id = inputs.get("resource_id")
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"Failed to retrieve post: {response.status_code}")
    
    data = response.json()
    
    # Handle empty response or missing title
    if not data or "title" not in data:
        return None
    
    return data["title"]
```