```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_username'.
        
    Returns:
        int or None: The ID of the created user, or None if response is empty.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    url = "https://dummyjson.com/users/add"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "username": inputs["new_username"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to create user. Status code: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns an empty dict on success for this endpoint in some versions,
    # or the created object with an 'id' field. We check for 'id'.
    if "id" in data and data["id"] is not None:
        return data["id"]
    elif data == {}:
        return None
    else:
        # If there's a response but no 'id' key, treat as empty success per instructions
        return None
```