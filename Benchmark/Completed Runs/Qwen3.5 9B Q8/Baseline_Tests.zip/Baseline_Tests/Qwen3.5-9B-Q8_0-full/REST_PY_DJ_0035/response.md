```python
import requests

def solve(inputs):
    resource_id = inputs.get('resource_id')
    
    if resource_id is None:
        return None
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        if response.status_code == 200:
            data = response.json()
            # Check if the response body is empty or lacks the 'id' field
            if not data or 'id' not in data:
                return None
            return data['id']
        else:
            raise Exception(f"Unexpected HTTP status code: {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```