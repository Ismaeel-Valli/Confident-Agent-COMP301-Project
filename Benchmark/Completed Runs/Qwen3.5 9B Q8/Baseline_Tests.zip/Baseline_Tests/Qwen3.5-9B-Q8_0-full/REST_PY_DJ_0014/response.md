```python
import requests

def solve(inputs):
    """
    Retrieves a post by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with the post identifier.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.RequestException: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    response = requests.get(url)
    response.raise_for_status()  # Raise exception for unsuccessful HTTP responses
    
    if response.status_code == 200 and not response.text:
        return None
        
    return response.json()
```