import requests
import json

def solve(inputs):
    """
    Retrieves the authenticated user from the GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing 'credential' with authentication details.
        
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    # GitHub API version 2026-03-10 endpoint for getting the authenticated user
    url = "https://api.github.com/user"
    
    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Extract credential from inputs
    credential = inputs.get("credential")
    
    if not credential:
        raise ValueError("Missing 'credential' in inputs.")
    
    # Make the authenticated request
    response = requests.get(url, headers=headers, auth=credential)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Decode JSON response
    data = response.json()
    
    # Return None for a successful empty response (though unlikely for /user endpoint)
    if not data:
        return None
    
    return data