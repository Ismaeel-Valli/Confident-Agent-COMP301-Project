import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (product ID) and 'new_description'.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty success.
        
    Raises:
        requests.exceptions.RequestException: If HTTP request fails.
    """
    resource_id = inputs['resource_id']
    new_description = inputs['new_description']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"description": new_description}
    
    try:
        response = requests.put(url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 204:
            return None
        
        return response.json()
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}") from e
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}") from e