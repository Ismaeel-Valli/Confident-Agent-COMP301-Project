```python
import requests

def solve(inputs):
    """
    Fetches the latest release from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The caller-supplied credential (e.g., token or Bearer token).
    
    Returns:
        dict or None: The decoded JSON response if successful. Returns None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    repository_owner = inputs['repository_owner']
    repository_name = inputs['repository_name']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/releases/latest"
    
    headers = {
        'Authorization': f'Bearer {credential}',
        'Accept': 'application/vnd.github+json'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code >= 200 and response.status_code < 300:
        data = response.json()
        return None if not data else data
    else:
        raise Exception(f"Failed to fetch latest release. Status code: {response.status_code}, Response: {response.text}")
```