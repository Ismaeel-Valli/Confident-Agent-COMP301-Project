import requests
from urllib.parse import quote_plus

def solve(inputs):
    """
    Creates a new repository for the authenticated user via GitHub REST API.
    
    Args:
        inputs (dict): Contains 'new_name', 'new_description', and 'credential'.
        
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty body.
        
    Raises:
        Exception: If the HTTP response indicates failure.
    """
    new_name = inputs["new_name"]
    new_description = inputs["new_description"]
    credential = inputs["credential"]
    
    # GitHub API version 2026-03-10 (future-proofing placeholder, logic remains same)
    url = "https://api.github.com/user/repos"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"token {credential}"
    }
    
    data = {
        "name": new_name,
        "description": new_description
    }
    
    response = requests.post(url, json=data, headers=headers)
    
    if response.status_code == 201:
        return None
    elif response.status_code == 202:
        # Accepted (async), but usually returns empty or minimal JSON for repo creation
        return response.json() if response.content else None
    else:
        raise Exception(f"Failed to create repository. Status code: {response.status_code}, Response: {response.text}")