```python
import requests

def solve(inputs):
    """
    Deletes a user by identifier using DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (user identifier).
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.exceptions.RequestException: If HTTP request fails.
        ValueError: If required input is missing.
    """
    resource_id = inputs.get('resource_id')
    if not resource_id:
        raise ValueError("Missing 'resource_id' in inputs")
    
    url = f"https://dummyjson.com/users/{resource_id}"
    response = requests.delete(url)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 404:
        raise ValueError(f"User with ID {resource_id} not found")
    else:
        response.raise_for_status()
```