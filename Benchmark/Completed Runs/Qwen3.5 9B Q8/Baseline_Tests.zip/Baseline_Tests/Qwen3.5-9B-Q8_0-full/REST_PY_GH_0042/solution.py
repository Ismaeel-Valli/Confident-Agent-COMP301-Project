import requests
from urllib.parse import quote

def solve(inputs):
    """
    Lists releases for a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The Bearer token for authentication.
    
    Returns:
        list or None: A list of release objects decoded from JSON, or None if the response is empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    token = inputs["credential"]
    
    url = f"https://api.github.com/repos/{quote(owner, safe='')}/{quote(repo, safe='')}/releases"
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to fetch releases. Status code: {response.status_code}")
    
    data = response.json()
    
    return data if data else None