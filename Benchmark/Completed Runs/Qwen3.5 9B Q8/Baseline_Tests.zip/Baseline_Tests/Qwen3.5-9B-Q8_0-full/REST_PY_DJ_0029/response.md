```python
import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'result_limit' (int) specifying 
                       the maximum number of results to return.
    
    Returns:
        list or None: The decoded JSON response as a list of users, or None if 
                      the response is successfully empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    result_limit = inputs.get('result_limit')
    
    # DummyJSON API endpoint for users with pagination support
    url = "https://dummyjson.com/users?limit={}".format(result_limit)
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Check if the users array is empty
        if not data.get('users'):
            return None
            
        return data['users']
        
    except requests.RequestException as e:
        raise e
```