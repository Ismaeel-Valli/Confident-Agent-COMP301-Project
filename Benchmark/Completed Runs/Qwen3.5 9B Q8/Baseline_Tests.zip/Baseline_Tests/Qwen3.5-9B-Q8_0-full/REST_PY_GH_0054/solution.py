import requests

def solve(inputs):
    """
    Follows a GitHub user based on the provided username and credential.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The GitHub username to follow.
            - 'credential' (str): The authentication token or bearer string.
    
    Returns:
        int: The successful HTTP status code (e.g., 204).
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    username = inputs['username']
    credential = inputs['credential']
    
    # Construct the URL for following a user on GitHub API v2026-03-10
    url = f"https://api.github.com/users/{username}/following"
    
    headers = {
        'Accept': 'application/vnd.github+json',
        'Authorization': f'Bearer {credential}'
    }
    
    response = requests.post(url, headers=headers)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to follow user '{username}': {response.status_code} - {response.text}")
    
    return response.status_code