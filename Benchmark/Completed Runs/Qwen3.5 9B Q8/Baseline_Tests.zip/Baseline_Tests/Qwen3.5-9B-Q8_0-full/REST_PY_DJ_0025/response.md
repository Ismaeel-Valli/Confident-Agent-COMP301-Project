```python
import requests

def solve(inputs):
    """
    Retrieves a product by identifier from DummyJSON and returns its 'id' value.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (product identifier).
        
    Returns:
        int or None: The product's id if found, None for empty successful response.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON endpoint for getting a specific product by ID
    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.get(url)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        data = response.json()
        
        # Return the id if present in the response
        return data.get('id')
        
    except requests.exceptions.RequestException as e:
        raise e
```