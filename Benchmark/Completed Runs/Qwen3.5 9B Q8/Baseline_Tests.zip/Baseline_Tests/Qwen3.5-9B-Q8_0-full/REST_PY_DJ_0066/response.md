```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the user
            - new_lastName (str): Value for the last Name attribute
    
    Returns:
        str or None: The response's id value, or None if that attribute is absent.
                     Returns None for a successful empty response.
    
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    new_lastName = inputs.get('new_lastName')
    
    # Base URL for DummyJSON API
    base_url = "https://dummyjson.com"
    url = f"{base_url}/users/{resource_id}"
    
    # Prepare the payload with only the field to update
    payload = {
        "lastName": new_lastName
    }
    
    try:
        response = requests.put(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (no content)
        if not response.text:
            return None
        
        # Parse the JSON response
        data = response.json()
        
        # Return the id value if present, otherwise None
        return data.get('id')
    
    except requests.RequestException as e:
        raise e
```