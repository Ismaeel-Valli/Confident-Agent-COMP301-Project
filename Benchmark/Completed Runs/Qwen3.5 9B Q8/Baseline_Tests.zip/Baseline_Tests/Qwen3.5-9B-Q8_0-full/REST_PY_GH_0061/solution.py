import requests

def solve(inputs):
    """
    Fetches a GitHub user based on the provided username using the specified API version.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The GitHub username to fetch.
            - 'credential' (str): The Bearer token for authentication.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None if the response is empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    username = inputs['username']
    credential = inputs['credential']
    
    url = f"https://api.github.com/users/{username}"
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to fetch user data. Status code: {response.status_code}")
    
    return response.json()