import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API using provided inputs.
    
    Args:
        inputs (dict): Dictionary containing 'new_title' for the product title.
        
    Returns:
        str or None: The response's title value, or None if absent or on successful empty response.
        
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "title": inputs["new_title"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if the response is empty or doesn't contain a title
        if not response.text.strip():
            return None
            
        data = response.json()
        
        # Return the title if present, otherwise None
        return data.get("title")
        
    except requests.RequestException as e:
        raise e