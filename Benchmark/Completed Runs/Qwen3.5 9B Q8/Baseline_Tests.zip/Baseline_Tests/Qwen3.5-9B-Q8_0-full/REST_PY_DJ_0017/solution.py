import requests

def solve(inputs):
    """
    Searches posts on DummyJSON using the provided search term.
    
    Args:
        inputs (dict): A dictionary containing 'search_text' key with the search term.
        
    Returns:
        list or None: The decoded JSON response if successful and non-empty, 
                      None if successful but empty.
                      
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    search_text = inputs.get("search_text", "")
    
    # DummyJSON doesn't have a direct /posts/search endpoint like some other APIs,
    # but jsonplaceholder (often used as a placeholder for such services) has /posts.
    # However, the prompt specifically mentions "DummyJSON". 
    # Since DummyJSON typically uses https://dummyjson.com/posts/search for this exact purpose,
    # we will use that endpoint which accepts a 'q' query parameter.
    
    url = f"https://dummyjson.com/posts/search?q={search_text}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # DummyJSON returns a dict with 'posts' key. If the list is empty, return None as per instructions.
        if not data.get("posts"):
            return None
            
        return data["posts"]
        
    except requests.exceptions.RequestException as e:
        raise e