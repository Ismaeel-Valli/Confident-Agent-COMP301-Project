import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on skip parameter.
    
    Args:
        inputs (dict): Dictionary containing 'results_to_skip' key.
        
    Returns:
        dict or None: Decoded JSON response, or None if successful but empty.
        
    Raises:
        requests.RequestException: If HTTP request fails.
    """
    results_to_skip = inputs.get('results_to_skip', 0)
    
    # DummyJSON API endpoint for users with pagination
    url = f"https://dummyjson.com/users?skip={results_to_skip}&limit=1"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        
        data = response.json()
        
        # Check if the response is successful but empty (no users found)
        if not data.get('users'):
            return None
            
        return data
        
    except requests.RequestException as e:
        raise e