import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API with provided price and title.
    
    Args:
        inputs (dict): Dictionary containing 'new_price' and 'new_title'.
        
    Returns:
        str or None: The response's title value if present, otherwise None for successful empty response.
        
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "title": inputs["new_title"],
        "price": inputs["new_price"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx and 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (no content)
        if not response.text.strip():
            return None
            
        # Try to parse JSON and extract title
        try:
            data = response.json()
            return data.get("title")
        except ValueError:
            # If response is not valid JSON, return None as per "successful empty response" interpretation
            return None
            
    except requests.RequestException as e:
        raise e