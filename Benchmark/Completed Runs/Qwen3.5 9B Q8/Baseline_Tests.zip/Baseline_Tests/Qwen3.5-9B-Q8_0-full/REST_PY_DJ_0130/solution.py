import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id', 'new_todo', and 'new_user_identifier'.
        
    Returns:
        str or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_todo = inputs['new_todo']
    new_user_identifier = inputs['new_user_identifier']
    
    base_url = "https://dummyjson.com"
    url = f"{base_url}/todos/{resource_id}"
    
    payload = {
        "todo": new_todo,
        "userId": new_user_identifier
    }
    
    try:
        response = requests.put(url, json=payload)
        
        if response.status_code == 200:
            # Successful update
            data = response.json()
            
            # Check if the response is empty or doesn't contain an id
            if not data or 'id' not in data:
                return None
            
            return data['id']
        
        elif response.status_code == 204:
            # No content (successful empty response)
            return None
        
        else:
            # Unsuccessful HTTP response
            raise Exception(f"HTTP {response.status_code}: {response.text}")
            
    except requests.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")