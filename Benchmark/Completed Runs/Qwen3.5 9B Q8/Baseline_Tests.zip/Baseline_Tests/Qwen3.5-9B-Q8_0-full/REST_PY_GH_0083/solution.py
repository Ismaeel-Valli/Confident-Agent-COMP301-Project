import requests
from urllib.parse import quote

def solve(inputs):
    """
    Creates a milestone in a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - new_state (str): Value for the state attribute ('open' or 'closed').
            - new_title (str): Value for the title attribute.
            - credential (str): Bearer token for authentication.
    
    Returns:
        dict or None: The decoded JSON response if successful, otherwise None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    new_state = inputs["new_title"]  # Note: The prompt says 'new_title' for title, but 'new_state' for state. 
                                     # However, the input dict keys are 'new_state' and 'new_title'.
                                     # Let's re-read carefully: 
                                     # "new_state: value for the state attribute; new_title: value for the title attribute."
    new_title = inputs["new_title"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{quote(repository_owner, safe='')}/{quote(repository_name, safe='')}/milestones"
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    payload = {
        "title": new_title,
        "state": new_state
    }
    
    response = requests.post(url, headers=headers, json=payload)
    
    if response.status_code == 201:
        return None
    elif response.status_code == 202:
        return None
    else:
        raise Exception(f"Failed to create milestone. Status code: {response.status_code}, Response: {response.text}")