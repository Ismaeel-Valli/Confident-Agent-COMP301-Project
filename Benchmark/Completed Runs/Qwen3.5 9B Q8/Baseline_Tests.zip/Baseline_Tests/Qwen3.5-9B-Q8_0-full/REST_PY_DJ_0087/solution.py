import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_age' (new age value).
        
    Returns:
        int or None: The response's id value if present, otherwise None for successful empty response.
        Raises: Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_age = inputs['new_age']
    
    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {"age": new_age}
    
    try:
        response = requests.put(url, json=payload)
        
        if response.status_code == 200:
            # Check if the response contains an 'id' field
            if 'id' in response.json():
                return response.json()['id']
            else:
                return None
        elif response.status_code == 204:
            # Empty response is considered successful
            return None
        else:
            raise Exception(f"HTTP {response.status_code}: {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")