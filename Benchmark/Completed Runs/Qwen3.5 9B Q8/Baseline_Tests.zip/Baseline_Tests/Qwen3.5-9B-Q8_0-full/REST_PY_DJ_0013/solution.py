import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON API based on inputs.
    
    Args:
        inputs (dict): A dictionary containing 'page' key for pagination.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.RequestException: If HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    # Extract page number from inputs, default to 1
    page = inputs.get('page', 1)
    
    # Construct the URL with query parameter
    url = f"{base_url}?_limit=10&_start={page}"
    
    try:
        response = requests.get(url)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None if the response is empty (successful but no data)
        if not data:
            return None
            
        return data
        
    except requests.RequestException as e:
        raise e