```python
import requests

def solve(inputs):
    """
    Fetches a specific branch from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'branch' (str): The name of the branch to fetch.
            - 'credential' (str): The authentication token or bearer token.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    branch = inputs['branch']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/branches/{branch}"
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch branch: HTTP {response.status_code} - {response.text}")
    
    data = response.json()
    
    # According to the prompt: "Return None for a successful empty response."
    # However, GitHub's get branch endpoint typically returns an object like {"name": "...", "protected": ...}.
    # If the API ever returned an empty list or dict for this specific endpoint, we would return None.
    # Given standard behavior, data will be a dict. We follow the instruction literally: 
    # if the JSON decoded result is empty (falsy), return None.
    if not data:
        return None
        
    return data
```