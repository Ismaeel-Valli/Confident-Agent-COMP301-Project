import requests

def solve(inputs):
    """
    Deletes a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The authentication token or string for the API call.
    
    Returns:
        int: The successful HTTP status code (typically 204 No Content).
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails or returns an unsuccessful status code.
    """
    owner = inputs['repository_owner']
    repo_name = inputs['repository_name']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo_name}"
    headers = {
        'Authorization': f'token {credential}',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2026-03-10'
    }
    
    response = requests.delete(url, headers=headers)
    response.raise_for_status()
    
    return response.status_code