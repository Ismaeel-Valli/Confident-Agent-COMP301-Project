```python
import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on the provided sort_field.
    
    Args:
        inputs (dict): A dictionary containing 'sort_field' key.
        
    Returns:
        list or None: The decoded JSON response as a list, or None if the response is empty.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    sort_field = inputs.get('sort_field')
    
    # Construct the API URL with sorting parameter
    url = f"https://jsonplaceholder.typicode.com/users?_sort={sort_field}&_limit=1"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None if the response is empty, otherwise return the list
        return data if data else None
        
    except requests.RequestException as e:
        raise e
```