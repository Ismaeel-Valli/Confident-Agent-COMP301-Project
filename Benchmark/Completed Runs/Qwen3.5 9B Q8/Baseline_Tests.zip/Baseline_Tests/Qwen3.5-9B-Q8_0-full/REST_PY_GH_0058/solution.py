import requests

def solve(inputs):
    """
    Checks if a repository is starred by the authenticated user using GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git extension).
            - 'credential' (str): The authentication token for the API request.
    
    Returns:
        int: The successful HTTP status code (200 or 304).
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    token = inputs['credential']
    
    url = f"https://api.github.com/user/starred/{owner}/{repo}"
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200 or response.status_code == 304:
        return response.status_code
    
    raise Exception(f"Failed to check star status. Status code: {response.status_code}, Response: {response.text}")