```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post on DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_body' (new body content).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty responses.
        
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    new_body = inputs.get('new_body')
    
    # Base URL for DummyJSON API
    base_url = "https://jsonplaceholder.typicode.com"
    
    try:
        # Prepare the payload with only the fields to update
        payload = {
            'body': new_body
        }
        
        # Make the PUT request to update the post
        response = requests.put(
            f"{base_url}/posts/{resource_id}",
            json=payload
        )
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (no content)
        if not response.text:
            return None
        
        # Parse the JSON response and return the id if present
        try:
            data = response.json()
            return data.get('id')
        except ValueError:
            # If response is not valid JSON but request was successful, return None
            return None
            
    except requests.RequestException as e:
        raise e
```