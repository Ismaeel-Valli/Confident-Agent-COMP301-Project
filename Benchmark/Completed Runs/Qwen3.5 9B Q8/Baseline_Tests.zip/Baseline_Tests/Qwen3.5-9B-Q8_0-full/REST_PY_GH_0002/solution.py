import requests
from requests.exceptions import RequestException, HTTPError

def solve(inputs):
    """
    Updates an organization on GitHub using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The organization name.
            - 'new_name' (str): The new name for the organization.
            - 'credential' (str): The authentication token or bearer token.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP request fails or returns an unsuccessful status code.
    """
    organization = inputs['organization']
    new_name = inputs['new_name']
    credential = inputs['credential']
    
    url = f"https://api.github.com/orgs/{organization}"
    headers = {
        'Authorization': f'token {credential}',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2026-03-10'
    }
    
    payload = {
        "name": new_name
    }
    
    try:
        response = requests.put(url, json=payload, headers=headers)
        response.raise_for_status()
        
        if response.status_code == 204:
            return None
        
        return response.json()
    
    except HTTPError as http_err:
        raise Exception(f"HTTP error occurred: {http_err}")
    except RequestException as err:
        raise Exception(f"Request failed: {err}")