```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_user_identifier' (new user ID).
        
    Returns:
        str or None: The title value from the response, or None if absent or successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_user_identifier = inputs['new_user_identifier']
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    
    payload = {
        "userId": new_user_identifier
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP request failed with status code: {response.status_code}")
    
    data = response.json()
    
    # Check for successful empty response (empty object or null content)
    if not data or (isinstance(data, dict) and len(data) == 0):
        return None
    
    title = data.get('title')
    return title
```