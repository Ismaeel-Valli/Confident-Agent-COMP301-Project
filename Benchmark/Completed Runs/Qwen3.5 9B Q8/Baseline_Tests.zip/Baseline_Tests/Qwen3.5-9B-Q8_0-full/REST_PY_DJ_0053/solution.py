import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on skip count.
    
    Args:
        inputs (dict): Dictionary containing 'results_to_skip' key.
        
    Returns:
        dict or None: Decoded JSON response, or None if successful but empty.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    results_to_skip = inputs.get('results_to_skip', 0)
    
    # DummyJSON endpoint for posts with pagination support
    url = f"https://jsonplaceholder.typicode.com/posts?_skip={results_to_skip}&_limit=1"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None if the response is successfully empty (though unlikely with _limit=1)
        if not data:
            return None
            
        return data
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")