import requests

def solve(inputs):
    """
    Fetches the list of files changed in a specific pull request for a GitHub repository.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository.
            - 'pull_number' (int): The pull request number.
            - 'credential' (str): The authentication token or string for GitHub API access.
    
    Returns:
        dict | None: The decoded JSON response if files exist, or None if the list is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    pr_number = inputs['pull_number']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}/files"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code >= 400:
        raise Exception(f"GitHub API request failed with status code {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response (e.g., no files changed)
    if not data:
        return None
        
    return data