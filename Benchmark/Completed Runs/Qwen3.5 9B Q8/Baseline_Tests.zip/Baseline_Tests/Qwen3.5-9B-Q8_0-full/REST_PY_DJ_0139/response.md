```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the todo.
            - new_completed (bool): New value for the completed attribute.
            - new_user_identifier (str): New value for the user Id attribute.
            
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty but successful.
                      
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs['resource_id']
    new_completed = inputs['new_completed']
    new_user_identifier = inputs['new_user_identifier']
    
    # Base URL for DummyJSON API
    base_url = "https://jsonplaceholder.typicode.com"
    url = f"{base_url}/todos/{resource_id}"
    
    # Prepare the payload with only the fields to update
    payload = {
        "completed": new_completed,
        "userId": new_user_identifier
    }
    
    try:
        response = requests.put(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Decode the JSON response
        decoded_response = response.json()
        
        # Return None for a successful empty response
        if not decoded_response:
            return None
            
        return decoded_response
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```