```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post on DummyJSON API and returns the title.
    
    Args:
        inputs (dict): Contains 'resource_id', 'new_body', and 'new_title'.
        
    Returns:
        str or None: The title from the response, or None if successful but empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_body = inputs['new_body']
    new_title = inputs['new_title']
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    payload = {
        "title": new_title,
        "body": new_body
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update post. Status code: {response.status_code}")
    
    data = response.json()
    
    # Check if the response is empty or doesn't contain 'title'
    if not data or 'title' not in data:
        return None
        
    return data['title']
```