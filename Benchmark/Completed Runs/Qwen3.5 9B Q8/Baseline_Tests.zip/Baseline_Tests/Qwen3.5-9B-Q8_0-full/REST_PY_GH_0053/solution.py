import requests

def solve(inputs):
    """
    Checks if the authenticated user is following a specific GitHub user.
    
    Args:
        inputs (dict): A dictionary containing:
            - "username" (str): The handle for the GitHub user account to check.
            - "credential" (str): The caller-supplied credential (e.g., Bearer token).
    
    Returns:
        int: The successful HTTP status code (typically 204 No Content if following, 
             or 302 Found with a Location header pointing to the follow URL if not following).
             Note: Based on GitHub API v2026-03-10 behavior for GET /users/{username}/following/{target},
             it returns 204 if following, and 302 if not. However, the problem asks to return 
             the successful status code. We will interpret "successful" as the response indicating 
             the state exists (204) or redirecting correctly (302). But strictly speaking, 
             if the user is NOT following, the API returns 302. If they ARE following, it returns 204.
             The prompt asks to return the successful HTTP status code. Let's assume we return 
             the status code of the response received from the API call which indicates the state.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    username = inputs["username"]
    credential = inputs["credential"]
    
    # GitHub API endpoint to check if authenticated user follows a specific user
    url = f"https://api.github.com/users/{username}/following/me"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code >= 400:
        raise Exception(f"GitHub API request failed with status code: {response.status_code}. Response body: {response.text}")
    
    # If the user is following, GitHub returns 204 No Content.
    # If the user is not following, GitHub returns 302 Found (redirect) to the follow URL.
    # Both are considered "successful" interactions in terms of API response validity for this check.
    return response.status_code