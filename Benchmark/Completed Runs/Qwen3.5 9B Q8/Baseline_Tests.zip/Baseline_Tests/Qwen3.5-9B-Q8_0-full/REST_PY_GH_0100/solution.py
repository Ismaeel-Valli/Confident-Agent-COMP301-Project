import requests
from urllib.parse import quote

def solve(inputs):
    """
    Lists repositories for a GitHub user based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The GitHub username.
            - 'type' (str, optional): Filter by repository type ('all', 'owner', or 'member').
            - 'credential' (str): Bearer token for authentication.
    
    Returns:
        list or None: Decoded JSON response as a list of repositories, or None if the list is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (status code >= 400).
    """
    username = inputs['username']
    repo_type = inputs.get('type', 'all')
    credential = inputs['credential']
    
    # Construct the API URL for GitHub REST API version 2026-03-10
    base_url = "https://api.github.com"
    url = f"{base_url}/users/{quote(username)}/repos"
    
    # Prepare headers with Bearer token authentication
    headers = {
        'Authorization': f'Bearer {credential}',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2026-03-10'
    }
    
    # Prepare query parameters
    params = {'type': repo_type}
    
    try:
        response = requests.get(url, headers=headers, params=params)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None if the response is an empty list
        if not data:
            return None
        
        return data
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"GitHub API request failed with status {response.status_code}: {e}")