import requests
from urllib.parse import quote

def solve(inputs):
    """
    Creates a milestone in a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - new_title (str): The title for the new milestone.
            - credential (str): The authentication token or string for API access.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    title = inputs["new_title"]
    credential = inputs["credential"]
    
    # Construct the API URL for creating a milestone
    url = f"https://api.github.com/repos/{quote(owner)}/{quote(repo)}/milestones"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    data = {
        "title": title
    }
    
    response = requests.post(url, headers=headers, json=data)
    
    if response.status_code == 201:
        # Successful creation; GitHub typically returns the created object
        return response.json()
    elif response.status_code == 204:
        # No content returned on success in some cases
        return None
    else:
        raise Exception(f"Failed to create milestone. Status code: {response.status_code}, Response: {response.text}")