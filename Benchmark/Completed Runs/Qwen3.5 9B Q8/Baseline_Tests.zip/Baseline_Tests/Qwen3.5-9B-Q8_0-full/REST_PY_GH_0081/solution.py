import requests

def solve(inputs):
    """
    Updates a label in a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - name (str): The name of the label to update.
            - new_color (str): The new color value for the label.
            - credential (dict): Caller-supplied credentials (assumed to have necessary permissions).
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    label_name = inputs["name"]
    new_color = inputs["new_color"]
    credential = inputs["credential"]

    # Construct the API URL for updating a label (GitHub REST API v2026-03-10)
    url = f"https://api.github.com/repos/{owner}/{repo}/labels/{label_name}"

    # Prepare headers with authentication
    headers = {
        "Authorization": f"token {credential.get('token', '')}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Prepare the payload for updating the label
    payload = {
        "color": new_color
    }

    # Send the PATCH request to update the label
    response = requests.patch(url, headers=headers, json=payload)

    # Check if the response is successful (status code 200-299)
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"Failed to update label: {response.status_code} - {response.text}")

    # Decode the JSON response
    try:
        json_response = response.json()
    except ValueError:
        # If the response is not valid JSON, return None for a successful empty response
        return None

    # Return None for a successful empty response (e.g., 204 No Content)
    if not json_response:
        return None

    return json_response