```python
import requests

def solve(inputs):
    """
    Fetches an organization from the GitHub REST API (version 2026-03-10).
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The name of the organization.
            - 'credential' (str): The authentication token or header value.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    org_name = inputs['organization']
    credential = inputs['credential']
    
    # GitHub API endpoint for getting an organization
    url = f"https://api.github.com/orgs/{org_name}"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        # Return None for a successful empty response (though orgs usually return data)
        if not data:
            return None
        return data
    else:
        raise Exception(f"Failed to fetch organization '{org_name}': HTTP {response.status_code}")
```