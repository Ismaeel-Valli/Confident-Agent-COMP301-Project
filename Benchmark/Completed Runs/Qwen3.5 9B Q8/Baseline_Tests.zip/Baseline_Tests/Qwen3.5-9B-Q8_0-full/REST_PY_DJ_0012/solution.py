import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' key.
        
    Returns:
        None if response is successful and empty.
        Decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    url = "https://dummyjson.com/users/addNewUser"
    
    # Prepare the payload with the provided first name
    payload = {
        "firstName": inputs["new_firstName"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # If the response is empty (204 No Content), return None
        if response.status_code == 204:
            return None
            
        # Return the decoded JSON response
        return response.json()
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")