```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post on DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (int) and 'new_title' (str).
        
    Returns:
        str or None: The title value from the response, or None if absent or successful empty response.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs['resource_id']
    new_title = inputs['new_title']
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    payload = {"title": new_title}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update post: {response.status_code}")
    
    data = response.json()
    
    # Check for successful empty response (no content)
    if not data.get('title'):
        return None
        
    return data['title']
```