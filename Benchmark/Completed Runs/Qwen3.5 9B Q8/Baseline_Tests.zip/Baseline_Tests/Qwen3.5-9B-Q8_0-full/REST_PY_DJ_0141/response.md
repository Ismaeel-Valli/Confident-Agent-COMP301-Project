```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the product
            - new_category (str): New value for the category attribute
    
    Returns:
        str or None: The title from the response, or None if absent or successful empty response.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    new_category = inputs.get('new_category')
    
    if not resource_id or new_category is None:
        raise ValueError("Missing required input fields: resource_id and new_category")
    
    # Base URL for DummyJSON API
    base_url = "https://dummyjson.com/products"
    
    # Prepare the update payload
    payload = {
        "category": new_category
    }
    
    # Make PATCH request to update the product
    response = requests.patch(
        f"{base_url}/{resource_id}",
        json=payload
    )
    
    # Raise exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Check if response is empty (successful but no content)
    if not response.text:
        return None
    
    # Parse JSON response
    try:
        data = response.json()
    except ValueError:
        raise requests.exceptions.JSONDecodeError("Failed to decode JSON response", response.text, 0)
    
    # Return title if present, otherwise None
    return data.get('title')
```