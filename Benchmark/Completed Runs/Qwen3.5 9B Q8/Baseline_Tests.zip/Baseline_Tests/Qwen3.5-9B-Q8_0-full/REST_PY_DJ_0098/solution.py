import requests
import json

def solve(inputs):
    """
    Submits a new user to DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'new_email' and 'new_firstName'.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    url = "https://dummyjson.com/users/addNewUser"
    
    payload = {
        "email": inputs["new_email"],
        "firstName": inputs["new_firstName"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code == 200:
            data = response.json()
            # DummyJSON returns an empty object {} on success for this endpoint
            return None if data == {} else data
        elif response.status_code == 400:
            raise Exception(f"Bad Request: {response.text}")
        elif response.status_code == 500:
            raise Exception(f"Internal Server Error: {response.text}")
        else:
            raise Exception(f"HTTP Error {response.status_code}: {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")