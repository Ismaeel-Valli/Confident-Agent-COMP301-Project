```python
import requests

def solve(inputs):
    """
    Submits a new post to DummyJSON API using provided inputs.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_body (str): Value for the body attribute
            - new_title (str): Value for the title attribute
            - new_user_identifier (str): Value for the user Id attribute
    
    Returns:
        str or None: The response's id value, or None if that attribute is absent.
                     Returns None for a successful empty response.
    
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": inputs["new_title"],
        "body": inputs["new_body"],
        "userId": inputs["new_user_identifier"]
    }
    
    try:
        response = requests.post(url, json=payload)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        if response.status_code == 201:
            data = response.json()
            return data.get("id")
        else:
            # For other successful status codes, check if it's empty
            if not response.text.strip():
                return None
            return None
            
    except requests.RequestException as e:
        raise e
```