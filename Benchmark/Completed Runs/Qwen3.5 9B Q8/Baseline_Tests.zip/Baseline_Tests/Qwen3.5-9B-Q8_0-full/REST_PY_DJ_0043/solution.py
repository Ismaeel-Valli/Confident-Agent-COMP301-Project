import requests

def solve(inputs):
    """
    Submits a new todo to DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_completed: value for the 'completed' attribute
            - new_todo: value for the 'todo' attribute
            - new_user_identifier: value for the 'userId' attribute
    
    Returns:
        str or None: The response's id value, or None if absent or response is empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    url = "https://jsonplaceholder.typicode.com/todos"
    
    payload = {
        "userId": inputs["new_user_identifier"],
        "title": inputs["new_todo"],
        "completed": inputs["new_completed"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create todo. Status code: {response.status_code}")
    
    data = response.json()
    
    # Return id if present, otherwise None
    return data.get("id")