```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API using provided email and first name.
    
    Args:
        inputs (dict): Dictionary containing 'new_email' and 'new_firstName'.
        
    Returns:
        int or None: The ID of the created user, or None if response is empty/missing ID.
        
    Raises:
        requests.RequestException: If HTTP request fails.
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "email": inputs["new_email"],
        "firstName": inputs["new_firstName"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. Status code: {response.status_code}")
    
    data = response.json()
    
    # Return id if present, otherwise None for successful empty response
    return data.get("id")
```