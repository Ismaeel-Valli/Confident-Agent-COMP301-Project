```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (int): Identifier of the product.
            - new_brand (str): New value for the brand attribute.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty (204 No Content),
                      raises an exception on unsuccessful HTTP response.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    resource_id = inputs['resource_id']
    new_brand = inputs['new_brand']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"brand": new_brand}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 204:
        return None
    
    if not response.ok:
        raise Exception(f"Failed to update product. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json()
```