```python
import requests

def solve(inputs):
    """
    Deletes a todo by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (str) of the todo to delete.
        
    Returns:
        bool or None: The 'isDeleted' value from the response if present, 
                      None for successful empty response, or raises exception on failure.
                      
    Raises:
        requests.exceptions.RequestException: If HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON API endpoint for deleting a todo
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    try:
        response = requests.delete(url)
        
        # Raise exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if response is empty (successful deletion often returns empty body)
        if not response.text.strip():
            return None
            
        # Parse JSON response and extract isDeleted value
        data = response.json()
        return data.get('isDeleted')
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Failed to delete todo: {e}")
```