import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the product
            - new_category (str): New value for the category attribute
    
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
    
    Raises:
        requests.exceptions.RequestException: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_category = inputs['new_category']
    
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    data = {
        'category': new_category
    }
    
    response = requests.put(url, json=data)
    
    if response.status_code != 200:
        raise requests.exceptions.RequestException(f"Failed to update product: {response.status_code}")
    
    return None