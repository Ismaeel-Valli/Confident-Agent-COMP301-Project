```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API with provided price and title.
    
    Args:
        inputs (dict): Dictionary containing 'new_price' and 'new_title'.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.exceptions.RequestException: If HTTP request fails.
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": inputs["new_title"],
        "body": f"New product with price: {inputs['new_price']}",
        "userId": 1
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code == 201:
        return None
    elif response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Failed to submit product. Status code: {response.status_code}")
```