import requests

def solve(inputs):
    """
    Updates selected fields of a post on DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_body' (new body content).
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty success response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_body = inputs['new_body']
    
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    payload = {
        "body": new_body
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update post. Status code: {response.status_code}, Response: {response.text}")
    
    if response.content:
        return response.json()
    else:
        return None