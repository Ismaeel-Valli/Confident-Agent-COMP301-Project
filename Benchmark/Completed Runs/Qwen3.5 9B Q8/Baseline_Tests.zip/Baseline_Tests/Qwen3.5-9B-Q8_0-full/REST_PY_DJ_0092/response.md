```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (todo ID) and 'new_user_identifier' (new user ID).
        
    Returns:
        str or None: The response's id value, or None if the response is empty/successful without an id.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    new_user_identifier = inputs.get('new_user_identifier')
    
    # Base URL for DummyJSON Todo API
    base_url = "https://jsonplaceholder.typicode.com"
    url = f"{base_url}/todos/{resource_id}"
    
    # Prepare the payload to update only the user field
    payload = {
        "userId": new_user_identifier
    }
    
    try:
        response = requests.put(url, json=payload)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        # Check if the response is empty (no content)
        if not response.text.strip():
            return None
            
        # Return the id from the response JSON
        data = response.json()
        return data.get('id')
        
    except requests.RequestException as e:
        raise e
```