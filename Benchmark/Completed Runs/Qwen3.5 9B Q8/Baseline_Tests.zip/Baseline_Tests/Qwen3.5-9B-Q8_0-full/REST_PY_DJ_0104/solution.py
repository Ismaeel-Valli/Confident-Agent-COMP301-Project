import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (product ID) and 'new_price' (new price value).
        
    Returns:
        int or None: The response's id value if present, otherwise None for successful empty response.
        Raises: Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_price = inputs.get('new_price')
    
    # Base URL for DummyJSON API (using the products endpoint)
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/{resource_id}"
    
    # Prepare the payload with only the field to update
    payload = {
        "price": new_price
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.put(url, json=payload, headers=headers)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (no content)
        if not response.text:
            return None
        
        # Parse the JSON response
        data = response.json()
        
        # Return the id value if present, otherwise None
        return data.get('id')
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")