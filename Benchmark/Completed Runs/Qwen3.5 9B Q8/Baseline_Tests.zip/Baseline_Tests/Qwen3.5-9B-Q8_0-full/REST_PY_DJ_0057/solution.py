import requests

def solve(inputs):
    """
    Submits a new post to DummyJSON API using provided inputs.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_body (str): Value for the body attribute
            - new_title (str): Value for the title attribute
            - new_user_identifier (str): Value for the user Id attribute
    
    Returns:
        str or None: The response's title value if present, otherwise None.
                     Returns None for a successful empty response.
    
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": inputs["new_title"],
        "body": inputs["new_body"],
        "userId": inputs["new_user_identifier"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Check if the response is empty
        if not response.text.strip():
            return None
        
        # Try to extract the title from the JSON response
        try:
            data = response.json()
            return data.get("title")
        except ValueError:
            # If response is not valid JSON, check if it contains a title string
            if "title" in response.text:
                return response.text.split("title")[1].split('"')[1] if '"' in response.text else None
            return None
            
    except requests.RequestException as e:
        raise e