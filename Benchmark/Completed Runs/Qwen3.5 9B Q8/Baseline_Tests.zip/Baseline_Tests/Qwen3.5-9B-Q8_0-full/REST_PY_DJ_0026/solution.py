import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str/int): Identifier of the product
            - new_title (str): New value for the title attribute
    
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    new_title = inputs.get('new_title')
    
    if not resource_id or new_title is None:
        raise ValueError("Missing required input fields: resource_id and new_title")
    
    url = f"https://dummyjson.com/products/{resource_id}"
    
    payload = {
        "title": new_title
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code not in [200, 201]:
        raise Exception(f"Failed to update product: HTTP {response.status_code} - {response.text}")
    
    # For successful updates, DummyJSON typically returns the updated object or an empty response
    data = response.json()
    
    # Check if 'id' is present in the response
    if isinstance(data, dict) and 'id' in data:
        return data['id']
    
    # Return None for successful empty response
    return None