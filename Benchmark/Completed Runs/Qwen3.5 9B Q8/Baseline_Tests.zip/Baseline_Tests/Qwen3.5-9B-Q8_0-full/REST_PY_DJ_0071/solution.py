import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on included_fields.
    
    Args:
        inputs (dict): Dictionary containing 'included_fields' as a comma-separated string.
        
    Returns:
        dict or None: Decoded JSON response, or None if the response is empty but successful.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    included_fields = inputs.get('included_fields', '')
    
    # Construct the URL with query parameters for fields
    url = "https://jsonplaceholder.typicode.com/todos"
    params = {}
    
    if included_fields:
        params['fields'] = included_fields
    
    response = requests.get(url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # Return None for a successful empty response (empty list)
    if not data:
        return None
    
    return data