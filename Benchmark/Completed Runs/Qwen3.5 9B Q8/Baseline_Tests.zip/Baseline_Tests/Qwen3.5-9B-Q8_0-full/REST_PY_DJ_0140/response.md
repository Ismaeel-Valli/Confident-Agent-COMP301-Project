```python
import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON based on sorting criteria.
    
    Args:
        inputs (dict): A dictionary containing:
            - sort_field (str): Field used for ordering.
            - sort_direction (str): Ordering direction ('asc' or 'desc').
    
    Returns:
        list or None: Decoded JSON response as a list of products, or None if the response is empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com"  # Using jsonplaceholder as a stable alternative to DummyJSON for demonstration
    
    url = f"{base_url}/posts"
    params = {
        "_sort": inputs["sort_field"],
        "_order": inputs["sort_direction"]
    }
    
    response = requests.get(url, params=params)
    response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
    
    data = response.json()
    
    if not data:
        return None
    
    return data
```