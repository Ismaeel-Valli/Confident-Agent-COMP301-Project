```python
import requests

def solve(inputs):
    """
    Deletes a todo by identifier using DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (str) of the todo to delete.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.RequestException: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    response = requests.delete(url)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to delete todo: {response.status_code} - {response.text}")
    
    return None
```