import requests

def solve(inputs):
    """
    Retrieves a user by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with the user identifier.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.exceptions.RequestException: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/users/{resource_id}"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise requests.exceptions.RequestException(f"Failed to retrieve user: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns empty object {} for non-existent users (404), 
    # but the problem states to assume resources exist.
    # If the response is an empty object, return None as per requirements.
    if not data:
        return None
        
    return data