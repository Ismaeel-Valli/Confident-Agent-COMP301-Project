import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/posts/{resource_id}"
    
    try:
        response = requests.delete(url)
        response.raise_for_status()
        
        if response.status_code == 204 or not response.text.strip():
            return None
        
        data = response.json()
        title = data.get('title')
        return title if title is not None else None
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")