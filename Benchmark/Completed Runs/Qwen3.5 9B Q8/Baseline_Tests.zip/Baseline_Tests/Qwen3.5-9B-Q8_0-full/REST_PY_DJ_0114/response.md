```python
import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    new_price = inputs['new_price']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    data = {'price': new_price}
    
    response = requests.put(url, json=data)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product. Status code: {response.status_code}")
    
    result = response.json()
    
    if not result:
        return None
    
    title = result.get('title')
    return title if title is not None else None
```