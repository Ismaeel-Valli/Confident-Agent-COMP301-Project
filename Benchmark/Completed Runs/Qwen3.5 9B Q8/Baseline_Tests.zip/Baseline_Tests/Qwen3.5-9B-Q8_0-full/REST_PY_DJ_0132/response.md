```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (product ID) and 'new_category' (new category value).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        Raises: Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_category = inputs.get('new_category')
    
    if not resource_id or new_category is None:
        raise ValueError("Missing required inputs: resource_id and new_category")

    url = f"https://dummyjson.com/products/{resource_id}"
    
    payload = {
        "category": new_category
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Check for successful empty response (indicated by empty data or specific success structure)
    if not data or (isinstance(data, dict) and len(data) == 0):
        return None
    
    # Return the id from the response if present
    if 'id' in data:
        return data['id']
    
    return None
```