import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API using the provided inputs.
    
    Args:
        inputs (dict): Dictionary containing 'new_title' for the product title.
        
    Returns:
        int or None: The ID of the created product, or None if response is empty/successful without ID.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    # Prepare the payload with the new title
    payload = {
        "title": inputs.get("new_title")
    }
    
    try:
        response = requests.post(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if the response is empty or doesn't contain an 'id'
        if not response.json():
            return None
            
        data = response.json()
        
        # Return the id if present, otherwise None
        return data.get("id")
        
    except requests.RequestException as e:
        raise e