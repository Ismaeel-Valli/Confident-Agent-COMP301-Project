import requests

def solve(inputs):
    """
    Updates selected fields of a post in DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the post to update.
            - new_user_identifier (str): New value for the user ID attribute.
    
    Returns:
        dict or None: Decoded JSON response if successful (empty), otherwise raises an exception.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    resource_id = inputs['resource_id']
    new_user_identifier = inputs['new_user_identifier']
    
    url = f"{base_url}/posts/{resource_id}"
    
    payload = {
        "userId": new_user_identifier
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return None
    else:
        raise Exception(f"Failed to update post. Status code: {response.status_code}, Response: {response.text}")