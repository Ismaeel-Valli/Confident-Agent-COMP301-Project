```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_description'.
        
    Returns:
        str or None: The title from the response, or None if absent or successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_description = inputs['new_description']
    
    # DummyJSON API endpoint for updating a product
    url = f"https://dummyjson.com/products/{resource_id}"
    
    payload = {
        "description": new_description
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product. Status code: {response.status_code}, Response: {response.text}")
    
    # Check if the response is empty (no data returned)
    if not response.json():
        return None
    
    data = response.json()
    
    # Return title if present, otherwise None
    return data.get('title')
```