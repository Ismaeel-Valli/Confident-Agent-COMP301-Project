```python
import requests
from urllib.parse import quote

def solve(inputs):
    """
    Lists forks for a given GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The Bearer token for authentication.
    
    Returns:
        list or None: A list of fork data dictionaries if forks exist, otherwise None.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    token = inputs['credential']
    
    url = f"https://api.github.com/repos/{quote(owner, safe='')}/{quote(repo, safe='')}/forks"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {token}",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to list forks. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    return None if not data else data
```