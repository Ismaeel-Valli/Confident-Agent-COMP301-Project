import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API using provided description and title.
    
    Args:
        inputs (dict): Dictionary containing 'new_description' and 'new_title'.
        
    Returns:
        int or None: The ID of the created product, or None if response is empty/successful without ID.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "description": inputs["new_description"],
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to create product. Status code: {response.status_code}")
    
    # Check if the response contains an 'id' field
    data = response.json()
    return data.get("id")