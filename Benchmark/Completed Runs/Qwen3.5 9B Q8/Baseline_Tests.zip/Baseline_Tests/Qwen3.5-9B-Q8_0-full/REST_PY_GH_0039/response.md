```python
import requests
from urllib.parse import quote

def solve(inputs):
    """
    Updates a pull request on GitHub using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - pull_number (int): The number that identifies the pull request.
            - new_title (str): The new title for the pull request.
            - credential (str): The authentication token or string for the API call.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    pull_number = inputs["pull_number"]
    new_title = inputs["new_title"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{quote(repository_owner, safe='')}/{quote(repository_name, safe='')}/pulls/{pull_number}"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}",
        "X-GitHub-Api-Version": "2026-03-10",
        "Content-Type": "application/json"
    }
    
    data = {
        "title": new_title
    }
    
    response = requests.put(url, headers=headers, json=data)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to update pull request. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json() if response.content else None
```