```python
import requests

def solve(inputs):
    """
    Fetches issue comments from a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'issue_number' (int): The issue number.
            - 'credential' (str): The authentication token or string for the API call.
    
    Returns:
        list | None: A list of decoded JSON comment objects, or None if the response is empty but successful.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    issue_number = inputs['issue_number']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}/comments"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch issue comments. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # GitHub API returns an empty list [] for no comments, not null.
    # The requirement says "Return None for a successful empty response".
    if len(data) == 0:
        return None
    
    return data
```