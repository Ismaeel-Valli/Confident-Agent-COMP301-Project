import requests

def solve(inputs):
    """
    Fetches a specific milestone from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository.
            - 'milestone_number' (int): The number identifying the milestone.
            - 'credential' (str): The authentication token or string for the API call.
    
    Returns:
        dict or None: The decoded JSON response if successful and data exists, 
                      None if the response is successfully empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails or returns an unsuccessful status code.
    """
    repository_owner = inputs['repository_owner']
    repository_name = inputs['repository_name']
    milestone_number = inputs['milestone_number']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/milestones/{milestone_number}"
    
    headers = {
        'Authorization': f'token {credential}',
        'Accept': 'application/vnd.github+json'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to fetch milestone. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response (though milestones usually have data)
    if not data:
        return None
        
    return data