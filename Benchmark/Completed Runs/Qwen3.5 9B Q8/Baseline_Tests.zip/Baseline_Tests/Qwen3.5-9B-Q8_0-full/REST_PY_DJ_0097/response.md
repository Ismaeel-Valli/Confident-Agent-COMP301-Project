```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the user
            - new_email (str): New value for the email attribute
    
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
    
    Raises:
        requests.exceptions.RequestException: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_email = inputs['new_email']
    
    # DummyJSON API endpoint for updating a user
    url = f"https://dummyjson.com/users/{resource_id}"
    
    # Prepare the payload with only the field to update
    payload = {
        "email": new_email
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code == 200:
        # Successful update with empty body
        return None
    elif response.status_code == 201:
        # Successful update with new data (though unlikely for PUT on existing resource)
        return response.json()
    else:
        raise requests.exceptions.RequestException(
            f"Failed to update user {resource_id}: HTTP {response.status_code} - {response.text}"
        )
```