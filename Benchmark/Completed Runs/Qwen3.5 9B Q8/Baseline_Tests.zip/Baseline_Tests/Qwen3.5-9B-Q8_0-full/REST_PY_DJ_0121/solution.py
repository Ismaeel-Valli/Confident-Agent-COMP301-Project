import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id', 'new_todo', and 'new_user_identifier'.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_todo = inputs['new_todo']
    new_user_identifier = inputs['new_user_identifier']
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    payload = {
        "todo": new_todo,
        "userId": new_user_identifier
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        data = response.json()
        return None if data is None else data
    elif response.status_code == 404:
        raise Exception(f"Resource not found: {resource_id}")
    else:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}, Response: {response.text}")