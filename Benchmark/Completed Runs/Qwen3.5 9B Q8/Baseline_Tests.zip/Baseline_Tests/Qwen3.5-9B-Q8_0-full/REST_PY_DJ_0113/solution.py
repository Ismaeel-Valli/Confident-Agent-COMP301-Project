import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON based on skip count and included fields.
    
    Args:
        inputs (dict): A dictionary containing:
            - results_to_skip (int): Number of results to skip.
            - included_fields (str): Comma-separated list of fields to include.
    
    Returns:
        dict or None: Decoded JSON response, or None if the response is empty but successful.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/products"
    
    # Parse inputs
    results_to_skip = inputs.get("results_to_skip", 0)
    included_fields = inputs.get("included_fields", "")
    
    # Build query parameters
    params = {
        "skip": results_to_skip,
        "limit": 1,  # Retrieve one page (one item)
        "select": included_fields if included_fields else None
    }
    
    # Send GET request
    response = requests.get(base_url, params=params)
    
    # Check for unsuccessful HTTP response
    if response.status_code != 200:
        raise Exception(f"HTTP error occurred: {response.status_code} - {response.text}")
    
    # Decode JSON response
    data = response.json()
    
    # Return None for a successful empty response (empty products array)
    if not data.get("products"):
        return None
    
    return data