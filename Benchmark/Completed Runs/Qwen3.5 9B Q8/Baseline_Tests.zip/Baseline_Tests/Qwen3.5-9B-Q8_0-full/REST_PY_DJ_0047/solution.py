import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.delete(url)
        response.raise_for_status()
        
        if response.status_code == 200 and not response.text.strip():
            return None
        
        data = response.json()
        return data.get('title')
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")