import requests

def solve(inputs):
    """
    Deletes a todo by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (str) - Identifier of the todo.
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON API endpoint for deleting a todo by ID
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    try:
        response = requests.delete(url)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (successful deletion often returns empty body)
        if not response.text.strip():
            return None
        
        # Try to parse the response as JSON and extract the id
        try:
            data = response.json()
            return data.get('id')
        except ValueError:
            # If response is not valid JSON, return None for successful empty response
            return None
            
    except requests.exceptions.HTTPError as e:
        raise e
    except requests.exceptions.RequestException as e:
        raise e