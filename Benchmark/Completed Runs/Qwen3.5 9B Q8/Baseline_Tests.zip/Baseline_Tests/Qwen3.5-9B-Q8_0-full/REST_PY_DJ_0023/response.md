```python
import requests

def solve(inputs):
    """
    Submits a new todo to DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing:
            - new_completed (bool): Value for the 'completed' attribute.
            - new_todo (str): Value for the 'todo' attribute.
            - new_user_identifier (int): Value for the 'userId' attribute.
            
    Returns:
        dict or None: The decoded JSON response if successful, None for an empty response.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request is unsuccessful.
    """
    url = "https://jsonplaceholder.typicode.com/todos"
    
    payload = {
        "userId": inputs["new_user_identifier"],
        "title": inputs["new_todo"],
        "completed": inputs["new_completed"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise requests.exceptions.HTTPError(f"Failed to create todo. Status code: {response.status_code}")
    
    return None
```