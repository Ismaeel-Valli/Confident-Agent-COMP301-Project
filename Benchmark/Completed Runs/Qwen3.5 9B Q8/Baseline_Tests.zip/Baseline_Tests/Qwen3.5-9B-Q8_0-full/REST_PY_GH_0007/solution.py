import requests
from urllib.parse import quote

def solve(inputs):
    """
    Updates the name of a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository without the .git extension.
            - 'new_name' (str): The new name for the repository.
            - 'credential' (str): The authentication token or string for the API request.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    owner = inputs['repository_owner']
    repo_name = inputs['repository_name']
    new_name = inputs['new_name']
    credential = inputs['credential']
    
    # Construct the API URL for updating a repository name
    url = f"https://api.github.com/repos/{quote(owner, safe='')}/{quote(repo_name, safe='')}"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}",
        "X-GitHub-Api-Version": "2026-03-10",
        "Content-Type": "application/json"
    }
    
    # Prepare the payload for updating the repository name
    data = {
        "name": new_name
    }
    
    response = requests.patch(url, headers=headers, json=data)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 201:
        return response.json()
    else:
        raise Exception(f"Failed to update repository name. Status code: {response.status_code}, Response: {response.text}")