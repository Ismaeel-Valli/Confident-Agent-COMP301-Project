```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (product ID) and 'new_title' (new title value).
        
    Returns:
        str or None: The updated title if present, otherwise None for successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    new_title = inputs.get('new_title')
    
    # Base URL for DummyJSON API
    base_url = "https://dummyjson.com"
    url = f"{base_url}/products/{resource_id}"
    
    # Prepare the payload with only the field to update
    payload = {
        "title": new_title
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.put(url, json=payload, headers=headers)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (no content)
        if not response.text.strip():
            return None
            
        # Parse the JSON response
        data = response.json()
        
        # Return the title value if present, otherwise None
        return data.get('title')
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```