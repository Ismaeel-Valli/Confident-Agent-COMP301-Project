import requests

def solve(inputs):
    """
    Deletes a product by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (product identifier)
        
    Returns:
        dict or None: Decoded JSON response if not empty, None for successful empty response
        
    Raises:
        requests.exceptions.RequestException: For unsuccessful HTTP responses
    """
    resource_id = inputs['resource_id']
    
    # DummyJSON delete endpoint pattern
    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.delete(url)
        
        # Raise exception for unsuccessful HTTP status codes
        response.raise_for_status()
        
        # Return decoded JSON if there's content, otherwise return None
        if response.content:
            return response.json()
        else:
            return None
            
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Failed to delete product: {e}")