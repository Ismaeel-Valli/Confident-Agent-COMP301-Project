import requests

def solve(inputs):
    """
    Retrieves a product by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' key with the product identifier.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.exceptions.RequestException: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/products/{resource_id}"
    
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        return None if not data else data
    elif response.status_code == 404:
        # Assuming referenced resources exist per instructions, 
        # but handling 404 gracefully by returning None for empty/not found
        return None
    else:
        raise requests.exceptions.RequestException(f"HTTP {response.status_code} error occurred")