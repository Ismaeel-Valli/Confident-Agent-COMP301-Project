import requests

def solve(inputs):
    """
    Lists repositories for a given GitHub organization using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - "organization" (str): The name of the organization.
            - "credential" (str): The caller-supplied credential (e.g., token).
    
    Returns:
        list or None: A list of repository objects if repositories exist, 
                      None if the response is successful but empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    org = inputs["organization"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/orgs/{org}/repos"
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to fetch repositories for organization '{org}': HTTP {response.status_code}")
    
    data = response.json()
    
    return data if data else None