import requests
import json

def solve(inputs):
    """
    Creates a fork of a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'new_name' (str): The new name for the forked repository.
            - 'credential' (str): The authentication token or string for API calls.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    owner = inputs['repository_owner']
    repo_name = inputs['repository_name']
    new_name = inputs['new_name']
    credential = inputs['credential']
    
    # GitHub API endpoint for creating a fork with a custom name
    url = f"https://api.github.com/repos/{owner}/{repo_name}/forks"
    
    headers = {
        'Accept': 'application/vnd.github+json',
        'Authorization': f'Bearer {credential}',
        'X-GitHub-Api-Version': '2026-03-10'
    }
    
    params = {'name': new_name}
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create fork. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json()