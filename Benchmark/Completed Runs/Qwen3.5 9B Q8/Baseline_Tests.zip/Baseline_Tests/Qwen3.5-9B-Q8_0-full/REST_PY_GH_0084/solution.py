import requests
from urllib.parse import quote

def solve(inputs):
    """
    Updates a milestone in a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - milestone_number (int): The number that identifies the milestone.
            - new_state (str): The new state value for the milestone ('open' or 'closed').
            - credential (str): The authentication token or string for the API request.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    milestone_number = inputs["milestone_number"]
    new_state = inputs["new_state"]
    credential = inputs["credential"]

    # Construct the API URL
    url = f"https://api.github.com/repos/{quote(repository_owner, safe='')}/{quote(repository_name, safe='')}/milestones/{milestone_number}"

    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Prepare the payload for updating the milestone state
    payload = {
        "state": new_state
    }

    try:
        response = requests.put(url, json=payload, headers=headers)
        
        if response.status_code == 200 or response.status_code == 204:
            # GitHub typically returns a 204 No Content for successful updates without body changes like state
            return None if response.status_code == 204 else response.json()
        elif response.status_code >= 400:
            raise Exception(f"Failed to update milestone. Status code: {response.status_code}, Response: {response.text}")
        else:
            raise Exception(f"Unexpected status code: {response.status_code}")
    
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")