import requests

def solve(inputs):
    """
    Creates an issue comment on GitHub using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - issue_number (int): The number that identifies the issue.
            - new_body (str): Value for the body attribute of the comment.
            - credential (str): The caller-supplied authentication token.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    new_body = inputs["new_body"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/issues/{issue_number}/comments"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.post(url, json={"body": new_body}, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to create issue comment. Status code: {response.status_code}, Response: {response.text}")
    
    return None