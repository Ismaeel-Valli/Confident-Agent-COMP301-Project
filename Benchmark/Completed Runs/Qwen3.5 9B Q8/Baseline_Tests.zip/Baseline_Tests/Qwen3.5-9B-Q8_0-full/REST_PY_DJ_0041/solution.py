import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (todo ID) and 'new_todo' (value to update).
        
    Returns:
        str or None: The response's id value, or None if absent or for empty successful response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    new_todo_value = inputs.get('new_todo')
    
    # Base URL for DummyJSON Todo API
    base_url = "https://dummyjson.com"
    url = f"{base_url}/todos/{resource_id}"
    
    # Prepare the payload to update only the 'todo' field
    payload = {
        "todo": new_todo_value
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
    response.raise_for_status()
    
    # Check if the response is empty (no content)
    if not response.text:
        return None
    
    try:
        data = response.json()
        # Return the id from the response, or None if absent
        return data.get('id')
    except ValueError:
        # If JSON parsing fails but we got a successful response, treat as empty
        return None