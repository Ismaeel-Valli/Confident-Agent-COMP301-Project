import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API with provided category and title.
    
    Args:
        inputs (dict): Dictionary containing 'new_category' and 'new_title'.
        
    Returns:
        str or None: The response's title value if present, otherwise None for successful empty response.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "category": inputs["new_category"],
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to submit product: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Check if 'title' is in the response (it might be absent in some API versions)
    if "title" in data and data["title"]:
        return data["title"]
    
    # Return None for successful empty response or missing title
    return None