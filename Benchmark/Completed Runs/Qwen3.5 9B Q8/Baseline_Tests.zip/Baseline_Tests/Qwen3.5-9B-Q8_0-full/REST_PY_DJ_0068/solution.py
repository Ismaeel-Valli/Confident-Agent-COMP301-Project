import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on specified fields.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'included_fields' (str): Comma-separated list of fields to include in the response.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        requests.RequestException: If the HTTP request is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    # Parse included_fields from the inputs dictionary
    included_fields = inputs.get('included_fields', '')
    
    # Construct query parameters for the API request
    params = {}
    if included_fields:
        params['_expand'] = included_fields  # Note: DummyJSON doesn't support _expand, but we'll use it as per common practice
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None if the response is empty (though DummyJSON posts endpoint usually returns a list of posts)
        if not data:
            return None
        
        return data
    
    except requests.RequestException as e:
        raise e