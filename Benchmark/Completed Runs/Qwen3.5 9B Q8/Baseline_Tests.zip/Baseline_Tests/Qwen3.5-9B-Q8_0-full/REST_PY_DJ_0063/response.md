```python
import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    
    try:
        response = requests.delete(f"https://dummyjson.com/products/{resource_id}")
        
        if response.status_code != 200:
            raise Exception(f"Failed to delete product. Status code: {response.status_code}, Response: {response.text}")
        
        if response.json():
            return response.json().get('isDeleted')
        else:
            return None
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```