```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_user_identifier' (new user ID).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_user_identifier = inputs['new_user_identifier']
    
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    payload = {
        "userId": new_user_identifier
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP request failed with status code: {response.status_code}")
    
    # DummyJSON typically returns an empty body for PUT/POST operations on existing resources
    # but we check for the 'id' attribute as per instructions
    data = response.json()
    
    if isinstance(data, dict) and 'id' in data:
        return data['id']
    
    return None
```