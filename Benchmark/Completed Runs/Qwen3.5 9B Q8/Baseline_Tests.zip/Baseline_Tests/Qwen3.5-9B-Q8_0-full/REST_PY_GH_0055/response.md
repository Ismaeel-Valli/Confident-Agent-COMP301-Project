```python
import requests

def solve(inputs):
    """
    Unfollows a GitHub user using the GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The handle for the GitHub user account to unfollow.
            - 'credential' (str): The caller-supplied credential (e.g., Personal Access Token).
    
    Returns:
        int: The successful HTTP status code (typically 204 No Content).
    
    Raises:
        requests.RequestException: If the HTTP request fails or returns an unsuccessful status code.
    """
    username = inputs['username']
    credential = inputs['credential']
    
    # Construct the URL to unfollow a user
    url = f"https://api.github.com/user/following/{username}"
    
    headers = {
        'Authorization': f'token {credential}',
        'Accept': 'application/vnd.github+json'
    }
    
    response = requests.delete(url, headers=headers)
    
    if response.status_code == 204:
        return response.status_code
    
    response.raise_for_status()
```