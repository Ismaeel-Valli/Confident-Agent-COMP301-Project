```python
import requests

def solve(inputs):
    """
    Deletes a label from a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'name' (str): The name of the label to delete.
            - 'credential' (str): The authentication token or string for the API call.
    
    Returns:
        int: The successful HTTP status code (typically 204 No Content).
    
    Raises:
        requests.RequestException: If the HTTP request fails or returns an unsuccessful status code.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    label_name = inputs['name']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/labels/{label_name}"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.delete(url, headers=headers)
    
    if response.status_code >= 400:
        raise requests.RequestException(f"Failed to delete label. Status code: {response.status_code}, Response: {response.text}")
    
    return response.status_code
```