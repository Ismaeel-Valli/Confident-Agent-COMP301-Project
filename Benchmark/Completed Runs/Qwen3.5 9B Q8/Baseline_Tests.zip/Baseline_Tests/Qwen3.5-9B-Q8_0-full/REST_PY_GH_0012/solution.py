import requests

def solve(inputs):
    """
    Fetches a commit from the GitHub REST API (version 2026-03-10).
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - ref (str): The commit reference (e.g., branch name, tag, or SHA).
            - credential (str): The authentication token or bearer token.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is successfully empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails or returns an unsuccessful status code.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    ref = inputs["ref"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/commits/{ref}"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to fetch commit: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response (though commits usually have data)
    if not data:
        return None
        
    return data