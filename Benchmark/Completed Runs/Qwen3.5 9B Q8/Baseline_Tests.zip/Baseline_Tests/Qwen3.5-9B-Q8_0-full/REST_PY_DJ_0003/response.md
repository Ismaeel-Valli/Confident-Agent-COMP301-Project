```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the product.
            - new_title (str): New value for the title attribute.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty (successful), 
                      raises an exception on unsuccessful HTTP response.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://dummyjson.com/products"
    resource_id = inputs.get("resource_id")
    new_title = inputs.get("new_title")

    if not resource_id or not new_title:
        raise ValueError("Missing required input fields: resource_id and new_title.")

    url = f"{base_url}/{resource_id}"
    payload = {"title": new_title}

    response = requests.put(url, json=payload)

    if response.status_code != 200:
        response.raise_for_status()

    if not response.text.strip():
        return None

    return response.json()
```