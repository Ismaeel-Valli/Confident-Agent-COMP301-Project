```python
import requests

def solve(inputs):
    """
    Submits a new post to DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing:
            - new_body (str): Value for the body attribute.
            - new_title (str): Value for the title attribute.
            - new_user_identifier (str): Value for the user Id attribute.
            
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty (204 No Content).
                      
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": inputs["new_title"],
        "body": inputs["new_body"],
        "userId": inputs["new_user_identifier"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code == 201:
        # Check if the response is empty (though typically 201 returns data)
        if not response.text.strip():
            return None
        return response.json()
    elif response.status_code == 204:
        # Some APIs might return 204 No Content for success
        return None
    else:
        raise requests.RequestException(f"Failed to create post. Status code: {response.status_code}")
```