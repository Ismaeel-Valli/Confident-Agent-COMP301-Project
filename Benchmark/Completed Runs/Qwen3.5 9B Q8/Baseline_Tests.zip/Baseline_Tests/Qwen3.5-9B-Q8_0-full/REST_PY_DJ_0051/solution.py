import requests

def solve(inputs):
    """
    Deletes a user by identifier from DummyJSON and returns the 'isDeleted' value.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (user identifier).
        
    Returns:
        bool or None: The 'isDeleted' value from the response, or None if absent or on success with empty response.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON delete endpoint for users (assuming standard structure)
    url = f"https://dummyjson.com/users/{resource_id}"
    
    try:
        response = requests.delete(url)
        
        if response.status_code not in [200, 204]:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
        
        # Check for isDeleted attribute
        data = response.json() if response.content else {}
        
        if 'isDeleted' in data:
            return data['isDeleted']
        elif response.status_code == 204:
            # Empty response on success
            return None
            
    except requests.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")

# Example usage (not executed):
# inputs = {'resource_id': '1'}
# result = solve(inputs)