import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on skip count and included fields.
    
    Args:
        inputs (dict): A dictionary containing:
            - results_to_skip (int): Number of results to skip.
            - included_fields (str): Comma-separated list of fields to include.
    
    Returns:
        dict or None: The decoded JSON response, or None if the response is empty but successful.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com/todos"
    
    # Parse included_fields
    fields = [field.strip() for field in inputs['included_fields'].split(',')]
    
    params = {
        '_skip': inputs['results_to_skip'],
        '_limit': 1,
        '_fields': ','.join(fields)
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP request failed with status code: {response.status_code}")
    
    data = response.json()
    
    # Return None for a successful empty response
    if not data:
        return None
    
    return data