```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_phone' (new phone number).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_phone = inputs['new_phone']
    
    url = f"https://dummyjson.com/users/{resource_id}"
    
    # Prepare the data to update
    data = {
        "phone": new_phone
    }
    
    try:
        response = requests.put(url, json=data)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        # Check if the response is empty (no content)
        if not response.text.strip():
            return None
        
        # Try to parse the JSON response and extract the id
        try:
            json_response = response.json()
            return json_response.get('id')
        except ValueError:
            # If response is not valid JSON, return None as per successful empty response logic
            return None
            
    except requests.RequestException as e:
        raise e
```