import requests

def solve(inputs):
    """
    Updates a GitHub issue using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - issue_number (int): The number that identifies the issue.
            - new_body (str): The new value for the body attribute.
            - credential (str): The caller-supplied credential (e.g., token).
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    new_body = inputs["new_body"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/issues/{issue_number}"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    data = {
        "body": new_body
    }
    
    response = requests.put(url, headers=headers, json=data)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update issue. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json() if response.content else None