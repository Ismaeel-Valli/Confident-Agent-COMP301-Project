import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON based on the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'result_limit' (int).
        
    Returns:
        list or None: The decoded JSON response as a list of products, 
                      or None if the response is successfully empty.
                      
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://dummyjson.com/products"
    result_limit = inputs.get('result_limit', 10)
    
    params = {
        'limit': result_limit,
        'skip': 0
    }
    
    response = requests.get(base_url, params=params)
    
    # Raise an exception for unsuccessful HTTP responses (status code outside 2xx range)
    response.raise_for_status()
    
    data = response.json()
    
    # Return the products list directly from the JSON response
    return data.get('products')