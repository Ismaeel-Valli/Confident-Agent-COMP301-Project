```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post on DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (int) and 'new_title' (str).
        
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_title = inputs['new_title']
    
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    try:
        response = requests.put(url, json={"title": new_title})
        
        if response.status_code != 200:
            raise Exception(f"HTTP {response.status_code}: {response.text}")
            
        return response.json().get('id')
        
    except requests.RequestException as e:
        raise e
```