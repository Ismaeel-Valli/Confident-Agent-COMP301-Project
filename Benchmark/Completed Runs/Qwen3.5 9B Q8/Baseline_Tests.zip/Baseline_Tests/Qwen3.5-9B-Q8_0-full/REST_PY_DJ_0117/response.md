```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_phone' (new phone number).
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    new_phone = inputs.get('new_phone')
    
    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {
        "phone": new_phone
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user: HTTP {response.status_code} - {response.text}")
    
    data = response.json()
    
    # DummyJSON returns an empty object {} on successful PUT for this endpoint
    return None if not data else data
```