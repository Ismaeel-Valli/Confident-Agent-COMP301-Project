import requests

def solve(inputs):
    """
    Retrieves a product by identifier from DummyJSON and returns its title.
    
    Args:
        inputs (dict): A dictionary containing 'resource_id' as the product identifier.
        
    Returns:
        str or None: The title of the product, None if title is absent or response is empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    
    # Construct the API URL for DummyJSON to get a specific product by ID
    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.get(url)
        
        # Raise an exception for unsuccessful HTTP responses (status code not in 200-299)
        response.raise_for_status()
        
        # Parse the JSON response
        data = response.json()
        
        # Check if the response is empty or doesn't contain a 'title'
        if not data or 'title' not in data:
            return None
            
        return data['title']
        
    except requests.exceptions.RequestException as e:
        raise e