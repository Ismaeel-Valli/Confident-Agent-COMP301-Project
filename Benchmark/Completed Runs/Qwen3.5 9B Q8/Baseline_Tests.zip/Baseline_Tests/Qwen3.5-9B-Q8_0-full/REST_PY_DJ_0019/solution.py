import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing 'page' key for pagination.
        
    Returns:
        list: Decoded JSON response (list of todos) if successful and not empty.
        None: If successful but the response is empty.
        
    Raises:
        requests.exceptions.RequestException: For unsuccessful HTTP responses.
    """
    base_url = "https://jsonplaceholder.typicode.com/todos"
    
    # Extract page number from inputs, default to 1 if not provided or invalid
    try:
        page = int(inputs.get('page', 1))
    except (ValueError, TypeError):
        raise ValueError("Invalid page number in inputs")

    url = f"{base_url}?page={page}"
    
    response = requests.get(url)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    data = response.json()
    
    # Return None for a successful empty response
    if not data:
        return None
    
    return data