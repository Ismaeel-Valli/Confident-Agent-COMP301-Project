```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_username'.
        
    Returns:
        str or None: The response's id value, or None if successful with empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_username = inputs['new_username']
    
    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {"username": new_username}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user: {response.status_code} - {response.text}")
    
    # DummyJSON returns a 200 OK with an empty body for successful updates
    if not response.text.strip():
        return None
    
    try:
        data = response.json()
        return data.get('id')
    except ValueError:
        return None
```