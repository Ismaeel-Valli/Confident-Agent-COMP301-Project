import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the user
            - new_firstName (str): New value for the first name attribute
    
    Returns:
        str or None: The response's id value, or None if that attribute is absent.
                     Returns None for a successful empty response.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs['resource_id']
    new_firstName = inputs['new_firstName']
    
    url = f"https://dummyjson.com/users/{resource_id}"
    
    payload = {
        "firstName": new_firstName
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP request failed with status code: {response.status_code}")
    
    # Check if the response is empty (no content)
    if not response.text.strip():
        return None
    
    try:
        data = response.json()
        return data.get('id')
    except ValueError:
        # If JSON parsing fails, return None as per successful but non-JSON response
        return None