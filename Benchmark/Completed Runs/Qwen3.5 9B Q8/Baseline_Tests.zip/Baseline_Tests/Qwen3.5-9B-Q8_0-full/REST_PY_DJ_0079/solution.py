import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on the provided sort_field.
    
    Args:
        inputs (dict): A dictionary containing 'sort_field' key.
        
    Returns:
        dict: The decoded JSON response if successful and non-empty.
        None: If the response is successful but empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    sort_field = inputs.get("sort_field")
    
    params = {}
    if sort_field:
        params["sort"] = sort_field
    
    response = requests.get(base_url, params=params)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    data = response.json()
    
    # Return None for a successful empty response
    if not data:
        return None
        
    return data