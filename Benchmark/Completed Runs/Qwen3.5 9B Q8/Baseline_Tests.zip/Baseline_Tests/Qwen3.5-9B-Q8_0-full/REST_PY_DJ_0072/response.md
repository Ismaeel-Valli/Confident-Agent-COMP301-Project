```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (todo id) and 'new_completed' (boolean).
        
    Returns:
        str or None: The response's 'id' value if present, otherwise None for successful empty response.
        Raises: Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_completed = inputs['new_completed']
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    payload = {
        "completed": new_completed
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}, Response: {response.text}")
    
    # Check if the response is empty (no content)
    if not response.content:
        return None
    
    try:
        data = response.json()
        return data.get('id')
    except ValueError:
        # If JSON parsing fails but status is 200, treat as empty success
        return None
```