import requests

def solve(inputs):
    base_url = "https://dummyjson.com/users/add"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "phone": inputs["new_phone"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        response.raise_for_status()
        
        data = response.json()
        
        if 'id' in data:
            return data['id']
        else:
            return None
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")