import requests

def solve(inputs):
    base_url = "https://dummyjson.com/users"
    url = f"{base_url}?new_firstName={inputs['new_firstName']}&new_phone={inputs['new_phone']}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        
        data = response.json()
        
        if 'id' in data:
            return data['id']
        else:
            return None
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")