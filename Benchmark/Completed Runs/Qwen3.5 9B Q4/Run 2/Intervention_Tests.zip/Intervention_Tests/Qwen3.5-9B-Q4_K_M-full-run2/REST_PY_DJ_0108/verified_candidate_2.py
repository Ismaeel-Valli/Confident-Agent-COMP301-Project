def solve(inputs):
    import requests
    
    base_url = "https://dummyjson.com/users/add"
    email = inputs["new_email"]
    first_name = inputs["new_firstName"]
    
    payload = {
        "email": email,
        "firstName": first_name
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code == 201:
        data = response.json()
        return data.get("id")
    elif response.status_code == 200:
        data = response.json()
        if not data:
            return None
        else:
            raise Exception(f"Unexpected successful response with status {response.status_code}: {data}")
    else:
        raise Exception(f"HTTP error {response.status_code}: {response.text}")