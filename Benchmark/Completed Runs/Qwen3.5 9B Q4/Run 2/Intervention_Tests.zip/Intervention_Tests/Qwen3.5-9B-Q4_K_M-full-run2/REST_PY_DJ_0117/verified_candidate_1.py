import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_phone = inputs["new_phone"]
    
    url = "https://dummyjson.com/users/{0}".format(resource_id)
    headers = {"Content-Type": "application/json"}
    payload = {"phone": new_phone}
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 404:
        raise Exception("User not found")
    else:
        raise Exception(f"HTTP error {response.status_code}: {response.text}")