def solve(inputs):
    resource_id = inputs["resource_id"]
    new_body = inputs["new_body"]
    new_title = inputs["new_title"]
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    payload = {"body": new_body, "title": new_title}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 200:
        return None
    elif response.status_code == 201:
        data = response.json()
        return data.get("id")
    else:
        raise Exception(f"Failed to update post: {response.status_code} {response.text}")