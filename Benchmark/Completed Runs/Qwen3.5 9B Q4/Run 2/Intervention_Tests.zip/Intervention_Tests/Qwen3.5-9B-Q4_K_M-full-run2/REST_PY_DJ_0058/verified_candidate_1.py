def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON, skipping a specified number of results.
    
    Args:
        inputs (dict): Must contain 'results_to_skip' (int).
        
    Returns:
        dict or None: The decoded JSON response if successful. Returns None for empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    import requests
    
    base_url = "https://dummyjson.com"
    endpoint = "/todos"
    
    # Build the query parameters
    params = {
        "skip": inputs["results_to_skip"],
        "limit": 10  # Retrieve one page (default limit is 10)
    }
    
    response = requests.get(f"{base_url}{endpoint}", params=params)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # Return None for empty response, otherwise return the decoded JSON
    if not data.get("todos"):
        return None
    
    return data