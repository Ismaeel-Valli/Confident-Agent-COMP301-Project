def solve(inputs):
    import requests
    resource_id = inputs["resource_id"]
    url = f"https://dummyjson.com/posts/{resource_id}"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        return data.get("isDeleted")
    elif response.status_code == 404:
        return None
    else:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")