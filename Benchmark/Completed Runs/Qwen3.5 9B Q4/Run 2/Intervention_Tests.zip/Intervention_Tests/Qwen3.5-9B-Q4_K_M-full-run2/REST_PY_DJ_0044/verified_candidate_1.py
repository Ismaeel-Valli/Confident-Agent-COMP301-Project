import requests

def solve(inputs):
    """
    Retrieve one page of products from DummyJSON, skipping a number of results.
    
    Args:
        inputs (dict): Must contain 'results_to_skip' (int).
    
    Returns:
        dict or None: The decoded JSON response, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/products"
    skip = inputs["results_to_skip"]
    
    url = f"{base_url}?skip={skip}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        
        data = response.json()
        
        # DummyJSON returns {"products": [], ...} for empty pages, not {}
        if "products" in data and len(data["products"]) == 0:
            return None
        
        return data
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")