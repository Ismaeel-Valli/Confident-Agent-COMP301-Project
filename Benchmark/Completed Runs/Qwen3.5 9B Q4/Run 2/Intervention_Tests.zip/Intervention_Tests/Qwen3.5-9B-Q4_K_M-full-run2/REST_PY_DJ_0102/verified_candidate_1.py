import requests

def solve(inputs):
    """
    Update selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id (int): Identifier of the todo to update.
            - new_completed (bool): New value for the 'completed' attribute.
            - new_todo (str): New value for the 'todo' attribute.
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response.
    
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com"
    resource_id = inputs["resource_id"]
    new_completed = inputs["new_completed"]
    new_todo = inputs["new_todo"]
    
    url = f"{base_url}/todos/{resource_id}"
    payload = {
        "completed": new_completed,
        "todo": new_todo
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return response.json() if response.text else None
    elif response.status_code == 204:
        return None
    else:
        raise Exception(f"HTTP {response.status_code}: {response.text}")