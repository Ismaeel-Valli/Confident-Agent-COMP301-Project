def solve(inputs):
    resource_id = inputs["resource_id"]
    new_title = inputs["new_title"]
    
    url = "https://dummyjson.com/posts/" + str(resource_id)
    payload = {"title": new_title}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    data = response.json()
    title = data.get("title")
    return title if title is not None else None