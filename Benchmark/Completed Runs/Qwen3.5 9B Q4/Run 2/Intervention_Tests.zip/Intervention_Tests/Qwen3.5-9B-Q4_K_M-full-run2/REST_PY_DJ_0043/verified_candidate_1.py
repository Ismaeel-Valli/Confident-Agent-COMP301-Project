import requests

def solve(inputs):
    base_url = "https://dummyjson.com"
    
    payload = {
        "todo": inputs["new_todo"],
        "completed": inputs["new_completed"],
        "userId": inputs["new_user_identifier"]
    }
    
    response = requests.post(f"{base_url}/todos", json=payload)
    response.raise_for_status()
    
    data = response.json()
    
    if "result" in data:
        return data["result"].get("id")
    elif "error" in data:
        raise Exception(data["error"])
    else:
        return None