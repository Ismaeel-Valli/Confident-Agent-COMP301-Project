def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_body = inputs["new_body"]
    
    url = "https://dummyjson.com/posts/{0}".format(resource_id)
    payload = {"body": new_body}
    
    response = requests.patch(url, json=payload)
    
    if response.status_code == 200:
        data = response.json()
        if "id" in data:
            return data["id"]
        else:
            return None
    elif response.status_code == 404:
        return None
    else:
        raise Exception("Unsuccessful HTTP response")