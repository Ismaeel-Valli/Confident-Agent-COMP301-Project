def solve(inputs):
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/users/{resource_id}"
    response = requests.delete(url)
    if response.status_code == 204:
        return None
    elif response.status_code == 404:
        raise Exception(f"Resource not found: {response.json()}")
    else:
        response.raise_for_status()