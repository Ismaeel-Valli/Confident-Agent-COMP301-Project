def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_title = inputs["new_title"]
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"title": new_title}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 404:
        raise Exception(f"Resource not found: {resource_id}")
    else:
        raise Exception(f"Failed to update product: {response.status_code} - {response.text}")