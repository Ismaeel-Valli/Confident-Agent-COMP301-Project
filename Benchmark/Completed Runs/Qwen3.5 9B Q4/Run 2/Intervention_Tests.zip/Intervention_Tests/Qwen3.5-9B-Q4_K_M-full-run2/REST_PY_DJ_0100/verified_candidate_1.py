import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_user_identifier = inputs["new_user_identifier"]
    
    url = "https://dummyjson.com/posts/{id}".format(id=resource_id)
    payload = {"userId": new_user_identifier}
    
    response = requests.patch(url, json=payload)
    
    if response.status_code == 200:
        return response.json()
    elif response.status_code == 204:
        return None
    else:
        raise Exception(f"HTTP {response.status_code}: {response.text}")