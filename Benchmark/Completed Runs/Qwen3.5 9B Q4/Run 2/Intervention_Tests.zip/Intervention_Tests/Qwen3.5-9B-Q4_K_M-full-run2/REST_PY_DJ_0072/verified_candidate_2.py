import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    new_completed = inputs['new_completed']
    
    url = "https://dummyjson.com/todos/" + str(resource_id)
    payload = {"completed": new_completed}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    data = response.json()
    if 'id' in data:
        return data['id']
    return None