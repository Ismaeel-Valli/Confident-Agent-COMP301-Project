def solve(inputs):
    import requests
    
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/add"
    
    headers = {
        "Content-Type": "application/json",
    }
    
    payload = {
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload, headers=headers)
    response.raise_for_status()
    
    data = response.json()
    
    if "product" in data:
        product = data["product"]
        if "id" in product:
            return product["id"]
        else:
            return None
    else:
        return None