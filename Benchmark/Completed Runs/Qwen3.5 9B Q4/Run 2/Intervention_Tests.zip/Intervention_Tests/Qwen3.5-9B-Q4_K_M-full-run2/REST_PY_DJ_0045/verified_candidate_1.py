def solve(inputs):
    resource_id = inputs["resource_id"]
    url = f"https://dummyjson.com/products/{resource_id}"
    response = requests.get(url)
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    data = response.json()
    title = data.get("title")
    if title is None:
        return None
    return title