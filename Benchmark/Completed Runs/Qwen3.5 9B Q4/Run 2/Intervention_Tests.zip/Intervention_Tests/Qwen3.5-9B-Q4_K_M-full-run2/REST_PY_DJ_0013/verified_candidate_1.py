import requests

def solve(inputs):
    """Retrieve one page of posts from DummyJSON and return the decoded JSON response."""
    base_url = "https://dummyjson.com"
    endpoint = "/posts"
    
    url = f"{base_url}{endpoint}"
    
    try:
        response = requests.get(url)
        
        if response.status_code != 200:
            raise Exception(f"HTTP error {response.status_code}: {response.text}")
        
        data = response.json()
        
        # Return None for a successful empty response (no posts)
        if not data.get("posts"):
            return None
        
        return data
    except requests.RequestException as e:
        raise Exception(f"Request failed: {e}")