def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_description = inputs["new_description"]
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"description": new_description}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    return response.json()