import requests

def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON, respecting result_limit.
    
    Args:
        inputs (dict): Must contain 'result_limit' (int).
    
    Returns:
        dict or None: Decoded JSON response if successful; None for empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com"
    endpoint = "/todos"
    url = f"{base_url}{endpoint}"
    
    params = {"limit": inputs["result_limit"]}
    
    response = requests.get(url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    return data.get("todos", None)