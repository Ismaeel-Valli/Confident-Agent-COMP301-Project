import requests

def solve(inputs):
    """Submit a new product to DummyJSON."""
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/add"
    
    payload = {
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    return response.json()