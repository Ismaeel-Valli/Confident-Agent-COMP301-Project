def solve(inputs):
    """Update selected fields of a product in DummyJSON and return the product's id."""
    import requests
    
    resource_id = inputs["resource_id"]
    new_price = inputs["new_price"]
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"price": new_price}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    data = response.json()
    
    if "id" in data:
        return data["id"]
    elif response.status_code == 204:
        return None
    else:
        raise Exception(f"Unexpected response for PUT request: {response.status_code}")