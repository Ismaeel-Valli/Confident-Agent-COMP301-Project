def solve(inputs):
    import requests
    
    base_url = "https://dummyjson.com/posts"
    new_body = inputs["new_body"]
    new_title = inputs["new_title"]
    new_user_identifier = inputs["new_user_identifier"]
    
    payload = {
        "body": new_body,
        "title": new_title,
        "userId": new_user_identifier
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create post. Status code: {response.status_code}")
    
    result = response.json()
    
    title = result.get("title")
    if title is None and result.get("posts"):
        return None
    
    return title