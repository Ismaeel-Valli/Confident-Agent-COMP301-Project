import requests

def solve(inputs):
    base_url = "https://dummyjson.com/products/add"
    new_price = inputs["new_price"]
    new_title = inputs["new_title"]

    payload = {
        "title": new_title,
        "price": new_price
    }

    response = requests.post(base_url, json=payload)
    if response.status_code != 201:
        raise Exception(f"Failed to create product: {response.status_code} {response.text}")

    result = response.json()
    return result.get("title")