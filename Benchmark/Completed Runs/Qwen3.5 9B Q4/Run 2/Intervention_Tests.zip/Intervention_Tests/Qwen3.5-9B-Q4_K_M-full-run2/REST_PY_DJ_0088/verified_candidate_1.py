def solve(inputs):
    import requests
    base_url = "https://dummyjson.com/users"
    payload = {
        "age": inputs["new_age"],
        "firstName": inputs["new_firstName"]
    }
    response = requests.post(base_url, json=payload)
    if response.status_code != 201:
        raise Exception(f"Failed to create user: {response.status_code} - {response.text}")
    data = response.json()
    if "user" in data and data["user"] is not None:
        return data["user"]["id"]
    return None