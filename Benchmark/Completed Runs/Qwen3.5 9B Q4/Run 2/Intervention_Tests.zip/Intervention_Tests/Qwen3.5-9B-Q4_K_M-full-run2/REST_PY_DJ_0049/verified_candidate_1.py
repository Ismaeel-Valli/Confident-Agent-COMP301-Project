def solve(inputs):
    """Retrieve one page of users from DummyJSON, skipping specified number of results."""
    import requests
    
    base_url = "https://dummyjson.com/users"
    skip = inputs.get("results_to_skip", 0)
    
    url = f"{base_url}?skip={skip}"
    
    response = requests.get(url)
    response.raise_for_status()
    
    if response.status_code == 200:
        data = response.json()
        return data
    else:
        raise Exception(f"HTTP error {response.status_code}: {response.text}")