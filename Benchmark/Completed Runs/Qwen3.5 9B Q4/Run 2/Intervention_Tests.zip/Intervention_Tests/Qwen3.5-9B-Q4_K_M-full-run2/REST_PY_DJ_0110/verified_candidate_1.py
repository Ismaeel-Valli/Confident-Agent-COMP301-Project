def solve(inputs):
    resource_id = inputs["resource_id"]
    new_user_identifier = inputs["new_user_identifier"]
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    payload = {"userId": new_user_identifier}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    data = response.json()
    if "id" in data:
        return data["id"]
    return None