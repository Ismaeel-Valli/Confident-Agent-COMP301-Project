def solve(inputs):
    """
    Update selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id (int): Identifier of the todo to update.
            - new_completed (bool): New value for the 'completed' attribute.
            - new_todo (str): New value for the 'todo' attribute.
    
    Returns:
        int or None: The response's 'id' value if present, otherwise None.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    import requests
    
    base_url = "https://dummyjson.com"
    url = f"{base_url}/todos/{inputs['resource_id']}"
    
    payload = {
        "completed": inputs["new_completed"],
        "todo": inputs["new_todo"]
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    return response.json().get("id")