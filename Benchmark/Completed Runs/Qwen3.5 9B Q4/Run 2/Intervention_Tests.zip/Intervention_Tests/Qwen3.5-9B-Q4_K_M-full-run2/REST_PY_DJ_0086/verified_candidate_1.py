import requests

def solve(inputs):
    base_url = "https://dummyjson.com/users"
    params = {
        "limit": inputs["result_limit"],
        "skip": inputs["results_to_skip"]
    }
    response = requests.get(base_url, params=params)
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    return response.json()