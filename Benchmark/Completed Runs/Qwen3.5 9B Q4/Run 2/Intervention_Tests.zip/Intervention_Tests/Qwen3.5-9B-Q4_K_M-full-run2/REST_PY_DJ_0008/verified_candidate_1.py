import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    url = "https://dummyjson.com/users/" + str(resource_id)
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        if not data:
            return None
        return data
    else:
        raise Exception(f"HTTP {response.status_code}")