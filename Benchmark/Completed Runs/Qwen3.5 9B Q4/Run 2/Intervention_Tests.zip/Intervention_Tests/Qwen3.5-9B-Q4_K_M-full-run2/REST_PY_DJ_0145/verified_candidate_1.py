import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON.
    
    Args:
        inputs (dict): Contains 'new_firstName' and 'new_username'.
        
    Returns:
        int or None: The response's id value, or None if absent.
                     Returns None for a successful empty response.
                     
    Raises:
        Exception: For an unsuccessful HTTP response.
    """
    base_url = "https://dummyjson.com/users"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "username": inputs["new_username"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. Status code: {response.status_code}")
    
    data = response.json()
    
    if "user" in data and data["user"] is not None:
        return data["user"].get("id")
    else:
        return None