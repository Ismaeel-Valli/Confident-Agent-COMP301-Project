def solve(inputs):
    """
    Retrieve one page of products from DummyJSON with pagination and field filtering.
    
    Args:
        inputs (dict): Dictionary containing:
            - results_to_skip (int): Number of results to skip for pagination.
            - included_fields (str): Comma-separated list of fields to include in the response.
    
    Returns:
        dict or None: Decoded JSON response, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    import requests
    
    base_url = "https://dummyjson.com/products"
    params = {
        "skip": inputs["results_to_skip"],
        "limit": 1,
    }
    
    headers = {"Accept": "application/json"}
    
    response = requests.get(base_url, params=params, headers=headers)
    
    if response.status_code >= 400:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    data = response.json()
    
    if not data.get("products"):
        return None
    
    included_fields = [f.strip() for f in inputs["included_fields"].split(",")]
    
    filtered_products = []
    for product in data["products"]:
        filtered_product = {}
        for field in included_fields:
            if field in product:
                filtered_product[field] = product[field]
        filtered_products.append(filtered_product)
    
    return {"products": filtered_products}