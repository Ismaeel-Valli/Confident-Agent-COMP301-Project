import requests

def solve(inputs):
    """Submit a new user to DummyJSON and return the decoded JSON response."""
    base_url = "https://dummyjson.com/users/add"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "username": inputs["new_username"]
    }
    
    response = requests.post(base_url, json=payload)
    response.raise_for_status()
    
    return response.json()