import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_title = inputs["new_title"]
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"title": new_title}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    data = response.json()
    
    if "id" in data:
        return data["id"]
    elif data.get("statusCode") == 204 or (isinstance(data, dict) and len(data) == 0):
        return None
    else:
        return None