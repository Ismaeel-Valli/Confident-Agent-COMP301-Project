import requests

def solve(inputs):
    """Retrieve one page of users from DummyJSON, respecting result_limit."""
    base_url = "https://dummyjson.com/users"
    params = {"limit": inputs["result_limit"]}
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()
    
    data = response.json()
    
    if not data.get("users"):
        return None
    
    return data["users"]