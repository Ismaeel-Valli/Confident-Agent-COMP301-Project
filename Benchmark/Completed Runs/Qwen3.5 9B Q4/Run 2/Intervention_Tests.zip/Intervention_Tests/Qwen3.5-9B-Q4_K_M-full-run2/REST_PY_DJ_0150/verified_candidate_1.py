import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_brand = inputs["new_brand"]
    
    url = "https://dummyjson.com/products/{id}".format(id=resource_id)
    payload = {"brand": new_brand}
    
    response = requests.patch(url, json=payload)
    response.raise_for_status()
    
    return response.json()