import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_email = inputs["new_email"]
    
    url = "https://dummyjson.com/users/{id}".format(id=resource_id)
    payload = {"email": new_email}
    
    response = requests.patch(url, json=payload)
    response.raise_for_status()
    
    return response.json()