import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_email = inputs["new_email"]
    
    url = "https://dummyjson.com/users/{id}/email".format(id=resource_id)
    payload = {"email": new_email}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    return response.json()