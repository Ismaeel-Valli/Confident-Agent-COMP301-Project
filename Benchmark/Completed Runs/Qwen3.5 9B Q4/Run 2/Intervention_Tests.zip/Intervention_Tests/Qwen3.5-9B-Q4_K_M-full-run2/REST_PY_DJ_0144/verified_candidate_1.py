def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_username = inputs["new_username"]
    
    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {"username": new_username}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        data = response.json()
        return data.get("id")
    elif response.status_code == 201:
        data = response.json()
        return data.get("id")
    else:
        raise Exception(f"HTTP {response.status_code}: {response.text}")