import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_firstName = inputs["new_firstName"]
    
    url = "https://dummyjson.com/users/{id}".format(id=resource_id)
    payload = {"firstName": new_firstName}
    
    response = requests.patch(url, json=payload)
    response.raise_for_status()
    
    return response.json()