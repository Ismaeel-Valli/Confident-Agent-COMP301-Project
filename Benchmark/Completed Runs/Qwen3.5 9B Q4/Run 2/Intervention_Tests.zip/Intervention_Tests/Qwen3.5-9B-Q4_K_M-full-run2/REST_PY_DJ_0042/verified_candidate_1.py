def solve(inputs):
    resource_id = inputs["resource_id"]
    url = "https://dummyjson.com/todos/" + str(resource_id)
    response = requests.delete(url)
    if response.status_code == 200:
        return None
    elif response.status_code == 404:
        data = response.json()
        if "id" in data:
            return data["id"]
        else:
            return None
    else:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")