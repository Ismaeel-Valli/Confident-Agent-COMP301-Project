def solve(inputs):
    resource_id = inputs["resource_id"]
    url = "https://dummyjson.com/todos/" + str(resource_id)
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        if data.get("length") == 0:
            return None
        return data
    else:
        raise Exception(f"HTTP {response.status_code}: {response.text}")