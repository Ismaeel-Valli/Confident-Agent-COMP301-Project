import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_body = inputs["new_body"]
    
    url = "https://dummyjson.com/posts/{id}".format(id=resource_id)
    headers = {"Content-Type": "application/json"}
    payload = {"body": new_body}
    
    response = requests.put(url, json=payload, headers=headers)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    return response.json()