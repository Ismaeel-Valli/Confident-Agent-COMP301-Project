def solve(inputs):
    import requests
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/add"
    headers = {"Content-Type": "application/json"}
    payload = {
        "description": inputs["new_description"],
        "title": inputs["new_title"]
    }
    response = requests.post(url, json=payload, headers=headers)
    if response.status_code != 200:
        raise Exception(f"Failed to add product: {response.text}")
    data = response.json()
    title = data.get("title")
    if title is None and data.get("statusCode") == 200:
        return None
    return title