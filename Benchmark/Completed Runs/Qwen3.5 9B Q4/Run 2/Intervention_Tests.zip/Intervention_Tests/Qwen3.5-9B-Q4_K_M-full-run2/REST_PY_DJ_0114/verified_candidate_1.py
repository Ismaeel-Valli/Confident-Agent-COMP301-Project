def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_price = inputs["new_price"]
    
    url = "https://dummyjson.com/products"
    payload = {"id": resource_id, "price": new_price}
    
    response = requests.patch(url, json=payload)
    response.raise_for_status()
    
    data = response.json()
    
    if data.get("statusCode") == 204:
        return None
    
    title = data.get("title")
    return title