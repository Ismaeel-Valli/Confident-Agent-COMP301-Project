import requests
import json

def solve(inputs):
    """
    Delete a GitHub organization using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): Contains 'organization' (str) and 'credential' (str).
        
    Returns:
        None if successful (empty response), otherwise raises an exception.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    org_name = inputs["organization"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/orgs/{org_name}"
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github.v3+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.delete(url, headers=headers)
    
    if response.status_code not in [204, 200]:
        raise Exception(f"Failed to delete organization: {response.status_code} - {response.text}")
    
    return None