import requests

def solve(inputs):
    """Search products using a search term on DummyJSON."""
    base_url = "https://dummyjson.com/products/search"
    url = f"{base_url}?q={inputs['search_text']}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        
        data = response.json()
        
        if not data.get('products'):
            return None
        
        return data
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")