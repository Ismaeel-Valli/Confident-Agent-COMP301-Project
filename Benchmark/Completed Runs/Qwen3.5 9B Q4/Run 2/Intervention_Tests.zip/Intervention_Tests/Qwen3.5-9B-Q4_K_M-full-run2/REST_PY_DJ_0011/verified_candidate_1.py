import requests

def solve(inputs):
    search_text = inputs["search_text"]
    url = "https://dummyjson.com/users/search"
    params = {"q": search_text}
    response = requests.get(url, params=params)
    response.raise_for_status()
    data = response.json()
    if not data.get("users"):
        return None
    return data["users"]