def solve(inputs):
    import requests
    
    resource_id = inputs.get("resource_id")
    
    url = "https://dummyjson.com/todos/" + str(resource_id)
    
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        if "id" in data:
            return data["id"]
        else:
            return None
    elif response.status_code == 404:
        return None
    else:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")