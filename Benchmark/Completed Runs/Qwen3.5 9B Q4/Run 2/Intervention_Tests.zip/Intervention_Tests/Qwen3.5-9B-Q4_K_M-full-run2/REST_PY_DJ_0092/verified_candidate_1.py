def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_user_identifier = inputs["new_user_identifier"]
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    headers = {
        "Content-Type": "application/json"
    }
    
    payload = {
        "userId": new_user_identifier
    }
    
    response = requests.patch(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    if "id" in data:
        return data["id"]
    elif response.status_code == 204:
        return None
    else:
        return None