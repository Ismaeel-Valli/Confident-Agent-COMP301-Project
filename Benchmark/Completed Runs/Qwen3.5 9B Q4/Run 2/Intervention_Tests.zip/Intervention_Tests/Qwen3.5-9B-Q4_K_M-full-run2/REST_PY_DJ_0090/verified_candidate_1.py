def solve(inputs):
    resource_id = inputs["resource_id"]
    new_body = inputs["new_body"]
    
    url = "https://dummyjson.com/posts/" + str(resource_id)
    payload = {"body": new_body}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    data = response.json()
    
    if "title" in data:
        return data["title"]
    elif data.get("statusCode") == 204 or data.get("status") == 204:
        return None
    else:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")