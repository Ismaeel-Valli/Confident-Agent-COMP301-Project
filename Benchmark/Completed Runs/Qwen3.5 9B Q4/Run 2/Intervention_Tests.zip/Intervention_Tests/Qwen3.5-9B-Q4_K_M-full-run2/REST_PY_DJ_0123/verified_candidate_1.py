def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_category = inputs["new_category"]
    
    url = "https://dummyjson.com/products/{0}".format(resource_id)
    payload = {"category": new_category}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    return response.json() if response.status_code != 204 else None