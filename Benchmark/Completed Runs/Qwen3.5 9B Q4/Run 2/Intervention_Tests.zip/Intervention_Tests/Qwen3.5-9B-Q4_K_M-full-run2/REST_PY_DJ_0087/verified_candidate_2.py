import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_age = inputs["new_age"]
    
    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {"age": new_age}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    data = response.json()
    return data.get("id")