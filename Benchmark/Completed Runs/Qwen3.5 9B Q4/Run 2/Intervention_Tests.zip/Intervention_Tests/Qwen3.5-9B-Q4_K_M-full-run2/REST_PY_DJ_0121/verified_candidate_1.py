def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_todo = inputs["new_todo"]
    new_user_identifier = inputs["new_user_identifier"]
    
    url = "https://dummyjson.com/todos/" + str(resource_id)
    
    payload = {
        "todo": new_todo,
        "userId": new_user_identifier
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    return None