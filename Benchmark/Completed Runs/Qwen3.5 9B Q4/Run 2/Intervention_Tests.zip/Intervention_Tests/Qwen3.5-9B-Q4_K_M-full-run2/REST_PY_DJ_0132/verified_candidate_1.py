def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_category = inputs["new_category"]
    
    url = "https://dummyjson.com/products"
    payload = {
        "id": resource_id,
        "category": new_category
    }
    
    response = requests.patch(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    if "id" in data:
        return data["id"]
    elif response.status_code == 200:
        return None
    else:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")