import requests

def solve(inputs):
    """
    Update selected fields of a product in DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id' (product ID) and 'new_price' (new price value).
        
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/{inputs['resource_id']}"
    
    payload = {
        "price": inputs["new_price"]
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code not in [200, 201]:
        raise Exception(f"Failed to update product: HTTP {response.status_code}")
    
    return response.json()