def solve(inputs):
    """Retrieve a product by identifier from DummyJSON and return its id."""
    import requests
    
    resource_id = inputs["resource_id"]
    url = f"https://dummyjson.com/products/{resource_id}"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON product endpoint returns {"id": ..., "title": ...}
    # If the resource exists, it will have an "id" field.
    # According to instructions: return only the response's id value, or None if that attribute is absent.
    # Also: Return None for a successful empty response.
    
    if data is None:
        return None
    
    if "id" not in data:
        return None
    
    return data["id"]