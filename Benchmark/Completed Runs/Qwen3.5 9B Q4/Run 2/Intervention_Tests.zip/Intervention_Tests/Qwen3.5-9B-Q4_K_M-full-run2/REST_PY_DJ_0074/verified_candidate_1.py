def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_description = inputs["new_description"]
    
    url = "https://dummyjson.com/products/{0}".format(resource_id)
    headers = {"Content-Type": "application/json"}
    payload = {"description": new_description}
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 404:
        return None
    else:
        raise Exception("Failed to update product")