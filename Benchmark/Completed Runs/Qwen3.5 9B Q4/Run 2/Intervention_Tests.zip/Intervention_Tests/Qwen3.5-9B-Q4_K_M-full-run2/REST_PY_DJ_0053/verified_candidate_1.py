import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON, skipping a number of results.
    
    Args:
        inputs (dict): Contains 'results_to_skip' (int) specifying how many results to skip.
        
    Returns:
        dict or None: The decoded JSON response if successful, None for an empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/posts"
    
    params = {
        "skip": inputs["results_to_skip"],
        "limit": 1
    }
    
    try:
        response = requests.get(base_url, params=params)
        
        if response.status_code != 200:
            raise Exception(f"HTTP error: status code {response.status_code}")
        
        data = response.json()
        
        # Check if the response is empty (no posts found)
        if not data.get("posts"):
            return None
        
        return data
    
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")