def solve(inputs):
    import requests
    base_url = "https://dummyjson.com/users"
    payload = {
        "firstName": inputs["new_firstName"],
        "lastName": inputs["new_lastName"]
    }
    response = requests.post(base_url, json=payload)
    if response.status_code != 201:
        raise Exception(f"Failed to create user: {response.status_code} {response.text}")
    data = response.json()
    return None