import requests

def solve(inputs):
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/add"
    
    payload = {
        "description": inputs["new_description"],
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 201:
        data = response.json()
        if "product" in data and "id" in data["product"]:
            return data["product"]["id"]
        else:
            return None
    elif response.status_code == 204:
        return None
    else:
        raise Exception(f"Failed to add product. Status code: {response.status_code}")