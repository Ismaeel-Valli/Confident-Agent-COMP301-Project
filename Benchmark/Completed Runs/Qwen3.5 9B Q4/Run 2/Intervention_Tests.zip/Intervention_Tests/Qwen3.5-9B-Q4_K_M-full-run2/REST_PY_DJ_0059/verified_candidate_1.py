import requests

def solve(inputs):
    """
    Update selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id' (todo ID) and 'new_completed' (boolean).
        
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com"
    resource_id = inputs["resource_id"]
    new_completed = inputs["new_completed"]
    
    url = f"{base_url}/todos/{resource_id}"
    payload = {"completed": new_completed}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 204:
        return None
    else:
        raise Exception(f"Failed to update todo: {response.status_code} - {response.text}")