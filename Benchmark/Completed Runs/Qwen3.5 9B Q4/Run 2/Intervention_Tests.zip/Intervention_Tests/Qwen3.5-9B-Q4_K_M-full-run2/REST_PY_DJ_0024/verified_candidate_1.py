import requests

def solve(inputs):
    result_limit = inputs.get("result_limit")
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}?limit={result_limit}"
    
    response = requests.get(url)
    if response.status_code != 200:
        raise Exception(f"HTTP error {response.status_code}: {response.text}")
    
    data = response.json()
    return data.get("products")