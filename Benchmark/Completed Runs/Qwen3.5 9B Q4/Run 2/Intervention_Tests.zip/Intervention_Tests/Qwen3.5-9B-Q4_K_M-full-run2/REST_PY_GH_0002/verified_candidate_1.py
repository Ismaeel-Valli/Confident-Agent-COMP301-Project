def solve(inputs):
    """
    Update an organization on GitHub using the REST API v2026-03-10.
    
    Args:
        inputs (dict): Contains:
            - organization (str): The organization name to update.
            - new_name (str): The new name for the organization.
            - credential (str): Bearer token for authentication.
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty body.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    import requests
    
    base_url = "https://api.github.com"
    org_name = inputs["organization"]
    new_name = inputs["new_name"]
    credential = inputs["credential"]
    
    url = f"{base_url}/orgs/{org_name}"
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github.v3+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    payload = {"name": new_name}
    
    response = requests.patch(url, json=payload, headers=headers)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    return response.json()