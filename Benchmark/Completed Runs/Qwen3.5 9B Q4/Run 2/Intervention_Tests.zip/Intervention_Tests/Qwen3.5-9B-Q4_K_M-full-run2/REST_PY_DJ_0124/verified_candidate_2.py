import requests

def solve(inputs):
    """Submit a new product to DummyJSON."""
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/add"
    
    payload = {
        "category": inputs["new_category"],
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to submit product: HTTP {response.status_code}")
    
    return None