import requests

def solve(inputs):
    """
    Update selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id (int): Identifier of the todo to update.
            - new_completed (bool): New value for the 'completed' attribute.
            - new_user_identifier (str): New value for the 'userId' attribute.
    
    Returns:
        dict or None: The decoded JSON response, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx).
    """
    base_url = "https://dummyjson.com"
    resource_id = inputs["resource_id"]
    new_completed = inputs["new_completed"]
    new_user_identifier = inputs["new_user_identifier"]
    
    url = f"{base_url}/todos/{resource_id}"
    payload = {
        "completed": new_completed,
        "userId": new_user_identifier
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code not in range(200, 300):
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    return response.json() if response.text else None