import requests

def solve(inputs):
    base_url = "https://dummyjson.com/products/add"
    title = inputs["new_title"]
    
    payload = {"title": title}
    
    response = requests.post(base_url, json=payload)
    response.raise_for_status()
    
    data = response.json()
    
    if "product" in data:
        return data["product"].get("title")
    else:
        return None