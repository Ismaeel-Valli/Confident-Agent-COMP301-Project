import requests
import json

def solve(inputs):
    """
    Create an organization repository on GitHub using the REST API v2026-03-10.
    
    Args:
        inputs (dict): Must contain:
            - "organization": str, the organization name
            - "new_name": str, the name for the new repository
            - "credential": str, the caller-supplied credential (token)
    
    Returns:
        dict or None: The decoded JSON response. Returns None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    base_url = "https://api.github.com"
    organization = inputs["organization"]
    new_name = inputs["new_name"]
    credential = inputs["credential"]
    
    url = f"{base_url}/orgs/{organization}/repos"
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    payload = {
        "name": new_name,
        "private": True
    }
    
    response = requests.post(url, headers=headers, json=payload)
    
    if response.status_code == 201:
        return None
    elif response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Failed to create repository. Status code: {response.status_code}, Response: {response.text}")