import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_age = inputs["new_age"]
    
    url = "https://dummyjson.com/users/{id}/age".format(id=resource_id)
    payload = {"age": new_age}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 404:
        raise Exception(f"Resource not found: {resource_id}")
    else:
        raise Exception(f"Failed to update user: {response.status_code} - {response.text}")