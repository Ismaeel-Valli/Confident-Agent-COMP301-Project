def solve(inputs):
    resource_id = inputs["resource_id"]
    new_category = inputs["new_category"]
    
    url = f"https://dummyjson.com/products/{resource_id}"
    headers = {"Content-Type": "application/json"}
    payload = {"category": new_category}
    
    response = requests.put(url, json=payload, headers=headers)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    data = response.json()
    title = data.get("title")
    return title