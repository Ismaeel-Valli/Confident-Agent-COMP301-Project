import requests

def solve(inputs):
    """
    Submit a new product to DummyJSON and return its id, or None if absent.
    
    Args:
        inputs (dict): Must contain 'new_category' and 'new_title'.
    
    Returns:
        int or None: The product's id if present in the response, else None.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/add"
    
    payload = {
        "category": inputs["new_category"],
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    data = response.json()
    
    return data.get("id")