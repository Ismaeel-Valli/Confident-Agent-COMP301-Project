def solve(inputs):
    import requests
    post_id = inputs["resource_id"]
    url = "https://dummyjson.com/posts/" + str(post_id)
    response = requests.get(url)
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    data = response.json()
    if "id" in data and data["id"] is not None:
        return data["id"]
    return None