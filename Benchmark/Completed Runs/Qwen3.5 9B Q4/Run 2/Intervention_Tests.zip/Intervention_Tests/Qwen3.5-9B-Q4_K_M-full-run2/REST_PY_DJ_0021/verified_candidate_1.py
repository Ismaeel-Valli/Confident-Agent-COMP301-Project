import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_todo = inputs["new_todo"]
    
    url = "https://dummyjson.com/todos"
    payload = {
        "id": resource_id,
        "todo": new_todo
    }
    
    response = requests.patch(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    return response.json()