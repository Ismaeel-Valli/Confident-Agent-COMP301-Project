def solve(inputs):
    import requests
    
    base_url = "https://dummyjson.com"
    
    url = f"{base_url}/todos/new"
    headers = {
        "Content-Type": "application/json",
    }
    
    payload = {
        "completed": inputs["new_completed"],
        "todo": inputs["new_todo"],
        "userId": inputs["new_user_identifier"],
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create todo. Status code: {response.status_code}")
    
    return response.json()