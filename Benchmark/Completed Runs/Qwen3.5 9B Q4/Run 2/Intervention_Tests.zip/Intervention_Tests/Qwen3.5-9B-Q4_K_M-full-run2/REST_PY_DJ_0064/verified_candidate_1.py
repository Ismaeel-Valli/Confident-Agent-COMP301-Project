def solve(inputs):
    """Submit a new product to DummyJSON."""
    import requests
    
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}"
    
    payload = {
        "description": inputs["new_description"],
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create product: HTTP {response.status_code}")
    
    return response.json()