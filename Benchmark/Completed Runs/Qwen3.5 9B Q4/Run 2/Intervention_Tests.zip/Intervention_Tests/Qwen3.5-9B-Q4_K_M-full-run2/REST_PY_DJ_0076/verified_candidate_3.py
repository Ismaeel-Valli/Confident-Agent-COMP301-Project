import requests

def solve(inputs):
    """
    Retrieve one page of users from DummyJSON, sorted by sort_field.
    
    Args:
        inputs (dict): Must contain 'sort_field' key with a string value.
        
    Returns:
        dict or None: Decoded JSON response if successful. Returns None for empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/users"
    
    try:
        response = requests.get(base_url)
        response.raise_for_status()
        
        data = response.json()
        
        # DummyJSON returns a dict with 'users' key and 'total', etc.
        # We return the entire decoded JSON as per "Return the decoded JSON response"
        return data
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")