```python
import requests

def solve(inputs):
    """
    Lists repository tags for a given GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'page_size' (int): Number of results per page (max 100).
            - 'credential' (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        list or None: Decoded JSON response as a list of tags, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    page_size = min(inputs['page_size'], 100)
    credential = inputs['credential']
    
    # Construct the API URL for listing tags
    url = f"https://api.github.com/repos/{owner}/{repo}/tags"
    
    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Add authentication based on credential type (assuming token for simplicity)
    if 'token' in credential:
        headers["Authorization"] = f"Bearer {credential['token']}"
    elif 'username' in credential and 'password' in credential:
        # Basic auth fallback if token is not provided
        import base64
        auth_string = f"{credential['username']}:{credential['password']}"
        encoded_auth = base64.b64encode(auth_string.encode()).decode()
        headers["Authorization"] = f"Basic {encoded_auth}"
    
    # Pagination handling
    page = 1
    all_tags = []
    
    while True:
        params = {"per_page": page_size, "page": page}
        response = requests.get(url, headers=headers, params=params)
        
        if response.status_code != 200:
            raise Exception(f"Failed to fetch tags. Status code: {response.status_code}, Response: {response.text}")
        
        data = response.json()
        
        if not data:
            # Empty response means no more tags or initial empty state
            return None
        
        all_tags.extend(data)
        
        # Check if there are more pages (GitHub uses Link header for pagination info)
        link_header = response.headers.get('Link', '')
        if 'rel="next"' not in link_header:
            break
        
        page += 1
    
    return all_tags
```