import requests
from urllib.parse import quote

def solve(inputs):
    """
    Updates an organization's name via the GitHub REST API (version 2026-03-10).
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The organization name.
            - 'new_name' (str): The new name for the organization.
            - 'credential' (dict): Contains authentication details ('token' and optionally 'base_url').
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response indicates failure (non-2xx status code).
    """
    org = inputs['organization']
    new_name = inputs['new_name']
    credential = inputs['credential']
    
    # Construct the API URL for updating an organization
    # GitHub REST API v2026-03-10 endpoint: PATCH /orgs/{org}
    base_url = credential.get('base_url', 'https://api.github.com')
    token = credential.get('token')
    
    if not token:
        raise ValueError("Token is required in the credential dictionary.")
    
    url = f"{base_url}/orgs/{quote(org)}"
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    payload = {
        "name": new_name
    }
    
    response = requests.patch(url, json=payload, headers=headers)
    
    if response.status_code == 204:
        # Successful update with no content
        return None
    elif response.status_code == 200:
        # Some versions might return JSON even on success
        try:
            return response.json()
        except ValueError:
            return None
    else:
        raise Exception(f"Failed to update organization '{org}'. Status code: {response.status_code}, Response: {response.text}")