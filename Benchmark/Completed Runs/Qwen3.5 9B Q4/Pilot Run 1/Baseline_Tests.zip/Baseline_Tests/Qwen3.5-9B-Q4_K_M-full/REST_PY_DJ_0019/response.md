```python
import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing 'apiKey' and optionally 'page'.
        
    Returns:
        list or None: The decoded JSON response as a list of todos, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response status code indicates an error.
    """
    api_key = inputs.get('apiKey')
    page = inputs.get('page', 1)
    
    url = "https://jsonplaceholder.typicode.com/todos"
    params = {
        'page': page,
        '_token': api_key
    }
    
    response = requests.get(url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error occurred: {response.status_code}")
    
    data = response.json()
    
    return data if len(data) > 0 else None
```