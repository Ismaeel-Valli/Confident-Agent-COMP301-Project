import requests

def solve(inputs):
    """
    Creates a pull request on GitHub using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - new_base (str): Value for the base attribute.
            - new_head (str): Value for the head attribute.
            - new_title (str): Value for the title attribute.
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    new_base = inputs["new_base"]
    new_head = inputs["new_head"]
    new_title = inputs["new_title"]
    credential = inputs["credential"]
    
    # Construct the API URL for creating a pull request
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/pulls"
    
    # Prepare headers with authentication
    headers = {
        "Authorization": f"Bearer {credential['token']}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare the payload for the pull request
    payload = {
        "title": new_title,
        "head": new_head,
        "base": new_base
    }
    
    # Send POST request to create the pull request
    response = requests.post(url, headers=headers, json=payload)
    
    # Check if the response is successful
    if response.status_code == 201:
        return None  # Successful empty response
    elif response.status_code == 202:
        return response.json()  # Accepted, might return JSON with details
    else:
        raise Exception(f"Failed to create pull request. Status code: {response.status_code}, Response: {response.text}")