import requests

def solve(inputs):
    """
    Unfollows a GitHub user using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The handle for the GitHub user account to unfollow.
            - 'credential' (dict): Caller-supplied credentials with necessary permissions.
                Expected structure: {'token': str} or similar auth mechanism supported by requests.
    
    Returns:
        int: The successful HTTP status code (e.g., 204).
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful operation.
    """
    username = inputs['username']
    credential = inputs['credential']
    
    # Construct the URL to unfollow a user
    url = f"https://api.github.com/user/following/{username}"
    
    headers = {
        'Accept': 'application/vnd.github+json'
    }
    
    # Prepare authentication based on common GitHub API patterns (e.g., Bearer token)
    if 'token' in credential:
        headers['Authorization'] = f'Bearer {credential["token"]}'
    
    response = requests.delete(url, headers=headers)
    
    if response.status_code == 204:
        return response.status_code
    else:
        raise Exception(f"Failed to unfollow user '{username}': HTTP {response.status_code}, Response: {response.text}")