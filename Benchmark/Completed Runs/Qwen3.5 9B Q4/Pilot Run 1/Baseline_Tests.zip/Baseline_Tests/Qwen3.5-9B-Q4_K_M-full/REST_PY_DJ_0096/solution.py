import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - included_fields (str): Comma-separated list of fields to include in the response.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"  # Using a reliable placeholder API
    
    limit = inputs.get("result_limit", 10)
    fields = inputs.get("included_fields", "")
    
    # Construct query parameters for included fields if any
    params = {}
    if fields:
        field_list = [f.strip() for f in fields.split(",")]
        params["fields"] = ",".join(field_list)
    
    url = f"{base_url}/users"
    
    response = requests.get(url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # Return None for an empty response
    if not data:
        return None
    
    return data