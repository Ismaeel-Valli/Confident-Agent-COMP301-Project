```python
import requests

def solve(inputs):
    """
    Deletes a GitHub issue comment using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - comment_id (int): The unique identifier of the comment to delete.
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        int: The successful HTTP status code (e.g., 204).
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    comment_id = inputs["comment_id"]
    credential = inputs["credential"]
    
    # Construct the API URL for deleting an issue comment
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/comments/{comment_id}"
    
    # Prepare headers with authentication using the provided credential
    # Assuming 'credential' contains a token under the key 'token' or similar.
    # Adjust based on actual credential structure if needed, but standard is Bearer token.
    auth_header = {
        "Authorization": f"Bearer {credential.get('token', '')}"
    }
    
    response = requests.delete(url, headers=auth_header)
    
    if response.status_code == 204:
        return 204
    else:
        raise Exception(f"Failed to delete issue comment. Status code: {response.status_code}, Response: {response.text}")
```