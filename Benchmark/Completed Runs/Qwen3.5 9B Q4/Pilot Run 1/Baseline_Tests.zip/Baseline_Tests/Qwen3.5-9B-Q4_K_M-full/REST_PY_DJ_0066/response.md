```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON and returns the response's id value,
    or None if that attribute is absent or the response is empty. Raises an exception for unsuccessful HTTP responses.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the user to update.
            - new_lastName (str): New value for the last name attribute.
    
    Returns:
        str or None: The 'id' from the response if present, otherwise None.
    
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful (status code 4xx or 5xx).
    """
    resource_id = inputs.get("resource_id")
    new_lastName = inputs.get("new_lastName")

    url = f"https://dummyjson.com/users/{resource_id}"
    
    payload = {
        "lastName": new_lastName
    }

    response = requests.put(url, json=payload)
    
    if response.status_code >= 400:
        raise requests.RequestException(f"Failed to update user: {response.text}")

    data = response.json()

    # DummyJSON returns the updated user object in the response body on PUT.
    if "user" in data and "id" in data["user"]:
        return data["user"]["id"]
    
    # If the response is empty or does not contain an 'id' field
    return None
```