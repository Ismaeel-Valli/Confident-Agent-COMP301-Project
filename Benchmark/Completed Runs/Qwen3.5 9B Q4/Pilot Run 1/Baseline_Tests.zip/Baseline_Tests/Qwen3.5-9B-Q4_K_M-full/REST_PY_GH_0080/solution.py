import requests

def solve(inputs):
    """
    Creates a label in a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - new_color (str): Value for the color attribute of the label.
            - new_name (str): Value for the name attribute of the label.
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    new_color = inputs["new_color"]
    new_name = inputs["new_name"]
    credential = inputs["credential"]
    
    # Construct the API URL for creating a label
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/labels"
    
    # Prepare headers with authentication
    headers = {
        "Authorization": f"token {credential['token']}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare the payload for creating a label
    data = {
        "name": new_name,
        "color": new_color
    }
    
    # Send POST request to create the label
    response = requests.post(url, headers=headers, json=data)
    
    # Check if the response is successful
    if response.status_code == 201:
        return None  # Successful empty response
    elif response.status_code == 422:
        raise Exception(f"Validation failed: {response.json()}")
    else:
        raise Exception(f"Failed to create label. Status code: {response.status_code}, Response: {response.text}")