import requests

def solve(inputs):
    """
    Updates an organization's description via the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The name of the organization to update.
            - 'new_description' (str): The new description for the organization.
            - 'credential' (dict): Contains authentication details, assumed to have necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    organization = inputs['organization']
    new_description = inputs['new_description']
    credential = inputs['credential']
    
    # Construct the URL for updating an organization
    url = f"https://api.github.com/orgs/{organization}"
    
    # Prepare headers with authentication
    headers = {
        'Authorization': f'token {credential.get("token", "")}',
        'Accept': 'application/vnd.github+json'
    }
    
    # Prepare the payload for updating the organization description
    payload = {
        'description': new_description
    }
    
    # Make the PUT request to update the organization
    response = requests.put(url, headers=headers, json=payload)
    
    # Check if the response is successful
    if response.status_code == 200:
        return response.json() if response.text else None
    elif response.status_code == 404:
        raise Exception(f"Organization '{organization}' not found.")
    elif response.status_code == 403:
        raise Exception("Access forbidden. Please check your credentials and permissions.")
    else:
        raise Exception(f"Failed to update organization description. Status code: {response.status_code}, Response: {response.text}")