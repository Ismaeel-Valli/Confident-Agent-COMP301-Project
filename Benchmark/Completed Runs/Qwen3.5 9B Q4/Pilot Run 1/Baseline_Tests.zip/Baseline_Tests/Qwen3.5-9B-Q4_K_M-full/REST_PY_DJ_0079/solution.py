import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on the provided sort field.
    
    Args:
        inputs (dict): A dictionary containing 'sort_field' for ordering posts.
        
    Returns:
        dict or None: The decoded JSON response if successful, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    sort_field = inputs.get("sort_field")
    
    # Construct the URL with query parameters for sorting and limiting to one page (10 items)
    url = f"{base_url}?_limit=10&_sort={sort_field}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        data = response.json()
        
        # Return None if the response is empty (though DummyJSON typically returns a list of posts)
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Failed to retrieve posts: {str(e)}")