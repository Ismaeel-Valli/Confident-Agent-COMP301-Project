import requests

def solve(inputs):
    resource_id = inputs.get("resource_id")
    
    # Assuming a base URL; adjust as needed for DummyJSON or your environment
    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.delete(url)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        if response.status_code == 200 and not response.text.strip():
            return None
        
        data = response.json()
        
        # Return the 'title' value if present, otherwise None
        return data.get("title")
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")