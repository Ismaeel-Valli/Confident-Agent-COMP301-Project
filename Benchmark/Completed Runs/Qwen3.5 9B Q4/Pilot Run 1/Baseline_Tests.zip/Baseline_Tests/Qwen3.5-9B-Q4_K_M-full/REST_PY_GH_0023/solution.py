import requests

def solve(inputs):
    """
    Lists issue comments for a given GitHub repository and issue using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'issue_number' (int): The issue number.
            - 'credential' (str): The caller-supplied credential (e.g., Bearer token or API key).
    
    Returns:
        list | None: A list of decoded JSON response items if comments exist, otherwise None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/issues/{issue_number}/comments"
    
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "Authorization": f"Bearer {credential}"
    }

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        data = response.json()
        return None if not data else data
    elif response.status_code >= 400:
        raise Exception(f"GitHub API request failed with status code {response.status_code}: {response.text}")
    else:
        raise Exception(f"Unexpected response from GitHub API: {response.status_code}")