import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the todo to update.
            - new_user_identifier (str): New value for the user Id attribute.
    
    Returns:
        None if the response is empty (success).
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    resource_id = inputs.get("resource_id")
    new_user_identifier = inputs.get("new_user_identifier")

    if not resource_id or not new_user_identifier:
        raise ValueError("Missing required fields in inputs.")

    url = f"https://dummyjson.com/todos/{resource_id}"
    payload = {"userId": new_user_identifier}

    response = requests.put(url, json=payload)

    if response.status_code != 200:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}, Response: {response.text}")

    return None