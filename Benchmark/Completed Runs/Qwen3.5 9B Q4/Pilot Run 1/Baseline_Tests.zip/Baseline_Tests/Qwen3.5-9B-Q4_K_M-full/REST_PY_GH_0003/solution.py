import requests

def solve(inputs):
    """
    Deletes an organization using the GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The name of the organization to delete.
            - 'credential' (str): The caller-supplied credential (e.g., token) for authentication.
    
    Returns:
        None if the deletion is successful (empty response).
        The decoded JSON response if an error occurs.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    organization = inputs['organization']
    credential = inputs['credential']
    
    # GitHub API endpoint for deleting an organization
    url = f"https://api.github.com/orgs/{organization}"
    
    headers = {
        'Accept': 'application/vnd.github+json',
        'Authorization': f'token {credential}'
    }
    
    response = requests.delete(url, headers=headers)
    
    if response.status_code == 204:
        # Successful deletion with empty response body
        return None
    
    elif response.status_code >= 400:
        # Unsuccessful response; decode and raise exception
        try:
            error_data = response.json()
        except ValueError:
            error_data = {"error": "Failed to decode JSON response"}
        
        raise Exception(f"GitHub API Error ({response.status_code}): {error_data}")
    
    else:
        # Handle unexpected status codes
        raise Exception(f"Unexpected HTTP status code: {response.status_code}")