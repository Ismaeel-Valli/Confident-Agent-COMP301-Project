```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_title' (new title value).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_title = inputs['new_title']
    
    # Construct the URL (assuming standard DummyJSON base URL)
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    # Prepare the payload for PATCH request
    payload = {
        "title": new_title
    }
    
    # Send the PATCH request
    response = requests.patch(url, json=payload)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Check if the response is empty (204 No Content or similar)
    if not response.text:
        return None
    
    # Try to extract the 'id' from the response JSON
    try:
        data = response.json()
        return data.get('id')
    except ValueError:
        # If response is not JSON, return None as per successful empty response handling
        return None
```