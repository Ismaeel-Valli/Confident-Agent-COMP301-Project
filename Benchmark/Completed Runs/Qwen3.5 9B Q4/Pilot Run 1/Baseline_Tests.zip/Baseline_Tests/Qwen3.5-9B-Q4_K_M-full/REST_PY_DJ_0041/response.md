```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON and returns the response's id value,
    or None if that attribute is absent or the response is empty (successful).
    Raises an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the todo to update.
            - new_todo (any): New value for the todo attribute.
    
    Returns:
        str or None: The 'id' from the JSON response, or None if absent or empty response.
    
    Raises:
        Exception: If the HTTP response status code indicates failure.
    """
    resource_id = inputs['resource_id']
    new_todo = inputs['new_todo']
    
    # DummyJSON API endpoint for updating a todo
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    payload = {
        "todo": new_todo
    }
    
    response = requests.patch(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}")
    
    data = response.json()
    
    # Check if 'id' is present in the response
    if 'id' in data and data['id'] is not None:
        return data['id']
    else:
        return None
```