```python
import requests

def solve(inputs):
    """
    Updates the name of a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner': str, the account owner of the repository.
            - 'repository_name': str, the current name of the repository (without .git).
            - 'new_name': str, the new name for the repository.
            - 'credential': dict, caller-supplied credential with necessary permissions.
    
    Returns:
        None if the response is empty (success), or the decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    new_name = inputs["new_name"]
    credential = inputs["credential"]

    # Construct the API URL for renaming a repository
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}"

    headers = {
        "Authorization": f"token {credential.get('token', '')}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    payload = {
        "name": new_name
    }

    response = requests.put(url, json=payload, headers=headers)

    if response.status_code == 200:
        # GitHub typically returns an empty body for this operation
        return None
    elif response.status_code >= 400:
        raise Exception(f"Failed to update repository name. Status code: {response.status_code}, Response: {response.text}")
    else:
        # Handle unexpected success codes if necessary, but per spec we assume only 200 or error
        return None

# Note: Do not execute the function above.
```