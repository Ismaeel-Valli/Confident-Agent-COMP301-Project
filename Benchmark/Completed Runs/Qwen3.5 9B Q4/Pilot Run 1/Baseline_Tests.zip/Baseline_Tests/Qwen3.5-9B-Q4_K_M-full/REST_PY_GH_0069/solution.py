import requests
from urllib.parse import quote_plus

def solve(inputs):
    """
    Updates a GitHub repository's description using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - new_description (str): The new description for the repository.
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo_name = inputs["repository_name"]
    new_description = inputs["new_description"]
    credential = inputs["credential"]

    # Construct the API URL for updating repository description
    url = f"https://api.github.com/repos/{quote_plus(owner)}/{quote_plus(repo_name)}"
    
    # Prepare headers with authentication
    headers = {
        "Authorization": f"Bearer {credential['token']}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Prepare the payload
    payload = {
        "description": new_description
    }

    try:
        response = requests.put(url, headers=headers, json=payload)
        
        if response.status_code == 200 or response.status_code == 204:
            return response.json() if response.content else None
        else:
            raise Exception(f"Failed to update repository description. Status code: {response.status_code}, Response: {response.text}")
    
    except requests.exceptions.RequestException as e:
        raise Exception(f"An error occurred while making the request: {str(e)}")