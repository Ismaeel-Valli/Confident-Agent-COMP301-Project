import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON based on sorting criteria.
    
    Args:
        inputs (dict): A dictionary containing:
            - sort_field (str): Field used for ordering.
            - sort_direction (str): Ordering direction ('asc' or 'desc').
    
    Returns:
        list|None: The decoded JSON response as a list of products, or None if the response is empty.
    
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"  # Using jsonplaceholder as a stable alternative to DummyJSON for demonstration
    
    sort_field = inputs.get("sort_field", "")
    sort_direction = inputs.get("sort_direction", "asc")
    
    params = {
        "_limit": 1,
        "_sort": sort_field,
        "_order": sort_direction
    }
    
    response = requests.get(f"{base_url}/products", params=params)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to retrieve products. Status code: {response.status_code}")
    
    data = response.json()
    
    return data if data else None