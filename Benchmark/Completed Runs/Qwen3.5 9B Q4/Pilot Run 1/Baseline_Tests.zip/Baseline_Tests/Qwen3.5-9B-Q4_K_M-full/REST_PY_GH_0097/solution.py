import requests
import json

def solve(inputs):
    """
    Creates a repository for the authenticated user using GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'new_name': str, value for the name attribute of the new repository.
            - 'new_description': str, value for the description attribute of the new repository.
            - 'credential': dict, containing authentication details (e.g., token and user info).
    
    Returns:
        None if the response is successfully empty (201 Created with no body or minimal body),
        otherwise returns the decoded JSON response.
    
    Raises:
        Exception for unsuccessful HTTP responses (non-2xx status codes).
    """
    new_name = inputs["new_name"]
    new_description = inputs["new_description"]
    credential = inputs["credential"]

    # Construct the API URL for creating a repository for the authenticated user
    # Assuming GitHub REST API version 2026-03-10, the endpoint is typically:
    # https://api.github.com/user/repos
    url = "https://api.github.com/user/repos"

    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10",
        "Authorization": f"Bearer {credential.get('token', '')}"
    }

    data = {
        "name": new_name,
        "description": new_description
    }

    response = requests.post(url, headers=headers, json=data)

    if response.status_code == 201:
        # GitHub typically returns a JSON object with the repository details on creation
        # However, per instructions, return None for a successful empty response.
        # If the response body is empty or minimal and we consider it "empty", return None.
        # But standard GitHub API returns a full repo object. We'll decode it unless it's truly empty.
        if not response.text.strip():
            return None
        return response.json()
    else:
        raise Exception(f"Failed to create repository. Status code: {response.status_code}, Response: {response.text}")