```python
import requests

def solve(inputs):
    """
    Fetches the latest release from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The caller-supplied credential (e.g., token or Bearer string).
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{owner}/{repo}/releases/latest"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        data = response.json()
        return data if data else None
    elif response.status_code in (401, 403):
        raise Exception(f"Authentication failed for {url}. Status: {response.status_code}")
    else:
        raise Exception(f"Failed to fetch latest release. Status: {response.status_code}, Body: {response.text}")
```