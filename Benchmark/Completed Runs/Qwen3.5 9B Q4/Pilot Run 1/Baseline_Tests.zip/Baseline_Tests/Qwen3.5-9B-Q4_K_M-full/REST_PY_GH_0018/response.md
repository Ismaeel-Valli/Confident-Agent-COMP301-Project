```python
import requests

def solve(inputs):
    """
    Fetches a specific issue comment from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'comment_id' (int): The unique identifier of the comment.
            - 'credential' (dict): Caller-supplied credential dict containing 'token'.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty (204 No Content).
    
    Raises:
        Exception: If the HTTP response status code indicates an error.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    comment_id = inputs["comment_id"]
    token = inputs["credential"]["token"]

    url = f"https://api.github.com/repos/{owner}/{repo}/issues/comments/{comment_id}"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {token}",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    response = requests.get(url, headers=headers)
    
    if response.status_code == 204:
        return None
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch issue comment. Status code: {response.status_code}, Response: {response.text}")

    return response.json()
```