```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the product to update.
            - new_title (str): New value for the 'title' attribute.
    
    Returns:
        None if the HTTP response is successful and empty.
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response indicates an error (status code >= 400).
    """
    resource_id = inputs.get('resource_id')
    new_title = inputs.get('new_title')
    
    if not resource_id or not new_title:
        raise ValueError("Missing required fields: 'resource_id' and 'new_title'.")

    url = f"https://httpbin.org/put"
    payload = {
        "resource_id": resource_id,
        "title": new_title
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to update product. Status code: {response.status_code}, Response: {response.text}")
    
    return None if response.text == "" else response.json()
```