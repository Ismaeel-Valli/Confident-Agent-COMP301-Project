import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON and returns the title value from the response,
    or None if the title attribute is absent or the response is successfully empty.
    Raises an exception for unsuccessful HTTP responses.

    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the product.
            - new_title (str): New value for the title attribute.

    Returns:
        str or None: The updated title from the response, or None if absent or empty response.

    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    resource_id = inputs.get("resource_id")
    new_title = inputs.get("new_title")

    url = f"https://httpbin.org/put"
    payload = {
        "resource_id": resource_id,
        "title": new_title
    }

    response = requests.put(url, json=payload)

    if response.status_code >= 400:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")

    # DummyJSON typically returns the updated object or an empty response on success.
    data = response.json()

    title = data.get("title")
    if title is None and not data:
        return None

    return title