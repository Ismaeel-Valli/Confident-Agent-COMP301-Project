import requests

def solve(inputs):
    """
    Updates a milestone in a GitHub repository using the REST API.
    
    Parameters:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - milestone_number (int): The number identifying the milestone.
            - new_state (str): The new state for the milestone ('open' or 'closed').
            - credential (dict): Caller-supplied credentials (e.g., token in 'token' key).
    
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    milestone_number = inputs["milestone_number"]
    new_state = inputs["new_state"]
    credential = inputs["credential"]

    # Construct the API URL for updating a milestone
    url = f"https://api.github.com/repos/{owner}/{repo}/milestones/{milestone_number}"

    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Prepare the payload
    payload = {"state": new_state}

    # Extract token from credential (assuming structure like {'token': 'ghx_...'})
    auth_token = credential.get("token")

    if not auth_token:
        raise ValueError("Credential must contain a 'token' key.")

    headers["Authorization"] = f"Bearer {auth_token}"

    response = requests.put(url, json=payload, headers=headers)

    # Raise an exception for unsuccessful HTTP responses (non-2xx)
    response.raise_for_status()

    # Return decoded JSON response; return None if the response body is empty
    data = response.json()
    return data if data else None