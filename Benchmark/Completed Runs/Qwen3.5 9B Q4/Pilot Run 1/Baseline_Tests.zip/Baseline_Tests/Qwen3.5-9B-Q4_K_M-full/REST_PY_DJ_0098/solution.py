import requests
import json

def solve(inputs):
    """
    Submits a new user to DummyJSON using the provided email and first name.
    
    Args:
        inputs (dict): A dictionary containing 'new_email' and 'new_firstName'.
        
    Returns:
        None if the response is empty (successful submission).
        The decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "email": inputs['new_email'],
        "firstName": inputs['new_firstName']
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. HTTP Status Code: {response.status_code}")
    
    # DummyJSON typically returns an empty body for POST requests on /users
    if not response.text.strip():
        return None
    
    return response.json()