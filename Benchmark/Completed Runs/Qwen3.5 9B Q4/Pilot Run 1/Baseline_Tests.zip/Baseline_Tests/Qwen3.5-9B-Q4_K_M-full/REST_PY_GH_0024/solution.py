import requests

def solve(inputs):
    """
    Creates an issue comment on a GitHub repository using the specified inputs.
    
    Parameters:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository without the .git extension.
            - 'issue_number' (int): The number that identifies the issue.
            - 'new_body' (str): The content of the new comment.
            - 'credential' (dict): A dictionary containing authentication details, 
                                  expected to have keys like 'token' or 'username' and 'password'.
    
    Returns:
        dict or None: The decoded JSON response from GitHub if successful but with data, 
                      or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    
    # Construct the API URL for creating an issue comment
    # Format: https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}/comments
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    issue_number = inputs['issue_number']
    new_body = inputs['new_body']
    
    # Prepare credentials (assuming token-based auth for simplicity, but can be adapted)
    credential = inputs['credential']
    
    # Determine authentication method based on available keys in credential
    if 'token' in credential:
        headers = {
            'Authorization': f'token {credential["token"]}',
            'Accept': 'application/vnd.github+json',
            'X-GitHub-Api-Version': '2026-03-10'
        }
    elif 'username' in credential and 'password' in credential:
        headers = {
            'Accept': 'application/vnd.github+json',
            'X-GitHub-Api-Version': '2026-03-10'
        }
        # Note: Basic auth is handled by requests, but we must ensure no conflicting Authorization header
    else:
        raise ValueError("Credential must contain either 'token' or both 'username' and 'password'.")

    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}/comments"
    
    payload = {
        "body": new_body
    }
    
    try:
        response = requests.post(url, headers=headers, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (non-2xx status codes)
        response.raise_for_status()
        
        # Return the decoded JSON response
        if response.text.strip():
            return response.json()
        else:
            return None
            
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Failed to create issue comment: {e}")