```python
import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    new_category = inputs['new_category']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    headers = {
        "Content-Type": "application/json"
    }
    payload = {
        "category": new_category
    }
    
    response = requests.patch(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    if 'title' in data and data['title'] is not None:
        return data['title']
    elif data.get('statusCode') == 204 or (not data and response.status_code == 204):
        return None
    else:
        return None
```