```python
import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON, skipping a specified number of results.

    Args:
        inputs (dict): A dictionary containing 'results_to_skip' (int).

    Returns:
        dict or None: The decoded JSON response if successful and data exists, 
                      None if the response is successfully empty.

    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    results_to_skip = inputs.get('results_to_skip', 0)
    
    # DummyJSON endpoint to get products with pagination
    url = f"https://jsonplaceholder.typicode.com/posts?skip={results_to_skip}"

    try:
        response = requests.get(url)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        if response.status_code == 200:
            data = response.json()
            return data if data else None
        else:
            raise Exception(f"Unexpected status code: {response.status_code}")

    except requests.exceptions.RequestException as e:
        raise Exception(f"HTTP request failed: {e}")
```