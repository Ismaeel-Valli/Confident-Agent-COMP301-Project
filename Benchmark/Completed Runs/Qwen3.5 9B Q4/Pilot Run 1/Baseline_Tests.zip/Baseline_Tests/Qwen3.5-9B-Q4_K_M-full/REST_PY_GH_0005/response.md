```python
import requests
import json

def solve(inputs):
    """
    Creates an organization repository on GitHub using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization': The name of the organization.
            - 'new_name': The desired name for the new repository.
            - 'credential': A dictionary with authentication details (e.g., token).
    
    Returns:
        dict or None: The decoded JSON response if successful (empty body returns None),
                      or raises an exception on failure.
    
    Raises:
        requests.exceptions.HTTPError: If the HTTP status code indicates an error.
    """
    org = inputs['organization']
    repo_name = inputs['new_name']
    credential = inputs['credential']
    
    # Construct the API URL for creating a repository in an organization
    # Format: https://api.github.com/orgs/{org}/repos
    url = f"https://api.github.com/orgs/{org}/repos"
    
    # Prepare headers with authentication using the provided credential
    # Assuming 'credential' contains a 'token' key for Bearer authentication
    headers = {
        "Authorization": f"Bearer {credential.get('token', '')}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Payload for creating the repository
    payload = {
        "name": repo_name
    }
    
    response = requests.post(url, headers=headers, json=payload)
    
    if response.status_code == 201:
        # GitHub typically returns an empty body for successful creation of repos
        return None
    elif response.status_code in [400, 403, 404, 422]:
        raise Exception(f"Failed to create repository. Status code: {response.status_code}, Response: {response.text}")
    else:
        # Handle other unexpected errors
        raise Exception(f"Unexpected error creating repository. Status code: {response.status_code}, Response: {response.text}")

# Note: Do not execute the function above; it is ready to be called with appropriate inputs.
```