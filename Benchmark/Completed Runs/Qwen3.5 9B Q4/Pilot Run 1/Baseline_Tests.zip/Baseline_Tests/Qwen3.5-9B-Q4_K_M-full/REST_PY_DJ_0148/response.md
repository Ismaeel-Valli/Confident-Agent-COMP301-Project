```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON and returns the response's id value,
    or None if that attribute is absent or for a successful empty response.
    Raises an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the todo to update.
            - new_completed (bool/None): New value for the completed attribute.
            - new_user_identifier (str/None): New value for the user Id attribute.
    
    Returns:
        str or None: The ID from the response if present, otherwise None.
    
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"  # Using standard placeholder for demo; replace with DummyJSON endpoint if different
    
    resource_id = inputs.get("resource_id")
    new_completed = inputs.get("new_completed")
    new_user_identifier = inputs.get("new_user_identifier")
    
    payload = {}
    if new_completed is not None:
        payload["completed"] = new_completed
    if new_user_identifier is not None:
        payload["userId"] = new_user_identifier
    
    url = f"{base_url}/todos/{resource_id}"
    
    try:
        response = requests.put(url, json=payload)
        response.raise_for_status()
        
        # Check if the response has an 'id' field
        if "id" in response.json():
            return response.json()["id"]
        else:
            return None
            
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```