```python
import requests

def solve(inputs):
    """
    Lists followers of a GitHub user using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The handle for the GitHub user account.
            - 'page_size' (int): The number of results per page (max 100).
            - 'credential' (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response, or None if the response is empty but successful.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    username = inputs['username']
    page_size = inputs['page_size']
    credential = inputs['credential']
    
    url = f"https://api.github.com/users/{username}/followers"
    headers = {
        'Accept': 'application/vnd.github+json'
    }
    
    # Prepare authentication based on common GitHub API patterns (e.g., Bearer token or Basic Auth)
    if 'token' in credential:
        headers['Authorization'] = f'Bearer {credential["token"]}'
    elif 'username' in credential and 'password' in credential:
        auth = requests.auth.HTTPBasicAuth(credential['username'], credential['password'])
    else:
        raise ValueError("Invalid credential format. Expected 'token' or ('username', 'password').")

    params = {'per_page': page_size}
    
    response = requests.get(url, headers=headers, auth=auth if 'username' in credential and 'password' in credential else None, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch followers: HTTP {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response (GitHub returns an empty list [])
    if not data:
        return None
    
    return data
```