import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    headers = {
        "Accept": "application/json"
    }
    
    response = requests.delete(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to delete product. Status code: {response.status_code}, Response: {response.text}")
    
    return None