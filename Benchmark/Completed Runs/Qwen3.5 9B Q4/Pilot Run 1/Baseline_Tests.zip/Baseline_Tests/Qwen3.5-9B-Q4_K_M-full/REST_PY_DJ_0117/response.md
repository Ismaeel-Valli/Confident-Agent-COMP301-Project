```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the user.
            - new_phone (str): New value for the phone attribute.
    
    Returns:
        None if the response is empty (successful update).
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    resource_id = inputs.get("resource_id")
    new_phone = inputs.get("new_phone")

    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {"phone": new_phone}

    response = requests.patch(url, json=payload)

    if response.status_code != 200:
        raise Exception(f"Failed to update user: {response.text}")

    return None
```