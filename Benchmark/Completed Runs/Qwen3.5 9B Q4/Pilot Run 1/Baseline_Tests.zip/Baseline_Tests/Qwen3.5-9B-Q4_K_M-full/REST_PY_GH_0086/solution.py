import requests

def solve(inputs):
    """
    Creates a pull request on GitHub using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - new_base (str): Value for the base attribute.
            - new_body (str): Value for the body attribute.
            - new_head (str): Value for the head attribute.
            - new_title (str): Value for the title attribute.
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response, or None if the response is empty on success.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    new_base = inputs["new_base"]
    new_body = inputs["new_body"]
    new_head = inputs["new_head"]
    new_title = inputs["new_title"]
    credential = inputs["credential"]

    # Construct the API URL for creating a pull request
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/pulls"

    # Prepare the payload for the pull request
    payload = {
        "title": new_title,
        "body": new_body,
        "head": new_head,
        "base": new_base
    }

    # Prepare headers with authentication
    headers = {
        "Authorization": f"token {credential.get('token', '')}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Send the POST request to create the pull request
    response = requests.post(url, json=payload, headers=headers)

    # Check if the response is successful (status code 201 Created)
    if response.status_code == 201:
        return None  # Return None for a successful empty response
    elif response.status_code == 422:
        # Handle validation errors by raising an exception with the error details
        raise Exception(f"Validation Error: {response.json()}")
    else:
        # Raise an exception for any other unsuccessful HTTP response
        raise Exception(f"Failed to create pull request. Status code: {response.status_code}, Response: {response.text}")