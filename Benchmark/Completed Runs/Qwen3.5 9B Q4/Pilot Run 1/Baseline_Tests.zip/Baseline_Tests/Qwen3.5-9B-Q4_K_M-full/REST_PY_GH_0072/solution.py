import requests

def solve(inputs):
    """
    Fetches a specific commit from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'page' (int): The page number of results to fetch (unused for single commit but included per spec).
            - 'ref' (str): The commit reference (e.g., branch, tag, or SHA).
            - 'credential' (str): The authentication token or header value.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    page = inputs['page']  # Note: Single commit endpoint doesn't use pagination, but we accept it.
    ref = inputs['ref']
    credential = inputs['credential']

    url = f"https://api.github.com/repos/{owner}/{repo}/commits/{ref}"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }

    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        raise Exception(f"Failed to fetch commit. Status code: {response.status_code}, Response: {response.text}")

    data = response.json()
    
    # Return None for a successful empty response (though unlikely for a commit endpoint)
    if not data:
        return None
        
    return data