```python
import requests

def solve(inputs):
    """
    Lists repository issues for GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner': str, the account owner of the repository.
            - 'repository_name': str, the name of the repository (without .git).
            - 'credential': dict, caller-supplied credential with necessary permissions.
    
    Returns:
        list or None: Decoded JSON response as a list of issues, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code 4xx or 5xx).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    credential = inputs['credential']
    
    # Construct the API URL for listing issues
    url = f"https://api.github.com/repos/{owner}/{repo}/issues"
    
    # Prepare headers with authentication using the provided credential
    # Assuming 'credential' contains a token under the key 'token' or similar.
    # Adjust based on actual credential structure if different (e.g., username/password).
    auth_header = {
        "Authorization": f"Bearer {credential.get('token', '')}"
    }
    
    response = requests.get(url, headers=auth_header)
    
    if response.status_code >= 400:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response
    if not data:
        return None
    
    return data
```