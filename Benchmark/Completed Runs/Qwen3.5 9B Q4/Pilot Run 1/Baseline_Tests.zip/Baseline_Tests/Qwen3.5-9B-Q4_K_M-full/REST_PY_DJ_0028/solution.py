import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API using the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'new_title' for the product title.
        
    Returns:
        int or None: The response's id value if present, otherwise None for successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    # Prepare the payload with the new title
    payload = {
        "title": inputs.get("new_title")
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.post(url, json=payload, headers=headers)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (successful but no data returned)
        if not response.text.strip():
            return None
        
        # Return the id from the response, or None if absent
        return response.json().get("id")
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")