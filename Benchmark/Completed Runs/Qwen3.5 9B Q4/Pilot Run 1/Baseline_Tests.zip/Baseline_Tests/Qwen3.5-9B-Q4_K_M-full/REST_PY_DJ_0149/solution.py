import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip (for pagination).
            - included_fields (str): Comma-separated list of fields to include in the response.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    # Construct the API URL with query parameters
    base_url = "https://jsonplaceholder.typicode.com"  # Using a common placeholder service for demonstration
    
    # Note: DummyJSON typically uses /products endpoint but doesn't support filtering/sorting via query params in the same way as JSONPlaceholder.
    # However, since the problem specifies 'DummyJSON', we will assume it behaves similarly to standard REST APIs that accept these parameters.
    # If DummyJSON is a specific service with different behavior, adjust accordingly.
    
    url = f"{base_url}/products"
    
    params = {
        "limit": inputs["result_limit"],
        "skip": inputs["results_to_skip"]
    }
    
    # Parse included_fields into a list if needed, but DummyJSON might expect a comma-separated string or specific format.
    # Assuming the API accepts a comma-separated string for fields as per common practices.
    headers = {
        "Accept": "application/json"
    }
    
    response = requests.get(url, params=params, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # If the response is empty (e.g., no products found), return None
    if not data or len(data) == 0:
        return None
    
    # Filter the included fields if necessary. 
    # Note: DummyJSON might automatically handle this, but we'll implement it here for completeness.
    if inputs["included_fields"]:
        fields_list = [f.strip() for f in inputs["included_fields"].split(",")]
        filtered_data = []
        for item in data:
            filtered_item = {key: value for key, value in item.items() if key in fields_list}
            filtered_data.append(filtered_item)
        return filtered_data
    
    return data