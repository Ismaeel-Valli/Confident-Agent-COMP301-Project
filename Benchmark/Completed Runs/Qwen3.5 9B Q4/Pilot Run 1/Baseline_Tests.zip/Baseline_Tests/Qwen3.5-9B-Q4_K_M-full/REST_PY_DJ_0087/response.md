```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_age' (new age value).
        
    Returns:
        int or None: The response's id value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_age = inputs['new_age']
    
    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {"age": new_age}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    # DummyJSON returns the updated user object on PUT request
    data = response.json()
    
    return data.get('id')
```