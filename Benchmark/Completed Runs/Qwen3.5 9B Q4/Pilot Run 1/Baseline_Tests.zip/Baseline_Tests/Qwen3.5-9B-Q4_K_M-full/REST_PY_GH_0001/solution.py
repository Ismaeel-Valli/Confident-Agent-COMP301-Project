import requests

def solve(inputs):
    """
    Fetches an organization from the GitHub REST API (version 2026-03-10).
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The name of the organization.
            - 'credential' (str): The authentication token or header value.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response indicates failure (non-2xx status).
    """
    org_name = inputs['organization']
    credential = inputs['credential']
    
    # GitHub REST API endpoint for getting an organization
    url = f"https://api.github.com/orgs/{org_name}"
    
    headers = {
        'Accept': 'application/vnd.github+json',
        'Authorization': f'Bearer {credential}'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        return None if not data else data
    elif response.status_code == 404:
        raise Exception(f"Organization '{org_name}' not found.")
    else:
        raise Exception(f"Failed to fetch organization: HTTP {response.status_code}, Body: {response.text}")