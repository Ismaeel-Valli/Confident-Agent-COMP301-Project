```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON with provided age and first name.
    
    Args:
        inputs (dict): Dictionary containing 'new_age' and 'new_firstName'.
        
    Returns:
        int or None: The ID of the newly created user, or None if response is empty.
        
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "name": inputs.get("new_firstName"),
        "age": inputs.get("new_age")
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code != 201:
            raise Exception(f"Failed to create user. Status code: {response.status_code}")
            
        data = response.json()
        
        # If the response contains an 'id' field, return it
        if "id" in data:
            return data["id"]
        else:
            # Return None for a successful empty response (though unlikely with this API)
            return None
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```