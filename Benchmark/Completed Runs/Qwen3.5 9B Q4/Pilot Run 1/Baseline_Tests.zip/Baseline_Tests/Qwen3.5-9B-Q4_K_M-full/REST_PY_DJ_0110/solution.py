import requests

def solve(inputs):
    """
    Updates selected fields of a post in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_user_identifier' (new user ID).
        
    Returns:
        str or None: The response's 'id' value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    resource_id = inputs['resource_id']
    new_user_identifier = inputs['new_user_identifier']
    
    # Construct the update payload
    payload = {
        "user": new_user_identifier
    }
    
    # Make the PUT request to DummyJSON API
    response = requests.put(f"https://jsonplaceholder.typicode.com/posts/{resource_id}", json=payload)
    
    # Check for unsuccessful HTTP response
    if response.status_code >= 400:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    # Return the id if present, otherwise None
    return response.json().get('id')