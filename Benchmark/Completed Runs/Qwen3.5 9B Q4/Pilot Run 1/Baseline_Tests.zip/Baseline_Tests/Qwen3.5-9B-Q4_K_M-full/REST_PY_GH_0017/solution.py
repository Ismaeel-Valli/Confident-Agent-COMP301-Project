import requests
from urllib.parse import quote_plus

def solve(inputs):
    """
    Creates a new issue in a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner': str, The account owner of the repository.
            - 'repository_name': str, The name of the repository without the .git extension.
            - 'new_title': str, The value for the title attribute of the new issue.
            - 'credential': dict, Caller-supplied credential (assumed to have necessary permissions).
    
    Returns:
        None if the response is empty (successful creation), otherwise returns the decoded JSON response.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    title = inputs['new_title']
    credential = inputs['credential']
    
    # Construct the URL for creating a new issue
    url = f"https://api.github.com/repos/{quote_plus(owner)}/{quote_plus(repo)}/issues"
    
    headers = {
        'Accept': 'application/vnd.github.v3+json'
    }
    
    # Prepare the payload for the new issue
    data = {
        'title': title
    }
    
    # Make the POST request to create the issue
    response = requests.post(url, headers=headers, json=data, auth=(credential.get('username'), credential.get('password')))
    
    # Check if the request was successful
    if response.status_code == 201:
        # GitHub typically returns an empty body for a successful POST to create an issue
        return None
    elif response.status_code >= 400:
        raise Exception(f"Failed to create issue. Status code: {response.status_code}, Response: {response.text}")
    
    # For any other status code, treat as unsuccessful
    raise Exception(f"Unexpected status code: {response.status_code}, Response: {response.text}")