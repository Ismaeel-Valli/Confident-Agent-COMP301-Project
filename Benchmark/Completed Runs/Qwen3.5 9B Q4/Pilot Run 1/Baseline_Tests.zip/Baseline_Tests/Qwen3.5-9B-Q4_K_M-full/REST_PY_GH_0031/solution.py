import requests
import json

def solve(inputs):
    """
    Lists milestones for a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The caller-supplied credential (e.g., Bearer token or API key).
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs['repository_owner']
    repository_name = inputs['repository_name']
    credential = inputs['credential']

    # Construct the API URL for listing milestones
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/milestones"

    headers = {
        'Accept': 'application/vnd.github.v3+json',
        'Authorization': f'Bearer {credential}'
    }

    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        raise Exception(f"Failed to list milestones. HTTP Status Code: {response.status_code}, Response: {response.text}")

    return response.json() if response.json() else None