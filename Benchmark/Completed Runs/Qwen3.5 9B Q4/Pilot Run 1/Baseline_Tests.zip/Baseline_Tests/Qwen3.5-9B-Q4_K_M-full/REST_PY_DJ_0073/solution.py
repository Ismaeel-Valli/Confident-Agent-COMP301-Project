import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON based on the provided sort field.
    
    Args:
        inputs (dict): A dictionary containing 'sort_field' for ordering products.
        
    Returns:
        list or None: The decoded JSON response as a list of products, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    sort_field = inputs.get('sort_field')
    
    # Construct the API URL with the sort parameter
    url = f"https://jsonplaceholder.typicode.com/products?sort={sort_field}"
    
    try:
        response = requests.get(url)
        
        # Raise an exception for unsuccessful HTTP responses (status code not in 200-299 range)
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None if the response is empty, otherwise return the list of products
        return data if data else None
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}") from e
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}") from e