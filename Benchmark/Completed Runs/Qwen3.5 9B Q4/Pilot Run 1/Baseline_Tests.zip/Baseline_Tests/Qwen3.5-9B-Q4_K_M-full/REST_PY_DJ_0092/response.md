```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the todo to update.
            - new_user_identifier (str): New value for the user Id attribute.
    
    Returns:
        str or None: The response's 'id' value if present, otherwise None for a successful empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx).
    """
    resource_id = inputs.get("resource_id")
    new_user_identifier = inputs.get("new_user_identifier")
    
    if not resource_id or not new_user_identifier:
        raise ValueError("Missing required input fields: resource_id and new_user_identifier.")

    url = f"https://dummyjson.com/todos/{resource_id}"
    payload = {
        "userId": new_user_identifier
    }

    response = requests.put(url, json=payload)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}, Response: {response.text}")
    
    # DummyJSON returns an empty body on successful PUT for this endpoint, 
    # but sometimes it might return the updated object depending on version/config.
    # We follow the instruction: Return None for a successful empty response.
    if not response.text.strip():
        return None
    
    try:
        data = response.json()
        return data.get("id")
    except (ValueError, KeyError):
        # If JSON parsing fails or 'id' is missing in the response body
        return None
```