```python
import requests

def solve(inputs):
    """
    Searches for products using a search term from the inputs dictionary.
    
    Args:
        inputs (dict): A dictionary containing 'search_text' as the search term.
        
    Returns:
        dict or None: The decoded JSON response if successful, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    search_text = inputs.get('search_text')
    
    # Assuming a base URL for DummyJSON API; adjust as necessary based on actual endpoint structure
    url = "https://dummyjson.com/products/search"
    
    params = {
        'q': search_text
    }
    
    response = requests.get(url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # If the response contains no products (empty list), return None
    if not data.get('products'):
        return None
    
    return data
```