import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (todo ID) and 'new_completed' (new value).
        
    Returns:
        str or None: The response's id if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_completed = inputs['new_completed']
    
    # Construct the payload for updating the todo
    payload = {
        "completed": new_completed
    }
    
    # Endpoint to update a specific todo by ID
    url = f"https://jsonplaceholder.typicode.com/todos/{resource_id}"
    
    try:
        response = requests.patch(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (no content)
        if not response.text.strip():
            return None
        
        # Try to parse the JSON response and extract the 'id' field
        try:
            json_response = response.json()
            return json_response.get('id')
        except ValueError:
            # If response is not valid JSON, return None as it's a successful update
            return None
            
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")