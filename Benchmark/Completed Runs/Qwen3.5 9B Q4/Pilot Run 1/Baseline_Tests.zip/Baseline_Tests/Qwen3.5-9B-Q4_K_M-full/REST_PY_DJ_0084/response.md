```python
import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    new_description = inputs['new_description']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {
        "description": new_description
    }
    
    response = requests.patch(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Check for empty response (indicated by status code 204 or empty dict/list in some APIs, 
    # but DummyJSON PATCH usually returns the updated object. However, per instructions:
    # "Return None for a successful empty response.")
    if not data:
        return None
    
    title = data.get('title')
    
    if title is None:
        return None
        
    return title
```