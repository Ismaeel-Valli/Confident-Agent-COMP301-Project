import requests

def solve(inputs):
    """
    Lists repositories for a given GitHub organization based on specified types.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The name of the organization.
            - 'type' (list or str): The type(s) of repositories to return ('all', 'public', 'private', 'internal').
            - 'credential' (str): The bearer token for authentication.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (status code >= 400).
    """
    organization = inputs["organization"]
    repo_type = inputs["type"]
    credential = inputs["credential"]

    # Ensure type is a list for consistent handling, though API accepts single string too
    if isinstance(repo_type, str):
        repo_type = [repo_type]
    
    # Construct query parameters
    params = {
        "org": organization,
        "type": ",".join(repo_type)
    }

    url = "https://api.github.com/orgs/{org}/repos".format(org=organization)
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json"
    }

    response = requests.get(url, params=params, headers=headers)

    if response.status_code >= 400:
        raise Exception(f"GitHub API request failed with status code {response.status_code}: {response.text}")

    data = response.json()
    
    # Return None for a successful empty response (empty list)
    if not data:
        return None
        
    return data