import requests
import json

def solve(inputs):
    """
    Updates a label on a GitHub repository using the REST API.
    
    Parameters:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'name' (str): The current name of the label to update.
            - 'new_new_name' (str): The new name for the label.
            - 'credential' (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: Decoded JSON response if successful and non-empty, None otherwise.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    label_name = inputs['name']
    new_label_name = inputs['new_new_name']
    credential = inputs['credential']

    # Construct the API URL for updating a label
    url = f"https://api.github.com/repos/{owner}/{repo}/labels/{label_name}"

    headers = {
        'Accept': 'application/vnd.github+json'
    }

    # Prepare authentication using the provided credential
    auth_token = credential.get('token') or credential.get('access_token')
    if not auth_token:
        raise ValueError("No valid token found in credential.")

    headers['Authorization'] = f'Bearer {auth_token}'

    payload = {
        'name': new_label_name
    }

    response = requests.patch(url, json=payload, headers=headers)

    # Raise an exception for unsuccessful HTTP responses (non-2xx)
    if not response.ok:
        raise Exception(f"Failed to update label. Status code: {response.status_code}, Response: {response.text}")

    # Return decoded JSON response
    return response.json() if response.text else None