```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_phone' (new phone number).
        
    Returns:
        str or None: The response's 'id' value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_phone = inputs['new_phone']
    
    # Construct the payload for updating the user
    payload = {
        "phone": new_phone
    }
    
    # Make the PUT request to DummyJSON API to update the user
    response = requests.put(
        f"https://dummyjson.com/users/{resource_id}",
        json=payload
    )
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Check if the response is empty (no content)
    if not response.text:
        return None
    
    # Parse the JSON response
    try:
        data = response.json()
    except ValueError:
        raise Exception("Failed to parse JSON response")
    
    # Return the 'id' value if present, otherwise None
    return data.get('id')
```