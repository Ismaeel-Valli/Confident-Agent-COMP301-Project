import requests

def solve(inputs):
    """
    Retrieves a user by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with the user identifier.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON endpoint to get a specific user by ID
    url = f"https://dummyjson.com/users/{resource_id}"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"Failed to retrieve user. HTTP Status Code: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns empty object {} for non-existent users, but the problem states
    # "Assume referenced resources and accounts exist", so we expect valid data or an empty response.
    if not data:
        return None
    
    return data