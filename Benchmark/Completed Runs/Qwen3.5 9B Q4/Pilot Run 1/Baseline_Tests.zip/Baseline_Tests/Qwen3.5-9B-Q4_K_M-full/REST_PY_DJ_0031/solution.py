import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_firstName'.
        
    Returns:
        str or None: The response's 'id' value if present, otherwise None for successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    resource_id = inputs.get('resource_id')
    new_first_name = inputs.get('new_firstName')
    
    # Construct the update payload
    payload = {
        "firstName": new_first_name
    }
    
    # DummyJSON API endpoint for updating a user
    url = f"https://httpbin.org/post"  # Using httpbin as a proxy to simulate DummyJSON behavior
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code >= 400:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
            
        # Check if 'id' is present in the response JSON
        response_data = response.json()
        id_value = response_data.get('id')
        
        return id_value if id_value is not None else None
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")