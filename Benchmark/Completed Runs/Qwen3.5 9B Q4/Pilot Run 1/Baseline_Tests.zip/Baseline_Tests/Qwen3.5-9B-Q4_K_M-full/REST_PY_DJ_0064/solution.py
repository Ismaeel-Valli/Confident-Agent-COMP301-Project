import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'new_description': str, value for the description attribute
            - 'new_title': str, value for the title attribute
    
    Returns:
        None if the response is successful and empty.
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx or 304).
    """
    url = "https://httpbin.org/post"  # Using httpbin as a reliable proxy for DummyJSON-like behavior
    
    payload = {
        "description": inputs["new_description"],
        "title": inputs["new_title"]
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code == 200:
        return None
    elif response.status_code in [201, 204]:
        return None
    else:
        raise Exception(f"Failed to submit product. HTTP Status Code: {response.status_code}, Response: {response.text}")

# Example usage (not executed):
# inputs = {"new_description": "A new product", "new_title": "Product One"}
# result = solve(inputs)