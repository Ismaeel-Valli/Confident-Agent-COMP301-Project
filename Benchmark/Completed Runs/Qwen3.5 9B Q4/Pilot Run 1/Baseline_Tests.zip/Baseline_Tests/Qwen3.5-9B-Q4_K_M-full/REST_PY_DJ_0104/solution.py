import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (product ID) and 'new_price'.
        
    Returns:
        str or None: The response's 'id' value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    resource_id = inputs.get('resource_id')
    new_price = inputs.get('new_price')
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"price": new_price}
    
    response = requests.patch(url, json=payload)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    # For DummyJSON PATCH on a single product, it returns the updated product object.
    # However, the instructions say to return None for a successful empty response.
    # Since DummyJSON doesn't typically return an empty JSON object for this endpoint,
    # we check if 'id' is present in the response.
    
    if 'id' in response.json():
        return response.json()['id']
    else:
        return None