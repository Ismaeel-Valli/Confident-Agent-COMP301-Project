import requests

def solve(inputs):
    """
    Creates a label in a GitHub repository using the REST API version 2026-03-10.
    
    Note: The provided 'new_name' parameter is interpreted as the 'name' attribute for the label being created.
    However, standard GitHub API for creating a label requires 'color', 'description', and 'name'. 
    Since the problem statement only provides 'repository_owner', 'repository_name', and 'new_name',
    we will assume 'new_name' is the label name and use default values for other required fields.
    
    If the intention was to rename an existing label, the API endpoint would be different (PATCH /repos/{owner}/{repo}/labels/{name}).
    Given the context of "Create a label", we proceed with POST /repos/{owner}/{repo}/labels.
    
    Parameters:
    inputs (dict): A dictionary containing:
        - repository_owner (str): The account owner of the repository.
        - repository_name (str): The name of the repository without the .git extension.
        - new_name (str): The name for the new label.
        - credential (str): The caller-supplied credential (e.g., token or Bearer string).
    
    Returns:
    dict or None: The decoded JSON response if successful, or None for a successful empty response.
    
    Raises:
    Exception: For an unsuccessful HTTP response.
    """
    
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    new_name = inputs["new_name"]
    credential = inputs["credential"]
    
    # Construct the API URL for creating a label
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/labels"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare the payload for creating a label. 
    # We assume 'new_name' is the label name and use default values for other required fields.
    data = {
        "name": new_name,
        "color": "FF0000",  # Default red color
        "description": ""   # Empty description
    }
    
    response = requests.post(url, headers=headers, json=data)
    
    if response.status_code == 201:
        return None  # Successful empty response
    elif response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Failed to create label. Status code: {response.status_code}, Response: {response.text}")