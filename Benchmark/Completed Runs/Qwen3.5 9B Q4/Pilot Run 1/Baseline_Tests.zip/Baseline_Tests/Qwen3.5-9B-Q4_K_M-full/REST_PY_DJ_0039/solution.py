import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON API based on inputs.
    
    Args:
        inputs (dict): Dictionary containing 'result_limit' for maximum number of results.
        
    Returns:
        list or None: Decoded JSON response (list of todos) or None if empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/todos"
    
    # Construct the request URL with limit parameter
    url = f"{base_url}{endpoint}?_limit={inputs['result_limit']}"
    
    try:
        response = requests.get(url)
        
        if response.status_code != 200:
            raise Exception(f"HTTP Error: {response.status_code}")
            
        data = response.json()
        
        # Return None for empty response, otherwise return the list
        return data if data else None
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")