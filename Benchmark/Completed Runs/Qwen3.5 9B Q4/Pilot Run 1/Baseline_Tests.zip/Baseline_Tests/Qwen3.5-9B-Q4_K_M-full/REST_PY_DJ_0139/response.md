```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON.
    
    Inputs:
        inputs (dict): Contains:
            - resource_id (str): Identifier of the todo to update.
            - new_completed (bool/None): New value for the 'completed' attribute.
            - new_user_identifier (str): New value for the 'user' attribute.
    
    Returns:
        The decoded JSON response body if successful (empty dict {}), or None for a successful empty response.
        Raises an exception for an unsuccessful HTTP response.
    """
    resource_id = inputs.get("resource_id")
    new_completed = inputs.get("new_completed")
    new_user_identifier = inputs.get("new_user_identifier")

    # Prepare the payload for PATCH request
    payload = {
        "completed": new_completed,
        "user": new_user_identifier
    }

    url = f"https://jsonplaceholder.typicode.com/todos/{resource_id}"

    try:
        response = requests.patch(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Decode the JSON response
        decoded_response = response.json()
        
        # DummyJSON typically returns an empty object {} on successful update
        if decoded_response == {}:
            return None
        
        return decoded_response

    except requests.exceptions.HTTPError as http_err:
        raise Exception(f"HTTP error occurred: {http_err}")
    except requests.exceptions.RequestException as req_err:
        raise Exception(f"Request error occurred: {req_err}")
```