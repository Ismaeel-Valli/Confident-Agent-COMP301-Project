import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing 'new_firstName' for the first name attribute.
        
    Returns:
        None if the request is successful (empty response body).
        The decoded JSON response if the response contains data.
        
    Raises:
        Exception: If the HTTP response indicates an error status code.
    """
    url = "https://dummyjson.com/users"
    
    # Prepare the payload with the provided first name and a dummy last name
    payload = {
        "firstName": inputs.get("new_firstName"),
        "lastName": "Doe",  # Dummy last name as required by the API schema for creation
        "email": "newuser@example.com",
        "age": 30,
        "phone": "+1250654987",
        "image": "https://dummyjson.com/avatar"
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. Status code: {response.status_code}, Response: {response.text}")
    
    # DummyJSON returns an empty body for POST /users on success
    if not response.text.strip():
        return None
        
    return response.json()