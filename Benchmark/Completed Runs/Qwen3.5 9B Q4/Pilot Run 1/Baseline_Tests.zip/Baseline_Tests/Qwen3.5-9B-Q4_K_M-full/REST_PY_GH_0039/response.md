```python
import requests

def solve(inputs):
    """
    Updates a pull request on GitHub using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - pull_number (int): The number that identifies the pull request.
            - new_title (str): The new title for the pull request.
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    pull_number = inputs["pull_number"]
    new_title = inputs["new_title"]
    credential = inputs["credential"]
    
    # Construct the API URL for updating a pull request
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/pulls/{pull_number}"
    
    # Prepare headers with authentication
    headers = {
        "Authorization": f"token {credential.get('token', '')}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare the payload for updating the pull request
    payload = {
        "title": new_title
    }
    
    # Send the PUT request to update the pull request
    response = requests.put(url, headers=headers, json=payload)
    
    # Check if the response is successful
    if response.status_code == 200:
        return response.json() if response.text else None
    elif response.status_code == 404:
        raise Exception(f"Resource not found: {response.url}")
    elif response.status_code == 403:
        raise Exception("Forbidden: Insufficient permissions.")
    else:
        raise Exception(f"HTTP error occurred: Status code {response.status_code}, Response: {response.text}")
```