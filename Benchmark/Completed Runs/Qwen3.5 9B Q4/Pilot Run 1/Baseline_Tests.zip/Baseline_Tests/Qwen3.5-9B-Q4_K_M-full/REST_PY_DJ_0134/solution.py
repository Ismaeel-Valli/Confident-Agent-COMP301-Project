import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'included_fields': Comma-separated string of fields to include in the response.
            - 'sort_field': The field name used for sorting the results.
    
    Returns:
        list or None: The decoded JSON response as a list of users, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/users"
    
    # Construct query parameters
    params = {
        '_limit': 1,  # Retrieve one page (one user)
        '_sort': inputs['sort_field'],
        '_fields': inputs['included_fields']
    }
    
    response = requests.get(f"{base_url}{endpoint}", params=params)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # Return None for a successful empty response
    if not data:
        return None
    
    return data