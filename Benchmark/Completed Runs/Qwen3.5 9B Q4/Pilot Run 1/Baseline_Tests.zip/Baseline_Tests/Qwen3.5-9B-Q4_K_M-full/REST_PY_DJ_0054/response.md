```python
import requests

def solve(inputs):
    resource_id = inputs.get('resource_id')
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"Failed to retrieve post: HTTP {response.status_code}")
    
    data = response.json()
    
    # Check for successful empty response (id is null or title is absent in a way that indicates emptiness)
    # Based on DummyJSON, an empty list or object might be returned if the resource doesn't exist, 
    # but the problem states to assume referenced resources exist. 
    # So we check if 'title' is present. If the response structure has no 'title', return None.
    if 'title' not in data:
        return None
    
    return data['title']
```