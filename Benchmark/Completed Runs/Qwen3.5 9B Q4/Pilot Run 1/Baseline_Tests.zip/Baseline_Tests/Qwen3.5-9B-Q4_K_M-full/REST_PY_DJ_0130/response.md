```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON and returns the response's id value,
    or None if that attribute is absent or the response is successfully empty.
    Raises an exception for an unsuccessful HTTP response.
    
    Inputs:
        inputs['resource_id']: Identifier of the todo (e.g., '/todos/1')
        inputs['new_todo']: New value for the 'todo' attribute
        inputs['new_user_identifier']: New value for the 'userId' attribute
    
    Returns:
        str or None: The updated todo's id, or None if absent or empty response.
    
    Raises:
        Exception: If the HTTP response status code indicates failure (non-2xx).
    """
    resource_id = inputs['resource_id']
    new_todo = inputs['new_todo']
    new_user_identifier = inputs['new_user_identifier']
    
    # Construct the update payload
    payload = {
        "todo": new_todo,
        "userId": new_user_identifier
    }
    
    # DummyJSON API endpoint for updating a todo (PATCH method)
    url = f"https://jsonplaceholder.typicode.com{resource_id}"
    
    try:
        response = requests.patch(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (non-2xx status codes)
        response.raise_for_status()
        
        # Check if the response content is empty
        if not response.text.strip():
            return None
        
        # Parse the JSON response to extract the 'id' field
        try:
            data = response.json()
            return data.get('id')
        except ValueError:
            # If response is not valid JSON, treat as absent id
            return None
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Failed to update todo: {str(e)}")
```