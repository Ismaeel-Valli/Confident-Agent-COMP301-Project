import requests

def solve(inputs):
    resource_id = inputs.get("resource_id")
    
    # Assuming a base URL for DummyJSON API, typically something like https://jsonplaceholder.typicode.com/posts/{id}
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    try:
        response = requests.delete(url)
        
        if response.status_code != 200:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
        
        # Check if 'isDeleted' attribute is present in the response JSON
        data = response.json()
        
        if "isDeleted" in data:
            return data["isDeleted"]
        else:
            # Return None for a successful empty response or if isDeleted is absent
            return None
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")