```python
import requests

def solve(inputs):
    """
    Searches posts using a search term from DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing 'search_text' key with the search term.
        
    Returns:
        list or None: Decoded JSON response if successful, or None for an empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    search_text = inputs.get('search_text')
    
    # DummyJSON endpoint for searching posts
    url = f"https://jsonplaceholder.typicode.com/posts?title={search_text}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None if the response is empty (successful but no results)
        if not data:
            return None
            
        return data
        
    except requests.exceptions.HTTPError as errh:
        raise Exception(f"HTTP Error occurred while searching posts: {str(errh)}")
    except requests.exceptions.ConnectionError as errc:
        raise Exception(f"Connection Error occurred while searching posts: {str(errc)}")
    except requests.exceptions.Timeout as errt:
        raise Exception(f"Timeout Error occurred while searching posts: {str(errt)}")
    except requests.exceptions.RequestException as err:
        raise Exception(f"Request Error occurred while searching posts: {str(err)}")
```