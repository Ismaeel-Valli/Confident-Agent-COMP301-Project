```python
import requests

def solve(inputs):
    """
    Lists the people a GitHub user follows using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The handle for the GitHub user account.
            - 'page_size' (int): The number of results per page (max 100).
            - 'credential' (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response, or None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    username = inputs['username']
    page_size = inputs['page_size']
    credential = inputs['credential']
    
    # Construct the API URL for following users
    url = f"https://api.github.com/users/{username}/following"
    
    # Prepare headers with authentication
    headers = {
        'Accept': 'application/vnd.github.v3+json'
    }
    
    # Add authorization header based on credential type (assuming token or basic auth)
    if 'token' in credential:
        headers['Authorization'] = f'token {credential["token"]}'
    elif 'username' in credential and 'password' in credential:
        import base64
        auth_string = f"{credential['username']}:{credential['password']}"
        encoded_auth = base64.b64encode(auth_string.encode()).decode()
        headers['Authorization'] = f'Basic {encoded_auth}'
    else:
        # Fallback if credential structure is unclear but assumed valid per problem statement
        raise ValueError("Credential must contain 'token' or both 'username' and 'password'.")

    params = {'per_page': page_size}

    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response (empty list)
    if not data:
        return None
    
    return data
```