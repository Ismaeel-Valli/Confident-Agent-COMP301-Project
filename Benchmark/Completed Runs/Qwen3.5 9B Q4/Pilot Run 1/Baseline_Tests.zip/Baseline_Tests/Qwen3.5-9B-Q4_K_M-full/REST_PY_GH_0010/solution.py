import requests
import json

def solve(inputs):
    """
    Fetches a specific branch from a GitHub repository using the REST API.
    
    Parameters:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'branch' (str): The name of the branch to fetch.
            - 'credential' (str): The authentication token or header value.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    branch = inputs["branch"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{owner}/{repo}/branches/{branch}"
    
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "Authorization": f"Bearer {credential}"
    }

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        data = response.json()
        return None if not data else data
    elif response.status_code in (403, 401):
        raise Exception(f"Authentication failed or rate limited. Status: {response.status_code}")
    else:
        raise Exception(f"Failed to fetch branch. Status: {response.status_code}, Body: {response.text}")