```python
import requests

def solve(inputs):
    """
    Fetches a GitHub repository using the REST API (version 2026-03-10).
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git extension).
            - 'credential' (str): The caller-supplied credential (e.g., Authorization token or Bearer token).
    
    Returns:
        dict or None: The decoded JSON response if successful. Returns None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    owner = inputs["repository_owner"]
    repo_name = inputs["repository_name"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{owner}/{repo_name}"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        data = response.json()
        return None if not data else data
    elif response.status_code >= 400:
        raise Exception(f"Failed to fetch repository. Status code: {response.status_code}, Response: {response.text}")

    # Fallback for unexpected success codes (shouldn't happen per problem constraints)
    if response.status_code == 204:
        return None
    
    raise Exception(f"Unexpected response status code: {response.status_code}")
```