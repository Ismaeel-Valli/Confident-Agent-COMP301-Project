```python
import requests

def solve(inputs):
    resource_id = inputs.get('resource_id')
    
    url = f"https://dummyjson.com/products/{resource_id}"
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    if not data:
        return None
    
    title = data.get('title')
    return title if title is not None else None
```