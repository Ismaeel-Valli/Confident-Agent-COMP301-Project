```python
import requests

def solve(inputs):
    """
    Lists commits on a pull request using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - pull_number (int): The number that identifies the pull request.
            - page_size (int): The number of results per page (max 100).
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    pull_number = inputs["pull_number"]
    page_size = inputs["page_size"]
    credential = inputs["credential"]
    
    # Construct the API URL for listing commits on a pull request
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pull_number}/commits"
    
    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "Authorization": f"Bearer {credential['token']}"
    }
    
    params = {"per_page": page_size}
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Failed to retrieve commits for pull request #{pull_number}. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Return None if the list is empty, otherwise return the decoded JSON
    return data if data else None
```