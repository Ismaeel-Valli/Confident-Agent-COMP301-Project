```python
import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    new_body = inputs['new_body']
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    payload = {"body": new_body}
    
    response = requests.patch(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Check for successful empty response (indicated by a specific structure or content)
    # DummyJSON typically returns an object with 'id' on success, but sometimes might return empty or different structures.
    # Based on the instruction: "Return None for a successful empty response."
    if not data or (isinstance(data, dict) and not any(data.keys())):
        return None
    
    # Return only the response's id value, or None if that attribute is absent.
    return data.get('id')
```