import requests

def solve(inputs):
    """
    Submits a new post to DummyJSON API with provided body, title, and user identifier.
    
    Args:
        inputs (dict): Contains 'new_body', 'new_title', 'new_user_identifier'
        
    Returns:
        str or None: The response's title value if present, otherwise None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses (non-2xx status codes).
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "body": inputs["new_body"],
        "title": inputs["new_title"],
        "userId": inputs["new_user_identifier"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create post. Status code: {response.status_code}")
    
    # DummyJSON returns the created object in the response body
    data = response.json()
    
    # Return title if present, otherwise None (though successful creation should always have a title)
    return data.get("title")