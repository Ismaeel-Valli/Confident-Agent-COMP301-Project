```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the user.
            - new_email (str): New value for the email attribute.
    
    Returns:
        None if the response is successfully empty.
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    new_email = inputs.get('new_email')
    
    url = f"https://dummyjson.com/users/{resource_id}"
    data = {
        "email": new_email
    }
    
    response = requests.patch(url, json=data)
    
    if response.status_code != 200:
        raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
    
    return None
```