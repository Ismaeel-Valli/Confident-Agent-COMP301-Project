import requests

def solve(inputs):
    """
    Lists watchers for a GitHub repository using the specified API version.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The caller-supplied credential (e.g., Bearer token or API key).
    
    Returns:
        dict or None: The decoded JSON response if watchers exist, or None if the list is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    credential = inputs["credential"]

    # GitHub REST API version 2026-03-10 endpoint for listing watchers
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/watchers"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    if credential:
        headers["Authorization"] = f"Bearer {credential}"

    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        raise Exception(f"Failed to list watchers. HTTP status code: {response.status_code}, Response: {response.text}")

    data = response.json()

    # Return None for a successful empty response (i.e., no watchers)
    if not data:
        return None

    return data