```python
import requests

def solve(inputs):
    resource_id = inputs.get('resource_id')
    
    # Assuming a base URL; adjust as needed for DummyJSON or your specific setup
    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.delete(url)
        
        if response.status_code == 204:
            return None
        
        if response.status_code == 200:
            data = response.json()
            return data.get('id')
            
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```