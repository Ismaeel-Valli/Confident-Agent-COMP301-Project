```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API using provided first name.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' key.
        
    Returns:
        str or None: The ID of the created user, or None if response is empty.
        
    Raises:
        Exception: If HTTP response is unsuccessful (status code >= 400).
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "name": inputs.get("new_firstName"),
        "email": "test@example.com",
        "address": {
            "street": "test street",
            "suite": "test suite",
            "city": "test city",
            "zipcode": "12345",
            "geo": {
                "lat": "test lat",
                "lng": "test lng"
            }
        },
        "phone": "test phone",
        "website": "test website",
        "company": {
            "name": "test company",
            "catchPhrase": "test catch phrase",
            "bs": "test bs"
        }
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    if not data:
        return None
    
    return data.get("id")
```