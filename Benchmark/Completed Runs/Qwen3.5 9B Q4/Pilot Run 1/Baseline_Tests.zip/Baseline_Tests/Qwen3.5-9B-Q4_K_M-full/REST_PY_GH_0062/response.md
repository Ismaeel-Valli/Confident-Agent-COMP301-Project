```python
import requests

def solve(inputs):
    """
    Lists followers of a GitHub user using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The handle for the GitHub user account.
            - 'credential' (dict): Caller-supplied credential with necessary permissions 
                                  (assumed to be a valid token or auth header info).
    
    Returns:
        list | None: Decoded JSON response as a list of followers, or None if the list is empty.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    username = inputs['username']
    credential = inputs['credential']
    
    # Construct the API URL for listing followers (version 2026-03-10)
    url = f"https://api.github.com/users/{username}/followers"
    
    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential.get('token', '')}" if isinstance(credential, dict) else ""
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for an empty list of followers
    return data if data else None
```