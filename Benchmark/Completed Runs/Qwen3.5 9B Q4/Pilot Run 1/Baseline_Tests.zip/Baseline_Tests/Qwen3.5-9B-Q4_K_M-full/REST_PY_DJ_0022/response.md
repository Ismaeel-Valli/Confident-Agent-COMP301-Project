```python
import requests

def solve(inputs):
    resource_id = inputs.get('resource_id')
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json"
    }
    
    response = requests.delete(url, headers=headers)
    
    if response.status_code == 204:
        return None
    
    if response.status_code != 200:
        raise Exception(f"Failed to delete todo. Status code: {response.status_code}, Response: {response.text}")
    
    try:
        data = response.json()
        return data
    except ValueError as e:
        raise Exception(f"Invalid JSON response: {e}")
```