```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API.
    
    Args:
        inputs (dict): Contains 'new_description' and 'new_title'.
        
    Returns:
        int or None: The response's id value if present, otherwise None for successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": inputs["new_title"],
        "body": inputs["new_description"]
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create product. Status code: {response.status_code}")
    
    if response.json():
        return response.json().get("id")
    
    return None
```