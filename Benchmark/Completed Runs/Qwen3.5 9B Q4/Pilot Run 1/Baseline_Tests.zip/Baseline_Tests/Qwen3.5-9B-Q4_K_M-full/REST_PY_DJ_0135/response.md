```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the user to update.
            - new_username (str): New value for the username attribute.
            
    Returns:
        None if the HTTP response is successful and empty.
        The decoded JSON response otherwise (though typically we expect an empty body on success).
        
    Raises:
        Exception: If the HTTP response indicates failure (non-2xx status code).
    """
    resource_id = inputs.get("resource_id")
    new_username = inputs.get("new_username")
    
    if not resource_id or not new_username:
        raise ValueError("Missing required fields in inputs: 'resource_id' and 'new_username'.")

    # DummyJSON endpoint for updating a user by ID
    url = f"https://dummyjson.com/users/{resource_id}"
    
    payload = {
        "username": new_username
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code == 200:
        # DummyJSON returns an empty body on successful update
        return None
    
    elif response.status_code == 404:
        raise Exception(f"Resource not found. Status code: {response.status_code}")
        
    else:
        raise Exception(f"Failed to update user. Status code: {response.status_code}, Response: {response.text}")

```