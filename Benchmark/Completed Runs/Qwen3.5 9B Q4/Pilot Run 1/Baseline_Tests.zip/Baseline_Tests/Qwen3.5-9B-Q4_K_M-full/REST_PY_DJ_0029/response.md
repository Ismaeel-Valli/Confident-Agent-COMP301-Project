```python
import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'result_limit' (int) specifying 
                       the maximum number of results to return.
    
    Returns:
        list or None: The decoded JSON response as a list of users, or None if 
                      the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code outside 200-299).
    """
    base_url = "https://jsonplaceholder.typicode.com/users"
    result_limit = inputs.get("result_limit", 10)
    
    params = {
        "_limit": result_limit
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # Return None for a successful empty response
    if not data:
        return None
    
    return data
```