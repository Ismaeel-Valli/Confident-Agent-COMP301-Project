```python
import requests

def solve(inputs):
    """
    Lists issue comments for a specific GitHub repository issue using the GitHub REST API.
    
    Parameters:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - issue_number (int): The number that identifies the issue.
            - since (str, optional): ISO 8601 timestamp to filter comments updated after this time.
            - credential (dict): Caller-supplied credentials (e.g., token or auth headers).
    
    Returns:
        dict or None: Decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    since = inputs.get("since")
    credential = inputs["credential"]

    # Construct the API URL for listing comments on an issue
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}/comments"

    headers = {
        "Accept": "application/vnd.github.v3+json",
    }

    # Add authentication if provided (assuming token in credential)
    if isinstance(credential, dict):
        token = credential.get("token") or credential.get("auth_token")
        if token:
            headers["Authorization"] = f"Bearer {token}"

    params = {}
    if since:
        params["since"] = since

    response = requests.get(url, headers=headers, params=params)

    if response.status_code != 200:
        raise Exception(f"Failed to retrieve issue comments. Status code: {response.status_code}, Response: {response.text}")

    data = response.json()

    # Return None for an empty list of comments
    if not data:
        return None

    return data
```