import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id', 'new_completed', and 'new_todo'.
        
    Returns:
        None if the response is empty (successful update).
        The decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_completed = inputs['new_completed']
    new_todo = inputs['new_todo']
    
    # Construct the payload for the update request
    payload = {
        "completed": new_completed,
        "todo": new_todo
    }
    
    # Endpoint to update a todo item in DummyJSON
    url = f"https://jsonplaceholder.typicode.com/todos/{resource_id}"
    
    try:
        response = requests.put(url, json=payload)
        
        if response.status_code == 200:
            # If the response is empty (which is typical for a successful PUT in this context), return None
            if not response.text.strip():
                return None
            return response.json()
        else:
            raise Exception(f"HTTP Error {response.status_code}: {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")