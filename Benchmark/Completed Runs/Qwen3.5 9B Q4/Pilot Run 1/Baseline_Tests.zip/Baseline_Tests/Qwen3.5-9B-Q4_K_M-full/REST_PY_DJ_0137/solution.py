import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'included_fields': Comma-separated string of fields to include in the response.
            - 'sort_field': Field name used for ordering the results.
    
    Returns:
        list or None: The decoded JSON response as a list of posts, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/posts"
    
    # Parse included_fields from comma-separated string into a list
    included_fields = [f.strip() for f in inputs['included_fields'].split(',') if f.strip()]
    
    # Build query parameters
    params = {
        '_limit': 1,      # Retrieve one page (one item)
        '_sort': inputs['sort_field'],
        '_fields': ','.join(included_fields)
    }
    
    url = f"{base_url}{endpoint}"
    
    try:
        response = requests.get(url, params=params)
        
        # Raise an exception for unsuccessful HTTP responses (non-2xx status codes)
        response.raise_for_status()
        
        data = response.json()
        
        # Return None if the response is empty (though with _limit=1 it's unlikely unless filtered out)
        if not data:
            return None
            
        return data
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")