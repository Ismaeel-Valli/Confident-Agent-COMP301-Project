import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON API based on the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'result_limit' for maximum number of results.
        
    Returns:
        list or None: Decoded JSON response as a list of products, or None if empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/posts"  # Using posts as an example resource since DummyJSON doesn't have a specific 'products' endpoint in the standard jsonplaceholder
    
    result_limit = inputs.get('result_limit', 10)
    
    params = {
        '_limit': result_limit,
        '_page': 1
    }
    
    response = requests.get(f"{base_url}{endpoint}", params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP request failed with status code: {response.status_code}")
    
    data = response.json()
    
    # Return None for successful empty response
    if not data:
        return None
    
    return data