import requests

def solve(inputs):
    """
    Fetches a specific label from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'name' (str): The name of the label to fetch.
            - 'credential' (dict): Caller-supplied credential info, assumed to have necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    repository_owner = inputs['repository_owner']
    repository_name = inputs['repository_name']
    name = inputs['name']
    credential = inputs['credential']

    # Construct the API URL for fetching a label
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/labels/{name}"

    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github.v3+json"
    }

    # Add authorization header if credentials are provided (assuming 'token' or similar key)
    if credential:
        auth_type = credential.get('auth_type', 'token')
        token_value = credential.get('token') or credential.get('access_token') or credential.get('private_key')
        
        if auth_type == 'token':
            headers["Authorization"] = f"Bearer {token_value}"
        elif auth_type == 'basic':
            username = credential.get('username')
            password = credential.get('password')
            if username and password:
                import base64
                creds = f"{username}:{password}"
                encoded_credentials = base64.b64encode(creds.encode()).decode()
                headers["Authorization"] = f"Basic {encoded_credentials}"

    try:
        response = requests.get(url, headers=headers)
        
        # Raise an exception for unsuccessful HTTP responses (non-2xx status codes)
        response.raise_for_status()
        
        # Decode the JSON response
        json_response = response.json()
        
        # Return None for a successful empty response
        if not json_response:
            return None
            
        return json_response
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")