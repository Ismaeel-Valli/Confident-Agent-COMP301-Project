import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    new_body = inputs['new_body']
    new_title = inputs['new_title']
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    payload = {
        "body": new_body,
        "title": new_title
    }
    
    response = requests.patch(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update post. Status code: {response.status_code}")
    
    data = response.json()
    
    if data.get("id") is not None:
        return data["id"]
    elif data == {}:
        return None
    else:
        return None