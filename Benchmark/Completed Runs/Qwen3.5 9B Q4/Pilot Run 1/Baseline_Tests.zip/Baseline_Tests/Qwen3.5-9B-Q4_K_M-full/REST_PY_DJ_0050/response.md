```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the user.
            - new_lastName (str): New value for the last Name attribute.
            
    Returns:
        None if the response is empty (successful update).
        The decoded JSON response otherwise.
        
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    resource_id = inputs.get("resource_id")
    new_lastName = inputs.get("new_lastName")
    
    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {"lastName": new_lastName}
    
    response = requests.patch(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user: {response.text}")
    
    return None if not response.json() else response.json()
```