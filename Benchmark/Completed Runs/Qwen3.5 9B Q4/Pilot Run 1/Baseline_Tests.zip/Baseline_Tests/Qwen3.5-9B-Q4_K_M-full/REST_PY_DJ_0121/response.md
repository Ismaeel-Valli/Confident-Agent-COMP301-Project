```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id', 'new_todo', and 'new_user_identifier'.
        
    Returns:
        None if the response is empty (success).
        The decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_todo = inputs['new_todo']
    new_user_identifier = inputs['new_user_identifier']
    
    # Construct the payload for updating the todo
    payload = {
        "todo": new_todo,
        "user_id": new_user_identifier
    }
    
    # Endpoint to update a specific todo by ID
    url = f"https://jsonplaceholder.typicode.com/todos/{resource_id}"
    
    try:
        response = requests.put(url, json=payload)
        
        if response.status_code == 200:
            # If the response is empty (which can happen with some APIs on success), return None
            if not response.text.strip():
                return None
            return response.json()
        else:
            raise Exception(f"HTTP Error {response.status_code}: {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```