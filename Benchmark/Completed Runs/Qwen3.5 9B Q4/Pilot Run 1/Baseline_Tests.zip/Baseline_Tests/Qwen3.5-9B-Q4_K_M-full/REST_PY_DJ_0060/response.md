```python
import requests

def solve(inputs):
    resource_id = inputs.get("resource_id")
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    headers = {"Accept": "application/json"}
    
    response = requests.delete(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    if "isDeleted" in data:
        return data["isDeleted"]
    elif not data:
        return None
    else:
        return None
```