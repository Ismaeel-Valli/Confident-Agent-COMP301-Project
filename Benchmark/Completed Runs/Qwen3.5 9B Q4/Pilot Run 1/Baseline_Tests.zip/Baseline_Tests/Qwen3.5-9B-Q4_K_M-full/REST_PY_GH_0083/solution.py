import requests
from urllib.parse import quote

def solve(inputs):
    """
    Creates a milestone in a GitHub repository using the REST API.
    
    Parameters:
        inputs (dict): A dictionary containing:
            - 'repository_owner': str, the account owner of the repository
            - 'repository_name': str, the name of the repository (without .git)
            - 'new_state': str, value for the state attribute
            - 'new_title': str, value for the title attribute
            - 'credential': dict or tuple, GitHub API credentials (e.g., {'token': 'ghp_xxx'} or ('username', 'password'))
    
    Returns:
        None if the response is empty (success), otherwise returns the decoded JSON response.
    
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    state = inputs['new_state']
    title = inputs['new_title']
    credential = inputs['credential']

    # Construct the API URL (GitHub REST API v2026-03-10)
    url = f"https://api.github.com/repos/{quote(owner, safe='')}/{quote(repo, safe='')}/milestones"

    headers = {
        "Accept": "application/vnd.github+json",
        "User-Agent": "GitHub-API-Client"
    }

    # Prepare authentication based on credential format
    if isinstance(credential, dict):
        token = credential.get('token')
        if token:
            headers['Authorization'] = f'Bearer {token}'
    elif isinstance(credential, tuple) and len(credential) == 2:
        username, password = credential
        auth = requests.auth.HTTPBasicAuth(username, password)
    else:
        raise ValueError("Invalid credential format. Expected dict with 'token' or tuple of (username, password).")

    payload = {
        "title": title,
        "state": state
    }

    response = requests.post(url, headers=headers, auth=auth, json=payload)

    if response.status_code == 201:
        # GitHub returns a JSON object with the created milestone on POST
        return response.json()
    elif response.status_code == 204:
        # Some endpoints may return 204 No Content; treat as success with no body
        return None
    else:
        raise Exception(f"Failed to create milestone. HTTP {response.status_code}: {response.text}")