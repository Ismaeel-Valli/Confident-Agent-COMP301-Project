import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip (for pagination).
            - included_fields (str): Comma-separated list of fields to include in the response.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/todos"
    
    # Construct query parameters
    params = {
        "_limit": inputs["result_limit"],
        "_skip": inputs["results_to_skip"]
    }
    
    # Handle included_fields if provided (DummyJSON doesn't natively support field filtering like this,
    # but we'll pass it as a parameter for completeness or ignore if not supported by the specific API version).
    # Note: The standard JSONPlaceholder API does not support _fields. If this is a custom DummyJSON endpoint,
    # adjust the URL construction accordingly. Assuming standard behavior where we just fetch and filter client-side
    # or the endpoint supports it via query params like ?_fields=...
    
    if inputs["included_fields"]:
        params["_fields"] = inputs["included_fields"]

    url = f"{base_url}{endpoint}"
    
    try:
        response = requests.get(url, params=params)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None if the response is empty (successful but no data)
        if not data:
            return None
        
        return data
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")