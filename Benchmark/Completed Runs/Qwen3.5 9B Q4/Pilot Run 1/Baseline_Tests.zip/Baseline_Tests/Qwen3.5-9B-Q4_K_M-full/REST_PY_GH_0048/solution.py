import requests

def solve(inputs):
    """
    Lists stargazers for a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The bearer token for authentication.
    
    Returns:
        list or None: A list of stargazer data dictionaries if there are any, 
                      None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    token = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/stargazers"
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "Authorization": f"Bearer {token}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"GitHub API request failed with status code {response.status_code}: {response.text}")
    
    data = response.json()
    
    # GitHub returns an empty list [] for no stargazers, which is a successful response.
    # The instructions say to return None for a successful empty response.
    if len(data) == 0:
        return None
    
    return data