```python
import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    new_title = inputs['new_title']
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    payload = {"title": new_title}
    
    response = requests.patch(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update post: {response.text}")
    
    data = response.json()
    
    # Check for empty response (no data returned)
    if not data or 'title' not in data:
        return None
    
    return data['title']
```