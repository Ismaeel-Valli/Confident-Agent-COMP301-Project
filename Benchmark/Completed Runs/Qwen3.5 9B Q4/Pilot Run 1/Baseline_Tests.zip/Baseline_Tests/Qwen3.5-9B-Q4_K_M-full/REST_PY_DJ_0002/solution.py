import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns an empty object {} for a successful empty response when the product doesn't exist, 
    # but the problem states to assume referenced resources exist. 
    # However, if the endpoint returns an empty list or object specifically as a "successful empty response", we return None.
    # Based on standard DummyJSON behavior for GET /products/{id}, it returns a single product object.
    # If the problem implies that an empty response (like an empty dict) should be treated as None, we check for that.
    if data == {}:
        return None
    
    return data