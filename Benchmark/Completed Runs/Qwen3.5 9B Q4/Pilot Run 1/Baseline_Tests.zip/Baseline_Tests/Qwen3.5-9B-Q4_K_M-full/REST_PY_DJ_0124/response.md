```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API with provided category and title.
    
    Args:
        inputs (dict): Contains 'new_category' and 'new_title' keys.
        
    Returns:
        None if the request is successful (empty response).
        Decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": inputs["new_title"],
        "body": inputs["new_category"]  # Using category as body since DummyJSON doesn't have a direct category field in posts, but we'll use it as the body content
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code != 201:
        raise Exception(f"Failed to submit product. Status code: {response.status_code}, Response: {response.text}")
    
    return None
```