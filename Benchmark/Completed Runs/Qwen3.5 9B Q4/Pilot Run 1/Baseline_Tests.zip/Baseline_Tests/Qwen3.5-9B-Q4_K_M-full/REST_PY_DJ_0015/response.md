```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the post to update.
            - new_title (str): The new value for the 'title' attribute.
    
    Returns:
        None if the HTTP response is successful and empty.
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    resource_id = inputs.get("resource_id")
    new_title = inputs.get("new_title")
    
    if not resource_id or not new_title:
        raise ValueError("Missing required fields: resource_id and new_title.")

    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    payload = {"title": new_title}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return None
    
    if response.status_code == 404:
        raise Exception(f"Resource not found: {resource_id}")
    
    if response.status_code == 422:
        raise Exception("Validation error occurred.")
        
    response.raise_for_status()
    return response.json()
```