import requests

def solve(inputs):
    """
    Lists repository tags for GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner': str, The account owner of the repository.
            - 'repository_name': str, The name of the repository without the .git extension.
            - 'credential': dict, Caller-supplied credential with necessary permissions.
    
    Returns:
        list or None: Decoded JSON response as a list of tags, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    credential = inputs['credential']
    
    # Construct the API URL for listing tags (GitHub REST API v2026-03-10)
    url = f"https://api.github.com/repos/{owner}/{repo}/tags"
    
    headers = {
        "Accept": "application/vnd.github+json",
        # Assuming 'credential' contains an 'Authorization' token or similar structure.
        # If the credential is a dict with 'token', we construct the header accordingly.
        # Adjust based on actual credential format if it differs (e.g., Bearer token).
    }
    
    if isinstance(credential, dict):
        if 'token' in credential:
            headers["Authorization"] = f"Bearer {credential['token']}"
        elif 'auth' in credential and isinstance(credential['auth'], str):
            headers["Authorization"] = credential['auth']
        # Add standard GitHub headers for versioning if needed, but typically not required for basic calls.
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        return None if len(data) == 0 else data
    elif response.status_code >= 400:
        raise Exception(f"GitHub API request failed with status {response.status_code}: {response.text}")
    else:
        raise Exception(f"Unexpected HTTP status code: {response.status_code}")