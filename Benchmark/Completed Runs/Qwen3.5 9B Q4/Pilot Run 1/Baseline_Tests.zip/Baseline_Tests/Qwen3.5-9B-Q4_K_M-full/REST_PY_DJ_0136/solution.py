import requests
import json

def solve(inputs):
    """
    Submits a new user to DummyJSON using the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'new_firstName' and 'new_username'.
        
    Returns:
        None if the response is successful (empty body).
        The decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "name": inputs.get("new_firstName"),
        "username": inputs.get("new_username")
    }
    
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json"
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. Status code: {response.status_code}, Response: {response.text}")
    
    # DummyJSON typically returns an empty body on successful POST for users in this context
    # but we decode it anyway as per instructions if there is content, or return None for success.
    if response.text.strip() == "":
        return None
    
    try:
        return response.json()
    except json.JSONDecodeError:
        raise Exception("Received non-JSON response body.")