import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON and returns the response's id value,
    or None if that attribute is absent or for a successful empty response.
    Raises an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the todo
            - new_completed (bool): Value for the completed attribute
            - new_todo (str): Value for the todo attribute
    
    Returns:
        str or None: The response's id value, or None if absent or empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    resource_id = inputs.get('resource_id')
    new_completed = inputs.get('new_completed')
    new_todo = inputs.get('new_todo')
    
    # Prepare the payload for PATCH request
    payload = {
        'completed': new_completed,
        'todo': new_todo
    }
    
    # Make the PATCH request to DummyJSON API
    response = requests.patch(
        f'https://jsonplaceholder.typicode.com/todos/{resource_id}',
        json=payload
    )
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Check if the response is empty (no content)
    if not response.text:
        return None
    
    # Parse the JSON response
    try:
        data = response.json()
    except ValueError:
        # If response is not valid JSON, treat as empty or error
        return None
    
    # Return the id value if present, otherwise None
    return data.get('id')