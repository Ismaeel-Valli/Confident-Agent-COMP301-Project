import requests

def solve(inputs):
    """
    Lists pull requests for a GitHub repository using the specified credentials.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: Decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    credential = inputs["credential"]
    
    # Construct the API URL for listing pull requests
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls"
    
    # Prepare headers with authentication using the provided credential
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential['token']}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to list pull requests. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Return None for an empty successful response
    if not data:
        return None
    
    return data