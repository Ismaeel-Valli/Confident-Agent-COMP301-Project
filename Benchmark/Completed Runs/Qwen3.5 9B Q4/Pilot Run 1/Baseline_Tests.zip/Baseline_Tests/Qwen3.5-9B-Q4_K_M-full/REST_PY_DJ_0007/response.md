```python
import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON and returns the decoded JSON response.
    
    Args:
        inputs (dict): A dictionary containing API parameters, expected to include 'page'.
        
    Returns:
        dict or None: The decoded JSON response if successful. Returns None for an empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    # Assuming the base URL for DummyJSON users endpoint
    url = "https://jsonplaceholder.typicode.com/users"
    
    # Extract page number from inputs, default to 1 if not provided
    page = inputs.get('page', 1)
    
    # Prepare headers and parameters
    headers = {
        'Content-Type': 'application/json'
    }
    params = {
        '_limit': 10,  # DummyJSON often uses _limit for pagination
        '_page': page
    }
    
    try:
        response = requests.get(url, headers=headers, params=params)
        
        # Raise an exception for unsuccessful HTTP responses
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None if the response is empty (though unlikely with this endpoint)
        if not data:
            return None
            
        return data
        
    except requests.exceptions.HTTPError as errh:
        raise Exception(f"HTTP Error: {errh}")
    except requests.exceptions.ConnectionError as errc:
        raise Exception(f"Connection Error: {errc}")
    except requests.exceptions.Timeout as errt:
        raise Exception(f"Timeout Error: {errt}")
    except requests.exceptions.RequestException as err:
        raise Exception(f"Request Error: {err}")
```