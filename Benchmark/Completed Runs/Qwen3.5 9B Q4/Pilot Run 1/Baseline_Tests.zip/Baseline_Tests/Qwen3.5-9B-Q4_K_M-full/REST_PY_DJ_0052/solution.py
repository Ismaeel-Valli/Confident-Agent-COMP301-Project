import requests
import json

def solve(inputs):
    """
    Submits a new user to DummyJSON API using provided first and last name.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_lastName'.
        
    Returns:
        None if the response is empty (successful submission).
        The decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "name": f"{inputs['new_firstName']} {inputs['new_lastName']}",
        "email": "test@example.com",
        "address": {"street": "test street", "suite": "test suite", "city": "test city", "zipcode": "12345", "geo": {"lat": "test lat", "lng": "test lng"}},
        "phone": "test phone",
        "website": "test website"
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. Status code: {response.status_code}, Response: {response.text}")
    
    return None