import requests

def solve(inputs):
    """
    Deletes a user by identifier using DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' which is the identifier of the user to delete.
        
    Returns:
        None if deletion was successful (empty response).
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/users/{resource_id}"
    
    try:
        response = requests.delete(url)
        response.raise_for_status()
        
        # DummyJSON returns an empty body on successful delete, but we decode it anyway
        decoded_response = response.json()
        
        # According to requirements: Return None for a successful empty response
        if not decoded_response or (isinstance(decoded_response, dict) and not decoded_response):
            return None
            
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")

# Note: Do not execute the function.