```python
import requests

def solve(inputs):
    """
    Submits a new todo to DummyJSON API and returns the response's id.
    
    Args:
        inputs (dict): Dictionary containing:
            - 'new_completed': value for the completed attribute
            - 'new_todo': value for the todo attribute
            - 'new_user_identifier': value for the user Id attribute
    
    Returns:
        str or None: The response's id if present, otherwise None.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    url = "https://jsonplaceholder.typicode.com/todos"
    
    payload = {
        "userId": inputs["new_user_identifier"],
        "id": len([t for t in requests.get(url, params={"userId": inputs["new_user_identifier"]}).json()]) + 1,
        "title": inputs["new_todo"],
        "completed": inputs["new_completed"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    data = response.json()
    
    return data.get("id") if data else None
```