```python
import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing 'page' key for pagination.
        
    Returns:
        list or None: Decoded JSON response (list of products) if successful, 
                      None if the response is empty.
                      
    Raises:
        requests.exceptions.RequestException: For unsuccessful HTTP responses.
    """
    # Extract page number from inputs, default to 1
    page = inputs.get('page', 1)
    
    # DummyJSON API endpoint for products
    url = f"https://jsonplaceholder.typicode.com/products?limit=5&skip={page*5-5}"
    
    try:
        response = requests.get(url)
        
        # Raise exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Decode JSON response
        data = response.json()
        
        # Return None for empty response
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise e
```