```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API using provided age and first name.
    
    Args:
        inputs (dict): Contains 'new_age' and 'new_firstName'.
        
    Returns:
        None if the request is successful (empty response body).
        The decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "name": inputs.get("new_firstName"),
        "age": inputs.get("new_age")
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. Status code: {response.status_code}, Response: {response.text}")
    
    return None
```