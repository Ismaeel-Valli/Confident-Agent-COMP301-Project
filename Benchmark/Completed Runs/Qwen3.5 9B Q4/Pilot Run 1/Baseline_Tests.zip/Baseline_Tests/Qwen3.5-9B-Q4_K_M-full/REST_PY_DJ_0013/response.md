```python
import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON using the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'api_key' and optionally 'page'.
                       If 'page' is not provided, defaults to 1.
    
    Returns:
        dict or None: The decoded JSON response if successful. Returns None for an empty response.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails (non-2xx status code).
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    # Extract parameters with defaults
    api_key = inputs.get("api_key", "")
    page = inputs.get("page", 1)
    
    headers = {
        "X-Custom-Header": api_key,
        "Accept": "application/json"
    }
    
    params = {
        "_limit": 10,
        "_start": (page - 1) * 10
    }
    
    response = requests.get(base_url, headers=headers, params=params)
    
    if response.status_code != 200:
        raise requests.exceptions.RequestException(
            f"HTTP Error {response.status_code}: {response.text}"
        )
    
    data = response.json()
    
    return data if data else None
```