import requests
from requests.exceptions import RequestException, HTTPError

def solve(inputs):
    """
    Updates the authenticated user's name via GitHub REST API.
    
    Args:
        inputs (dict): Contains 'new_name' and 'credential'.
        
    Returns:
        None if successful (empty response), otherwise decoded JSON response.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    new_name = inputs["new_name"]
    credential = inputs["credential"]
    
    # Construct the URL to update user name
    url = "https://api.github.com/user"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json"
    }
    
    payload = {
        "name": new_name
    }
    
    try:
        response = requests.put(url, json=payload, headers=headers)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Return None for a successful empty response
        if not response.text:
            return None
            
        # Return the decoded JSON response
        return response.json()
        
    except HTTPError as http_err:
        raise Exception(f"HTTP error occurred: {http_err}")
    except RequestException as req_err:
        raise Exception(f"Request error occurred: {req_err}")