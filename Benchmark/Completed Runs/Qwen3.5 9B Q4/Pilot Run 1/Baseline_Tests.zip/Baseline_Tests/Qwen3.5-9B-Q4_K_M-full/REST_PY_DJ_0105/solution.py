import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API with provided price and title.
    
    Args:
        inputs (dict): Dictionary containing 'new_price' and 'new_title'.
        
    Returns:
        int or None: The response's id if present, otherwise None for successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": inputs.get("new_title"),
        "body": inputs.get("new_price")  # Using price as body since DummyJSON doesn't have a specific price endpoint, treating it as content for demonstration
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to submit product. Status code: {response.status_code}")
    
    # DummyJSON typically returns the created object with an id
    data = response.json()
    
    if "id" in data:
        return data["id"]
    else:
        return None