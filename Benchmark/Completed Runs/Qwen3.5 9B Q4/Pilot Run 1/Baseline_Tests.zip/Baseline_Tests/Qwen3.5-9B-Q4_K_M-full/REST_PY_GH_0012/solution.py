import requests

def solve(inputs):
    """
    Fetches a specific commit from a GitHub repository using the provided credentials.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git extension).
            - ref (str): The commit reference (e.g., branch, tag, or SHA).
            - credential (dict): Caller-supplied credentials containing 'token' and optionally 'headers'.
    
    Returns:
        dict or None: The decoded JSON response if successful. Returns None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    ref = inputs["ref"]
    credential = inputs["credential"]

    # Construct the API URL for GitHub REST API version 2026-03-10
    url = f"https://api.github.com/repos/{owner}/{repo}/commits/{ref}"

    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Add token if provided in credential
    if "token" in credential:
        headers["Authorization"] = f"Bearer {credential['token']}"

    # Optionally add custom headers from credential
    if "headers" in credential:
        headers.update(credential["headers"])

    response = requests.get(url, headers=headers)

    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"Failed to fetch commit: HTTP {response.status_code} - {response.text}")

    return response.json() if response.text else None