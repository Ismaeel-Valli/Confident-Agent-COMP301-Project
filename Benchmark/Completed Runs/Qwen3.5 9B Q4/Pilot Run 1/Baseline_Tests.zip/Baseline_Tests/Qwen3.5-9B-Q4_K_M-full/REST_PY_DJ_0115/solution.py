import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API with provided price and title.
    
    Args:
        inputs (dict): Contains 'new_price' and 'new_title' keys.
        
    Returns:
        str or None: The response's title value if present, otherwise None for empty success responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    new_price = inputs['new_price']
    new_title = inputs['new_title']
    
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": new_title,
        "body": "",
        "userId": 1
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    return data.get('title')