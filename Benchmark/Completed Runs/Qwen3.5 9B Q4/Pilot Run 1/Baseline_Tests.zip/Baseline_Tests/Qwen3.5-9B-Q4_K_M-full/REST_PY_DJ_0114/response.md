```python
import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    new_price = inputs['new_price']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"price": new_price}
    
    response = requests.patch(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product: {response.text}")
    
    data = response.json()
    
    if 'title' in data and data['title'] is not None:
        return data['title']
    elif len(data) == 0:
        return None
    else:
        return None
```