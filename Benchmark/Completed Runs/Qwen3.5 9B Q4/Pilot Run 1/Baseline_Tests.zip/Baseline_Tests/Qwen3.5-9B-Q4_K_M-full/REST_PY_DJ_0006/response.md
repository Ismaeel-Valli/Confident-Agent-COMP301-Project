```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing 'new_title' for the product title.
        
    Returns:
        None if the request is successful (empty response).
        The decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    # Prepare the payload with the new title
    payload = {
        "title": inputs["new_title"]
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code == 201:
        # DummyJSON returns an empty body for successful POST to /posts
        return None
    elif response.status_code >= 400:
        raise Exception(f"Failed to submit product. HTTP Status Code: {response.status_code}, Response: {response.text}")
    
    # For any other status code, return the decoded JSON if available
    try:
        return response.json()
    except ValueError:
        raise Exception(f"Unexpected response format for status code {response.status_code}: {response.text}")
```