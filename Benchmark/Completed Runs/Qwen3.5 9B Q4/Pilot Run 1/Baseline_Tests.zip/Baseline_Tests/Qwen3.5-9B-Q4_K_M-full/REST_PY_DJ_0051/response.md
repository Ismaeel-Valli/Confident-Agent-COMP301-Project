```python
import requests

def solve(inputs):
    resource_id = inputs.get('resource_id')
    
    url = f"https://dummyjson.com/users/{resource_id}"
    headers = {
        "Accept": "application/json"
    }
    
    try:
        response = requests.delete(url, headers=headers)
        
        if response.status_code != 200:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
        
        response_data = response.json()
        
        if 'isDeleted' in response_data:
            return response_data['isDeleted']
        else:
            return None
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```