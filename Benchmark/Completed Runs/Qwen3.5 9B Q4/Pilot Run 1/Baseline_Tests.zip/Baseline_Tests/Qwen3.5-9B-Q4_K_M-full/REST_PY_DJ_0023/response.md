```python
import requests

def solve(inputs):
    """
    Submits a new todo to DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'new_completed': value for the completed attribute
            - 'new_todo': value for the todo attribute
            - 'new_user_identifier': value for the user Id attribute
    
    Returns:
        None if the response is successfully empty.
        The decoded JSON response otherwise.
    
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    url = "https://dummyjson.com/todos"
    
    payload = {
        "completed": inputs["new_completed"],
        "todo": inputs["new_todo"],
        "userId": inputs["new_user_identifier"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
    
    response_data = response.json()
    
    # DummyJSON returns an empty object {} on success for POST /todos
    if not response_data:
        return None
    
    return response_data
```