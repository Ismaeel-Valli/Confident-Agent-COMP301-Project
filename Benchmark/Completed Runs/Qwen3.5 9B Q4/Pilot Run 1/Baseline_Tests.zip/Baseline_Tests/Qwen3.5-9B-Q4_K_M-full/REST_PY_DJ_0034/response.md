```python
import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'result_limit' for maximum number of results.
        
    Returns:
        list or None: The decoded JSON response as a list of posts, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/posts"
    
    # Prepare request parameters
    params = {
        "_limit": inputs.get("result_limit", 10)
    }
    
    url = f"{base_url}{endpoint}"
    
    try:
        response = requests.get(url, params=params)
        
        if response.status_code != 200:
            raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
        
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```