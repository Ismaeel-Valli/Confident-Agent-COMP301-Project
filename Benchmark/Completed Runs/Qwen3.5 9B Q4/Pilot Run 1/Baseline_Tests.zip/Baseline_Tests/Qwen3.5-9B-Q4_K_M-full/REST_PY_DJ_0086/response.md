```python
import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on pagination inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip (for pagination).
    
    Returns:
        list or None: The decoded JSON response as a list of users, or None if the response is empty.
    
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful (status code 4xx or 5xx).
    """
    base_url = "https://jsonplaceholder.typicode.com/users"
    
    # Construct query parameters for pagination
    params = {
        "_limit": inputs["result_limit"],
        "_skip": inputs["results_to_skip"]
    }
    
    try:
        response = requests.get(base_url, params=params)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None if the response is empty (though unlikely with this API structure)
        return data if data else None
        
    except requests.exceptions.HTTPError as http_err:
        raise Exception(f"HTTP error occurred: {http_err}")
    except requests.exceptions.RequestException as req_err:
        raise Exception(f"A request error occurred: {req_err}")
```