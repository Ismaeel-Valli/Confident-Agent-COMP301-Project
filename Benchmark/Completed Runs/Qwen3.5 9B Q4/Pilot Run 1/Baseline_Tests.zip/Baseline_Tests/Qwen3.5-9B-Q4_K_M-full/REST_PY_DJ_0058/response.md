```python
import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on the number of results to skip.
    
    Args:
        inputs (dict): A dictionary containing 'results_to_skip' key.
        
    Returns:
        list or None: The decoded JSON response as a list, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    results_to_skip = inputs.get('results_to_skip', 0)
    
    # DummyJSON endpoint for todos with skip parameter
    url = f"https://jsonplaceholder.typicode.com/todos?skip={results_to_skip}&_limit=1"
    
    try:
        response = requests.get(url)
        
        if response.status_code != 200:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
        
        data = response.json()
        
        # Return None for successful empty response
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```