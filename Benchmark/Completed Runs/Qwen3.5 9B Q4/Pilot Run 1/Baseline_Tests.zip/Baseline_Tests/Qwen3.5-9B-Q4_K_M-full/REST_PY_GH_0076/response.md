```python
import requests

def solve(inputs):
    """
    Creates a new issue in a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - new_body (str): The value for the body attribute of the issue.
            - new_title (str): The value for the title attribute of the issue.
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    title = inputs["new_title"]
    body = inputs["new_body"]
    credential = inputs["credential"]
    
    # Construct the URL for creating an issue
    url = f"https://api.github.com/repos/{owner}/{repo}/issues"
    
    # Prepare headers with authentication
    headers = {
        "Authorization": f"Bearer {credential.get('token', '')}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare the payload for the issue creation
    data = {
        "title": title,
        "body": body
    }
    
    # Send POST request to create the issue
    response = requests.post(url, headers=headers, json=data)
    
    # Check if the response is successful
    if response.status_code == 201:
        return response.json()
    elif response.status_code == 204:
        return None
    else:
        raise Exception(f"Failed to create issue. Status code: {response.status_code}, Response: {response.text}")
```