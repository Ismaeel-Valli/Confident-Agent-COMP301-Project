import requests
from urllib.parse import urlencode

def solve(inputs):
    """
    Lists repositories for the authenticated user based on GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'credential' (str): The caller-supplied credential (e.g., token or Bearer string).
            - 'visibility' (str, optional): Limit results to repositories with the specified visibility ('public', 'private', or 'internal').
    
    Returns:
        dict or None: The decoded JSON response. Returns None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    # Base URL for GitHub API v3 (standard for user repos listing)
    base_url = "https://api.github.com/user/repos"
    
    params = {}
    
    if 'visibility' in inputs and inputs['visibility'] is not None:
        visibility = inputs['visibility'].lower()
        if visibility not in ['public', 'private', 'internal']:
            raise ValueError(f"Invalid visibility: {inputs['visibility']}. Must be 'public', 'private', or 'internal'.")
        params['visibility'] = visibility
    
    # Prepare headers with the credential
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {inputs['credential']}"
    }
    
    response = requests.get(base_url, headers=headers, params=params)
    
    if response.status_code == 200:
        data = response.json()
        # GitHub returns an empty list [] for no results, which is a successful response.
        return None if len(data) == 0 else data
    elif response.status_code in [401, 403]:
        raise Exception(f"Authentication or Authorization failed: {response.status_code} - {response.text}")
    else:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")