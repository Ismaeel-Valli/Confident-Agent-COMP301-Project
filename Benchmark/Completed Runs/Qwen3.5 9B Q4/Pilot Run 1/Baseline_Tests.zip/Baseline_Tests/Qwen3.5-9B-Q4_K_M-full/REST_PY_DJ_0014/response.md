```python
import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/posts/{resource_id}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        
        if response.status_code == 200 and not response.json():
            return None
        
        return response.json()
    except requests.exceptions.HTTPError as errh:
        raise Exception(f"HTTP Error: {errh}")
    except requests.exceptions.RequestException as err:
        raise Exception(f"Request Error: {err}")
```