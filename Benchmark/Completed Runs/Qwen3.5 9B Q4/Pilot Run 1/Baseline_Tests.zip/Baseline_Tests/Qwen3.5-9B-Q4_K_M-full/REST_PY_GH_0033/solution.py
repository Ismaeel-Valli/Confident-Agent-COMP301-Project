import requests

def solve(inputs):
    """
    Fetches a specific milestone from a GitHub repository using the REST API.
    
    Parameters:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'milestone_number' (int or str): The milestone number to fetch.
            - 'credential' (dict): Caller-supplied credentials with 'token' and optionally 'headers'.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    milestone_number = inputs['milestone_number']
    credential = inputs['credential']

    # Construct the API URL for GitHub REST API version 2026-03-10
    url = f"https://api.github.com/repos/{owner}/{repo}/milestones/{milestone_number}"

    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # If credential contains a 'token', add Authorization header; otherwise use provided headers if any
    if 'token' in credential:
        headers["Authorization"] = f"Bearer {credential['token']}"
    
    if 'headers' in credential:
        headers.update(credential['headers'])

    response = requests.get(url, headers=headers)

    # Raise an exception for unsuccessful HTTP responses (non-2xx)
    if not response.ok:
        raise Exception(f"Failed to fetch milestone. Status code: {response.status_code}, Response: {response.text}")

    # Decode the JSON response
    try:
        data = response.json()
    except ValueError:
        # If response is empty or not JSON, return None for successful empty response
        if response.content == b'':
            return None
        raise Exception(f"Invalid JSON response from GitHub API. Status code: {response.status_code}, Response: {response.text}")

    # Return None for a successful empty response (though milestones usually have data)
    if not data:
        return None

    return data