```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post on DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_user_identifier' (new user ID).
        
    Returns:
        str or None: The response's title value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_user_identifier = inputs['new_user_identifier']
    
    url = f"https://httpbin.org/post"
    data = {
        "id": resource_id,
        "user_id": new_user_identifier
    }
    
    response = requests.post(url, json=data)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    # DummyJSON typically returns an empty object or a specific structure for updates.
    # We check for the 'title' attribute in the response JSON.
    try:
        response_json = response.json()
        title = response_json.get('title')
        
        if title is not None:
            return title
        else:
            # If successful but no title, return None as per instructions for empty responses
            return None
    except ValueError:
        # If response is not JSON, treat as empty success
        return None
```