```python
import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON based on sorting criteria.
    
    Args:
        inputs (dict): A dictionary containing:
            - sort_field (str): Field used for ordering (e.g., 'id', 'title')
            - sort_direction (str): Ordering direction ('asc' or 'desc')
    
    Returns:
        list: Decoded JSON response as a list of posts.
        None: If the response is successfully empty.
    
    Raises:
        Exception: For unsuccessful HTTP responses (status code not in 2xx range).
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    # Construct query parameters
    params = {
        '_limit': 1,      # Retrieve one page (one item)
        '_sort': inputs['sort_field'],
        '_order': inputs['sort_direction']
    }
    
    try:
        response = requests.get(base_url, params=params)
        
        # Raise an exception for unsuccessful HTTP responses
        response.raise_for_status()
        
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
        
        return data
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```