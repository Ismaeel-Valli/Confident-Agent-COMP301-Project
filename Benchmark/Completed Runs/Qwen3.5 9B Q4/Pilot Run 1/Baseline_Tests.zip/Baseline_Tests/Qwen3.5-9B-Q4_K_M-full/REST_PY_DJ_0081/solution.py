import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on pagination parameters.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip (for pagination).
    
    Returns:
        list or None: The decoded JSON response as a list of todos, or None if the response is empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/todos"
    
    params = {
        "_limit": inputs.get("result_limit", 10),
        "_skip": inputs.get("results_to_skip", 0)
    }
    
    try:
        response = requests.get(f"{base_url}{endpoint}", params=params)
        response.raise_for_status()
        
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
            
        return data
    
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Failed to retrieve todos: {str(e)}") from e