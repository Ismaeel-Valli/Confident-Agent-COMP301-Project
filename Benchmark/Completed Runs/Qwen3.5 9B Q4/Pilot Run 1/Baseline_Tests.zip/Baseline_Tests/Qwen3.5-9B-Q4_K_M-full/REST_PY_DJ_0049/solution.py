import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON, skipping a specified number of results.
    
    Args:
        inputs (dict): A dictionary containing 'results_to_skip' as an integer.
        
    Returns:
        dict or None: The decoded JSON response if successful and data exists, 
                      None if the response is successful but empty.
                      
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com/users"
    
    # Validate inputs
    if not isinstance(inputs, dict):
        raise ValueError("Inputs must be a dictionary.")
        
    results_to_skip = inputs.get('results_to_skip')
    if results_to_skip is None:
        raise ValueError("Missing 'results_to_skip' in inputs.")
        
    if not isinstance(results_to_skip, int) or results_to_skip < 0:
        raise ValueError("'results_to_skip' must be a non-negative integer.")
    
    # Construct the API URL with skip parameter
    url = f"{base_url}?skip={results_to_skip}"
    
    try:
        response = requests.get(url)
        
        # Raise an exception for unsuccessful HTTP responses (status code not in 2xx range)
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
            
        return data
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")