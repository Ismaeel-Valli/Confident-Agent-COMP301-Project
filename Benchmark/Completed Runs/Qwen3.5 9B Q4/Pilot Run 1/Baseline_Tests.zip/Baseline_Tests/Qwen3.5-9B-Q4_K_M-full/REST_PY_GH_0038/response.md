```python
import requests

def solve(inputs):
    """
    Fetches a pull request from the GitHub REST API (version 2026-03-10).
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git extension).
            - pull_number (int): The number that identifies the pull request.
            - credential (str): The caller-supplied credential (e.g., token or Bearer string).
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    pr_number = inputs["pull_number"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}"
    
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    if credential:
        headers["Authorization"] = f"Bearer {credential}"

    response = requests.get(url, headers=headers)

    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"Failed to fetch pull request. Status code: {response.status_code}, Response: {response.text}")

    return response.json() if response.text else None
```