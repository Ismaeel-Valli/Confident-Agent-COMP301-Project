import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on skip count and included fields.
    
    Args:
        inputs (dict): A dictionary containing:
            - results_to_skip (int): Number of results to skip.
            - included_fields (str): Comma-separated list of fields to include.
    
    Returns:
        dict or None: Decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com/users"
    
    # Parse included_fields
    fields_list = [f.strip() for f in inputs["included_fields"].split(",")]
    
    # Construct query parameters
    params = {
        "_limit": 1,
        "_skip": inputs["results_to_skip"],
        "_fields": ",".join(fields_list)
    }
    
    try:
        response = requests.get(base_url, params=params)
        
        if response.status_code != 200:
            raise Exception(f"HTTP Error: Status code {response.status_code}")
        
        data = response.json()
        
        # Return None for empty response
        if not data:
            return None
        
        return data
    
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")