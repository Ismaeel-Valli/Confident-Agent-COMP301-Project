```python
import requests

def solve(inputs):
    """
    Creates a milestone in a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - new_title (str): The title for the new milestone.
            - credential (dict): Caller-supplied credentials (e.g., token in 'token' key).
    
    Returns:
        dict or None: Decoded JSON response if successful, None for an empty successful response.
    
    Raises:
        Exception: If the HTTP response indicates failure (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    title = inputs["new_title"]
    credential = inputs["credential"]

    # Construct the API URL for creating a milestone
    url = f"https://api.github.com/repos/{owner}/{repo}/milestones"

    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential.get('token', '')}"
    }

    # Prepare the payload for the new milestone
    data = {
        "title": title
    }

    # Send POST request to create the milestone
    response = requests.post(url, headers=headers, json=data)

    # Check if the request was successful (2xx status codes)
    if response.status_code == 201:
        # GitHub typically returns an empty body for a successful creation of a milestone
        return None
    elif response.status_code >= 400:
        raise Exception(f"Failed to create milestone. Status code: {response.status_code}, Response: {response.text}")
    
    # Handle other unexpected status codes by raising an exception
    else:
        raise Exception(f"Unexpected status code: {response.status_code}, Response: {response.text}")
```