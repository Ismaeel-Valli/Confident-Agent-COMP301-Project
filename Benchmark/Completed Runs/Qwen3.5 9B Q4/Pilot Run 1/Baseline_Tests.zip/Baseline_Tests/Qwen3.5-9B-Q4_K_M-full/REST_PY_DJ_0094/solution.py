import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the product.
            - new_price (float/int): New value for the price attribute.
    
    Returns:
        None if the response is successfully empty.
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_price = inputs['new_price']
    
    # DummyJSON API endpoint for updating a product
    url = f"https://dummyjson.com/products/{resource_id}"
    
    payload = {
        "price": new_price
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product. Status code: {response.status_code}, Response: {response.text}")
    
    # DummyJSON returns an empty body on successful PUT for this endpoint
    if not response.text.strip():
        return None
    
    return response.json()