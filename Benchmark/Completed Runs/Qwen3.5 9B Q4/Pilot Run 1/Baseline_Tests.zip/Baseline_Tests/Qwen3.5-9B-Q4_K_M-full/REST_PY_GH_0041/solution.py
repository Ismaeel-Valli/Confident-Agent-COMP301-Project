import requests

def solve(inputs):
    """
    Lists files in a specific pull request for a GitHub repository.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - pull_number (int): The number identifying the pull request.
            - credential (dict): Caller-supplied credentials (e.g., token in 'token' key).
    
    Returns:
        dict or None: Decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    pr_number = inputs["pull_number"]
    credential = inputs["credential"]

    # Construct the API URL for GitHub REST API version 2026-03-10
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}/files"

    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Prepare authentication header from the credential dict
    if isinstance(credential, dict):
        token = credential.get("token")
        if not token:
            raise ValueError("Missing 'token' in credential dictionary.")
        headers["Authorization"] = f"Bearer {token}"
    else:
        raise ValueError("Credential must be a dictionary containing a 'token'.")

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        data = response.json()
        return None if not data else data
    elif response.status_code in (401, 403):
        raise Exception(f"Authentication or permission error: {response.status_code} - {response.text}")
    else:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")