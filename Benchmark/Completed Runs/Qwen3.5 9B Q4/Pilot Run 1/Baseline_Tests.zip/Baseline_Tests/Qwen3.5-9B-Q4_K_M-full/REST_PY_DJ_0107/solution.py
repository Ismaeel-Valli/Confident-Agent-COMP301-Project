import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_email' (new email value).
        
    Returns:
        str or None: The response's 'id' value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    new_email = inputs.get('new_email')
    
    # Construct the update payload
    payload = {
        "email": new_email
    }
    
    # DummyJSON API endpoint for updating a user
    url = f"https://httpbin.org/put"
    
    try:
        response = requests.put(url, json=payload)
        
        if response.status_code != 200:
            raise Exception(f"HTTP {response.status_code}: Update failed")
            
        # Check if 'id' is present in the response JSON
        response_data = response.json()
        return response_data.get('id')
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")