import requests

def solve(inputs):
    """
    Submits a new post to DummyJSON API with provided title, body, and user identifier.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'new_body': str, value for the body attribute
            - 'new_title': str, value for the title attribute
            - 'new_user_identifier': str, value for the user Id attribute
    
    Returns:
        None if the response is successful and empty.
        The decoded JSON response if it contains data.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    payload = {
        "title": inputs["new_title"],
        "body": inputs["new_body"],
        "userId": inputs["new_user_identifier"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to submit post. Status code: {response.status_code}. Response: {response.text}")
    
    return None if response.status_code == 201 else response.json()