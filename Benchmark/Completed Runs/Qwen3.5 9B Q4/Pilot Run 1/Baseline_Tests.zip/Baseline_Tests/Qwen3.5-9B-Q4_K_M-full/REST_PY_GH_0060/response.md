```python
import requests

def solve(inputs):
    """
    Unstars a repository for the authenticated user via GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner': str, the account owner of the repository
            - 'repository_name': str, the name of the repository (without .git)
            - 'credential': dict, assumed to have necessary permissions and authentication info.
                          Expected keys: 'token' for Authorization header.
    
    Returns:
        int: The successful HTTP status code (e.g., 204).
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    credential = inputs['credential']
    
    # Construct the API endpoint for unstar (GitHub v2026-03-10 follows standard REST patterns)
    url = f"https://api.github.com/repos/{owner}/{repo}/star"
    
    headers = {
        "Authorization": f"token {credential.get('token', '')}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    response = requests.delete(url, headers=headers)
    
    if response.status_code == 204:
        return response.status_code
    else:
        raise Exception(f"Failed to unstar repository. Status code: {response.status_code}, Response: {response.text}")
```