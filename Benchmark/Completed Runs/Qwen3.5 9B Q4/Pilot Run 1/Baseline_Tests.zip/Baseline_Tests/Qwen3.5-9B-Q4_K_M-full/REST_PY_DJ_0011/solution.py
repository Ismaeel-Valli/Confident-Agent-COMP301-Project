import requests

def solve(inputs):
    """
    Searches for users using a search term from the inputs dictionary.
    
    Args:
        inputs (dict): A dictionary containing 'search_text' as the search term.
        
    Returns:
        list or None: The decoded JSON response if successful, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    search_text = inputs.get('search_text')
    
    # Construct the URL and parameters for the DummyJSON API
    url = "https://httpbin.org/get"  # Using httpbin as a proxy to demonstrate logic; replace with actual DummyJSON endpoint if available
    
    # Note: Since 'DummyJSON' is not a single, universally accessible public API without specific documentation or a base URL,
    # and the prompt implies searching users, we will assume a hypothetical endpoint structure.
    # However, to adhere strictly to "Do not execute" and provide a robust template based on common patterns:
    # We will use httpbin to simulate the request structure if a real DummyJSON isn't provided, 
    # but the logic below is designed for a generic 'search_users' endpoint.
    
    # Hypothetical endpoint for DummyJSON (adjust base_url as per actual DummyJSON service)
    base_url = "https://httpbin.org"  # Placeholder; replace with actual DummyJSON base URL if known
    
    endpoint = "/get"  # Placeholder; replace with actual search endpoint like "/users/search"
    
    params = {
        "search_text": search_text
    }
    
    try:
        response = requests.get(f"{base_url}{endpoint}", params=params)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Decode the JSON response
        json_response = response.json()
        
        # Return None for a successful empty response
        if not json_response:
            return None
            
        return json_response
        
    except requests.exceptions.HTTPError as errh:
        raise Exception(f"HTTP Error: {errh}")
    except requests.exceptions.ConnectionError as errc:
        raise Exception(f"Connection Error: {errc}")
    except requests.exceptions.Timeout as errt:
        raise Exception(f"Timeout Error: {errt}")
    except requests.exceptions.RequestException as err:
        raise Exception(f"Request Error: {err}")