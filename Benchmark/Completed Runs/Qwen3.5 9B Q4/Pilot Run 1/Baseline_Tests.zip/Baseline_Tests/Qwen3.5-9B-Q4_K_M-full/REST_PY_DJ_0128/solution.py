import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on skip count and sort field.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'results_to_skip' (int): Number of results to skip.
            - 'sort_field' (str): Field used for ordering the results.
    
    Returns:
        list or None: The decoded JSON response as a list, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    # Construct query parameters
    params = {
        'skip': inputs['results_to_skip'],
        'sort': inputs['sort_field']
    }
    
    try:
        response = requests.get(base_url, params=params)
        
        # Raise an exception for unsuccessful HTTP responses (non-2xx status codes)
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None if the response is empty
        return data if data else None
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"HTTP request failed: {e}")