import requests
from urllib.parse import quote

def solve(inputs):
    """
    Updates a label on a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - name (str): The name of the label to update.
            - new_color (str): The new hex color value for the label.
            - credential (dict): Caller-supplied credentials (e.g., {'token': 'ghx_...'}).
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    label_name = inputs["name"]
    new_color = inputs["new_color"]
    credential = inputs["credential"]

    # Construct the API URL for updating a label
    url = f"https://api.github.com/repos/{quote(owner)}/{quote(repo)}/labels/{quote(label_name)}"
    
    # Prepare headers with authentication
    headers = {
        "Authorization": f"Bearer {credential.get('token', '')}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Prepare the payload for updating the label color
    data = {"color": new_color}

    try:
        response = requests.put(url, headers=headers, json=data)
        
        if response.status_code == 200 or response.status_code == 204:
            return response.json() if response.content else None
        elif response.status_code >= 400:
            raise Exception(f"Failed to update label. Status code: {response.status_code}, Response: {response.text}")
        else:
            raise Exception(f"Unexpected status code: {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Network error occurred while updating the label: {str(e)}")