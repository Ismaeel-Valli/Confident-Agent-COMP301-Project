```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API with provided description and title.
    
    Args:
        inputs (dict): Dictionary containing 'new_description' and 'new_title'.
        
    Returns:
        str or None: The response's title value if present, otherwise None for successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": inputs.get("new_title"),
        "body": inputs.get("new_description")
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    # DummyJSON (jsonplaceholder) returns the created post in the response body
    data = response.json()
    
    return data.get("title")
```