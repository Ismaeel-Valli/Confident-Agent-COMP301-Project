```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API with given category and title.
    
    Args:
        inputs (dict): Contains 'new_category' and 'new_title'.
        
    Returns:
        str or None: The response's title value if present, otherwise None for successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    url = "https://httpbin.org/post"  # Using httpbin as a proxy for DummyJSON-like behavior since actual DummyJSON API structure isn't specified
    
    # Prepare the payload based on inputs
    payload = {
        "category": inputs.get("new_category"),
        "title": inputs.get("new_title")
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses
    if response.status_code >= 400:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    # Check if the response contains a 'title' attribute
    data = response.json()
    
    # Return title if present, otherwise None for successful empty response
    if "title" in data and data["title"]:
        return data["title"]
    else:
        return None
```