import requests

def solve(inputs):
    """
    Updates a GitHub issue using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - issue_number (int): The number that identifies the issue.
            - new_title (str): The new value for the title attribute.
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    new_title = inputs["new_title"]
    credential = inputs["credential"]
    
    # Construct the URL for updating an issue with a new title
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}"
    
    headers = {
        "Authorization": f"token {credential.get('token', '')}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    data = {
        "title": new_title
    }
    
    response = requests.put(url, json=data, headers=headers)
    
    if response.status_code == 200:
        return None  # Successful empty response
    elif response.status_code == 201:
        return response.json()  # New resource created (though PUT usually returns 200 or 204)
    else:
        raise Exception(f"Failed to update issue. Status code: {response.status_code}, Response: {response.text}")