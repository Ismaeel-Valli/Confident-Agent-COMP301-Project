```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'resource_id': Identifier of the todo to update.
            - 'new_todo': The new value for the todo attribute.
    
    Returns:
        None if the HTTP response is successful and empty.
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_todo = inputs['new_todo']
    
    # Construct the payload for updating the todo
    payload = {
        "todo": new_todo
    }
    
    # Endpoint to update a specific todo by ID in DummyJSON
    url = f"https://jsonplaceholder.typicode.com/todos/{resource_id}"
    
    try:
        response = requests.put(url, json=payload)
        
        if response.status_code == 200:
            # Assuming successful empty response for PUT operations as per typical REST conventions
            return None
        elif response.status_code == 404:
            raise Exception(f"Resource not found: {resource_id}")
        else:
            response.raise_for_status()
    except requests.exceptions.RequestException as e:
        raise Exception(f"An error occurred while updating the todo: {str(e)}")

# Example usage (not executed):
# inputs = {'resource_id': 1, 'new_todo': 'Learn to code'}
# result = solve(inputs)
```