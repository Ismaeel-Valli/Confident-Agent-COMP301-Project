```python
import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on included fields.
    
    Args:
        inputs (dict): A dictionary containing 'included_fields' as a comma-separated string.
        
    Returns:
        list or None: The decoded JSON response (list of todos) if successful, 
                      None for an empty response.
                      
    Raises:
        requests.exceptions.RequestException: If the HTTP response is unsuccessful.
    """
    included_fields = inputs.get('included_fields', '')
    
    # Construct the URL with query parameters for fields
    url = "https://jsonplaceholder.typicode.com/todos?_limit=1"
    
    # Add fields parameter if specified
    if included_fields:
        url += f"&fields={included_fields}"
    
    try:
        response = requests.get(url)
        
        # Raise an exception for unsuccessful HTTP responses
        response.raise_for_status()
        
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise e
```