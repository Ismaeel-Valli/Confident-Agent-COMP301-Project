```python
import requests

def solve(inputs):
    """
    Fetches a GitHub user by username using the provided credentials.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The GitHub username to fetch.
            - 'credential' (dict): Contains authentication details (e.g., token).
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    username = inputs["username"]
    credential = inputs["credential"]
    
    # Construct the URL for fetching a user by username
    url = f"https://api.github.com/users/{username}"
    
    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github+json"
    }
    
    # Add authorization header if token is provided
    if "token" in credential:
        headers["Authorization"] = f"Bearer {credential['token']}"
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        return None if not data else data
    elif response.status_code == 404:
        # Assuming resources exist as per instructions, but handling gracefully
        raise Exception(f"User '{username}' not found.")
    else:
        raise Exception(f"Failed to fetch user. Status code: {response.status_code}, Response: {response.text}")
```