```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the product.
            - new_description (str): New value for the description attribute.
    
    Returns:
        None if the response is empty (successful update).
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    resource_id = inputs['resource_id']
    new_description = inputs['new_description']
    
    # Construct the URL for updating a specific product in DummyJSON
    url = f"https://dummyjson.com/products/{resource_id}"
    
    # Prepare the payload with the new description
    payload = {
        "description": new_description
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product. Status code: {response.status_code}, Response: {response.text}")
    
    # DummyJSON returns an empty body on successful PUT for this endpoint
    if not response.text.strip():
        return None
    
    return response.json()
```