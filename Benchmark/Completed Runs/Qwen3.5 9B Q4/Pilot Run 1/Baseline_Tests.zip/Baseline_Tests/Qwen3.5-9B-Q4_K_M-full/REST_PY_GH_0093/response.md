```python
import requests

def solve(inputs):
    """
    Lists stargazers for a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'page_size' (int): Number of results per page (max 100).
            - 'credential' (str): Bearer token or OAuth token for authentication.
    
    Returns:
        list[dict] | None: Decoded JSON response containing stargazers, or None if empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    page_size = inputs["page_size"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{owner}/{repo}/stargazers"
    
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "Authorization": f"Bearer {credential}"
    }

    params = {"per_page": page_size}

    response = requests.get(url, headers=headers, params=params)

    if response.status_code != 200:
        raise Exception(f"Failed to fetch stargazers: HTTP {response.status_code}, body: {response.text}")

    data = response.json()
    
    # Return None for successful empty response
    return data if data else None
```