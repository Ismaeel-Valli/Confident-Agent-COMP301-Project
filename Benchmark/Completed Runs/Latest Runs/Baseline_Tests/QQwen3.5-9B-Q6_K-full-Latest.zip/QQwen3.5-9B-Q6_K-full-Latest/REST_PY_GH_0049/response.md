```python
import requests
from urllib.parse import quote

def solve(inputs):
    """
    Lists watchers for a GitHub repository using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The authentication token or Bearer token.
    
    Returns:
        list or None: A list of watcher objects if there are watchers, 
                      None if the response is successfully empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{quote(owner)}/{quote(repo)}/network/members"
    
    headers = {
        'Accept': 'application/vnd.github+json',
        'Authorization': f'Bearer {credential}'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to list watchers. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # GitHub API returns an empty list [] for no watchers, not null.
    # The requirement says "Return None for a successful empty response".
    if len(data) == 0:
        return None
    
    return data
```