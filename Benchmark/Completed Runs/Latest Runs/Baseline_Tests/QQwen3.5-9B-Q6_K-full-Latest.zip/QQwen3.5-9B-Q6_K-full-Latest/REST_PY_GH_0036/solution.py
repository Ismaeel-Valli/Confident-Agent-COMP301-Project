import requests
from urllib.parse import quote

def solve(inputs):
    """
    Lists pull requests for a given GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository.
            - 'credential' (str): The authentication token or bearer token string.
    
    Returns:
        list | None: A list of decoded JSON objects representing pull requests, 
                     or None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response status code indicates an error.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{quote(owner)}/{quote(repo)}/pulls"
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch pull requests. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # GitHub API returns an empty list [] for no PRs, not null. 
    # The requirement says "Return None for a successful empty response".
    if len(data) == 0:
        return None
    
    return data