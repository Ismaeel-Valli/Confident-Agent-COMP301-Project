import requests

def solve(inputs):
    """
    Lists commits on a pull request for GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - pull_number (int): The number that identifies the pull request.
            - page_size (int): The number of results per page (max 100).
            - credential (str): The caller-supplied credential (e.g., token or Bearer token).
    
    Returns:
        list | None: A list of decoded JSON responses for each page, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    pull_number = inputs["pull_number"]
    page_size = inputs["page_size"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/pulls/{pull_number}/commits"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }

    params = {"per_page": page_size}

    all_commits = []

    while True:
        response = requests.get(url, headers=headers, params=params)
        
        if response.status_code != 200:
            raise Exception(f"Failed to fetch commits: HTTP {response.status_code}")

        data = response.json()
        
        if not data:
            return None
        
        all_commits.extend(data)
        
        # Check for pagination
        link_header = response.headers.get("Link", "")
        next_url = None
        for part in link_header.split(","):
            if "rel=\"next\"" in part:
                next_url = part.split(";")[0].strip().split(">")[1]
                break
        
        if not next_url:
            break

        # Prepare params for the next page
        params["page"] = int(params.get("page", 1)) + 1

    return all_commits