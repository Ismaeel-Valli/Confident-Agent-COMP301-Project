import requests
from datetime import datetime

def solve(inputs):
    """
    Fetches issue comments from a GitHub repository using the REST API version 2026-03-10.
    
    Parameters:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - issue_number (int): The number that identifies the issue.
            - since (str, optional): ISO 8601 timestamp to filter comments updated after this time.
            - credential (str): Bearer token for authentication.
    
    Returns:
        list or None: A list of decoded JSON comment objects if results exist; None if the response is empty.
    
    Raises:
        Exception: If the HTTP response status code indicates an error.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    since = inputs.get("since")
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}/comments"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    params = {}
    if since:
        # Ensure the 'since' parameter is in ISO 8601 format
        params["since"] = since

    response = requests.get(url, headers=headers, params=params)

    if response.status_code != 200:
        raise Exception(f"Failed to fetch issue comments. Status code: {response.status_code}, Response: {response.text}")

    data = response.json()
    
    # GitHub returns an empty list [] for no results, not null. 
    # The requirement says return None for a successful empty response.
    if not data:
        return None
    
    return data