```python
import requests

def solve(inputs):
    """
    Retrieves a product by identifier from DummyJSON and returns its title.
    
    Args:
        inputs (dict): A dictionary containing 'resource_id' as the product identifier.
        
    Returns:
        str or None: The title of the product, None if title is absent or response is empty.
        
    Raises:
        requests.exceptions.HTTPError: If the HTTP response status code indicates an error.
    """
    resource_id = inputs.get('resource_id')
    
    url = f"https://dummyjson.com/products/{resource_id}"
    response = requests.get(url)
    
    if response.status_code != 200:
        raise requests.exceptions.HTTPError(f"HTTP {response.status_code} error")
    
    data = response.json()
    
    # Handle empty response or missing title
    if not data or 'title' not in data:
        return None
        
    return data['title']
```