```python
import requests
from urllib.parse import quote

def solve(inputs):
    """
    Lists stargazers for a given GitHub repository using the specified API version.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The caller-supplied credential (e.g., token or Bearer string).
    
    Returns:
        list or None: A list of stargazers if any exist, otherwise None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    credential = inputs["credential"]

    # Construct the API URL for version 2026-03-10
    url = f"https://api.github.com/repos/{quote(repository_owner, safe='')}/{quote(repository_name, safe='')}/stargazers"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }

    response = requests.get(url, headers=headers)

    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"GitHub API request failed with status code {response.status_code}: {response.text}")

    data = response.json()

    # Return None for an empty list of stargazers as per requirement
    return data if data else None
```