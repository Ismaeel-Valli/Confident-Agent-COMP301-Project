import requests

def solve(inputs):
    """
    Searches posts using a search term from DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing 'search_text' key with the search term.
        
    Returns:
        list or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    search_text = inputs.get("search_text", "")
    
    # Note: jsonplaceholder doesn't have a dedicated posts search endpoint with text filtering.
    # We will fetch all posts and filter client-side based on the search term.
    url = f"{base_url}/posts"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        if not data:
            return None
        
        # Filter posts based on search_text in title or body
        filtered_posts = [
            post for post in data 
            if search_text.lower() in post.get("title", "").lower() or 
               search_text.lower() in post.get("body", "").lower()
        ]
        
        return filtered_posts
        
    except requests.exceptions.HTTPError as errh:
        raise Exception(f"HTTP Error occurred: {errh}")
    except requests.exceptions.RequestException as err:
        raise Exception(f"Request failed: {err}")