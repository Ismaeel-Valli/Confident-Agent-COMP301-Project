```python
import requests

def solve(inputs):
    """
    Fetches a specific milestone from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository.
            - 'milestone_number' (int): The number identifying the milestone.
            - 'credential' (str): The caller-supplied credential (e.g., token).
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs['repository_owner']
    repository_name = inputs['repository_name']
    milestone_number = inputs['milestone_number']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/milestones/{milestone_number}"
    
    headers = {
        'Authorization': f'token {credential}',
        'Accept': 'application/vnd.github+json'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch milestone. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json()
```