```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the todo to update.
            - new_user_identifier (str): New value for the user Id attribute.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty but successful.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get("resource_id")
    new_user_identifier = inputs.get("new_user_identifier")

    url = f"https://dummyjson.com/todos/{resource_id}"
    payload = {
        "userId": new_user_identifier
    }

    response = requests.put(url, json=payload)

    if response.status_code != 200:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}")

    return response.json() if response.text else None
```