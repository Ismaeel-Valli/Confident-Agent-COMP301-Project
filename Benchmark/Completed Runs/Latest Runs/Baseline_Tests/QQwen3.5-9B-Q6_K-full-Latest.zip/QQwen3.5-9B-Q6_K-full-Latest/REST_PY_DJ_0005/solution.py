import requests

def solve(inputs):
    """
    Searches for products using DummyJSON API based on the provided search term.
    
    Args:
        inputs (dict): A dictionary containing 'search_text' key with the search term.
        
    Returns:
        list or None: The decoded JSON response as a list of products, or None if the response is empty.
        
    Raises:
        requests.exceptions.HTTPError: If the HTTP response status code indicates an error (4xx or 5xx).
    """
    search_text = inputs.get('search_text')
    
    if not search_text:
        raise ValueError("Search text is required in inputs.")

    url = "https://dummyjson.com/products/search"
    params = {'q': search_text}
    
    response = requests.get(url, params=params)
    
    # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
    response.raise_for_status()
    
    data = response.json()
    
    # Return None for a successful empty response
    if not data.get('products'):
        return None
        
    return data['products']