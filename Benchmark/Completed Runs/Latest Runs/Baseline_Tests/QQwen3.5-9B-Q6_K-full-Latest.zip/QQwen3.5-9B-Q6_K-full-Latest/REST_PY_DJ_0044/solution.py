import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON based on pagination inputs.
    
    Args:
        inputs (dict): A dictionary containing 'results_to_skip' (int).
        
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/products"
    results_to_skip = inputs.get('results_to_skip', 0)
    
    params = {
        'skip': results_to_skip,
        'limit': 1  # Retrieve one page (one item)
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP Error: Status code {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns an empty list for products in some cases or when no items match
    if not data.get('products'):
        return None
        
    return data