import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on the provided sort_field.
    
    Args:
        inputs (dict): A dictionary containing 'sort_field' for ordering posts.
        
    Returns:
        list or None: The decoded JSON response as a list of posts, or None if the response is empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    # Prepare the query parameters
    params = {
        '_limit': 1,  # Retrieve one page (one post)
        '_sort': inputs.get('sort_field', 'id')  # Default to 'id' if not specified
    }
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise e