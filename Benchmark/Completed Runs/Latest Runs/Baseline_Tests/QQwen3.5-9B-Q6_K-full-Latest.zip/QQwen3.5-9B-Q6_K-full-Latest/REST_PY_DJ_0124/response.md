```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API.
    
    Args:
        inputs (dict): Contains 'new_category' and 'new_title'.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty body.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "title": inputs["new_title"],
        "category": inputs["new_category"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code != 201 and response.status_code != 200:
            raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
            
        return response.json()
        
    except requests.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```