import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on provided pagination inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip (offset).
    
    Returns:
        list or None: The decoded JSON response as a list of users, or None if the response is empty.
    
    Raises:
        requests.exceptions.HTTPError: If the HTTP response status code indicates an error.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/users"
    
    params = {
        "limit": inputs.get("result_limit", 10),
        "skip": inputs.get("results_to_skip", 0)
    }
    
    response = requests.get(f"{base_url}{endpoint}", params=params)
    
    if response.status_code != 200:
        raise requests.exceptions.HTTPError(
            f"HTTP {response.status_code} error occurred while fetching users."
        )
    
    data = response.json()
    
    return data if data else None