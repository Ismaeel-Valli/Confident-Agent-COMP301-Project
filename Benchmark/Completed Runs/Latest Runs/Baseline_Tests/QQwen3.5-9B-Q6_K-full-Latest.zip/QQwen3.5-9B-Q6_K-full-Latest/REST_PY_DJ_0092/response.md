```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (todo ID) and 'new_user_identifier' (new user ID).
        
    Returns:
        str or None: The response's id value, or None if the response is empty/successful without an id.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    # Base URL for DummyJSON API
    base_url = "https://jsonplaceholder.typicode.com"
    
    resource_id = inputs.get('resource_id')
    new_user_identifier = inputs.get('new_user_identifier')
    
    if resource_id is None or new_user_identifier is None:
        raise ValueError("Missing required inputs: 'resource_id' and 'new_user_identifier'")
    
    # Endpoint to update a todo
    url = f"{base_url}/todos/{resource_id}"
    
    # Prepare the payload with only the field we want to update
    payload = {
        "userId": new_user_identifier
    }
    
    try:
        response = requests.put(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx and 5xx)
        response.raise_for_status()
        
        # Check if the response is empty
        if not response.text.strip():
            return None
        
        # Parse the JSON response
        try:
            data = response.json()
            
            # Return the id value if present, otherwise None
            return data.get('id')
        except ValueError:
            # If response is not valid JSON but we got a successful status
            return None
            
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP request failed: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request error occurred: {e}")
```