```python
import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing 'page' key with an integer value.
        
    Returns:
        list or None: The decoded JSON response as a list, or None if the response is empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    page = inputs.get('page', 1)
    url = f"https://jsonplaceholder.typicode.com/todos?page={page}"
    
    response = requests.get(url)
    response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
    
    data = response.json()
    
    if not data:
        return None
        
    return data
```