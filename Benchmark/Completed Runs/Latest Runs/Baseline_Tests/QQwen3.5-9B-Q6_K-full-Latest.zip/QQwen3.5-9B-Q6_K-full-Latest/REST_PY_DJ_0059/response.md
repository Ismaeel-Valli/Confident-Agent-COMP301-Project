```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (int): Identifier of the todo.
            - new_completed (bool): Value for the completed attribute.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty (204 No Content).
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs['resource_id']
    new_completed = inputs['new_completed']
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    payload = {"completed": new_completed}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 204:
        return None
    
    if not response.ok:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}")
    
    return response.json()
```