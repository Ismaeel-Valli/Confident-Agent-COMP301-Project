```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_description'.
        
    Returns:
        str or None: The title from the response, or None if successful with empty response.
        Raises: Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_description = inputs['new_description']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {
        "description": new_description
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product. Status code: {response.status_code}")
    
    data = response.json()
    
    # If the response is empty (no content), return None
    if not data:
        return None
    
    # Return the title if present, otherwise None
    return data.get('title')
```