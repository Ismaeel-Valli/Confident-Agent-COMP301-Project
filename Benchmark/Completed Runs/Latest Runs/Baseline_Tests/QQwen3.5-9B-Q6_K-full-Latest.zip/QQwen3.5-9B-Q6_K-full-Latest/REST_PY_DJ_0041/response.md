```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (todo ID) and 'new_todo' (value to update).
        
    Returns:
        str or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_todo_value = inputs.get('new_todo')
    
    # Base URL for DummyJSON Todo API
    base_url = "https://dummyjson.com/todos"
    
    # Prepare the update payload
    payload = {
        "todoId": resource_id,
        "todo": new_todo_value
    }
    
    try:
        response = requests.put(base_url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (no content)
        if not response.text.strip():
            return None
        
        # Parse the JSON response
        data = response.json()
        
        # Return the id value from the response, or None if absent
        return data.get('id')
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```