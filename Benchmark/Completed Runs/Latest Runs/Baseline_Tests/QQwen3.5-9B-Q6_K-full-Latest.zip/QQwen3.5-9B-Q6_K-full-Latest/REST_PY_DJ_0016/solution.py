import requests

def solve(inputs):
    """
    Deletes a post by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (str) of the post to delete.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.exceptions.HTTPError: If the HTTP response status code indicates failure.
    """
    resource_id = inputs['resource_id']
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    try:
        response = requests.delete(url)
        response.raise_for_status()
        
        if response.status_code == 204:
            return None
        
        return response.json()
        
    except requests.exceptions.HTTPError as e:
        raise e