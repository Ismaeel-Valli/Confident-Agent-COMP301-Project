import requests

def solve(inputs):
    """
    Checks if a repository is starred by the authenticated user using GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git extension).
            - 'credential' (str): The authentication token or header value for the API call.
    
    Returns:
        int: The successful HTTP status code (e.g., 200, 204).
    
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/user/starred/{owner}/{repo}"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code not in [200, 204]:
        raise requests.RequestException(f"Failed to check star status: {response.status_code} - {response.text}")
    
    return response.status_code