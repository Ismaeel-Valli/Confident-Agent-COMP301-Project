import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'result_limit' (int).
        
    Returns:
        list or None: The decoded JSON response as a list, or None if the response is empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    result_limit = inputs.get('result_limit', 10)
    
    url = "https://jsonplaceholder.typicode.com/todos"
    params = {'_limit': result_limit}
    
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        
        data = response.json()
        
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise SystemExit(f"HTTP request failed: {e}")