```python
import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on skip parameter.
    
    Args:
        inputs (dict): Dictionary containing 'results_to_skip' key.
        
    Returns:
        dict or None: Decoded JSON response, or None if successful but empty.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    results_to_skip = inputs.get('results_to_skip', 0)
    
    # DummyJSON API endpoint for posts with pagination support
    url = "https://jsonplaceholder.typicode.com/posts"
    
    params = {
        'skip': results_to_skip,
        'limit': 1  # Retrieve one page (one result)
    }
    
    response = requests.get(url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP request failed with status code: {response.status_code}")
    
    data = response.json()
    
    # Return None for successful empty response
    if not data:
        return None
    
    return data
```