```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API with the provided first name.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' key.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/users/add"
    
    payload = {
        "firstName": inputs["new_firstName"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        if response.status_code == 200:
            data = response.json()
            # DummyJSON returns empty object on success for this endpoint
            return None if not data else data
        elif response.status_code == 400:
            raise Exception(f"Bad Request: {response.text}")
        elif response.status_code == 401:
            raise Exception("Unauthorized: Invalid or missing authentication")
        elif response.status_code == 403:
            raise Exception("Forbidden: Access denied")
        elif response.status_code == 500:
            raise Exception(f"Internal Server Error: {response.text}")
        else:
            raise Exception(f"HTTP Error {response.status_code}: {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```