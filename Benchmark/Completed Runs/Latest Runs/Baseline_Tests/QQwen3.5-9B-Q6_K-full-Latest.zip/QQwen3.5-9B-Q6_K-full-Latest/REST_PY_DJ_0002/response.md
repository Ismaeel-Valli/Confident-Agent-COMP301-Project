```python
import requests

def solve(inputs):
    """
    Retrieves a product by identifier from DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing 'resource_id' (str) as the product identifier.
        
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
        
    Raises:
        requests.HTTPError: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON endpoint to get a specific product by ID
    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # DummyJSON returns an empty object {} when a product is not found, 
        # but the problem states to assume referenced resources exist.
        # However, if the response body is empty string (rare in JSON APIs unless explicitly set), handle it.
        # Based on standard DummyJSON behavior for existing IDs: it returns the product object.
        # If the API returns an empty list or object specifically defined as "empty" by the user's context, return None.
        # Since the prompt says "Return None for a successful empty response", we check if data is effectively empty.
        
        if not data:
            return None
            
        return data
        
    except requests.exceptions.HTTPError as e:
        raise e
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"An error occurred while requesting the resource: {e}")
```