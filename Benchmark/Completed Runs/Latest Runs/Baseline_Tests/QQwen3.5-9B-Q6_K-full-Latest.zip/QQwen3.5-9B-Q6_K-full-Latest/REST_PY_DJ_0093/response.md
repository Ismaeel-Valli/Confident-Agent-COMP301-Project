```python
import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - included_fields (str): Comma-separated list of fields to include in the response.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request is unsuccessful.
    """
    base_url = "https://dummyjson.com/products"
    
    # Parse included_fields into a list
    fields_list = [field.strip() for field in inputs['included_fields'].split(',')]
    
    params = {
        'limit': inputs['result_limit'],
        'select': ','.join(fields_list)
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise requests.exceptions.RequestException(f"HTTP request failed with status code: {response.status_code}")
    
    data = response.json()
    
    # Return None for a successful empty response
    if not data.get('products'):
        return None
    
    return data
```