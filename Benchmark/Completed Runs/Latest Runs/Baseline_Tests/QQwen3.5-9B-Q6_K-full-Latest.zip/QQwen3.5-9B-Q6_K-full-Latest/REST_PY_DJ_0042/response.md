```python
import requests

def solve(inputs):
    """
    Deletes a todo by identifier using DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (identifier of the todo).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON delete endpoint for todos
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    try:
        response = requests.delete(url)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Return the id from response data if present
        if response.json():
            return response.json().get('id')
        else:
            return None
            
    except requests.exceptions.HTTPError as e:
        raise e
    except requests.exceptions.RequestException as e:
        raise e
```