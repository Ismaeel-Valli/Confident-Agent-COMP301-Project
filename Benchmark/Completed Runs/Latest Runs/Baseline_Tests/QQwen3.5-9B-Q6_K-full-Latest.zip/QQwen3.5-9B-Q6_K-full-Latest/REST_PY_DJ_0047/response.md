```python
import requests

def solve(inputs):
    """
    Deletes a product by identifier from DummyJSON and returns the title of the response,
    or None if the title is absent or the response is empty (successful deletion).
    Raises an exception for unsuccessful HTTP responses.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (product identifier).
        
    Returns:
        str or None: The title of the response, or None if absent or successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON API endpoint for deleting a product
    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.delete(url)
        
        # Raise an exception for unsuccessful HTTP responses (status code not in 200-299 range)
        response.raise_for_status()
        
        # Check if the response is empty (successful deletion often returns empty JSON {})
        if not response.json():
            return None
        
        # Return the title value if present, otherwise None
        data = response.json()
        return data.get('title')
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```