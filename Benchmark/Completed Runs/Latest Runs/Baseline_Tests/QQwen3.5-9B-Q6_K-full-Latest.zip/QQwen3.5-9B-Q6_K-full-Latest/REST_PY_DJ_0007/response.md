```python
import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing 'page' key with an integer value.
        
    Returns:
        list or None: The decoded JSON response as a list of users, or None if the list is empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    page = inputs.get('page', 1)
    
    url = f"{base_url}/users?page={page}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        
        data = response.json()
        
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise SystemExit(f"HTTP request failed: {e}")
```