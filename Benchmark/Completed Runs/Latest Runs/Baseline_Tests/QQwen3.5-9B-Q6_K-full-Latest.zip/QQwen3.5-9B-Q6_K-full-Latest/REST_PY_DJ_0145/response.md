```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_username'.
        
    Returns:
        int or None: The ID of the created user, or None if response is empty.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    url = "https://dummyjson.com/users/add"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "username": inputs["new_username"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to create user. Status code: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns the created user in the 'user' key for POST /users/add
    if "user" in data and data["user"]:
        return data["user"].get("id")
    elif "id" in data:
        return data["id"]
    else:
        return None
```