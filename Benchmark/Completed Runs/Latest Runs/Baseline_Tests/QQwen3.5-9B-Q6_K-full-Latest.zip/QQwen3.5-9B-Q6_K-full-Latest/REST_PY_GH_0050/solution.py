import requests
import json

def solve(inputs):
    """
    Lists repository tags for a given GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The authentication token or Bearer token for the API.
    
    Returns:
        list | None: A list of tag objects if tags exist, or None if the response is empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails or returns an unsuccessful status code.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/tags"
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to fetch tags. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    return None if not data else data