```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API.
    
    Args:
        inputs (dict): Contains 'new_description' and 'new_title'.
        
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty body.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "description": inputs["new_description"],
        "title": inputs["new_title"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code == 201:
            return None
        elif response.status_code == 400:
            # Bad request - might be due to missing fields or validation errors
            raise Exception(f"Bad Request: {response.text}")
        else:
            # Any other unsuccessful status code
            raise Exception(f"Failed to submit product. Status Code: {response.status_code}, Response: {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")

# Example usage (not executed):
# inputs = {"new_description": "A sample product", "new_title": "Sample Product"}
# result = solve(inputs)
```