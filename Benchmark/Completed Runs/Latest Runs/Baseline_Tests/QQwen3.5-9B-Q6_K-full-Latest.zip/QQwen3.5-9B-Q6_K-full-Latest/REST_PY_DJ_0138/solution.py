import requests

def solve(inputs):
    """
    Updates selected fields of a post in DummyJSON and returns the response's id value,
    or None if that attribute is absent or for a successful empty response.
    Raises an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (int): Identifier of the post to update.
            - new_body (str): New value for the body attribute.
            - new_title (str): New value for the title attribute.
    
    Returns:
        str or None: The ID of the updated post, or None if absent or empty response.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    resource_id = inputs['resource_id']
    new_body = inputs['new_body']
    new_title = inputs['new_title']

    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    payload = {
        "body": new_body,
        "title": new_title
    }

    try:
        response = requests.put(url, json=payload)
        response.raise_for_status()  # Raises HTTPError for bad responses (4xx or 5xx)

        if response.status_code == 200 and len(response.text.strip()) == 0:
            return None
        
        data = response.json()
        return data.get('id')
    
    except requests.RequestException as e:
        raise e