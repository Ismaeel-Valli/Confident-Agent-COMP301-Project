```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_lastName'.
        
    Returns:
        None if the response is successful and empty.
        The decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    url = "https://dummyjson.com/users/add"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "lastName": inputs["new_lastName"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to submit user. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # DummyJSON returns an empty object {} on success for this endpoint
    if not data:
        return None
    
    return data
```