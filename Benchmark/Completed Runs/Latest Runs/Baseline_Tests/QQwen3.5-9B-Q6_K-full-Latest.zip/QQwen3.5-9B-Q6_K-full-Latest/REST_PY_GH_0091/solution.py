import requests

def solve(inputs):
    """
    Creates a release on GitHub using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - new_tag_name (str): Value for the tag name attribute.
            - new_target_commitish (str): Value for the target commitish attribute.
            - credential (str): The caller-supplied credential (e.g., token).
    
    Returns:
        dict or None: The decoded JSON response. Returns None for a successful empty response.
    
    Raises:
        Exception: For an unsuccessful HTTP response.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    new_tag_name = inputs["new_tag_name"]
    new_target_commitish = inputs["new_target_commitish"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/releases"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    data = {
        "tag_name": new_tag_name,
        "target_commitish": new_target_commitish
    }

    response = requests.post(url, headers=headers, json=data)

    if response.status_code != 201:
        raise Exception(f"Failed to create release. Status code: {response.status_code}, Response: {response.text}")

    return response.json()