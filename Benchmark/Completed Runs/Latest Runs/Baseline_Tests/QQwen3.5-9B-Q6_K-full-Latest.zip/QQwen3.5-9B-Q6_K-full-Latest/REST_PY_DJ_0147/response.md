```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post on DummyJSON API and returns the title.
    
    Args:
        inputs (dict): Contains 'resource_id', 'new_body', and 'new_title'.
        
    Returns:
        str or None: The title of the updated post, or None if successful but no title in response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_body = inputs['new_body']
    new_title = inputs['new_title']
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    data = {
        "title": new_title,
        "body": new_body
    }
    
    response = requests.put(url, json=data)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update post. Status code: {response.status_code}, Response: {response.text}")
    
    result = response.json()
    
    # Check for successful empty response or missing title
    if not result.get("title"):
        return None
    
    return result["title"]
```