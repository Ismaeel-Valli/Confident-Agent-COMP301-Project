```python
import requests

def solve(inputs):
    """
    Retrieves a specific todo by its identifier from DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing 'resource_id' (str) which is the ID of the todo.
        
    Returns:
        dict or None: The decoded JSON response if successful and data exists, 
                      None if the response is an empty list/object indicating no data.
                      
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs['resource_id']
    
    # DummyJSON endpoint for getting a specific todo by ID
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # DummyJSON returns a single todo object if found, or an empty object {} if not found.
        # The prompt asks to return None for a "successful empty response". 
        # In the context of getting a specific ID, an empty dict usually means "not found" but is still a 200 OK.
        # However, strictly following "Return None for a successful empty response":
        if not data:
            return None
            
        return data
        
    except requests.exceptions.HTTPError as e:
        raise e
    except requests.exceptions.RequestException as e:
        raise e
```