import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON using the provided email and first name.
    
    Args:
        inputs (dict): A dictionary containing 'new_email' and 'new_firstName'.
        
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    url = "https://dummyjson.com/users/add"
    
    payload = {
        "email": inputs["new_email"],
        "firstName": inputs["new_firstName"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code == 200:
            data = response.json()
            return None if not data else data
        elif response.status_code == 400:
            # Bad request, but we'll raise an exception as per instructions for unsuccessful responses
            raise Exception(f"Bad Request: {response.text}")
        else:
            raise Exception(f"HTTP Error {response.status_code}: {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")