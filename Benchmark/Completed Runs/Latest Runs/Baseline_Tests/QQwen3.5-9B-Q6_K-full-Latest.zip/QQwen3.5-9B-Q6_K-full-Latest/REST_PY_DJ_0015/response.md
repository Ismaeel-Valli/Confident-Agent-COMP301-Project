```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post on DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (int): Identifier of the post.
            - new_title (str): New value for the title attribute.
            
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty (204 No Content).
                      
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs['resource_id']
    new_title = inputs['new_title']
    
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    data = {"title": new_title}
    
    response = requests.patch(url, json=data)
    
    if response.status_code == 204:
        return None
    
    if not response.ok:
        raise Exception(f"Failed to update post. Status code: {response.status_code}")
        
    return response.json()
```