```python
import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    new_body = inputs['new_body']
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    payload = {"body": new_body}
    
    response = requests.patch(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    if data.get('title') is None and not data:
        return None
    
    return data.get('title')
```