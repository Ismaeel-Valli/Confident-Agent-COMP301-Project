```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API with given price and title.
    
    Args:
        inputs (dict): Contains 'new_price' and 'new_title' values.
        
    Returns:
        str or None: The title from the response if present, otherwise None for success.
        Raises: Exception for unsuccessful HTTP responses.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "price": inputs["new_price"],
        "title": inputs["new_title"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code != 200:
            raise Exception(f"Failed to submit product. Status code: {response.status_code}")
        
        # For successful submission, DummyJSON typically returns an empty body or a success message
        # The requirement states: "Return None for a successful empty response."
        if not response.text.strip():
            return None
            
        # If there's content but no 'title' attribute in the response body
        data = response.json()
        if "title" not in data:
            return None
            
        return data["title"]
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```