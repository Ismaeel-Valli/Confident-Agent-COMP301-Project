```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (int): Identifier of the product
            - new_category (str): New value for the category attribute
    
    Returns:
        int or None: The response's id value if present, otherwise None.
                     Returns None for a successful empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_category = inputs['new_category']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {
        "category": new_category
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product: HTTP {response.status_code}")
    
    data = response.json()
    
    # Check if the response is empty (no content)
    if not data or 'id' not in data:
        return None
    
    return data['id']
```