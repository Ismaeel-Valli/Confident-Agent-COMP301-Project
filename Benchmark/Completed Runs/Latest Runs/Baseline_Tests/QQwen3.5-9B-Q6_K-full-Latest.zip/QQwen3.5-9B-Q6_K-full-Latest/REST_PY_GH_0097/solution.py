import requests
import json

def solve(inputs):
    """
    Creates a new repository for the authenticated user using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'new_name' (str): The name for the new repository.
            - 'new_description' (str): The description for the new repository.
            - 'credential' (str): The authentication token or header value.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty (success).
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    new_name = inputs['new_name']
    new_description = inputs['new_description']
    credential = inputs['credential']
    
    # GitHub API endpoint for creating a repository for the authenticated user
    url = "https://api.github.com/user/repos"
    
    headers = {
        'Authorization': f'token {credential}',
        'Accept': 'application/vnd.github+json'
    }
    
    data = {
        'name': new_name,
        'description': new_description
    }
    
    response = requests.post(url, json=data, headers=headers)
    
    if response.status_code == 201:
        # GitHub typically returns a JSON object on success, not an empty body for POST
        return response.json()
    elif response.status_code == 202:
        # Accepted (async), but usually returns JSON with location header
        return response.json()
    else:
        raise Exception(f"Failed to create repository. Status code: {response.status_code}, Response: {response.text}")