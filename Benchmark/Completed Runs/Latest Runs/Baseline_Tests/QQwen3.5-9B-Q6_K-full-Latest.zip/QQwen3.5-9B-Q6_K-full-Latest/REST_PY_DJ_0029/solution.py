import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'result_limit' specifying the maximum number of results.
        
    Returns:
        list or None: The decoded JSON response as a list of users, or None if the response is empty.
        
    Raises:
        requests.RequestException: If the HTTP request is unsuccessful.
    """
    result_limit = inputs.get('result_limit', 10)
    
    # DummyJSON endpoint for users with limit parameter
    url = f"https://dummyjson.com/users?limit={result_limit}"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise requests.RequestException(f"HTTP request failed with status code: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns a dictionary with 'users' key. 
    # If the list is empty, return None as per instructions.
    users = data.get('users', [])
    
    if not users:
        return None
        
    return users