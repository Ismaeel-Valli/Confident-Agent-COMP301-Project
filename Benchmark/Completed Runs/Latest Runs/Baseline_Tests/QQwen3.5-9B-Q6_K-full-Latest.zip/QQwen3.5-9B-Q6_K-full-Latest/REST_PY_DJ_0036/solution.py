import requests

def solve(inputs):
    """
    Updates selected fields of a post in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_title' (new title value).
        
    Returns:
        str or None: The response's id value, or None if the response is empty/successful without id.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    new_title = inputs.get('new_title')
    
    if not resource_id or new_title is None:
        raise ValueError("Missing required inputs: resource_id and new_title")

    url = f"https://dummyjson.com/posts/{resource_id}"
    payload = {"title": new_title}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update post. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Check for empty response or absence of 'id'
    if not data or 'id' not in data:
        return None
        
    return data['id']