```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id', 'new_todo', and 'new_user_identifier'.
        
    Returns:
        str or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_todo = inputs.get('new_todo')
    new_user_identifier = inputs.get('new_user_identifier')
    
    # Base URL for DummyJSON API
    base_url = "https://dummyjson.com"
    
    # Prepare the update payload
    payload = {
        "todo": new_todo,
        "userId": new_user_identifier
    }
    
    # Make PATCH request to update the todo
    response = requests.patch(
        f"{base_url}/todos/{resource_id}",
        json=payload
    )
    
    # Raise exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Check if response is empty (successful but no content)
    if not response.text:
        return None
    
    # Parse JSON response
    try:
        data = response.json()
    except ValueError:
        raise Exception("Invalid JSON response")
    
    # Return the id from the response if present
    return data.get('id')
```