import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API with provided email and first name.
    
    Args:
        inputs (dict): Dictionary containing 'new_email' and 'new_firstName'.
        
    Returns:
        int or None: The ID of the created user, or None if response is empty.
        
    Raises:
        requests.exceptions.RequestException: If HTTP request fails.
    """
    url = "https://dummyjson.com/users/add"
    
    payload = {
        "email": inputs["new_email"],
        "firstName": inputs["new_firstName"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to create user. Status code: {response.status_code}")
    
    data = response.json()
    
    # Check for id in different possible locations based on DummyJSON structure
    if "id" in data:
        return data["id"]
    elif "user" in data and isinstance(data["user"], dict) and "id" in data["user"]:
        return data["user"]["id"]
    else:
        return None