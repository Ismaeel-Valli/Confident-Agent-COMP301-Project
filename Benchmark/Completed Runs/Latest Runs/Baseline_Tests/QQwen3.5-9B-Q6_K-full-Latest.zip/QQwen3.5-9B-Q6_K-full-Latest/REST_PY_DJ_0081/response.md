```python
import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on pagination parameters.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip (offset).
    
    Returns:
        list or None: The decoded JSON response as a list of todos, or None if the response is empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/todos"
    
    params = {
        "_limit": inputs.get("result_limit", 10),
        "_skip": inputs.get("results_to_skip", 0)
    }
    
    response = requests.get(f"{base_url}{endpoint}", params=params)
    
    if response.status_code != 200:
        raise requests.exceptions.RequestException(f"Failed to retrieve todos. Status code: {response.status_code}")
    
    data = response.json()
    
    return data if data else None
```