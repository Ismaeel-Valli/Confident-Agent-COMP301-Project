```python
import requests
from urllib.parse import quote

def solve(inputs):
    """
    Fetches a specific branch from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository.
            - 'branch' (str): The name of the branch to fetch.
            - 'credential' (str): The authentication token or string for the API call.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        requests.RequestException: If the HTTP request fails or returns an unsuccessful status code.
    """
    repository_owner = inputs['repository_owner']
    repository_name = inputs['repository_name']
    branch = inputs['branch']
    credential = inputs['credential']

    # Construct the URL for fetching a specific branch
    url = f"https://api.github.com/repos/{quote(repository_owner, safe='')}/{quote(repository_name, safe='')}/branches/{quote(branch, safe='')}"

    headers = {
        'Authorization': f'token {credential}',
        'Accept': 'application/vnd.github+json'
    }

    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        raise requests.RequestException(f"Failed to fetch branch. Status code: {response.status_code}, Response: {response.text}")

    return response.json()
```