```python
import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'result_limit' (int) specifying 
                       the maximum number of results to return.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty but successful.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    limit = inputs.get('result_limit', 10)
    
    params = {
        '_limit': limit,
        '_page': 1
    }
    
    response = requests.get(base_url, params=params)
    
    if not response.ok:
        raise requests.exceptions.HTTPError(f"HTTP error occurred: {response.status_code}")
    
    data = response.json()
    
    if not data:
        return None
    
    return data
```