import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on skip count and included fields.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'results_to_skip' (int): Number of results to skip.
            - 'included_fields' (str): Comma-separated list of fields to include.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty but successful.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/users"
    
    # Parse inputs
    results_to_skip = inputs.get('results_to_skip', 0)
    included_fields = inputs.get('included_fields', '')
    
    # Prepare query parameters
    params = {
        'skip': results_to_skip,
        'limit': 1,  # Retrieve one page (one result)
        'select': included_fields if included_fields else None
    }
    
    # Make the GET request
    response = requests.get(base_url, params=params)
    
    # Check for unsuccessful HTTP response
    if not response.ok:
        raise Exception(f"HTTP error occurred: {response.status_code} - {response.text}")
    
    # Decode JSON response
    data = response.json()
    
    # Return None for a successful empty response (empty array)
    if not data.get('users'):
        return None
    
    return data