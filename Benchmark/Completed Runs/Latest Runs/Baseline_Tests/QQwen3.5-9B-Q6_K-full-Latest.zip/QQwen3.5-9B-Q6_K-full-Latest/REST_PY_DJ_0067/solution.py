import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API using provided first and last name.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_lastName'.
        
    Returns:
        int or None: The ID of the created user if present in response, 
                     None for successful empty response.
                     
    Raises:
        requests.exceptions.HTTPError: If HTTP response status code indicates failure.
    """
    url = "https://dummyjson.com/users/add"
    
    payload = {
        "firstName": inputs.get("new_firstName"),
        "lastName": inputs.get("new_lastName")
    }
    
    try:
        response = requests.post(url, json=payload)
        
        # Raise exception for unsuccessful HTTP responses (4xx and 5xx)
        response.raise_for_status()
        
        # Check if response is empty (no content)
        if not response.text.strip():
            return None
        
        # Parse JSON response to extract ID
        data = response.json()
        
        # Return the id if present, otherwise None
        return data.get("id")
        
    except requests.exceptions.HTTPError as e:
        raise e
    except Exception as e:
        raise RuntimeError(f"An error occurred while submitting user: {str(e)}") from e