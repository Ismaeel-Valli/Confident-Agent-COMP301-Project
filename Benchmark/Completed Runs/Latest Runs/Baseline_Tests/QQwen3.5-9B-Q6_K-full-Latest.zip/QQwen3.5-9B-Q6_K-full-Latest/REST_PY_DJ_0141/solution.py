import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON and returns the title 
    from the response, or None if absent or on successful empty response.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_category'.
        
    Returns:
        str or None: The title from the updated product response, or None.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_category = inputs['new_category']
    
    # DummyJSON update endpoint for products
    url = f"https://dummyjson.com/products/{resource_id}"
    
    payload = {
        "category": new_category
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product. Status code: {response.status_code}")
    
    data = response.json()
    
    # Check for successful empty response or missing title
    if not data.get("title"):
        return None
        
    return data["title"]