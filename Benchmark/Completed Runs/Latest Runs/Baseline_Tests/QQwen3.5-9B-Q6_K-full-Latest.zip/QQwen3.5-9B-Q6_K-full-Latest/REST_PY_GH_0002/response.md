```python
import requests
from urllib.parse import quote_plus

def solve(inputs):
    """
    Updates an organization on GitHub using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The organization name.
            - 'new_name' (str): The new name for the organization.
            - 'credential' (str): The authentication token or username/password pair.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    organization = inputs['organization']
    new_name = inputs['new_name']
    credential = inputs['credential']

    # Determine authentication method based on credential format
    if ':' in credential and '@' not in credential:
        # Assume it's a token if no username is present (common for GitHub Apps or tokens)
        auth = ('', credential)
    else:
        # Split into username and password
        username, password = credential.split(':', 1)
        auth = (username, password)

    url = f"https://api.github.com/orgs/{quote_plus(organization)}"
    headers = {
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2026-03-10'
    }

    payload = {
        "name": new_name
    }

    response = requests.put(url, json=payload, auth=auth, headers=headers)

    if response.status_code == 204:
        return None
    elif response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Failed to update organization: {response.status_code} - {response.text}")
```