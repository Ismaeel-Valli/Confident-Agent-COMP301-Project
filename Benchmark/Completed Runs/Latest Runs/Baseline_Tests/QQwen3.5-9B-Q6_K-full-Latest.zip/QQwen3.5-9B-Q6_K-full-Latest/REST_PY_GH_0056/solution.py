import requests
import json

def solve(inputs):
    """
    Lists repositories for the authenticated user using GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing 'credential' with authentication details.
        
    Returns:
        list or None: Decoded JSON response as a list of repositories, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    # Extract credentials from inputs
    credential = inputs["credential"]
    
    # GitHub API version 2026-03-10 endpoint for listing user repositories
    url = "https://api.github.com/user/repos"
    
    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10",
        "Authorization": f"token {credential}"
    }
    
    # Make the GET request
    response = requests.get(url, headers=headers)
    
    # Check if the response is successful (status code 200-299)
    if not response.ok:
        raise Exception(f"GitHub API request failed with status code {response.status_code}: {response.text}")
    
    # Decode the JSON response
    data = response.json()
    
    # Return None for an empty successful response, otherwise return the list
    return data if data else None