import requests
import json

def solve(inputs):
    """
    Lists followers of a GitHub user using the GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - "username" (str): The GitHub username.
            - "credential" (str): The bearer token for authentication.
    
    Returns:
        list or None: A list of follower data dictionaries if followers exist, 
                      None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response status code indicates an error.
    """
    username = inputs["username"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/users/{username}/followers"
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch followers. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # GitHub returns an empty list [] for no followers, which is a successful response.
    # The requirement says "Return None for a successful empty response".
    if not data:
        return None
    
    return data