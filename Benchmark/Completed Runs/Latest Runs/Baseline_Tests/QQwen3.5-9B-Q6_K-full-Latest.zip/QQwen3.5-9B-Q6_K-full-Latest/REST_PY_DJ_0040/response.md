```python
import requests

def solve(inputs):
    resource_id = inputs.get('resource_id')
    
    try:
        response = requests.get(f"https://dummyjson.com/todos/{resource_id}")
        
        if response.status_code != 200:
            raise Exception(f"HTTP {response.status_code} error")
        
        data = response.json()
        
        if not data:
            return None
        
        return data.get('id')
    
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```