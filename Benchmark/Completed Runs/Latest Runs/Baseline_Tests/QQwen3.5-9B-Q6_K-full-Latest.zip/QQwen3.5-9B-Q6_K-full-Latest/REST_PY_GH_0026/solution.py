import requests
from urllib.parse import quote

def solve(inputs):
    """
    Creates a new label in a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - new_name (str): The value for the name attribute of the new label.
            - credential (str): The authentication token or string for the API request.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    label_name = inputs["new_name"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{quote(owner)}/{quote(repo)}/labels"
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    data = {
        "name": label_name
    }
    
    response = requests.post(url, headers=headers, json=data)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create label. Status code: {response.status_code}, Response: {response.text}")
    
    return None