import requests

def solve(inputs):
    username = inputs["username"]
    page_size = inputs["page_size"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/users/{username}/following"
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    params = {"per_page": page_size}
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch following users: {response.status_code} - {response.text}")
    
    data = response.json()
    
    if not data:
        return None
    
    return data