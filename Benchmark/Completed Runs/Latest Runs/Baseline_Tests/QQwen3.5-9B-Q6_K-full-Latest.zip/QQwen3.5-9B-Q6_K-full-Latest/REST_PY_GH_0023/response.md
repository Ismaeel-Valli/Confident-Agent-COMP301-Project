```python
import requests

def solve(inputs):
    """
    Fetches issue comments from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository.
            - 'issue_number' (int): The issue number to fetch comments for.
            - 'credential' (str): The authentication token or bearer string.
    
    Returns:
        list | None: A list of decoded JSON comment objects, or None if the response is empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}/comments"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch issue comments. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    return data if data else None
```