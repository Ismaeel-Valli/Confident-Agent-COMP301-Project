```python
import requests

def solve(inputs):
    """
    Retrieves a post by identifier from DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing 'resource_id' as the post identifier.
        
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
        
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON endpoint for retrieving a post by ID
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        if response.status_code == 200 and not response.text.strip():
            return None
        
        return response.json()
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```