```python
import requests
import json

def solve(inputs):
    """
    Creates a milestone in a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - new_title (str): The title for the new milestone.
            - credential (str): The caller-supplied credential (e.g., token).
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    new_title = inputs["new_title"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/milestones"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    data = {
        "title": new_title
    }
    
    response = requests.post(url, headers=headers, json=data)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to create milestone. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json() if response.content else None
```