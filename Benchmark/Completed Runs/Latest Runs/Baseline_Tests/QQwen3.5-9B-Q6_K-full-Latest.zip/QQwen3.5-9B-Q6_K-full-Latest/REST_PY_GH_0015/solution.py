import requests
from urllib.parse import quote

def solve(inputs):
    """
    Creates a fork of a repository on GitHub using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'new_name' (str): The desired name for the forked repository.
            - 'credential' (str): The authentication token or username:password string.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    new_name = inputs['new_name']
    credential = inputs['credential']

    # Construct the URL for creating a fork with a custom name
    url = f"https://api.github.com/repos/{quote(owner)}/{quote(repo)}/forks"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Prepare parameters for the request
    params = {
        "name": new_name
    }

    # Determine authentication method based on credential format
    if ':' in credential:
        username, password = credential.split(':', 1)
        auth = (username, password)
    else:
        auth = ("", credential)  # Token-only auth

    response = requests.post(url, headers=headers, params=params, auth=auth)

    if response.status_code >= 400:
        raise Exception(f"GitHub API Error: {response.status_code} - {response.text}")

    return response.json() if response.text else None