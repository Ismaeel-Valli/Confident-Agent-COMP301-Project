```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API with provided price and title.
    
    Args:
        inputs (dict): Dictionary containing 'new_price' and 'new_title'.
        
    Returns:
        int or None: The ID of the created product, or None if response is empty/successful without ID.
        Raises: Exception for unsuccessful HTTP responses.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "price": inputs["new_price"],
        "title": inputs["new_title"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code != 201 and response.status_code != 200:
            raise Exception(f"Failed to create product. Status code: {response.status_code}, Response: {response.text}")
        
        data = response.json()
        
        # Check for 'id' in the response
        if "id" in data and data["id"] is not None:
            return data["id"]
        elif data == {}:
            return None
        else:
            # If id is missing but response isn't empty, assume it's an error case or unexpected format
            raise Exception(f"Unexpected response format. Status code: {response.status_code}, Response: {data}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```