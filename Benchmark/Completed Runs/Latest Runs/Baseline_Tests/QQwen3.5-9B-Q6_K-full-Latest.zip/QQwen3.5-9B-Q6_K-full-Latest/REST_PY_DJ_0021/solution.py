import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id' (todo ID) and 'new_todo' (value for the attribute).
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.exceptions.RequestException: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_todo_value = inputs['new_todo']
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    payload = {
        "todo": new_todo_value
    }
    
    try:
        response = requests.put(url, json=payload)
        
        if response.status_code == 200:
            return None
        elif response.status_code == 201:
            return response.json()
        else:
            raise Exception(f"Failed to update todo. Status code: {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        raise e