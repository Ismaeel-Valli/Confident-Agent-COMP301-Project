```python
import requests

def solve(inputs):
    """
    Fetches a specific commit from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'ref' (str): The commit reference (e.g., branch, tag, or SHA).
            - 'credential' (str): The authentication token for the API request.
    
    Returns:
        dict or None: The decoded JSON response if successful. Returns None if the response body is empty.
    
    Raises:
        Exception: If the HTTP response status code indicates an error.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    ref = inputs['ref']
    token = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/commits/{ref}"
    
    headers = {
        'Authorization': f'token {token}',
        'Accept': 'application/vnd.github+json'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"GitHub API request failed with status code {response.status_code}: {response.text}")
    
    data = response.json()
    
    return None if not data else data
```