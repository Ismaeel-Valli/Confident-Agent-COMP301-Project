import requests
from urllib.parse import quote

def solve(inputs):
    """
    Creates an issue comment on a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - issue_number (int): The number that identifies the issue.
            - new_body (str): The value for the body attribute of the comment.
            - credential (dict): Caller-supplied credentials with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    new_body = inputs["new_body"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{quote(repository_owner, safe='')}/{quote(repository_name, safe='')}/issues/{issue_number}/comments"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential['token']}",
        "X-GitHub-Api-Version": "2026-03-10",
        "Content-Type": "application/json"
    }
    
    data = {"body": new_body}
    
    response = requests.post(url, headers=headers, json=data)
    
    if response.status_code == 201:
        return None
    elif response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Failed to create issue comment. Status code: {response.status_code}, Response: {response.text}")