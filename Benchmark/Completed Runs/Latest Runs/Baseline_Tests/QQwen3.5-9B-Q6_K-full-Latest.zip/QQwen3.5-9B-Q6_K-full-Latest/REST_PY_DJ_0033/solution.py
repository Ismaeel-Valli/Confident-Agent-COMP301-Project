import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API with provided first name.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' key.
        
    Returns:
        int or None: The ID of the created user, or None if response is empty.
        
    Raises:
        requests.RequestException: If HTTP response indicates failure.
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    # Prepare payload with only the required field
    payload = {
        "name": inputs.get("new_firstName")
    }
    
    try:
        response = requests.post(url, json=payload)
        
        # Raise exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if response is empty
        if not response.text.strip():
            return None
            
        # Parse JSON and extract id
        data = response.json()
        return data.get("id")
        
    except requests.RequestException as e:
        raise e