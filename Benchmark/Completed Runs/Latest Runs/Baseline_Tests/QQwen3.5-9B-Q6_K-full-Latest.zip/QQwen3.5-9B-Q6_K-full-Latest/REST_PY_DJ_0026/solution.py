import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (product ID) and 'new_title' (new title value).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        Raises: Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_title = inputs.get('new_title')
    
    if not resource_id or new_title is None:
        raise ValueError("Missing required input fields: resource_id and new_title")

    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"title": new_title}
    
    try:
        response = requests.put(url, json=payload)
        
        if response.status_code != 200:
            raise Exception(f"HTTP {response.status_code}: {response.text}")
            
        data = response.json()
        
        # DummyJSON returns the updated product object on PUT success
        return data.get('id')
        
    except requests.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")