import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on provided sort parameters.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'sort_field' (str): Field used for ordering.
            - 'sort_direction' (str): Ordering direction ('asc' or 'desc').
    
    Returns:
        list | None: The decoded JSON response as a list of users, or None if the response is empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com/users"
    sort_field = inputs.get('sort_field')
    sort_direction = inputs.get('sort_direction', 'asc').lower()
    
    params = {'_sort': sort_field, '_order': sort_direction}
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
    
    data = response.json()
    
    if not data:
        return None
    
    return data