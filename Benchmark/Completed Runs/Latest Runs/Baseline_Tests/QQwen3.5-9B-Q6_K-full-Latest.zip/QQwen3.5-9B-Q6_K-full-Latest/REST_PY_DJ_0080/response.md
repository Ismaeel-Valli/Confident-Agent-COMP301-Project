```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post on DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_body' (new body value).
        
    Returns:
        str or None: The response's id if present, otherwise None for successful empty responses.
        Raises: Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_body = inputs.get('new_body')
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    payload = {"body": new_body}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update post. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Check for successful empty response (indicated by status 200 and no content or specific structure)
    if not data.get('id'):
        return None
        
    return data.get('id')
```