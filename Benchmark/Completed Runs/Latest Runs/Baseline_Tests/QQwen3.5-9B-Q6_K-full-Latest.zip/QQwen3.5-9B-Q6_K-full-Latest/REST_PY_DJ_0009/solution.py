import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the user.
            - new_firstName (str): New value for the first name attribute.
    
    Returns:
        dict or None: The decoded JSON response if successful, None otherwise.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    new_firstName = inputs.get('new_firstName')
    
    # Base URL for DummyJSON API
    base_url = "https://dummyjson.com/users"
    
    # Prepare the payload for updating the user
    payload = {
        "id": resource_id,
        "firstName": new_firstName
    }
    
    try:
        response = requests.put(base_url, json=payload)
        
        if response.status_code == 200:
            # Return None for a successful empty response
            return None
        elif response.status_code == 201:
            # If the API returns a new resource (e.g., created), return the decoded JSON
            return response.json()
        else:
            raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")