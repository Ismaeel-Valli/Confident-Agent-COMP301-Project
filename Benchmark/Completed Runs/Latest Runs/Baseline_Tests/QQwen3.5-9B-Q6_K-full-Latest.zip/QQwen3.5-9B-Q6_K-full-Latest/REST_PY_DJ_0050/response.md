```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_lastName' (new last name).
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty success response.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_last_name = inputs['new_lastName']
    
    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {
        "lastName": new_last_name
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json()
```