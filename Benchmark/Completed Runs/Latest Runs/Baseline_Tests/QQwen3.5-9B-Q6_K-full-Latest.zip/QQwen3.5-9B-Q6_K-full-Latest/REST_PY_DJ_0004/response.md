```python
import requests

def solve(inputs):
    """
    Deletes a product by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (str) of the product to delete.
        
    Returns:
        dict or None: Decoded JSON response if unsuccessful, None for successful deletion.
        
    Raises:
        requests.RequestException: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    
    # DummyJSON endpoint for deleting a product
    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.delete(url)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # DummyJSON returns empty body on success (204 No Content)
        if response.status_code == 204:
            return None
        
        # Return decoded JSON for other successful status codes
        return response.json()
        
    except requests.exceptions.HTTPError as e:
        raise e
```