```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON and returns the title value.
    
    Args:
        inputs (dict): Contains 'resource_id' (product ID) and 'new_title' (new title value).
        
    Returns:
        str or None: The updated title if present, otherwise None for successful empty response.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs['resource_id']
    new_title = inputs['new_title']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"title": new_title}
    
    try:
        response = requests.put(url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 204:
            return None
        
        data = response.json()
        return data.get('title')
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Failed to update product: {e}")
```