```python
import requests

def solve(inputs):
    """
    Updates the authenticated user's name via GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'new_name' (str): The new name for the authenticated user.
            - 'credential' (str): The authentication token or header value.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    url = "https://api.github.com/user"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {inputs['credential']}",
        "X-GitHub-Api-Version": "2026-03-10",
        "Content-Type": "application/json"
    }
    
    payload = {
        "name": inputs['new_name']
    }
    
    response = requests.put(url, headers=headers, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user: {response.status_code} - {response.text}")
    
    return response.json() if response.text else None
```