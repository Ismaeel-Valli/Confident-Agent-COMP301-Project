```python
import requests

def solve(inputs):
    """
    Deletes a milestone from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - milestone_number (int): The number identifying the milestone.
            - credential (str): The caller-supplied credential (e.g., token or Bearer string).
    
    Returns:
        int: The successful HTTP status code (typically 204 No Content).
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    milestone_number = inputs["milestone_number"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/milestones/{milestone_number}"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    response = requests.delete(url, headers=headers)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to delete milestone. Status code: {response.status_code}, Response: {response.text}")
    
    return response.status_code
```