import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API with provided category and title.
    
    Args:
        inputs (dict): Contains 'new_category' and 'new_title'.
        
    Returns:
        str or None: The response's title value, or None if absent or successful empty response.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "category": inputs["new_category"],
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to submit product. Status code: {response.status_code}")
    
    data = response.json()
    
    # Check for title in the response
    if "title" in data and data["title"]:
        return data["title"]
    
    # Return None for successful empty response or missing title
    return None