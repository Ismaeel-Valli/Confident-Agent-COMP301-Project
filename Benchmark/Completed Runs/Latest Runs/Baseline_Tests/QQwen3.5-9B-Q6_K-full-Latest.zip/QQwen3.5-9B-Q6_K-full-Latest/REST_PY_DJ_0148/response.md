```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON and returns the response's id value,
    or None if that attribute is absent or the response is empty. Raises an exception for unsuccessful HTTP responses.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the todo to update.
            - new_completed (bool): New value for the 'completed' attribute.
            - new_user_identifier (str): New value for the 'userId' attribute.
    
    Returns:
        str or None: The 'id' from the response JSON, or None if absent or empty response.
    
    Raises:
        requests.RequestException: If the HTTP request fails (non-2xx status code).
    """
    resource_id = inputs['resource_id']
    new_completed = inputs['new_completed']
    new_user_identifier = inputs['new_user_identifier']

    # Base URL for DummyJSON Todo API
    base_url = "https://dummyjson.com/todos"
    
    # Prepare the payload with only the fields to update
    payload = {
        "completed": new_completed,
        "userId": new_user_identifier
    }

    try:
        response = requests.put(
            f"{base_url}/{resource_id}",
            json=payload
        )
        
        # Raise an exception for unsuccessful HTTP responses (non-2xx)
        response.raise_for_status()
        
        # Check if the response is empty
        if not response.text.strip():
            return None
        
        # Parse the JSON response
        data = response.json()
        
        # Return the 'id' if present, otherwise None
        return data.get('id')
    
    except requests.RequestException as e:
        raise e
```