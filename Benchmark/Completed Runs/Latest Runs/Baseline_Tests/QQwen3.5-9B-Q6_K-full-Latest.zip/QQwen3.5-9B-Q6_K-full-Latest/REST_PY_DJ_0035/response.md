```python
import requests

def solve(inputs):
    resource_id = inputs.get('resource_id')
    url = f"https://dummyjson.com/posts/{resource_id}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        if response.status_code == 200:
            data = response.json()
            # Check if the response is empty (e.g., no content or null)
            if not data:
                return None
            # Return the 'id' value if it exists, otherwise None
            return data.get('id')
        else:
            raise Exception(f"HTTP error occurred: {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```