import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'included_fields' (str): Comma-separated list of fields to include.
            - 'sort_field' (str): Field to sort the results by.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty but successful.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    # Parse included_fields
    fields = inputs.get('included_fields', '').split(',')
    params = {
        '_limit': 1,
        '_sort': inputs.get('sort_field', 'id'),
        '_fields': ','.join(fields) if fields else ''
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP request failed with status code: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns an empty list for a successful empty response
    if not data:
        return None
    
    return data