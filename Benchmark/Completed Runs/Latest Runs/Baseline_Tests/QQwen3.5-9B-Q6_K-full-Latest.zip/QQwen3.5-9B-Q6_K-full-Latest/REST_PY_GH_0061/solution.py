import requests

def solve(inputs):
    """
    Fetches a GitHub user based on the provided username using the specified API version.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The GitHub username to fetch.
            - 'credential' (str): The authentication token or bearer string.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    username = inputs['username']
    credential = inputs['credential']
    
    # GitHub REST API version 2026-03-10 endpoint for getting a user by username
    url = f"https://api.github.com/users/{username}"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch user '{username}': HTTP {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response (though GitHub user endpoints typically return an object)
    if not data:
        return None
    
    return data