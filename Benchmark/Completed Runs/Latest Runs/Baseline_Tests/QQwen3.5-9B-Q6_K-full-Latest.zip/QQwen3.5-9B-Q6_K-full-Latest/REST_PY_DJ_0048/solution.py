import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON using the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'new_title' for the product title.
        
    Returns:
        str or None: The title value from the response, or None if absent or on successful empty response.
        
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "title": inputs.get("new_title")
    }

    try:
        response = requests.post(url, json=payload)
        
        if response.status_code != 200:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
            
        # Check if the response body is empty or lacks a 'title' attribute
        data = response.json()
        if not data or "title" not in data:
            return None
            
        return data["title"]
        
    except requests.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")