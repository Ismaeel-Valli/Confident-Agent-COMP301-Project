import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON and returns the response's id value,
    or None if that attribute is absent or for a successful empty response.
    Raises an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Contains 'resource_id', 'new_completed', and 'new_todo'.
        
    Returns:
        str or None: The ID of the updated todo, or None if absent or empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    new_completed = inputs.get('new_completed')
    new_todo = inputs.get('new_todo')
    
    # Base URL for DummyJSON (assuming standard structure)
    base_url = "https://dummyjson.com"
    
    # Construct the update payload
    payload = {}
    if new_completed is not None:
        payload['completed'] = new_completed
    if new_todo is not None:
        payload['todo'] = new_todo
    
    # Endpoint to update a todo by ID
    url = f"{base_url}/todos/{resource_id}"
    
    try:
        response = requests.put(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Check if the response is empty
        if not response.text.strip():
            return None
        
        # Parse the JSON response
        data = response.json()
        
        # Return the id value if present, otherwise None
        return data.get('id')
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")