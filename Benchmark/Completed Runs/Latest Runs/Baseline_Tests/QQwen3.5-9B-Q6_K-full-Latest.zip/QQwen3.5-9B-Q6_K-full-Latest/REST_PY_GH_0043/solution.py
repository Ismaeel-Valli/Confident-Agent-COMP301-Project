import requests
from urllib.parse import quote

def solve(inputs):
    """
    Creates a release on GitHub using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository.
            - new_tag_name (str): The value for the tag name attribute.
            - credential (str): The caller-supplied credential (token).
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    new_tag_name = inputs["new_tag_name"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{quote(repository_owner, safe='')}/{quote(repository_name, safe='')}/releases"
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json"
    }
    
    data = {
        "tag_name": new_tag_name
    }
    
    response = requests.post(url, json=data, headers=headers)
    
    if response.status_code == 201:
        return None
    elif response.status_code == 202:
        return response.json()
    else:
        raise Exception(f"Failed to create release. Status code: {response.status_code}, Response: {response.text}")