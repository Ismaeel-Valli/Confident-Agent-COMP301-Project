```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON and returns the response's id value,
    or None if that attribute is absent or the response is empty. Raises an exception for unsuccessful HTTP responses.
    
    Args:
        inputs (dict): Contains 'resource_id' (todo ID) and 'new_completed' (boolean to set).
        
    Returns:
        str or None: The updated todo's id, or None if absent or empty response.
        
    Raises:
        requests.exceptions.HTTPError: If the HTTP response status code indicates failure.
    """
    resource_id = inputs.get('resource_id')
    new_completed = inputs.get('new_completed')
    
    if resource_id is None or new_completed is None:
        raise ValueError("Missing required inputs: 'resource_id' and 'new_completed'.")

    url = f"https://dummyjson.com/todos/{resource_id}"
    payload = {
        "completed": new_completed
    }

    response = requests.put(url, json=payload)
    
    # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
    response.raise_for_status()
    
    # Check if the response is empty
    if not response.text.strip():
        return None
    
    try:
        data = response.json()
        # Return the id if present, otherwise None
        return data.get('id')
    except ValueError:
        # If JSON parsing fails but we have a successful response, treat as no id found
        return None
```