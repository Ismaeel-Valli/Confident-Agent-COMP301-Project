import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the todo.
            - new_completed (bool): New value for the completed attribute.
            - new_todo (str): New value for the todo attribute.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty but successful.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs['resource_id']
    new_completed = inputs['new_completed']
    new_todo = inputs['new_todo']

    url = f"https://dummyjson.com/todos/{resource_id}"
    
    payload = {
        "completed": new_completed,
        "todo": new_todo
    }

    response = requests.put(url, json=payload)
    response.raise_for_status()

    if response.status_code == 204:
        return None
    
    return response.json()