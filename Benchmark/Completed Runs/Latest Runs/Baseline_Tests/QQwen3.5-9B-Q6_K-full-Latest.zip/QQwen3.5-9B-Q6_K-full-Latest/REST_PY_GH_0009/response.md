```python
import requests

def solve(inputs):
    """
    Lists branches for a given GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git extension).
            - 'credential' (str): The authentication token or bearer token for API access.
    
    Returns:
        list or None: A list of branch objects if branches exist, otherwise None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code outside 200-299 range).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/branches"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if not (200 <= response.status_code < 300):
        raise Exception(f"Failed to fetch branches: HTTP {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response
    if len(data) == 0:
        return None
    
    return data
```