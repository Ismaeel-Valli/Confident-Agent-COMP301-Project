```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON and returns the response's id value,
    or None if that attribute is absent or the response is empty. Raises an exception for unsuccessful HTTP responses.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (int): Identifier of the user to update.
            - new_age (int): New value for the age attribute.
    
    Returns:
        int or None: The ID from the response if present, otherwise None.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    new_age = inputs.get('new_age')

    if resource_id is None or new_age is None:
        raise ValueError("Missing required input fields: resource_id and new_age")

    url = f"https://dummyjson.com/users/{resource_id}"
    data = {"age": new_age}

    response = requests.put(url, json=data)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user. Status code: {response.status_code}, Response: {response.text}")

    return response.json().get('id')
```