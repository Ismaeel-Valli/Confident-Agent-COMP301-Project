```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON and returns the response's id value,
    or None if that attribute is absent or for a successful empty response.
    Raises an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the product.
            - new_price (float/int): Value for the price attribute.
    
    Returns:
        str or None: The ID from the response, or None if absent or empty response.
    
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/products"
    resource_id = inputs.get("resource_id")
    new_price = inputs.get("new_price")

    if not resource_id or new_price is None:
        raise ValueError("Missing required inputs: resource_id and new_price")

    url = f"{base_url}/{resource_id}"
    payload = {"price": new_price}

    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to update product. Status code: {response.status_code}, Response: {response.text}")

    data = response.json()

    # Handle different possible response structures based on DummyJSON behavior
    # Sometimes it returns the updated object, sometimes an empty object or just status
    if isinstance(data, dict):
        return data.get("id")
    
    return None
```