```python
import requests

def solve(inputs):
    """
    Fetches the list of files changed in a specific pull request for a GitHub repository.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository.
            - 'pull_number' (int): The pull request number.
            - 'credential' (str): The authentication token or string for GitHub API.
    
    Returns:
        dict or None: The decoded JSON response containing the list of files, 
                      or None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response status code indicates an error.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    pull_number = inputs['pull_number']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pull_number}/files"
    
    headers = {
        'Authorization': f'token {credential}',
        'Accept': 'application/vnd.github+json'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"GitHub API request failed with status code {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response (e.g., no files changed)
    if not data:
        return None
    
    return data
```