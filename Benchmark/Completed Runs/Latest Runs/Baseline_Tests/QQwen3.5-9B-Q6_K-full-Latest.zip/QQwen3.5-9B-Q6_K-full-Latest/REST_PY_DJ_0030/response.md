```python
import requests

def solve(inputs):
    """
    Retrieves a user by identifier from DummyJSON and returns the user's ID.
    
    Args:
        inputs (dict): A dictionary containing 'resource_id' as the user identifier.
        
    Returns:
        int or None: The user's ID if found, None for successful empty response.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    
    # Construct the API URL for DummyJSON to get a specific user by ID
    url = f"https://dummyjson.com/users/{resource_id}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        if response.status_code == 200:
            data = response.json()
            # Check if the response is empty (no users found)
            if not data or 'users' not in data or len(data['users']) == 0:
                return None
            
            # Return the ID of the first user in the list
            return data['users'][0]['id']
        else:
            raise requests.exceptions.HTTPError(f"HTTP {response.status_code} error")
            
    except requests.exceptions.RequestException as e:
        raise e
```