```python
import requests

def solve(inputs):
    """
    Deletes a user by identifier using DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with user identifier.
        
    Returns:
        bool or None: The 'isDeleted' value from response, or None if absent or on success with empty response.
        
    Raises:
        requests.exceptions.RequestException: If HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON delete endpoint for users (assuming standard structure)
    url = f"https://dummyjson.com/users/{resource_id}"
    
    try:
        response = requests.delete(url)
        
        if response.status_code != 200:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
        
        # Check if response is empty (no content)
        if not response.text.strip():
            return None
            
        data = response.json()
        
        # Return isDeleted value if present, otherwise None
        return data.get('isDeleted')
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```