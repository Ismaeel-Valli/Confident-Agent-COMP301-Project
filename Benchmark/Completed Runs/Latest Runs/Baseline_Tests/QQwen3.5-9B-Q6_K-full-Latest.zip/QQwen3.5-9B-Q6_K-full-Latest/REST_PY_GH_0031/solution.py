import requests
from urllib.parse import quote

def solve(inputs):
    """
    Lists milestones for a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The caller-supplied credential (e.g., token or Bearer token).
    
    Returns:
        list | None: A list of milestone dictionaries if milestones exist, or None if the response is empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails (non-2xx status code).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{quote(owner)}/{quote(repo)}/milestones"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise requests.exceptions.RequestException(f"Failed to fetch milestones. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    return data if data else None