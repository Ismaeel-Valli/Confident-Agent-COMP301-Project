import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the user
            - new_phone (str): New phone number value
    
    Returns:
        None if successful (empty response)
        dict with decoded JSON response otherwise
    
    Raises:
        Exception for unsuccessful HTTP responses
    """
    base_url = "https://dummyjson.com/users"
    
    # Extract inputs
    resource_id = inputs.get('resource_id')
    new_phone = inputs.get('new_phone')
    
    if not resource_id or new_phone is None:
        raise ValueError("Missing required inputs: resource_id and new_phone")
    
    # Prepare the update payload
    payload = {
        "phone": new_phone
    }
    
    # Make PATCH request to update user
    response = requests.patch(
        f"{base_url}/{resource_id}",
        json=payload
    )
    
    # Check for unsuccessful HTTP response
    if response.status_code != 200:
        raise Exception(f"Failed to update user. Status code: {response.status_code}, Response: {response.text}")
    
    # Return None for successful empty response, otherwise return decoded JSON
    if not response.content:
        return None
    
    return response.json()