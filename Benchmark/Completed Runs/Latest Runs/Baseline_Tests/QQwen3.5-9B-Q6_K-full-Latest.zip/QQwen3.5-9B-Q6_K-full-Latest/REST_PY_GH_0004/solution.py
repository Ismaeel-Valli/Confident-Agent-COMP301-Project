import requests

def solve(inputs):
    """
    Lists repositories for a given GitHub organization using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - "organization" (str): The name of the GitHub organization.
            - "credential" (str): The authentication token or bearer token for the API.
    
    Returns:
        list | None: A list of repository objects if repositories exist, or None if the response is empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails (non-2xx status code).
    """
    organization = inputs["organization"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/orgs/{organization}/repos"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to fetch repositories for organization '{organization}': HTTP {response.status_code}")
    
    data = response.json()
    
    return None if not data else data