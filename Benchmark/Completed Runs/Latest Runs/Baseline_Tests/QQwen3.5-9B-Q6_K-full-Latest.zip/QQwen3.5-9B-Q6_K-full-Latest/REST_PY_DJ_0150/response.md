```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the product.
            - new_brand (str): New value for the brand attribute.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    new_brand = inputs.get('new_brand')
    
    url = f"https://dummyjson.com/products/{resource_id}"
    data = {
        "brand": new_brand
    }
    
    response = requests.put(url, json=data)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to update product: {response.status_code} - {response.text}")
    
    return response.json() if response.json() else None
```