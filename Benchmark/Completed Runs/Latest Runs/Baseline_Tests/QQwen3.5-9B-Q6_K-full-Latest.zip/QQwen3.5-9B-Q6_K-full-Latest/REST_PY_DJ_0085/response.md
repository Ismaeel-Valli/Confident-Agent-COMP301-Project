```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API using provided inputs.
    
    Args:
        inputs (dict): Dictionary containing 'new_description' and 'new_title'.
        
    Returns:
        str or None: The title from the response if present, otherwise None for success.
        Raises: Exception on unsuccessful HTTP response.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "description": inputs.get("new_description"),
        "title": inputs.get("new_title")
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code != 200:
            raise Exception(f"Failed to submit product. Status code: {response.status_code}")
        
        # For a successful submission with empty body or no title in response, return None
        data = response.json()
        if not data.get("title"):
            return None
            
        return data["title"]
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```