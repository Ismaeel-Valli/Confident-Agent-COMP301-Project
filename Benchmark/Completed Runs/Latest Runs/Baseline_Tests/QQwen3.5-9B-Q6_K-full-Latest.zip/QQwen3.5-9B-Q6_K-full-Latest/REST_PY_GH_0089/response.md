```python
import requests

def solve(inputs):
    """
    Fetches the list of files changed in a specific pull request from GitHub.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository.
            - pull_number (int): The number that identifies the pull request.
            - page_size (int): The number of results per page (max 100).
            - credential (str): The caller-supplied credential (e.g., Bearer token or API key).
    
    Returns:
        list | None: A list of dictionaries representing the files changed in the pull request.
                     Returns None if the response is successfully empty.
        Raises:
            requests.RequestException: If the HTTP response indicates an error.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    pull_number = inputs["pull_number"]
    page_size = inputs["page_size"]
    credential = inputs["credential"]
    
    # Construct the API URL for GitHub REST API version 2026-03-10
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/pulls/{pull_number}/files"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10",
        "Authorization": f"Bearer {credential}"
    }
    
    params = {
        "per_page": page_size
    }
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to fetch pull request files. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response
    if not data:
        return None
    
    return data
```