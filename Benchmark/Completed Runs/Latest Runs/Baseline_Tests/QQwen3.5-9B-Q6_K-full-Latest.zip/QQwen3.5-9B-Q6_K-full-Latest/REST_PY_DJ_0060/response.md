```python
import requests

def solve(inputs):
    """
    Deletes a todo by identifier from DummyJSON and returns the 'isDeleted' value.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (str) of the todo to delete.
        
    Returns:
        bool or None: The 'isDeleted' value from the response, or None if absent or on success with empty response.
        
    Raises:
        requests.exceptions.HTTPError: If the HTTP response status code indicates an error.
    """
    resource_id = inputs.get('resource_id')
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json"
    }
    
    try:
        response = requests.delete(url, headers=headers)
        
        # Raise an exception for unsuccessful HTTP responses (4xx and 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (no content)
        if not response.text.strip():
            return None
            
        # Parse the JSON response
        data = response.json()
        
        # Return 'isDeleted' value if present, otherwise None
        return data.get('isDeleted')
        
    except requests.exceptions.HTTPError as e:
        raise e
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Request failed: {e}")
```