import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_username'.
        
    Returns:
        None if the response is successful and empty.
        The decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_username = inputs['new_username']
    
    url = f"https://dummyjson.com/users/{resource_id}"
    data = {"username": new_username}
    
    response = requests.put(url, json=data)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user. Status code: {response.status_code}, Response: {response.text}")
    
    return None