import requests

def solve(inputs):
    """
    Lists repositories for a GitHub user based on the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The GitHub username.
            - 'type' (str, optional): The type of repository ('all', 'owner', or 'public'). Defaults to 'all'.
            - 'credential' (dict): Contains authentication details, assumed to have necessary permissions.
    
    Returns:
        list or None: A list of repository objects if repositories are found, otherwise None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    username = inputs['username']
    repo_type = inputs.get('type', 'all')
    credential = inputs['credential']
    
    # Construct the URL for listing user repositories
    url = f"https://api.github.com/users/{username}/repos"
    
    # Prepare headers with authentication
    headers = {
        "Authorization": f"token {credential.get('token', '')}",
        "Accept": "application/vnd.github+json"
    }
    
    # Optional query parameter for repository type
    params = {}
    if repo_type != 'all':
        params['type'] = repo_type
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code == 200:
        data = response.json()
        return data if data else None
    else:
        raise Exception(f"Failed to retrieve repositories. Status code: {response.status_code}, Response: {response.text}")