import requests
import json

def solve(inputs):
    """
    Lists repositories for a given GitHub organization using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The name of the organization.
            - 'type' (str): The type of repositories to return ('all', 'public', or 'private').
            - 'credential' (str): The authentication token for the API request.
    
    Returns:
        list or None: A list of repository objects if there are results, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response status code indicates an error.
    """
    organization = inputs.get('organization')
    repo_type = inputs.get('type')
    credential = inputs.get('credential')
    
    # Construct the API URL for version 2026-03-10
    url = f"https://api.github.com/repos/{organization}"
    
    # Prepare headers with Bearer token authentication
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Determine query parameters based on the type of repositories requested
    params = {}
    if repo_type:
        params['type'] = repo_type
    
    response = requests.get(url, headers=headers, params=params)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Decode the JSON response
    data = response.json()
    
    # Return None for a successful empty response
    if not data:
        return None
    
    return data