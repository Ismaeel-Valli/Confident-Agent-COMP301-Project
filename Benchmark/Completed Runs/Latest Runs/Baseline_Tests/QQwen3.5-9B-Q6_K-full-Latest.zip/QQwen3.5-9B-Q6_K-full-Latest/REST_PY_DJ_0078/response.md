```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API with provided age and first name.
    
    Args:
        inputs (dict): Dictionary containing 'new_age' and 'new_firstName'.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.exceptions.RequestException: If HTTP request fails.
    """
    url = "https://dummyjson.com/users/add"
    
    payload = {
        "age": inputs["new_age"],
        "firstName": inputs["new_firstName"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code == 200:
        data = response.json()
        return None if not data else data
    elif response.status_code == 400:
        # Assuming 400 means validation error or empty response as per common DummyJSON behavior for add user
        return None
    else:
        raise requests.exceptions.RequestException(f"HTTP {response.status_code} error occurred")
```