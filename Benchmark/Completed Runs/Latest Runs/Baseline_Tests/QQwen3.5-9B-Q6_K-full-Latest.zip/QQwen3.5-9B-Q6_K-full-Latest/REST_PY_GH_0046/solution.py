import requests

def solve(inputs):
    """
    Updates a release on GitHub using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - release_id (int): The unique identifier of the release.
            - new_tag_name (str): The new value for the tag name attribute.
            - credential (str): The authentication token or string for the API request.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    release_id = inputs["release_id"]
    new_tag_name = inputs["new_tag_name"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{owner}/{repo}/releases/{release_id}"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    data = {
        "tag_name": new_tag_name
    }

    response = requests.put(url, headers=headers, json=data)

    if response.status_code != 200:
        raise Exception(f"Failed to update release. Status code: {response.status_code}, Response: {response.text}")

    return response.json() if response.text else None