```python
import requests
from urllib.parse import urljoin

def solve(inputs):
    """
    Creates a pull request on GitHub using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - new_base (str): Value for the base attribute.
            - new_body (str): Value for the body attribute.
            - new_head (str): Value for the head attribute.
            - new_title (str): Value for the title attribute.
            - credential (str): The caller-supplied credential (token).
    
    Returns:
        dict or None: The decoded JSON response, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    base = inputs["new_base"]
    body = inputs["new_body"]
    head = inputs["new_head"]
    title = inputs["new_title"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{owner}/{repo}/pulls"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}",
        "X-GitHub-Api-Version": "2026-03-10",
        "Content-Type": "application/json"
    }

    payload = {
        "title": title,
        "body": body,
        "head": head,
        "base": base
    }

    response = requests.post(url, headers=headers, json=payload)

    if response.status_code != 201:
        raise Exception(f"Failed to create pull request. Status code: {response.status_code}, Response: {response.text}")

    return response.json()
```