```python
import requests

def solve(inputs):
    """
    Deletes a post by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (post ID).
        
    Returns:
        str or None: The response's id value if present, otherwise None for success.
                     Raises an exception for unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    
    if not resource_id:
        raise ValueError("Missing 'resource_id' in inputs")

    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    response = requests.delete(url)
    
    # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
    response.raise_for_status()
    
    # Return None for a successful empty response
    if not response.text:
        return None
    
    # Try to parse the JSON response and extract 'id'
    try:
        data = response.json()
        return data.get('id')
    except (ValueError, TypeError):
        # If JSON parsing fails or response is not a dict, return None
        return None
```