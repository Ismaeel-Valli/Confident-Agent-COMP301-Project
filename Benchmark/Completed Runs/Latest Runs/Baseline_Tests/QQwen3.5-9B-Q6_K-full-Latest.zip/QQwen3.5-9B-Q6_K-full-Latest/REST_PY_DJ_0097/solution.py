import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the user
            - new_email (str): New email value
    
    Returns:
        None if successful (empty response), or the decoded JSON response otherwise.
    
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com"
    resource_id = inputs["resource_id"]
    new_email = inputs["new_email"]
    
    url = f"{base_url}/users/{resource_id}"
    payload = {"email": new_email}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user: {response.status_code} - {response.text}")
    
    return None