import requests

def solve(inputs):
    """
    Fetches a specific issue from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'issue_number' (int or str): The issue number.
            - 'credential' (str): The authentication token for the API request.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response status code indicates an error.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    issue_number = inputs['issue_number']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}"
    
    headers = {
        'Accept': 'application/vnd.github+json',
        'Authorization': f'Bearer {credential}'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch issue. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response (though GitHub issues typically have content)
    if not data:
        return None
        
    return data