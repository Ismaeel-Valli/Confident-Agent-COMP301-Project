import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_email' (new email value).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        Raises: Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_email = inputs.get('new_email')
    
    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {"email": new_email}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user. Status code: {response.status_code}, Response: {response.text}")
    
    # DummyJSON returns an empty body on successful PUT for this endpoint in some versions,
    # or a full object in others. We check for 'id' in the response content.
    if response.content:
        try:
            data = response.json()
            return data.get('id')
        except ValueError:
            # If JSON parsing fails but status is 200, treat as empty success
            return None
    
    return None