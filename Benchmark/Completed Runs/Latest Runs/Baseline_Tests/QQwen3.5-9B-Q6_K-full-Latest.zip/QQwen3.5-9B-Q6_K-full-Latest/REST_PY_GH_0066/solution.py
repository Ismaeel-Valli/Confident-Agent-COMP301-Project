import requests
from urllib.parse import quote

def solve(inputs):
    """
    Updates an organization's description via the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The name of the organization to update.
            - 'new_description' (str): The new description for the organization.
            - 'credential' (dict): Contains 'token' and optionally 'base_url'.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP request is unsuccessful.
    """
    organization = inputs['organization']
    new_description = inputs['new_description']
    credential = inputs['credential']
    
    # Prepare headers with the provided token
    headers = {
        'Authorization': f'token {credential["token"]}',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2026-03-10'
    }
    
    # Determine the base URL (default to GitHub's main API if not provided)
    base_url = credential.get('base_url', 'https://api.github.com')
    
    # Construct the endpoint URL
    url = f"{base_url}/orgs/{quote(organization)}"
    
    # Prepare the payload
    payload = {
        "description": new_description
    }
    
    try:
        response = requests.put(url, headers=headers, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx and 5xx)
        response.raise_for_status()
        
        # Return the decoded JSON response if it exists, otherwise return None
        if response.text:
            return response.json()
        else:
            return None
            
    except requests.exceptions.HTTPError as e:
        raise Exception(f"GitHub API request failed with status {response.status_code}: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request error occurred: {e}")