```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post in DummyJSON and returns the title value.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_title'.
        
    Returns:
        str or None: The updated title if present, otherwise None for success.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_title = inputs['new_title']
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    payload = {"title": new_title}
    
    try:
        response = requests.put(url, json=payload)
        
        if response.status_code not in [200, 201]:
            raise Exception(f"HTTP error occurred: {response.status_code}")
            
        # DummyJSON returns the updated post object on success
        data = response.json()
        
        # Check if 'title' is present in the response
        if 'title' in data:
            return data['title']
        else:
            # Return None for a successful empty response (or missing title)
            return None
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```