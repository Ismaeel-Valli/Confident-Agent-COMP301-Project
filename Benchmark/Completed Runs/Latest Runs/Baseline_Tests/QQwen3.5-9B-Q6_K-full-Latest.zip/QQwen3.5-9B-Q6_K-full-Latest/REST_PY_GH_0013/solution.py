import requests
from urllib.parse import quote

def solve(inputs):
    """
    Lists contributors for a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The Bearer token for authentication.
    
    Returns:
        list or None: A list of contributor dictionaries if contributors exist, 
                      None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    owner = inputs['repository_owner']
    repo_name = inputs['repository_name']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{quote(owner)}/{quote(repo_name)}/contributors"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"GitHub API request failed with status code {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response as per instructions
    if not data:
        return None
    
    return data