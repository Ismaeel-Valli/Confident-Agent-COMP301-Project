```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_username'.
        
    Returns:
        str or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_username = inputs.get('new_username')
    
    # DummyJSON API endpoint for updating a user
    url = f"https://dummyjson.com/users/{resource_id}"
    
    payload = {
        "username": new_username
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user. Status code: {response.status_code}, Response: {response.text}")
    
    # Check if the response is empty (no content)
    if not response.content:
        return None
    
    try:
        data = response.json()
        # Return the id from the response if present
        return data.get('id')
    except ValueError:
        # If JSON parsing fails, return None as per requirement for successful empty response interpretation
        return None
```