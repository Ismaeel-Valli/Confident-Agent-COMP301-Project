```python
import requests

def solve(inputs):
    """
    Deletes a post by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (identifier of the post).
        
    Returns:
        bool or None: The 'isDeleted' value from the response, or None if absent or on success with empty response.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON API endpoint for deleting a post (assuming standard structure)
    url = f"https://dummyjson.com/posts/{resource_id}"
    
    try:
        response = requests.delete(url)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (successful deletion often returns empty JSON {})
        if not response.json():
            return None
            
        # Return the 'isDeleted' value if present
        data = response.json()
        return data.get('isDeleted')
        
    except requests.exceptions.HTTPError as e:
        raise e
    except requests.exceptions.RequestException as e:
        raise e
```