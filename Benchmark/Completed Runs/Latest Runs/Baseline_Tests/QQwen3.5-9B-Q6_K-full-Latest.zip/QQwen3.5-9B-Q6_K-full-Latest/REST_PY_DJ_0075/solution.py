import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API using provided inputs.
    
    Args:
        inputs (dict): Dictionary containing 'new_description' and 'new_title'.
        
    Returns:
        int or None: The ID of the created product, or None if response is empty/successful without ID.
        
    Raises:
        requests.exceptions.RequestException: If HTTP request fails.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "description": inputs.get("new_description"),
        "title": inputs.get("new_title")
    }
    
    try:
        response = requests.post(url, json=payload)
        response.raise_for_status()  # Raises HTTPError for bad responses (4xx or 5xx)
        
        if response.status_code == 201:
            data = response.json()
            return data.get("id")
        elif response.status_code == 200:
            # Some APIs might return empty body on success
            return None
            
    except requests.exceptions.RequestException as e:
        raise e