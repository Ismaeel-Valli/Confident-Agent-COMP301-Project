```python
import requests
from urllib.parse import quote

def solve(inputs):
    """
    Creates a milestone in a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - new_state (str): Value for the state attribute ('open' or 'closed').
            - new_title (str): Value for the title attribute.
            - credential (str): The caller-supplied credential (token).
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    new_state = inputs["new_title"]  # Note: The prompt says 'new_state' for state and 'new_title' for title, but the description for new_state in the docstring was missing. I will assume the key is 'new_state' based on the parameter list.
    new_title = inputs["new_title"]
    credential = inputs["credential"]

    # Construct the API URL
    url = f"https://api.github.com/repos/{quote(repository_owner)}/{quote(repository_name)}/milestones"
    
    # Prepare headers with Bearer token authentication
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Prepare the payload for creating the milestone
    payload = {
        "title": new_title,
        "state": new_state
    }

    try:
        response = requests.post(url, headers=headers, json=payload)
        
        if response.status_code == 201:
            # Successful creation, usually returns the created object or empty depending on specific endpoint behavior.
            # The prompt asks to return None for a successful empty response.
            data = response.json()
            if not data:
                return None
            return data
        elif response.status_code == 404:
            raise Exception(f"Resource not found: {response.text}")
        else:
            # Unsuccessful HTTP response
            raise Exception(f"Failed to create milestone. Status code: {response.status_code}, Response: {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```