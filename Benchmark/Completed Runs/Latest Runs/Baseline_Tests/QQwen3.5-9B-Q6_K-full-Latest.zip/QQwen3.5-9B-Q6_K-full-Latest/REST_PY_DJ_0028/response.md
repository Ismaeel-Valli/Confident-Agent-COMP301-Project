```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API using the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'new_title' for the product title.
        
    Returns:
        int or None: The ID of the created product, or None if the response is empty/successful without an ID.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://dummyjson.com/products"
    
    payload = {
        "title": inputs.get("new_title")
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (no content)
        if not response.text.strip():
            return None
            
        data = response.json()
        
        # Return the id value if present, otherwise None
        return data.get("id")
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Failed to submit product: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```