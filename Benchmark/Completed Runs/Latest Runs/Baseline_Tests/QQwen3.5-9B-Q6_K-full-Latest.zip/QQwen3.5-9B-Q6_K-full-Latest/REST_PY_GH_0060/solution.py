import requests

def solve(inputs):
    """
    Unstars a repository for the authenticated user via GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The authentication token or bearer string.
    
    Returns:
        int: The successful HTTP status code (expected 204 No Content).
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    credential = inputs['credential']
    
    url = f"https://api.github.com/user/starred/{owner}/{repo}"
    
    headers = {
        'Authorization': f'Bearer {credential}',
        'Accept': 'application/vnd.github+json'
    }
    
    response = requests.delete(url, headers=headers)
    
    if response.status_code != 204:
        raise Exception(f"Failed to unstar repository. Status code: {response.status_code}, Response: {response.text}")
    
    return response.status_code