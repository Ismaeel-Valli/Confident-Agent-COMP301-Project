import requests
from urllib.parse import quote

def solve(inputs):
    """
    Creates an issue in a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository.
            - new_title (str): The title for the new issue.
            - credential (str): The caller-supplied credential (token).
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty (success), or raises an exception on failure.
    
    Raises:
        requests.RequestException: If the HTTP request fails or returns an unsuccessful status code.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    new_title = inputs["new_title"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{quote(repository_owner, safe='')}/{quote(repository_name, safe='')}/issues"
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    data = {
        "title": new_title
    }
    
    response = requests.post(url, headers=headers, json=data)
    
    if response.status_code != 201:
        response.raise_for_status()
    
    return None