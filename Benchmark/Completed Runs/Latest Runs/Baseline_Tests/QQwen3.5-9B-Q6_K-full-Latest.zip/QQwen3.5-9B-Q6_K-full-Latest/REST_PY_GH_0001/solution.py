import requests
from requests.exceptions import RequestException, HTTPError

def solve(inputs):
    """
    Fetches an organization from the GitHub REST API (version 2026-03-10).
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The name of the organization.
            - 'credential' (str): The authentication token or header value.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    org_name = inputs['organization']
    credential = inputs['credential']
    
    # Construct the URL for fetching an organization
    url = f"https://api.github.com/orgs/{org_name}"
    
    # Prepare headers with the provided credential (assuming it's a Bearer token or similar)
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None if the response is empty (though GitHub usually returns a dict even for empty orgs)
        if not data:
            return None
            
        return data
    
    except HTTPError as http_err:
        raise Exception(f"HTTP error occurred: {http_err}")
    except RequestException as err:
        raise Exception(f"Request failed: {err}")