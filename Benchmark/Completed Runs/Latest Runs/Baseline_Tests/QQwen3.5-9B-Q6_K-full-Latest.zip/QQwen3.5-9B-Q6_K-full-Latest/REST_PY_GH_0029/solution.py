import requests

def solve(inputs):
    """
    Deletes a label from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository.
            - name (str): The name of the label to delete.
            - credential (str): The caller-supplied credential (e.g., token).
    
    Returns:
        int: The successful HTTP status code (typically 204).
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails or returns an unsuccessful status code.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    name = inputs["name"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/labels/{name}"
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.delete(url, headers=headers)
    
    if response.status_code >= 400:
        raise requests.exceptions.RequestException(f"Failed to delete label. Status code: {response.status_code}, Response: {response.text}")
    
    return response.status_code