```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_phone' (new phone number).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    new_phone = inputs.get('new_phone')
    
    # Base URL for DummyJSON API (assuming standard structure)
    base_url = "https://dummyjson.com/users"
    
    # Prepare the update payload
    payload = {
        "phone": new_phone
    }
    
    try:
        response = requests.put(
            f"{base_url}/{resource_id}",
            json=payload
        )
        
        if response.status_code == 200:
            # Check if the response contains an 'id' field
            data = response.json()
            return data.get('id')
        elif response.status_code == 204:
            # Empty response is considered successful
            return None
        else:
            raise Exception(f"HTTP {response.status_code}: {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```