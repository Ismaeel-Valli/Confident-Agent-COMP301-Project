```python
import requests

def solve(inputs):
    """
    Updates a GitHub issue with a new title using the GitHub REST API.
    
    Parameters:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - issue_number (int): The issue number to update.
            - new_title (str): The new title for the issue.
            - credential (dict): Contains authentication details, assumed to have 'token' key.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP request is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    new_title = inputs["new_title"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}"
    
    headers = {
        "Authorization": f"token {credential['token']}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    data = {
        "title": new_title
    }
    
    response = requests.put(url, json=data, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update issue. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json() if response.text else None
```