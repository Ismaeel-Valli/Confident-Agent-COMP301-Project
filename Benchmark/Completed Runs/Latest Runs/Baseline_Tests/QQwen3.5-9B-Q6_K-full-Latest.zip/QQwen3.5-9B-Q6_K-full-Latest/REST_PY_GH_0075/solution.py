import requests

def solve(inputs):
    """
    Lists repository issues for GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository without the .git extension.
            - 'state' (str): The state of the issues to return ('open', 'closed', or 'all').
            - 'credential' (str): The Bearer token for authentication.
    
    Returns:
        list or None: A list of decoded JSON issue objects, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response status code indicates an error.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    state = inputs['state']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/issues"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    params = {'state': state}
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch issues. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    return data if data else None