```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'new_title' for the product title.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "title": inputs["new_title"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code == 201:
            # Successful creation, check if response is empty
            if not response.text.strip():
                return None
            return response.json()
        elif response.status_code == 400:
            raise Exception(f"Bad Request: {response.text}")
        else:
            raise Exception(f"Failed to create product. Status code: {response.status_code}, Response: {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```