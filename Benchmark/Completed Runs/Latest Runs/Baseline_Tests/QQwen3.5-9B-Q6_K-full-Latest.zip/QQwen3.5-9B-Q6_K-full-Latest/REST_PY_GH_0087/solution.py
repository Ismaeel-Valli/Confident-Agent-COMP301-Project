import requests

def solve(inputs):
    """
    Updates a pull request on GitHub using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - pull_number (int): The number that identifies the pull request.
            - new_body (str): The new value for the body attribute.
            - credential (str): The caller-supplied credential (e.g., token).
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    pull_number = inputs["pull_number"]
    new_body = inputs["new_body"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/pulls/{pull_number}"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    payload = {
        "body": new_body
    }

    response = requests.patch(url, json=payload, headers=headers)

    if response.status_code != 200:
        raise requests.RequestException(f"Failed to update pull request. Status code: {response.status_code}, Response: {response.text}")

    return response.json() if response.content else None