```python
import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON based on the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'result_limit' specifying the maximum number of results.
        
    Returns:
        list or None: The decoded JSON response as a list of products, or None if the response is empty.
        
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    result_limit = inputs.get('result_limit', 10)
    
    url = "https://dummyjson.com/products"
    params = {
        'limit': result_limit,
        'skip': 0  # Retrieve one page starting from the beginning
    }
    
    response = requests.get(url, params=params)
    
    if response.status_code != 200:
        raise requests.RequestException(f"HTTP request failed with status code: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns a dictionary with 'products' key containing the list
    products = data.get('products', [])
    
    return products if products else None
```