```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_description'.
        
    Returns:
        str or None: The response's id value, or None if absent or on successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    new_description = inputs.get('new_description')
    
    # Base URL for DummyJSON API
    base_url = "https://dummyjson.com"
    url = f"{base_url}/products/{resource_id}"
    
    payload = {
        "description": new_description
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses
    if not response.ok:
        raise Exception(f"HTTP request failed with status code: {response.status_code}")
    
    # Return the id from the response if present, otherwise None
    data = response.json()
    return data.get('id')
```