import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API with provided age and first name.
    
    Args:
        inputs (dict): Dictionary containing 'new_age' and 'new_firstName'.
        
    Returns:
        int or None: The ID of the created user, or None if response is empty/missing ID.
        Raises:
            requests.exceptions.HTTPError: If the HTTP response status code indicates failure.
    """
    url = "https://dummyjson.com/users/add"
    
    payload = {
        "age": inputs.get("new_age"),
        "firstName": inputs.get("new_firstName")
    }
    
    try:
        response = requests.post(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Check if the response content is empty
        if not response.text.strip():
            return None
            
        data = response.json()
        
        # Return the id if present, otherwise None
        return data.get("id")
        
    except requests.exceptions.HTTPError as e:
        raise e
    except Exception as e:
        # Re-raise other exceptions to let the caller handle them appropriately
        raise e