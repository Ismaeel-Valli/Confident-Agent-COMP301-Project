import requests
from requests.exceptions import RequestException, HTTPError

def solve(inputs):
    """
    Deletes a user by identifier using DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with the user identifier.
        
    Returns:
        None if deletion is successful (empty response).
        Decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses or network errors.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON endpoint for deleting a user by ID
    url = f"https://dummyjson.com/users/{resource_id}"
    
    try:
        response = requests.delete(url)
        response.raise_for_status()  # Raises HTTPError for bad responses (4xx, 5xx)
        
        # According to DummyJSON API, successful deletion returns an empty body with status 200
        if not response.text.strip():
            return None
            
        return response.json()
        
    except HTTPError as http_err:
        raise Exception(f"HTTP error occurred: {http_err}")
    except RequestException as err:
        raise Exception(f"Request failed: {err}")