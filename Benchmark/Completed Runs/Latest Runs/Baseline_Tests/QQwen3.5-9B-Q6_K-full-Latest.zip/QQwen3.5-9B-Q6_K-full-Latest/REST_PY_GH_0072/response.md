```python
import requests

def solve(inputs):
    """
    Fetches a commit from the GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - page (int): The page number of the results to fetch.
            - ref (str): The commit reference.
            - credential (str): The caller-supplied credential (e.g., token).
    
    Returns:
        dict or None: The decoded JSON response, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    page = inputs["page"]
    ref = inputs["ref"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/commits/{ref}"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    params = {
        "page": page
    }
    
    response = requests.get(url, headers=headers, params=params, auth=("token", credential))
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch commit: HTTP {response.status_code} - {response.text}")
    
    data = response.json()
    
    return None if not data else data
```