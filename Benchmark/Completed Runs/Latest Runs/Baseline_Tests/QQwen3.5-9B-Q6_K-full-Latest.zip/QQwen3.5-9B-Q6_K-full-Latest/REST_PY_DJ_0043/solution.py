import requests

def solve(inputs):
    """
    Submits a new todo to DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_completed: value for the 'completed' attribute
            - new_todo: value for the 'todo' attribute
            - new_user_identifier: value for the 'userId' attribute
    
    Returns:
        str or None: The response's id value, or None if absent or on successful empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code outside 200-299).
    """
    base_url = "https://jsonplaceholder.typicode.com/todos"
    
    payload = {
        "userId": inputs["new_user_identifier"],
        "title": inputs["new_todo"],
        "completed": inputs["new_completed"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if not (200 <= response.status_code < 300):
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    # Check for empty response body
    if not response.text.strip():
        return None
    
    try:
        data = response.json()
        return data.get("id")
    except ValueError:
        # If JSON parsing fails, treat as no valid id found
        return None