import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON using the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing API configuration, expected to have 'baseUrl' and 'page'.
        
    Returns:
        dict or None: The decoded JSON response if successful. Returns None for an empty response.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request is unsuccessful.
    """
    base_url = inputs.get('baseUrl', 'https://jsonplaceholder.typicode.com')
    page = inputs.get('page', 1)
    
    url = f"{base_url}/posts?page={page}"
    
    try:
        response = requests.get(url, timeout=5)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None if the response is empty (though DummyJSON posts endpoint rarely returns empty unless filtered heavily)
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise SystemExit(f"HTTP request failed: {e}")