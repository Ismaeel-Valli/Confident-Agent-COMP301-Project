import requests

def solve(inputs):
    """
    Lists watchers for a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - page_size (int): The number of results per page (max 100).
            - credential (str): The caller-supplied credential (e.g., token or Bearer token).
    
    Returns:
        list | None: A list of decoded JSON responses for each page, or None if the response is empty.
    
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    page_size = inputs["page_size"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/network/stargazers"
    # Note: The endpoint for watchers is /repos/{owner}/{repo}/watchers, not stargazers.
    url = f"https://api.github.com/repos/{owner}/{repo}/watchers"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    all_results = []
    page = 1
    
    while True:
        params = {
            "per_page": page_size,
            "page": page
        }
        
        response = requests.get(url, headers=headers, params=params)
        
        if response.status_code != 200:
            raise requests.RequestException(f"Failed to fetch watchers: {response.status_code} - {response.text}")
        
        data = response.json()
        
        if not data:
            return None
        
        all_results.extend(data)
        
        # Check if there are more pages
        if len(data) < page_size:
            break
        
        page += 1
    
    return all_results