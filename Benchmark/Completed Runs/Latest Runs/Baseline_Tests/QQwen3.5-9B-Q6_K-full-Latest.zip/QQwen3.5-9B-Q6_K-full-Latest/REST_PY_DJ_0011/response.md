```python
import requests

def solve(inputs):
    """
    Searches for users using a search term from the inputs dictionary.
    
    Args:
        inputs (dict): A dictionary containing 'search_text' key with the search term.
        
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty but successful.
                      
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    search_text = inputs.get('search_text')
    
    url = "https://dummyjson.com/users/search"
    params = {'q': search_text}
    
    response = requests.get(url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP request failed with status code: {response.status_code}")
    
    data = response.json()
    
    # According to DummyJSON API, an empty search returns a list of users (possibly empty)
    # The instruction says "Return None for a successful empty response". 
    # Assuming this means if the 'users' list in the response is empty.
    if not data.get('users'):
        return None
        
    return data
```