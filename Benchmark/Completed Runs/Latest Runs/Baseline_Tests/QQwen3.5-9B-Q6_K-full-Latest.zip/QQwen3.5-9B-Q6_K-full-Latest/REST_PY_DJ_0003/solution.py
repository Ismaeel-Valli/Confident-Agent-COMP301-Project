import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the product.
            - new_title (str): New value for the title attribute.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty (successful).
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    new_title = inputs.get('new_title')
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {
        "title": new_title
    }
    
    try:
        response = requests.put(url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 204:
            return None
        
        return response.json()
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")