```python
import requests

def solve(inputs):
    """
    Submits a new todo to DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'new_completed': value for the completed attribute (bool)
            - 'new_todo': value for the todo attribute (str)
            - 'new_user_identifier': value for the user Id attribute (int)
    
    Returns:
        dict or None: The decoded JSON response if successful, None for an empty response.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request is unsuccessful.
    """
    url = "https://jsonplaceholder.typicode.com/todos"
    
    payload = {
        "userId": inputs["new_user_identifier"],
        "title": inputs["new_todo"],
        "completed": inputs["new_completed"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to submit todo. Status code: {response.status_code}, Response: {response.text}")
    
    return None
```