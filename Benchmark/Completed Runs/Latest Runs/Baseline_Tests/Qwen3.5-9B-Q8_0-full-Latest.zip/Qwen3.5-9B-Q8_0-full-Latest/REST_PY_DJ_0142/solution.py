import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API with provided category and title.
    
    Args:
        inputs (dict): Contains 'new_category' and 'new_title' keys.
        
    Returns:
        str or None: The title from the response if present, otherwise None for success.
                     Raises an exception for unsuccessful HTTP responses.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "title": inputs["new_title"],
        "category": inputs["new_category"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (successful but no content)
        if not response.text.strip():
            return None
        
        # Try to extract title from response
        try:
            data = response.json()
            return data.get("title")
        except ValueError:
            # If JSON parsing fails, check raw text for title
            if "title" in response.text:
                return response.text.split("title")[1].split("</")[0]
            return None
            
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")