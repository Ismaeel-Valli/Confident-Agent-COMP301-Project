import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on pagination inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip.
    
    Returns:
        list or None: The decoded JSON response as a list of todos, or None if the response is empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com/todos"
    
    params = {
        "_limit": inputs.get("result_limit", 10),
        "_skip": inputs.get("results_to_skip", 0)
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise requests.RequestException(f"HTTP request failed with status code: {response.status_code}")
    
    data = response.json()
    
    return data if data else None