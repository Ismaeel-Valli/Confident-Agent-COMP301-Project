```python
import requests
from urllib.parse import quote

def solve(inputs):
    """
    Creates a new repository for the authenticated user using GitHub REST API.
    
    Args:
        inputs (dict): Dictionary containing:
            - "new_name": str, name for the new repository
            - "credential": dict, containing authentication details (e.g., token)
    
    Returns:
        None if successful (empty response), or decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response indicates failure.
    """
    # Extract inputs
    new_name = inputs["new_name"]
    credential = inputs["credential"]
    
    # Prepare headers with authentication
    headers = {
        "Authorization": f"token {credential.get('token', '')}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare the request URL and payload
    url = "https://api.github.com/user/repos"
    payload = {
        "name": new_name
    }
    
    # Make the POST request
    response = requests.post(url, headers=headers, json=payload)
    
    # Check for successful response (201 Created or 204 No Content)
    if response.status_code in [201, 204]:
        return None
    
    # Raise an exception for unsuccessful responses
    response.raise_for_status()
```