```python
import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on provided pagination parameters.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip.
            
    Returns:
        list or None: The decoded JSON response as a list of users, or None if the response is empty.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com/users"
    
    # Construct query parameters
    params = {
        "_limit": inputs.get("result_limit"),
        "_skip": inputs.get("results_to_skip")
    }
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None if the response is empty
        if not data:
            return None
            
        return data
        
    except requests.RequestException as e:
        raise e
```