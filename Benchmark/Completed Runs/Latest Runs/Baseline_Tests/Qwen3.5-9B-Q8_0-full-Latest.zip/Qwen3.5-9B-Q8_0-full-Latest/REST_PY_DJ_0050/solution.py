import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the user.
            - new_lastName (str): New value for the last name attribute.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty (successful).
    
    Raises:
        requests.exceptions.HTTPError: If the HTTP response indicates an error.
    """
    resource_id = inputs.get('resource_id')
    new_last_name = inputs.get('new_lastName')

    if not resource_id or new_last_name is None:
        raise ValueError("Missing required input fields: 'resource_id' and 'new_lastName'.")

    url = f"https://dummyjson.com/users/{resource_id}"
    
    payload = {
        "lastName": new_last_name
    }

    response = requests.put(url, json=payload)
    response.raise_for_status()

    if response.status_code == 204:
        return None
    
    return response.json()