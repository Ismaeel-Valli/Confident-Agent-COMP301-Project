import requests
from urllib.parse import quote

def solve(inputs):
    """
    Updates a GitHub issue using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository.
            - issue_number (int): The issue number to update.
            - new_body (str): The new body content for the issue.
            - credential (str): The authentication token or string.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    new_body = inputs["new_body"]
    credential = inputs["credential"]
    
    # Construct the API URL for version 2026-03-10
    url = f"https://api.github.com/repos/{quote(repository_owner, safe='')}/{quote(repository_name, safe='')}/issues/{issue_number}"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10",
        "Content-Type": "application/json"
    }
    
    payload = {
        "body": new_body
    }
    
    response = requests.put(url, headers=headers, json=payload)
    
    if response.status_code == 200:
        # GitHub typically returns a 200 OK with an empty body for updates
        return None
    elif response.status_code >= 400:
        raise Exception(f"Failed to update issue. Status code: {response.status_code}, Response: {response.text}")
    else:
        # Handle unexpected status codes
        raise Exception(f"Unexpected status code: {response.status_code}")

# Example usage (not executed):
# inputs = {
#     "repository_owner": "owner",
#     "repository_name": "repo",
#     "issue_number": 123,
#     "new_body": "Updated issue body",
#     "credential": "your_token_here"
# }
# result = solve(inputs)