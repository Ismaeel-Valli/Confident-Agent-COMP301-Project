```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API using provided inputs.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_username'.
        
    Returns:
        int or None: The ID of the created user, or None if response is empty/successful without ID.
        
    Raises:
        requests.RequestException: If HTTP response indicates failure.
    """
    base_url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "name": inputs.get("new_firstName"),
        "username": inputs.get("new_username")
    }
    
    try:
        response = requests.post(base_url, json=payload)
        response.raise_for_status()  # Raises HTTPError for bad responses (4xx or 5xx)
        
        if response.status_code == 201:  # Created
            data = response.json()
            return data.get("id")
        elif response.status_code == 204:  # No Content (successful empty response)
            return None
        else:
            raise Exception(f"Unexpected successful status code: {response.status_code}")
            
    except requests.exceptions.HTTPError as e:
        if response.status_code >= 400:
            raise Exception(f"Failed to create user. HTTP Error: {e}")
        raise
```