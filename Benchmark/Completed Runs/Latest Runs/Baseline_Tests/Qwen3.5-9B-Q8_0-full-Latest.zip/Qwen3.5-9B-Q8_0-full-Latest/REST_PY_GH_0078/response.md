```python
import requests

def solve(inputs):
    """
    Fetches issue comments from a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - issue_number (int): The number that identifies the issue.
            - since (str, optional): ISO 8601 timestamp to filter comments updated after this time.
            - credential (str): The authentication token or header value for the API request.
    
    Returns:
        list or None: A list of decoded JSON comment objects if comments exist, otherwise None.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    since = inputs.get("since")
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}/comments"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10",
        "Authorization": f"Bearer {credential}"
    }
    
    params = {}
    if since:
        params["since"] = since
    
    response = requests.get(url, headers=headers, params=params)
    
    if not response.ok:
        raise Exception(f"GitHub API request failed with status code {response.status_code}: {response.text}")
    
    data = response.json()
    
    # GitHub returns an empty list [] for no comments. 
    # The requirement says "Return None for a successful empty response".
    if not data:
        return None
    
    return data
```