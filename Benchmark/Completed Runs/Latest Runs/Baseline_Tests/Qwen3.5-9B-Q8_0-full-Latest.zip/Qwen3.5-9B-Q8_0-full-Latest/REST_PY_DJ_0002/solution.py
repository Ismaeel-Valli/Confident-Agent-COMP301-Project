import requests

def solve(inputs):
    """
    Retrieves a product by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (str) of the product.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.RequestException: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        if response.status_code == 200 and not response.content:
            return None
            
        return response.json()
        
    except requests.RequestException as e:
        raise e