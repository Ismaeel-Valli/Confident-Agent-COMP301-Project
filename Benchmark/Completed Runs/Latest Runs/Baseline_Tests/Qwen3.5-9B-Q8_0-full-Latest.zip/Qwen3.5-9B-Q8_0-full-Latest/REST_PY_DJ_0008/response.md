```python
import requests

def solve(inputs):
    """
    Retrieves a user by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with user identifier.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.RequestException: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    
    # DummyJSON endpoint for getting a user by ID
    url = f"https://jsonplaceholder.typicode.com/users/{resource_id}"
    
    try:
        response = requests.get(url)
        
        if response.status_code == 200:
            data = response.json()
            return None if not data else data
        else:
            raise requests.RequestException(f"HTTP {response.status_code}: Failed to retrieve user")
            
    except requests.RequestException as e:
        raise e
```