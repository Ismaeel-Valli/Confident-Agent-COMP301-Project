import requests
from urllib.parse import quote

def solve(inputs):
    """
    Creates a milestone in a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - new_title (str): Value for the title attribute.
            - credential (str): Caller-supplied credential (token).
    
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    title = inputs["new_title"]
    token = inputs["credential"]
    
    url = f"https://api.github.com/repos/{quote(owner, safe='')}/{quote(repo, safe='')}/milestones"
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    payload = {
        "title": title
    }
    
    response = requests.post(url, headers=headers, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create milestone. Status code: {response.status_code}, Response: {response.text}")
    
    return None