import requests

def solve(inputs):
    """
    Lists repository contributors from GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - anon (bool or int): Set to 1 or true to include anonymous contributors.
            - credential (dict): Caller-supplied credentials (assumed to have necessary permissions).
    
    Returns:
        list or None: Decoded JSON response as a list of contributors, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    anon = inputs.get("anon", False)
    credential = inputs["credential"]
    
    # Construct the URL for the contributors endpoint
    url = f"https://api.github.com/repos/{owner}/{repo}/contributors"
    
    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Add query parameter for anonymous contributors if needed
    params = {}
    if anon:
        params["anon"] = True
    
    # Make the GET request
    response = requests.get(url, headers=headers, params=params)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Decode the JSON response
    data = response.json()
    
    # Return None if the response is empty (successful but no contributors)
    if not data:
        return None
    
    return data