import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API using provided first and last name.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_lastName'.
        
    Returns:
        int or None: The ID of the created user, or None if response is empty.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    url = "https://dummyjson.com/users/add"
    
    payload = {
        "firstName": inputs.get("new_firstName"),
        "lastName": inputs.get("new_lastName")
    }
    
    try:
        response = requests.post(url, json=payload)
        response.raise_for_status()  # Raises HTTPError for bad responses (4xx or 5xx)
        
        if response.status_code == 201 and response.text.strip():
            data = response.json()
            return data.get("id")
        elif response.status_code == 201:
            return None
            
    except requests.RequestException as e:
        raise e

# Example usage (not executed):
# inputs = {"new_firstName": "John", "new_lastName": "Doe"}
# user_id = solve(inputs)