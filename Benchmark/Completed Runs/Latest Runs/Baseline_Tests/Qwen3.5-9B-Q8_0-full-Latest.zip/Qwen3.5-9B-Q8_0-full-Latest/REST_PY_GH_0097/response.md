```python
import requests
from urllib.parse import quote_plus

def solve(inputs):
    """
    Creates a new repository for the authenticated user via GitHub REST API.
    
    Args:
        inputs (dict): Contains 'new_name', 'new_description', and 'credential'.
        
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty body.
        
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    new_name = inputs["new_name"]
    new_description = inputs["new_description"]
    credential = inputs["credential"]
    
    # GitHub API version 2026-03-10
    api_url = "https://api.github.com/user/repos"
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10",
        "Authorization": f"token {credential}"
    }
    
    data = {
        "name": new_name,
        "description": new_description
    }
    
    response = requests.post(api_url, headers=headers, json=data)
    
    if response.status_code == 201:
        return None
    elif response.status_code == 202:
        # Accepted, but we wait for the actual creation. 
        # For this exercise, we assume immediate success or handle as error depending on strictness.
        # Since the prompt says "Return None for a successful empty response", and 202 is not empty body usually,
        # but let's stick to the main success case 201. If 202 comes, it might be rate limited or queued.
        # We'll treat non-201 as error per "Raise an exception for an unsuccessful HTTP response".
        pass
    
    if response.status_code >= 400:
        raise Exception(f"Failed to create repository. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json()
```