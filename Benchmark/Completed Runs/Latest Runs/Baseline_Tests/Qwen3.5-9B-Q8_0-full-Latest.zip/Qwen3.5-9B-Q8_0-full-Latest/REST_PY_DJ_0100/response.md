```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post in DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the post to update.
            - new_user_identifier (str): New value for the user Id attribute.
    
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    resource_id = inputs.get("resource_id")
    new_user_identifier = inputs.get("new_user_identifier")
    
    if not resource_id or new_user_identifier is None:
        raise ValueError("Missing required input fields: resource_id and new_user_identifier")

    url = f"{base_url}/posts/{resource_id}"
    payload = {"userId": new_user_identifier}

    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update post. Status code: {response.status_code}, Response: {response.text}")
    
    if len(response.content) == 0:
        return None
    
    return response.json()
```