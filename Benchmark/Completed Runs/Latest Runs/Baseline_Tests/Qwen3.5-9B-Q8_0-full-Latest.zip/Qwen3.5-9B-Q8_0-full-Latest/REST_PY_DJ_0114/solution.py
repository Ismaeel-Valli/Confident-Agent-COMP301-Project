import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (product ID) and 'new_price' (new price value).
        
    Returns:
        str or None: The title of the updated product, or None if absent or response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_price = inputs['new_price']
    
    # DummyJSON API endpoint for updating a product
    url = f"https://dummyjson.com/products/{resource_id}"
    
    payload = {
        "price": new_price
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Check if the response is empty (no content)
    if not response.text.strip():
        return None
    
    try:
        data = response.json()
        # Return the title if present, otherwise None
        return data.get('title')
    except ValueError:
        # If JSON parsing fails but we have content, return None
        return None