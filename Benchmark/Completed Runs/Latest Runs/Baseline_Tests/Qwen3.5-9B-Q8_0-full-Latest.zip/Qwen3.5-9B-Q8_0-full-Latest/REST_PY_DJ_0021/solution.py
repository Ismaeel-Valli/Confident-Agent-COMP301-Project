import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id' (todo ID) and 'new_todo' (value to update).
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_todo_value = inputs['new_todo']
    
    # DummyJSON API endpoint for updating a todo
    url = f"https://jsonplaceholder.typicode.com/todos/{resource_id}"
    
    payload = {
        "todo": new_todo_value
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        # Return None for successful empty response (though DummyJSON usually returns the updated object)
        if not response.text.strip():
            return None
        return response.json()
    else:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}, Response: {response.text}")