```python
import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on skip count and included fields.
    
    Args:
        inputs (dict): A dictionary containing:
            - results_to_skip (int): Number of results to skip.
            - included_fields (str): Comma-separated list of fields to include.
    
    Returns:
        dict or None: Decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    # Parse included_fields
    fields_list = [field.strip() for field in inputs['included_fields'].split(',')]
    
    # Build query parameters
    params = {
        'skip': inputs['results_to_skip'],
        '_limit': 1,  # Retrieve one page (one result)
        '_fields': ','.join(fields_list)
    }
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raises an HTTPError for bad responses
        
        data = response.json()
        
        # Return None for successful empty response
        if not data:
            return None
            
        return data
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```