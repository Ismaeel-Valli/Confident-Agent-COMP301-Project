import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on the provided sort_field.
    
    Args:
        inputs (dict): A dictionary containing 'sort_field' key.
        
    Returns:
        list or None: The decoded JSON response as a list of users, or None if the response is empty.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    sort_field = inputs.get('sort_field')
    
    # Construct the API URL with sorting parameter
    url = f"https://jsonplaceholder.typicode.com/users?sort={sort_field}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
            
        return data
        
    except requests.RequestException as e:
        raise e