```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (product ID) and 'new_price' (new price value).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_price = inputs['new_price']
    
    # DummyJSON API endpoint for updating a product
    url = f"https://dummyjson.com/products/{resource_id}"
    
    payload = {
        "price": new_price
    }
    
    try:
        response = requests.put(url, json=payload)
        
        if response.status_code != 200:
            raise Exception(f"HTTP error! Status code: {response.status_code}")
        
        # Check if the response contains an 'id' field
        data = response.json()
        return data.get('id')
    
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```