```python
import requests

def solve(inputs):
    """
    Searches for products on DummyJSON using the provided search term.
    
    Args:
        inputs (dict): A dictionary containing 'search_text' key with the search term.
        
    Returns:
        list or None: The decoded JSON response as a list of products, or None if the response is empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com"  # Note: DummyJSON doesn't have a standard public search API like this, but jsonplaceholder does for posts/users/etc. 
    # However, the prompt specifically asks for "DummyJSON". Since DummyJSON (api.dummyjson.com) has a /products endpoint but no built-in search query parameter in their v1/v2 docs that works exactly like a text search filter returning filtered results dynamically without pagination logic often required, 
    # we will assume the standard behavior for such tasks: hitting the products endpoint. 
    # BUT, re-reading "Search products using a search term", DummyJSON v2 has /products?search={term}.
    
    url = f"https://api.dummyjson.com/products?search={inputs['search_text']}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise SystemExit(e)
```