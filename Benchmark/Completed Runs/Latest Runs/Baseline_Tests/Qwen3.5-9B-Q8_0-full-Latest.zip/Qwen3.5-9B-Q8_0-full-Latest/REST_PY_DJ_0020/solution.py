import requests

def solve(inputs):
    """
    Retrieves a todo by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with the todo identifier.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.exceptions.RequestException: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    url = f"https://jsonplaceholder.typicode.com/todos/{resource_id}"
    
    response = requests.get(url)
    response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
    
    if response.status_code == 200:
        data = response.json()
        return data if data else None
    
    raise Exception(f"Unsuccessful HTTP response: {response.status_code}")