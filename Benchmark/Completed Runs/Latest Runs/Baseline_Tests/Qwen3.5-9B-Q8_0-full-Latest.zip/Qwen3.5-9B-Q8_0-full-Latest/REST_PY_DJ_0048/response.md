```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API using the provided inputs.
    
    Args:
        inputs (dict): Dictionary containing 'new_title' for the product title.
        
    Returns:
        str or None: The response's title value if present, otherwise None.
                     Returns None for a successful empty response.
                     
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "title": inputs.get("new_title")
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code != 200:
            raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
        
        # Check if the response is empty (no content)
        if not response.content:
            return None
            
        data = response.json()
        
        # Return title if present in the response, otherwise None
        return data.get("title")
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```