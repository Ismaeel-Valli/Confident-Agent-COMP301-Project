import requests
from requests.exceptions import RequestException

def solve(inputs):
    """
    Updates selected fields of a post on DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id', 'new_body', and 'new_title'.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    new_body = inputs.get('new_body')
    new_title = inputs.get('new_title')
    
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    payload = {
        "body": new_body,
        "title": new_title
    }
    
    try:
        response = requests.put(url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 204:
            return None
        
        return response.json()
        
    except RequestException as e:
        raise Exception(f"Failed to update post: {str(e)}")