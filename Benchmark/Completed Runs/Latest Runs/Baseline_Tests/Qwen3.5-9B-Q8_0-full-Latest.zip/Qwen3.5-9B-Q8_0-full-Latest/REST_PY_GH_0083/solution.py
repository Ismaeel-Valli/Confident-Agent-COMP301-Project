import requests
from urllib.parse import quote

def solve(inputs):
    """
    Creates a milestone in a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - new_state (str): Value for the state attribute ('open' or 'closed').
            - new_title (str): Value for the title attribute.
            - credential (str): Bearer token for authentication.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    state = inputs["new_state"]
    title = inputs["new_title"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/milestones"
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    data = {
        "title": title,
        "state": state
    }
    
    response = requests.post(url, headers=headers, json=data)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create milestone. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json()