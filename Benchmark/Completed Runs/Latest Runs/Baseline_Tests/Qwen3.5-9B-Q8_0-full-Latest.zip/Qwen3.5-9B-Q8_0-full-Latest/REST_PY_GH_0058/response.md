```python
import requests

def solve(inputs):
    """
    Checks if a repository is starred by the authenticated user using GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git extension).
            - 'credential' (str): The Bearer token for authentication.
    
    Returns:
        int: The successful HTTP status code (200 if starred, 404 if not starred).
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    token = inputs['credential']
    
    url = f"https://api.github.com/user/starred/{owner}/{repo}"
    headers = {
        'Authorization': f'Bearer {token}',
        'Accept': 'application/vnd.github+json'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code >= 400:
        raise Exception(f"GitHub API request failed with status code: {response.status_code}")
    
    return response.status_code
```