```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_email' (new email value).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_email = inputs['new_email']
    
    # Base URL for DummyJSON API
    base_url = "https://jsonplaceholder.typicode.com"
    url = f"{base_url}/users/{resource_id}"
    
    # Prepare the payload with only the email field to update
    payload = {
        "email": new_email
    }
    
    try:
        response = requests.put(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (no content)
        if not response.text.strip():
            return None
        
        # Parse the JSON response and extract the id
        data = response.json()
        return data.get('id')
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```