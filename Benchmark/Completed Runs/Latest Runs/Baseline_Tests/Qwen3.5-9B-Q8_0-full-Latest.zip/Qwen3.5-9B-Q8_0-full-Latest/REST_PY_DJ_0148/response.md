```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON and returns the response's id value,
    or None if that attribute is absent or for a successful empty response.
    Raises an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the todo to update
            - new_completed (bool): New value for the completed attribute
            - new_user_identifier (str): New value for the user Id attribute
    
    Returns:
        str or None: The response's id value, or None if absent or empty response
    
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful
    """
    resource_id = inputs['resource_id']
    new_completed = inputs['new_completed']
    new_user_identifier = inputs['new_user_identifier']
    
    # Base URL for DummyJSON API
    base_url = "https://dummyjson.com"
    endpoint = f"{base_url}/todos/{resource_id}"
    
    # Prepare the payload with only the fields to update
    payload = {
        "completed": new_completed,
        "userId": new_user_identifier
    }
    
    try:
        response = requests.put(endpoint, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Check if the response is empty
        if not response.text.strip():
            return None
        
        # Parse the JSON response
        data = response.json()
        
        # Return the id value if present, otherwise None
        return data.get('id')
    
    except requests.RequestException as e:
        raise e
```