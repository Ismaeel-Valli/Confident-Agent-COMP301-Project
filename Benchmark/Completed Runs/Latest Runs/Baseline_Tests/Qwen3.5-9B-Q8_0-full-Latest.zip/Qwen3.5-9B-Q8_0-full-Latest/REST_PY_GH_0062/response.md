```python
import requests

def solve(inputs):
    """
    Lists followers of a GitHub user using the GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - "username" (str): The handle for the GitHub user account.
            - "credential" (str): The caller-supplied credential (e.g., token).
    
    Returns:
        list or None: A list of decoded JSON follower objects, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    username = inputs["username"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/users/{username}/followers"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch followers for user '{username}': HTTP {response.status_code}")
    
    data = response.json()
    
    # Return None for a successful empty response (though GitHub typically returns [] directly)
    return data if data else None
```