import requests

def solve(inputs):
    """
    Lists issue comments for a specific GitHub repository issue using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'issue_number' (int): The issue number.
            - 'credential' (str): The authentication token or string for the API call.
    
    Returns:
        list or None: A list of decoded JSON comment objects, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response status code indicates an error (non-2xx).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    issue_number = inputs['issue_number']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}/comments"
    
    headers = {
        'Accept': 'application/vnd.github+json',
        'Authorization': f'Bearer {credential}'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"GitHub API request failed with status code: {response.status_code}. Response body: {response.text}")
    
    data = response.json()
    
    if not data:
        return None
    
    return data