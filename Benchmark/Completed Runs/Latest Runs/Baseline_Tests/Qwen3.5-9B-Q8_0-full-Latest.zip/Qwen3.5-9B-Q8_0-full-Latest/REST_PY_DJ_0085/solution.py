import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API.
    
    Args:
        inputs (dict): Contains 'new_description' and 'new_title'.
        
    Returns:
        str or None: The title from the response, or None if absent or successful empty response.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "description": inputs["new_description"],
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to submit product. Status code: {response.status_code}")
    
    # Check if the response is empty or doesn't contain a title
    data = response.json()
    if not data or "title" not in data:
        return None
        
    return data["title"]