```python
import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on provided pagination parameters.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip (offset).
    
    Returns:
        list or None: The decoded JSON response as a list of posts, or None if the response is empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    params = {
        "limit": inputs.get("result_limit", 10),
        "skip": inputs.get("results_to_skip", 0)
    }
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
    
    data = response.json()
    
    if not data:
        return None
    
    return data
```