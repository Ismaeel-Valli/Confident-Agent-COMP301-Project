import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_phone' (new phone number).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_phone = inputs['new_phone']
    
    url = f"https://dummyjson.com/users/{resource_id}"
    data = {"phone": new_phone}
    
    try:
        response = requests.put(url, json=data)
        
        if response.status_code != 200:
            raise Exception(f"HTTP {response.status_code}: {response.text}")
        
        # DummyJSON returns a 200 OK with an empty body for successful updates
        if not response.text.strip():
            return None
            
        response_data = response.json()
        
        # Return the id from the response if present
        if 'id' in response_data:
            return response_data['id']
            
    except requests.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")

# Example usage (not executed):
# inputs = {"resource_id": 1, "new_phone": "+1234567890"}
# result = solve(inputs)