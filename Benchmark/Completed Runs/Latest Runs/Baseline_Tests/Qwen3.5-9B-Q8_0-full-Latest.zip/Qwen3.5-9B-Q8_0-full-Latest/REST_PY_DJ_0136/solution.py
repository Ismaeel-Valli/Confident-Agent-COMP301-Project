import requests
import json

def solve(inputs):
    """
    Submits a new user to DummyJSON API using provided inputs.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_username'.
        
    Returns:
        None if the response is successful and empty.
        Decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    # Prepare the payload based on inputs
    payload = {
        "name": inputs.get("new_firstName"),
        "username": inputs.get("new_username")
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code == 201:
            # Successful creation with empty response body
            return None
        elif response.status_code == 200:
            # Success but with data (though typically POST to create returns 201)
            return response.json()
        else:
            raise Exception(f"HTTP error occurred: {response.status_code} - {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")