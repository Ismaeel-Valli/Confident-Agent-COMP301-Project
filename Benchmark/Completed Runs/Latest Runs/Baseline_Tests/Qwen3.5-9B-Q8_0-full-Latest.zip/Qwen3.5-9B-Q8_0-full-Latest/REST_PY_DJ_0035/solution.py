import requests

def solve(inputs):
    """
    Retrieves a post by identifier from DummyJSON API and returns its ID.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with the post identifier.
        
    Returns:
        int or None: The post's ID if found, None for successful empty response.
        
    Raises:
        requests.exceptions.HTTPError: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    
    if not resource_id:
        raise ValueError("Missing 'resource_id' in inputs")
    
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises HTTPError for bad responses (4xx or 5xx)
        
        if not response.json():
            return None
            
        data = response.json()
        return data.get('id')
        
    except requests.exceptions.HTTPError:
        raise
    except Exception as e:
        # Re-raise as HTTPError to maintain the contract for unsuccessful responses
        raise requests.exceptions.HTTPError(f"Failed to retrieve post: {str(e)}") from e