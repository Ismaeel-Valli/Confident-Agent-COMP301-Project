```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_description'.
        
    Returns:
        str or None: The title from the response, or None if absent or empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_description = inputs['new_description']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {
        "description": new_description
    }
    
    try:
        response = requests.put(url, json=payload)
        
        if response.status_code != 200:
            raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
        
        if not response.json():
            return None
            
        data = response.json()
        return data.get('title')
        
    except requests.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```