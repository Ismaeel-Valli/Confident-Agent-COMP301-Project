```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (product ID) and 'new_title' (new title value).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_title = inputs['new_title']
    
    # Base URL for DummyJSON API
    base_url = "https://dummyjson.com/products"
    
    # Prepare the update payload
    payload = {
        "title": new_title
    }
    
    try:
        response = requests.put(
            f"{base_url}/{resource_id}",
            json=payload,
            timeout=10
        )
        
        # Raise an exception for unsuccessful HTTP responses
        response.raise_for_status()
        
        # Check if the response is empty (204 No Content)
        if response.status_code == 204:
            return None
        
        # Return the id from the response data if present
        if 'id' in response.json():
            return response.json()['id']
        else:
            return None
            
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```