import requests

def solve(inputs):
    """
    Fetches a GitHub user based on the provided username using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The GitHub username to fetch.
            - 'credential' (str): The authentication token or Bearer token for the API call.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None if the response is empty but successful.
    
    Raises:
        requests.RequestException: If the HTTP request fails or returns an unsuccessful status code.
    """
    username = inputs['username']
    credential = inputs['credential']
    
    url = f"https://api.github.com/users/{username}"
    
    headers = {
        'Authorization': f'Bearer {credential}',
        'Accept': 'application/vnd.github+json'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to fetch user data. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json()