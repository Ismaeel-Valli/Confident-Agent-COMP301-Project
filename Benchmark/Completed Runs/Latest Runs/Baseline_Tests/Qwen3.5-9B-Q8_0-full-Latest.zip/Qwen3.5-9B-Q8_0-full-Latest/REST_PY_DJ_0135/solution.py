import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_username' (new username).
        
    Returns:
        None if the update is successful (empty response body).
        The decoded JSON response if there's an error (non-empty response body).
        
    Raises:
        Exception: If the HTTP response status code indicates failure.
    """
    base_url = "https://dummyjson.com/users"
    
    # Extract parameters from inputs
    resource_id = inputs.get('resource_id')
    new_username = inputs.get('new_username')
    
    if not resource_id or not new_username:
        raise ValueError("Missing required fields in inputs: 'resource_id' and 'new_username'")

    url = f"{base_url}/{resource_id}"
    
    # Prepare the payload for PATCH request
    payload = {
        "username": new_username
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.patch(url, json=payload, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
    response.raise_for_status()
    
    # Check if the response body is empty (successful update often returns empty JSON {})
    if not response.text:
        return None
    
    # Decode and return the JSON response
    try:
        return response.json()
    except ValueError:
        raise Exception(f"Failed to decode JSON response: {response.text}")