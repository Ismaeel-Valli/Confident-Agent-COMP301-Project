```python
import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - included_fields (str): Comma-separated list of fields to include in the response.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    todos_endpoint = f"{base_url}/todos"
    
    params = {
        "_limit": inputs["result_limit"],
        "_fields": inputs["included_fields"]
    }
    
    response = requests.get(todos_endpoint, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP request failed with status code: {response.status_code}")
    
    data = response.json()
    
    return data if data else None
```