```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_username' (new username).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty responses.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    new_username = inputs.get('new_username')
    
    if not resource_id or new_username is None:
        raise ValueError("Missing required input fields: resource_id and new_username")

    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {"username": new_username}
    
    try:
        response = requests.put(url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 204:
            return None
        
        data = response.json()
        return data.get('id')
        
    except requests.exceptions.HTTPError as e:
        raise RuntimeError(f"Failed to update user: {e}") from e
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Request failed: {e}") from e
```