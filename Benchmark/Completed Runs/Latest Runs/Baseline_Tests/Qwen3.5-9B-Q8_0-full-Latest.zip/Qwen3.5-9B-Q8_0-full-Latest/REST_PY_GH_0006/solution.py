import requests

def solve(inputs):
    """
    Fetches a repository from the GitHub REST API (version 2026-03-10).
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git extension).
            - 'credential' (str): The caller-supplied credential (e.g., token or Bearer token).
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        return None if not data else data
    elif response.status_code in (404, 401, 403):
        raise Exception(f"Failed to fetch repository. Status code: {response.status_code}")
    else:
        raise Exception(f"Unexpected error fetching repository. Status code: {response.status_code}, Response: {response.text}")