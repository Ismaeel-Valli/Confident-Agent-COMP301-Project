```python
import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on included_fields.
    
    Args:
        inputs (dict): A dictionary containing 'included_fields' as a comma-separated string.
        
    Returns:
        dict or None: The decoded JSON response, or None if the response is empty but successful.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    # Extract included fields from inputs
    included_fields = inputs.get('included_fields', '')
    
    # Construct the URL with query parameters for specific fields
    url = "https://jsonplaceholder.typicode.com/todos"
    params = {}
    
    if included_fields:
        params['fields'] = included_fields
    
    # Send GET request
    response = requests.get(url, params=params)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Decode the JSON response
    data = response.json()
    
    # Return None if the response is empty (successful but no data)
    if not data:
        return None
    
    return data
```