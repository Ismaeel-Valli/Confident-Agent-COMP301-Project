import requests

def solve(inputs):
    """
    Retrieves a product by identifier from DummyJSON API and returns its ID.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with the product identifier.
        
    Returns:
        str or None: The product's ID if found, None for successful empty response.
        
    Raises:
        requests.exceptions.HTTPError: If the HTTP response status code indicates an error.
    """
    resource_id = inputs.get('resource_id')
    
    # Construct the API URL for fetching a specific product
    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.get(url)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (no content)
        if not response.text.strip():
            return None
        
        # Parse the JSON response
        data = response.json()
        
        # Return the 'id' attribute if it exists, otherwise None
        return data.get('id')
        
    except requests.exceptions.HTTPError as e:
        raise e
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"An error occurred while making the request: {e}")