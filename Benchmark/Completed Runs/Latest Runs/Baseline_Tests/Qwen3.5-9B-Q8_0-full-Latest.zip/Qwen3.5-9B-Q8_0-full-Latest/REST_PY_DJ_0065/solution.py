import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on included fields.
    
    Args:
        inputs (dict): A dictionary containing 'included_fields' as a comma-separated string.
        
    Returns:
        dict or None: The decoded JSON response, or None if the response is empty but successful.
        
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    included_fields = inputs.get('included_fields', '')
    
    # Construct the API URL with query parameters for fields
    url = "https://jsonplaceholder.typicode.com/users"
    params = {}
    
    if included_fields:
        params['fields'] = included_fields
    
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None if the list of users is empty
        if not data:
            return None
            
        return data
        
    except requests.RequestException as e:
        raise e