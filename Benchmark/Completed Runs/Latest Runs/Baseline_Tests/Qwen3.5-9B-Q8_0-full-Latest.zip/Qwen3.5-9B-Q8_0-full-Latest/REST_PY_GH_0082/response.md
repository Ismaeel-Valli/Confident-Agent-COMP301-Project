```python
import requests
import json

def solve(inputs):
    """
    Lists milestones for a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - state (str): The state of the milestone (e.g., 'open', 'closed').
            - credential (str): The caller-supplied credential (token or Bearer token).
    
    Returns:
        list or None: A list of decoded JSON milestone objects, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    state = inputs["state"]
    credential = inputs["credential"]
    
    # Construct the API URL for version 2026-03-10
    url = f"https://api.github.com/repos/{owner}/{repo}/milestones"
    
    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    # Query parameters
    params = {"state": state}
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"Failed to fetch milestones. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Return None for successful empty response
    if not data:
        return None
    
    return data
```