import requests

def solve(inputs):
    """
    Lists repository tags for GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository without the .git extension.
            - 'credential' (str): The caller-supplied credential (e.g., token).
    
    Returns:
        list or None: A list of decoded JSON response items, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs['repository_owner']
    repository_name = inputs['repository_name']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/tags"
    headers = {
        'Accept': 'application/vnd.github+json',
        'Authorization': f'token {credential}'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch repository tags. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    return data if data else None