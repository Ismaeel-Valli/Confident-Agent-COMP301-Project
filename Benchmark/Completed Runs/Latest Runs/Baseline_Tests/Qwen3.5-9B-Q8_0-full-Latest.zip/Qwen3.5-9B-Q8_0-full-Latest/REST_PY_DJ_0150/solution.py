import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the product
            - new_brand (str): New value for the brand attribute
    
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
    
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_brand = inputs['new_brand']
    
    # DummyJSON API endpoint for updating a product
    url = f"https://dummyjson.com/products/{resource_id}"
    
    # Prepare the payload with only the field to update
    payload = {
        "brand": new_brand
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code == 200:
        # Successful update with empty body
        return None
    elif response.status_code == 201 or response.status_code == 204:
        # Created or No Content - also successful
        return None
    else:
        raise Exception(f"Failed to update product: HTTP {response.status_code} - {response.text}")

# Example usage (not executed):
# inputs = {"resource_id": "1", "new_brand": "NewBrand"}
# result = solve(inputs)