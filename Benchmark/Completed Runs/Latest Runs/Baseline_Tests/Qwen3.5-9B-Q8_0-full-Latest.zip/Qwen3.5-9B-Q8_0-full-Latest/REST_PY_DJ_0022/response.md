```python
import requests

def solve(inputs):
    """
    Deletes a todo by identifier using DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (identifier of the todo).
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.exceptions.RequestException: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    response = requests.delete(url)
    
    if response.status_code == 200:
        # Successful deletion typically returns an empty body for this endpoint
        return None
    elif response.status_code == 404:
        # Resource not found - treat as unsuccessful based on requirements
        raise Exception(f"Resource not found: {response.text}")
    else:
        # Any other unsuccessful status code
        raise Exception(f"Failed to delete todo: Status {response.status_code}, Response: {response.text}")

# Example usage (not executed):
# inputs = {"resource_id": 1}
# result = solve(inputs)
```