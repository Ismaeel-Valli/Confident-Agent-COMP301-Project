```python
import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON based on the provided sort_field.
    
    Args:
        inputs (dict): A dictionary containing 'sort_field' key.
        
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
        
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    sort_field = inputs.get('sort_field')
    
    # Construct the API endpoint with sorting parameter
    url = f"{base_url}/posts?_sort={sort_field}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None if the response is empty (successful but no data)
        if not data:
            return None
            
        return data
        
    except requests.RequestException as e:
        raise e
```