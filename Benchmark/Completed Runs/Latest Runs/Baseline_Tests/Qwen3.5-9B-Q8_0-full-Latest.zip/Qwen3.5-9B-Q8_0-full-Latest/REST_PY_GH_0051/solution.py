import requests
import json

def solve(inputs):
    """
    Retrieves the authenticated user from the GitHub REST API (version 2026-03-10).
    
    Args:
        inputs (dict): A dictionary containing 'credential' (auth token) and optionally 'base_url'.
        
    Returns:
        dict or None: The decoded JSON response if successful. Returns None for an empty response.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    credential = inputs["credential"]
    base_url = inputs.get("base_url", "https://api.github.com")
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.get(f"{base_url}/user", headers=headers)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to retrieve user data. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json()