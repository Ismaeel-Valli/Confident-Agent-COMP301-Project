import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing 'userId' key with an integer value.
        
    Returns:
        list: Decoded JSON response as a list of todos.
        None: If the response is successfully empty.
        
    Raises:
        requests.exceptions.RequestException: For unsuccessful HTTP responses.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    user_id = inputs.get('userId')
    
    if user_id is None:
        raise ValueError("userId is required in inputs")
    
    url = f"{base_url}/todos?userId={user_id}"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise requests.exceptions.RequestException(f"HTTP error occurred: {response.status_code}")
    
    data = response.json()
    
    return data if data else None