import requests

def solve(inputs):
    """
    Updates selected fields of a post in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_title' (new title value).
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        Raises: Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_title = inputs.get('new_title')
    
    if not resource_id or new_title is None:
        raise ValueError("Missing required inputs: resource_id and new_title")

    url = f"https://dummyjson.com/posts/{resource_id}"
    payload = {"title": new_title}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update post. Status code: {response.status_code}, Response: {response.text}")
    
    # DummyJSON returns the updated object on PUT for posts
    data = response.json()
    
    # Check if 'id' is present in the response
    if 'id' in data:
        return data['id']
    
    # Return None for successful empty response (though unlikely with this API structure)
    return None