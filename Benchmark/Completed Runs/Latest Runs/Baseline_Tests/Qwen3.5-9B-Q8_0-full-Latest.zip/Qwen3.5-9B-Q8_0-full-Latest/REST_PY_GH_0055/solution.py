import requests

def solve(inputs):
    """
    Unfollows a GitHub user using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The handle for the GitHub user account to unfollow.
            - 'credential' (str): The caller-supplied credential (e.g., Personal Access Token).
    
    Returns:
        int: The successful HTTP status code (typically 204 No Content).
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails or returns an unsuccessful status.
    """
    username = inputs['username']
    credential = inputs['credential']
    
    # GitHub API endpoint to unfollow a user
    url = f"https://api.github.com/user/following/{username}"
    
    headers = {
        'Authorization': f'token {credential}',
        'Accept': 'application/vnd.github+json'
    }
    
    response = requests.delete(url, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
    response.raise_for_status()
    
    return response.status_code