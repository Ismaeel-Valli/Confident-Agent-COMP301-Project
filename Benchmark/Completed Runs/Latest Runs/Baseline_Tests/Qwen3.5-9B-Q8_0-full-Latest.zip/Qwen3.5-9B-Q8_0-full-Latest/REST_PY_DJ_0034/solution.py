import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'result_limit' (int) specifying 
                       the maximum number of results to return.
    
    Returns:
        list or None: The decoded JSON response as a list of posts if successful and non-empty,
                      None if successful but empty, or raises an exception on HTTP error.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    result_limit = inputs.get('result_limit', 10)
    
    # DummyJSON endpoint for posts with a limit parameter
    url = f"https://jsonplaceholder.typicode.com/posts?_limit={result_limit}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
            
        return data
        
    except requests.RequestException as e:
        raise e