import requests

def solve(inputs):
    """
    Creates a pull request on GitHub using the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository.
            - new_base (str): The base branch for the pull request.
            - new_body (str): The body text for the pull request.
            - new_head (str): The head branch for the pull request.
            - new_title (str): The title for the pull request.
            - credential (str): The authentication token or string for API access.
    
    Returns:
        dict or None: The decoded JSON response from the API. Returns None if the response is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    new_base = inputs["new_base"]
    new_body = inputs["new_body"]
    new_head = inputs["new_head"]
    new_title = inputs["new_title"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/pulls"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    data = {
        "title": new_title,
        "body": new_body,
        "head": new_head,
        "base": new_base
    }

    response = requests.post(url, headers=headers, json=data)

    if response.status_code != 201:
        raise Exception(f"Failed to create pull request. Status code: {response.status_code}, Response: {response.text}")

    return response.json() if response.content else None