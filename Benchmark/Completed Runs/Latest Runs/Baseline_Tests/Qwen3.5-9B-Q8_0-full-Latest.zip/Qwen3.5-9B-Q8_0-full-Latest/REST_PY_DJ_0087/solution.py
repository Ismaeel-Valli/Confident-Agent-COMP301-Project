import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_age' (new age value).
        
    Returns:
        int or None: The response's id value if present, otherwise None for successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_age = inputs['new_age']
    
    url = f"https://dummyjson.com/users/{resource_id}"
    
    payload = {
        "age": new_age
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user. Status code: {response.status_code}, Response: {response.text}")
    
    # For successful updates in DummyJSON, the response is typically empty (204 No Content) 
    # or contains the updated object. We check for 'id' in the response JSON if it exists.
    try:
        response_data = response.json()
        
        # If the response is an empty object or null, return None
        if not response_data or (isinstance(response_data, dict) and len(response_data) == 0):
            return None
            
        # Return the id if present in the response
        return response_data.get('id')
    except ValueError:
        # If response is empty body (204), json() might fail or return empty
        if response.status_code == 204:
            return None
        raise Exception(f"Unexpected response format. Status code: {response.status_code}, Response: {response.text}")