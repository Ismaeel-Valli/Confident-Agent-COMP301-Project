import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API using the provided inputs.
    
    Args:
        inputs (dict): Dictionary containing 'new_title' for the product title.
        
    Returns:
        int or None: The ID of the created product, or None if the response is empty/successful without an ID.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com"  # Using jsonplaceholder as a realistic dummy JSON API
    
    payload = {
        "title": inputs.get("new_title")
    }
    
    try:
        response = requests.post(f"{base_url}/products", json=payload)
        
        if response.status_code != 200:
            raise Exception(f"Failed to create product. Status code: {response.status_code}")
        
        data = response.json()
        
        # Return ID if present, otherwise None for successful empty response
        return data.get("id")
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"HTTP request failed: {str(e)}")