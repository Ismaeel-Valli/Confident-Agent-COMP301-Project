import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API using provided inputs.
    
    Args:
        inputs (dict): Dictionary containing 'new_age' and 'new_firstName'.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.RequestException: If HTTP request fails.
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    # Prepare the payload with required fields and default values for other common user fields
    payload = {
        "name": inputs.get("new_firstName", "New User"),
        "age": inputs.get("new_age", 0),
        "username": f"user_{len(inputs)}",
        "email": f"newuser{len(inputs)}@example.com",
        "address": {
            "street": "123 Main St",
            "suite": "Apt 1",
            "city": "New York",
            "zipcode": "10001",
            "geo": {
                "lat": "40.7128",
                "lng": "-74.0060"
            }
        },
        "phone": "555-0123",
        "website": "example.com",
        "company": {
            "name": "Acme Corp",
            "catchPhrase": "Innovative Solutions",
            "bs": "synergize scalable solutions"
        }
    }
    
    try:
        response = requests.post(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None for successful empty response
        if not data:
            return None
            
        return data
        
    except requests.RequestException as e:
        raise e