import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id', 'new_completed', and 'new_todo'.
        
    Returns:
        str or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_completed = inputs.get('new_completed')
    new_todo = inputs.get('new_todo')
    
    # Base URL for DummyJSON Todo API
    base_url = "https://jsonplaceholder.typicode.com/todos"
    
    # Prepare the payload with only the fields to update
    payload = {}
    if new_completed is not None:
        payload['completed'] = new_completed
    if new_todo is not None:
        payload['todo'] = new_todo
    
    url = f"{base_url}/{resource_id}"
    
    try:
        response = requests.put(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Check if the response is empty
        if not response.text.strip():
            return None
        
        # Parse the JSON response and extract the id
        data = response.json()
        return data.get('id')
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")