```python
import requests

def solve(inputs):
    """
    Searches posts on DummyJSON using the provided search term.
    
    Args:
        inputs (dict): A dictionary containing 'search_text' key with the search term.
        
    Returns:
        list or None: The decoded JSON response as a list of posts, or None if the response is empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    search_text = inputs.get("search_text", "")
    
    params = {
        "q": search_text
    }
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raises HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None if the response is empty (successful but no results)
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"HTTP request failed: {str(e)}")
```