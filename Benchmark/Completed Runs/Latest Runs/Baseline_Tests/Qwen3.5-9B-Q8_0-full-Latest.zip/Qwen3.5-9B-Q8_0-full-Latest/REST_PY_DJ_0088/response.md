```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API with provided age and first name.
    
    Args:
        inputs (dict): Dictionary containing 'new_age' and 'new_firstName'.
        
    Returns:
        int or None: The ID of the created user, or None if response is empty.
        
    Raises:
        requests.exceptions.RequestException: If HTTP request fails.
    """
    url = "https://dummyjson.com/users/add"
    
    payload = {
        "age": inputs.get("new_age"),
        "firstName": inputs.get("new_firstName")
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to create user. Status code: {response.status_code}")
    
    data = response.json()
    
    # Check for empty response (no content or null)
    if not data:
        return None
    
    # Return the id if present, otherwise None
    return data.get("id")
```