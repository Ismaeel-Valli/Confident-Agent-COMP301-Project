import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'new_description' and 'new_title'.
        
    Returns:
        int or None: The ID of the created product, or None if successful but no ID returned.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "description": inputs.get("new_description"),
        "title": inputs.get("new_title")
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to submit product. Status code: {response.status_code}")
    
    # Check if the response contains an 'id' field
    data = response.json()
    if "id" in data and data["id"] is not None:
        return data["id"]
    
    # Return None for a successful empty response (or response without id)
    return None