import requests
from requests.exceptions import RequestException, HTTPError

def solve(inputs):
    """
    Submits a new product to DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'new_title' for the product title.
        
    Returns:
        dict or None: Decoded JSON response if successful (empty), otherwise the response content.
                     Returns None for a successful empty response.
                     
    Raises:
        HTTPError: If the HTTP status code indicates an unsuccessful response.
        RequestException: For other network-related errors.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "title": inputs.get("new_title")
    }
    
    try:
        response = requests.post(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # If the response is empty (204 No Content), return None
        if response.status_code == 204:
            return None
        
        # Return the decoded JSON response
        return response.json()
        
    except HTTPError as http_err:
        raise http_err
    except RequestException as err:
        raise err