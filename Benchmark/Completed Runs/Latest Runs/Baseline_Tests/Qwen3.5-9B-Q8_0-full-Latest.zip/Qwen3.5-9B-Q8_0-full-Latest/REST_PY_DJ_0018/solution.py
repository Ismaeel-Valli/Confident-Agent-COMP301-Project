import requests

def solve(inputs):
    """
    Submits a new post to DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing:
            - new_body (str): Value for the body attribute.
            - new_title (str): Value for the title attribute.
            - new_user_identifier (str): Value for the user ID attribute.
            
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty but successful.
                      
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": inputs["new_title"],
        "body": inputs["new_body"],
        "userId": inputs["new_user_identifier"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create post. Status code: {response.status_code}")
    
    return None