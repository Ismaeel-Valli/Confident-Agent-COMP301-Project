```python
import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON based on the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'result_limit' (int) specifying 
                       the maximum number of results to return.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty but successful.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    result_limit = inputs.get('result_limit')
    if result_limit is None:
        raise ValueError("Missing 'result_limit' in inputs")

    url = "https://dummyjson.com/products"
    params = {
        "limit": result_limit,
        "skip": 0  # Retrieve one page starting from the beginning
    }

    response = requests.get(url, params=params)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to retrieve products. Status code: {response.status_code}")

    data = response.json()
    
    # DummyJSON returns a dict with 'products' key. 
    # If the list is empty, we return None as per instructions for successful empty response.
    if not data.get('products'):
        return None
        
    return data
```