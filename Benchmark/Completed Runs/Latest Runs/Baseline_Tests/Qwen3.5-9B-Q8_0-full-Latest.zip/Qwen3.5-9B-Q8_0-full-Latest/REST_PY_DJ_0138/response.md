```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post on DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id', 'new_body', and 'new_title'.
        
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    new_body = inputs.get('new_body')
    new_title = inputs.get('new_title')
    
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    payload = {}
    if new_body is not None:
        payload['body'] = new_body
    if new_title is not None:
        payload['title'] = new_title
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    # DummyJSON typically returns the updated object on PUT for this endpoint
    # but the requirement says return None for a successful empty response.
    # Standard JSONPlaceholder returns the full object, not empty.
    # We follow the instruction: if the response body is effectively empty or lacks 'id', return None.
    
    if not data or 'id' not in data:
        return None
        
    return data.get('id')
```