```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API using provided inputs.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and other required fields.
        
    Returns:
        int or None: The ID of the created user, or None if response is empty.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    url = "https://dummyjson.com/users/addNewUser"
    
    # Prepare the payload with the provided inputs
    payload = {
        "firstName": inputs.get("new_firstName"),
        "lastName": inputs.get("new_lastName", "Doe"),  # Default last name if not provided
        "email": inputs.get("new_email", "user@example.com"),  # Default email if not provided
        "age": inputs.get("new_age", 30),  # Default age if not provided
        "phone": inputs.get("new_phone", "+1234567890"),  # Default phone if not provided
        "username": inputs.get("new_username", "user123"),  # Default username if not provided
        "password": inputs.get("new_password", "password123")  # Default password if not provided
    }
    
    try:
        response = requests.post(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Check if the response is empty
        if not response.json():
            return None
        
        # Return the ID from the response
        data = response.json()
        return data.get("id")
        
    except requests.RequestException as e:
        raise e
```