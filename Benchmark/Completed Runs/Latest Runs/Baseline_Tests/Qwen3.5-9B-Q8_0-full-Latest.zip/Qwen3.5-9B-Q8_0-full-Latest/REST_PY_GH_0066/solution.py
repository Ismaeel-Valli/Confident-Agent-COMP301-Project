import requests
from requests.exceptions import RequestException, HTTPError

def solve(inputs):
    """
    Updates an organization's description via the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The name of the organization.
            - 'new_description' (str): The new description for the organization.
            - 'credential' (str): The authentication token or string for the API.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty but successful.
    
    Raises:
        Exception: If the HTTP request fails or returns an unsuccessful status code.
    """
    organization = inputs['organization']
    new_description = inputs['new_description']
    credential = inputs['credential']
    
    url = f"https://api.github.com/orgs/{organization}"
    headers = {
        'Authorization': f'token {credential}',
        'Accept': 'application/vnd.github+json'
    }
    
    payload = {
        "description": new_description
    }
    
    try:
        response = requests.put(url, json=payload, headers=headers)
        response.raise_for_status()
        
        # GitHub often returns an empty body for successful updates
        if len(response.content) == 0:
            return None
        
        return response.json()
    
    except HTTPError as http_err:
        raise Exception(f"HTTP error occurred: {http_err}")
    except RequestException as err:
        raise Exception(f"Request failed: {err}")