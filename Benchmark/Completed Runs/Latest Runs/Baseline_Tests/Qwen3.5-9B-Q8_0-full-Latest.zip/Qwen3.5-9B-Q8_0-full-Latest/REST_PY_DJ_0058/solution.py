import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on skip parameter.
    
    Args:
        inputs (dict): Dictionary containing 'results_to_skip' key.
        
    Returns:
        list or None: Decoded JSON response as a list, or None if empty.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    results_to_skip = inputs.get('results_to_skip', 0)
    
    # DummyJSON API endpoint for todos with skip parameter
    url = f"https://jsonplaceholder.typicode.com/todos?_skip={results_to_skip}&_limit=1"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"HTTP request failed with status code: {response.status_code}")
    
    data = response.json()
    
    # Return None for successful empty response
    if not data:
        return None
    
    return data