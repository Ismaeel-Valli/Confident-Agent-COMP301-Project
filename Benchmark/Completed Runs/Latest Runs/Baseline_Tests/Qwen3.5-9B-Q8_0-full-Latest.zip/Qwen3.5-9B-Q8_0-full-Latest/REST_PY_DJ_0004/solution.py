import requests

def solve(inputs):
    """
    Deletes a product by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (str) of the product to delete.
        
    Returns:
        None if deletion is successful (empty response).
        Decoded JSON response otherwise (for non-empty responses).
        
    Raises:
        requests.exceptions.HTTPError: If HTTP status code indicates failure.
    """
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.delete(url)
        response.raise_for_status()
        
        if response.status_code == 204:
            return None
            
        return response.json()
        
    except requests.exceptions.HTTPError as e:
        raise e