import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on the provided result_limit.
    
    Args:
        inputs (dict): A dictionary containing 'result_limit' key with an integer value.
        
    Returns:
        list or None: The decoded JSON response as a list, or None if the response is empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    result_limit = inputs.get('result_limit')
    
    # Construct the API URL with the limit parameter
    url = f"https://jsonplaceholder.typicode.com/users?_limit={result_limit}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise e