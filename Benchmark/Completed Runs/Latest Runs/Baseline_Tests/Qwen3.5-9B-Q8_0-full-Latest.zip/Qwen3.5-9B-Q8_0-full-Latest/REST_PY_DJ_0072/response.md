```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (todo ID) and 'new_completed' (boolean).
        
    Returns:
        str or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_completed = inputs.get('new_completed')
    
    url = f"https://jsonplaceholder.typicode.com/todos/{resource_id}"
    
    payload = {
        "completed": new_completed
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}")
    
    # DummyJSON typically returns an empty body on successful PUT for this endpoint
    # but we follow the instruction to check for id in response
    
    data = response.json()
    
    if isinstance(data, dict) and 'id' in data:
        return data['id']
    
    return None
```