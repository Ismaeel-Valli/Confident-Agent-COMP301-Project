import requests

def solve(inputs):
    """
    Fetches a specific commit from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - page (int): The page number of results to fetch.
            - ref (str): The commit reference (e.g., branch name, tag, or SHA).
            - credential (str): The authentication token for the API request.
    
    Returns:
        dict or None: The decoded JSON response if successful. Returns None if the response is empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails or returns an unsuccessful status code.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    page = inputs["page"]
    ref = inputs["ref"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/commits/{ref}"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    params = {"page": page}
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to fetch commit. Status code: {response.status_code}")
    
    data = response.json()
    
    return None if not data else data