import requests
from urllib.parse import quote

def solve(inputs):
    """
    Creates a repository in a GitHub organization using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The name of the organization.
            - 'new_name' (str): The desired name for the new repository.
            - 'credential' (str): The authentication token or username/password pair.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    org = inputs['organization']
    repo_name = inputs['new_name']
    credential = inputs['credential']
    
    # Construct the URL for creating a repository in an organization
    url = f"https://api.github.com/orgs/{quote(org)}/repos"
    
    # Prepare headers with authentication
    if isinstance(credential, str):
        # Assuming it's a personal access token (PAT)
        headers = {
            'Authorization': f'token {credential}',
            'Accept': 'application/vnd.github+json',
            'X-GitHub-Api-Version': '2026-03-10'
        }
    elif isinstance(credential, dict):
        # Assuming it's a username/password pair
        headers = {
            'Authorization': f'basic {credential["username"]}:{credential["password"]}',
            'Accept': 'application/vnd.github+json',
            'X-GitHub-Api-Version': '2026-03-10'
        }
    else:
        raise ValueError("Credential must be a string (token) or dictionary (username/password)")
    
    # Prepare the payload for creating the repository
    payload = {
        'name': repo_name,
        'auto_init': True  # Optional: Initialize with README.md
    }
    
    try:
        response = requests.post(url, json=payload, headers=headers)
        
        # Raise an exception for unsuccessful HTTP responses (4xx and 5xx)
        response.raise_for_status()
        
        # Return None for a successful empty response
        if not response.text.strip():
            return None
        
        # Return the decoded JSON response
        return response.json()
    
    except requests.exceptions.HTTPError as e:
        raise RuntimeError(f"Failed to create repository: {e}") from e
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Request failed: {e}") from e