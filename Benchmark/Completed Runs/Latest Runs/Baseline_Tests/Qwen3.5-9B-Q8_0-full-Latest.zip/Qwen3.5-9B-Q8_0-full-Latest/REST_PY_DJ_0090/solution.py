import requests

def solve(inputs):
    """
    Updates selected fields of a post on DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_body' (new body content).
        
    Returns:
        str or None: The title of the updated post, or None if successful but no title exists.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_body = inputs['new_body']
    
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    payload = {
        "body": new_body
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"HTTP request failed with status code: {response.status_code}")
    
    data = response.json()
    
    # According to DummyJSON/JSONPlaceholder behavior, PUT usually returns the updated resource.
    # However, the prompt says "Return None for a successful empty response". 
    # Standard JSONPlaceholder PUT returns the updated object, not an empty response.
    # We will follow the instruction: if data is empty or lacks 'title', return None.
    
    if not data:
        return None
        
    title = data.get('title')
    return title