```python
import requests
import json

def solve(inputs):
    """
    Updates the name of a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'new_name' (str): The new name for the repository.
            - 'credential' (str): The authentication token or string for the API call.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response indicates an error (status code >= 400).
    """
    owner = inputs['repository_owner']
    repo_name = inputs['repository_name']
    new_name = inputs['new_name']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo_name}"
    headers = {
        'Authorization': f'token {credential}',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2026-03-10'
    }
    
    payload = {
        "name": new_name
    }
    
    response = requests.patch(url, headers=headers, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to update repository name. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json() if response.text else None
```