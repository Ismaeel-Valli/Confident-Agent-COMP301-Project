import requests

def solve(inputs):
    """
    Deletes a todo by identifier from DummyJSON and returns the response's id value,
    or None if that attribute is absent or the response is empty.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (identifier of the todo).
        
    Returns:
        str or None: The ID from the response, or None if absent/empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON API endpoint for deleting a todo
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    try:
        response = requests.delete(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx/5xx)
        
        # Check if the response is empty or doesn't contain an 'id' field
        data = response.json()
        if not data or 'id' not in data:
            return None
            
        return data['id']
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")