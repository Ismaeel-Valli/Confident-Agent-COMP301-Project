```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the product
            - new_description (str): New value for the description attribute
    
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
    
    Raises:
        requests.exceptions.RequestException: If HTTP request fails.
    """
    resource_id = inputs['resource_id']
    new_description = inputs['new_description']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {
        "description": new_description
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 204:
        return None
    else:
        response.raise_for_status()
```