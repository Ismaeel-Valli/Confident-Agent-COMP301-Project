import requests

def solve(inputs):
    """
    Fetches the list of files changed in a specific pull request for a GitHub repository.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository.
            - pull_number (int): The number that identifies the pull request.
            - page_size (int): The number of results per page (max 100).
            - credential (dict): Caller-supplied credentials (e.g., token or app auth details).
    
    Returns:
        list or None: A list of dictionaries representing the changed files, or None if the list is empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    pull_number = inputs["pull_number"]
    page_size = min(inputs.get("page_size", 30), 100)
    
    # Prepare authentication based on common GitHub credential structures
    # Assuming 'credential' contains a token under 'token' or similar. 
    # Adjust key access if the credential structure differs (e.g., 'app_id', 'private_key').
    auth_token = inputs.get("credential", {}).get("token")
    
    if not auth_token:
        raise ValueError("Missing authentication token in credentials.")

    headers = {
        "Authorization": f"Bearer {auth_token}",
        "Accept": "application/vnd.github.v3+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pull_number/files?per_page={page_size}"
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to fetch pull request files. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response as per instructions
    return data if data else None