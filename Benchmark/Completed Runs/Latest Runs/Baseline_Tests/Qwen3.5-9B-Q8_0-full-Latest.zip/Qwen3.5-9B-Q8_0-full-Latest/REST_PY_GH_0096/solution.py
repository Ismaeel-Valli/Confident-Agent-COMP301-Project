import requests

def solve(inputs):
    """
    Lists repositories for the authenticated user using GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'credential' (str): The authentication token or header value.
            - 'visibility' (str, optional): Limit results to repositories with the specified visibility ('public', 'private', or 'internal').
    
    Returns:
        list | None: A list of repository objects if there are results, or None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response status code indicates an error (non-2xx).
    """
    # Base URL for GitHub API version 2026-03-10
    base_url = "https://api.github.com"
    endpoint = "/user/repos"
    
    url = f"{base_url}{endpoint}"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {inputs['credential']}",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    params = {}
    if 'visibility' in inputs and inputs['visibility']:
        params['visibility'] = inputs['visibility']
    
    response = requests.get(url, headers=headers, params=params)
    
    # Raise an exception for unsuccessful HTTP responses (non-2xx)
    response.raise_for_status()
    
    data = response.json()
    
    # If the list is empty, return None as per requirement
    if not data:
        return None
    
    return data