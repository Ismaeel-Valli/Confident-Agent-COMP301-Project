import requests

def solve(inputs):
    """
    Fetches the list of files changed in a specific pull request from GitHub.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository.
            - pull_number (int): The number that identifies the pull request.
            - credential (str): The caller-supplied authentication token (Bearer token).
    
    Returns:
        dict or None: The decoded JSON response containing the list of files, 
                      or None if the response is an empty list.
    
    Raises:
        requests.RequestException: If the HTTP request fails (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    pr_number = inputs["pull_number"]
    token = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}/files"
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.get(url, headers=headers)
    
    if not response.ok:
        raise requests.RequestException(f"GitHub API request failed with status code {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response (empty list of files)
    if isinstance(data, list) and len(data) == 0:
        return None
        
    return data