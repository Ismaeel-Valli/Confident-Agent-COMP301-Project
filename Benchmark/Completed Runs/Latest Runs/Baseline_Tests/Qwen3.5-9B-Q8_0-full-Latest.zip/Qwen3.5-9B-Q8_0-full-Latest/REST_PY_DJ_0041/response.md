```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (todo ID) and 'new_todo' (value to update).
        
    Returns:
        str or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_todo_value = inputs['new_todo']
    
    # Base URL for DummyJSON API
    base_url = "https://jsonplaceholder.typicode.com"
    update_url = f"{base_url}/todos/{resource_id}"
    
    # Prepare the payload to update only the 'todo' field (assuming the attribute is named 'todo')
    # Note: The problem says "new_todo: value for the todo attribute", so we map it to 'todo' in the request.
    payload = {'todo': new_todo_value}
    
    try:
        response = requests.put(update_url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (no content)
        if not response.text.strip():
            return None
        
        # Try to parse the JSON response and extract the 'id' field
        try:
            data = response.json()
            return data.get('id')
        except ValueError:
            # If response is not valid JSON, return None as per "successful empty response" interpretation
            # or raise an exception if non-empty non-JSON is considered an error.
            # Based on "Return only the response's id value, or None if that attribute is absent",
            # we'll treat non-JSON with content as having no 'id', so return None.
            return None
            
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```