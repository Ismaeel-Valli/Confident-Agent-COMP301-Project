import requests

def solve(inputs):
    """
    Deletes a user by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with the user identifier.
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful deletion.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON delete endpoint pattern: /users/{id}
    url = f"https://dummyjson.com/users/{resource_id}"
    
    response = requests.delete(url)
    
    if not response.ok:
        raise requests.RequestException(f"Failed to delete user: {response.status_code}")
    
    # For successful deletion, DummyJSON typically returns an empty body or 204 No Content
    # Check if 'id' attribute is present in the response JSON
    try:
        data = response.json()
        return data.get('id')
    except (ValueError, KeyError):
        # If no JSON content or no 'id' key, return None for successful empty response
        return None