import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (product ID) and 'new_category' (new category value).
        
    Returns:
        str or None: The title of the updated product, or None if absent or response is empty.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    new_category = inputs.get('new_category')
    
    if not resource_id or new_category is None:
        raise ValueError("Missing required input fields: resource_id and new_category")

    url = f"https://dummyjson.com/products/{resource_id}"
    
    payload = {
        "category": new_category
    }
    
    try:
        response = requests.put(url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 204:
            return None
            
        data = response.json()
        
        # Check for title in the response (could be at root or nested depending on API version)
        title = data.get('title')
        if not title:
            return None
            
        return title
        
    except requests.exceptions.HTTPError as e:
        raise e
    except requests.RequestException as e:
        raise e