```python
import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on skip count and sort field.
    
    Args:
        inputs (dict): A dictionary containing:
            - results_to_skip (int): Number of results to skip.
            - sort_field (str): Field used for ordering.
    
    Returns:
        list or None: Decoded JSON response as a list, or None if the response is empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    params = {
        "skip": inputs["results_to_skip"],
        "sort": inputs["sort_field"]
    }
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
    
    data = response.json()
    
    if not data:
        return None
    
    return data
```