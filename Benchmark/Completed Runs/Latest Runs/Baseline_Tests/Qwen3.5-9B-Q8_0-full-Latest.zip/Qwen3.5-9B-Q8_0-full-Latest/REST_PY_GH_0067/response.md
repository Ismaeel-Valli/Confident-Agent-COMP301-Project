```python
import requests

def solve(inputs):
    """
    Lists repositories for a GitHub organization based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - "organization" (str): The name of the organization.
            - "type" (str): The type of repositories to return (e.g., 'all', 'public', 'private').
            - "credential" (str): The authentication token or header value for API access.
    
    Returns:
        list or None: A list of repository objects if repositories are found, 
                      None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (status code >= 400).
    """
    organization = inputs["organization"]
    repo_type = inputs["type"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/orgs/{organization}/repos"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    params = {"type": repo_type}
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code >= 400:
        raise Exception(f"GitHub API request failed with status code {response.status_code}: {response.text}")
    
    data = response.json()
    
    if not data:
        return None
    
    return data
```