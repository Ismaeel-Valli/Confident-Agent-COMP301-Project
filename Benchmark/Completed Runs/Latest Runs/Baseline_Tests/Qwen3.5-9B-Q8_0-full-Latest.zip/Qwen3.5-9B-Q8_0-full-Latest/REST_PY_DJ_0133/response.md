```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API with provided category and title.
    
    Args:
        inputs (dict): Dictionary containing 'new_category' and 'new_title'.
        
    Returns:
        int or None: The ID of the created product, or None if response is empty/successful without ID.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "title": inputs["new_title"],
        "category": inputs["new_category"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to create product. Status code: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns the created item in the 'product' key on success
    if "product" in data and data["product"]:
        return data["product"].get("id")
    elif "error" in data:
        raise requests.RequestException(f"API returned an error: {data['error']}")
    
    return None
```