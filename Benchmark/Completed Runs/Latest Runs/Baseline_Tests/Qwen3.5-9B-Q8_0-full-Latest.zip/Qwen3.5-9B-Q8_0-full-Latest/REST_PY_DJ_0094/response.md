```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the product
            - new_price (float/int): New value for the price attribute
    
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
    
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_price = inputs['new_price']
    
    # Base URL for DummyJSON API
    base_url = "https://dummyjson.com"
    url = f"{base_url}/products/{resource_id}"
    
    # Prepare the payload with only the field to update
    payload = {
        "price": new_price
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.put(url, json=payload, headers=headers)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None if the response is empty (though DummyJSON typically returns a full object)
        if not data:
            return None
            
        return data
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```