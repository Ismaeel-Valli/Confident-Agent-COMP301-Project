import requests

def solve(inputs):
    """
    Checks if a person is followed by the authenticated user via GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The handle for the GitHub user account to check.
            - 'credential' (str): The caller-supplied credential (e.g., Bearer token).
    
    Returns:
        int: The successful HTTP status code (typically 204 No Content if followed, 
             or 302 Found with a redirect location if not followed in older versions, 
             but per current API behavior for 'following' check, we expect 204 if true).
    
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    username = inputs['username']
    credential = inputs['credential']
    
    # GitHub API endpoint to check if the authenticated user follows a specific user
    url = f"https://api.github.com/user/{username}/following"
    
    headers = {
        'Authorization': f'Bearer {credential}',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2026-03-10'
    }
    
    response = requests.get(url, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
    response.raise_for_status()
    
    # If the user is followed, GitHub returns a 204 No Content status code.
    # If not followed, it typically returns a 302 Found with a redirect to the user's profile,
    # but per the problem statement, we assume resources exist and focus on successful check.
    # However, the problem asks to return the successful HTTP status code upon success.
    # Since the API returns 204 when followed (success condition for this check), we return it.
    # Note: If not followed, the behavior might differ, but the problem states to assume referenced resources exist 
    # and implies a successful check scenario. We'll return the status code if the request is successful.
    
    return response.status_code