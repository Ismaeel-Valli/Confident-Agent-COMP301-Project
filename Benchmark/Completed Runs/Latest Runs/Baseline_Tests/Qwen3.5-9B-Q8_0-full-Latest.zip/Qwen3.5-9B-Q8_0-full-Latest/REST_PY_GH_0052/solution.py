import requests
from requests.exceptions import RequestException, HTTPError

def solve(inputs):
    """
    Updates the authenticated user's name via GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'new_name' (str): The new name for the authenticated user.
            - 'credential' (str): The authentication token or header value.
    
    Returns:
        dict: Decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP request fails or returns an unsuccessful status code.
    """
    url = "https://api.github.com/user"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {inputs['credential']}",
        "X-GitHub-Api-Version": "2026-03-10",
        "Content-Type": "application/json"
    }
    
    payload = {
        "name": inputs['new_name']
    }
    
    try:
        response = requests.put(url, json=payload, headers=headers)
        response.raise_for_status()
        
        if response.status_code == 204:
            return None
        
        return response.json()
    
    except HTTPError as http_err:
        raise Exception(f"HTTP error occurred: {http_err}")
    except RequestException as err:
        raise Exception(f"Request failed: {err}")