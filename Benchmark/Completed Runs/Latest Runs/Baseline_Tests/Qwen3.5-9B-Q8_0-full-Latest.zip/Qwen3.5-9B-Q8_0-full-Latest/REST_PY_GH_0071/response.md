```python
import requests

def solve(inputs):
    """
    Lists commits for a GitHub repository starting from a given SHA or branch.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'sha' (str): SHA or branch to start listing commits from.
            - 'credential' (str): Bearer token for authentication.
    
    Returns:
        list | None: Decoded JSON response as a list, or None if the list is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    sha = inputs['sha']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/commits"
    params = {'sha': sha}
    headers = {
        'Authorization': f'Bearer {credential}',
        'Accept': 'application/vnd.github+json'
    }
    
    response = requests.get(url, params=params, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"GitHub API request failed with status code {response.status_code}: {response.text}")
    
    data = response.json()
    
    return None if not data else data
```