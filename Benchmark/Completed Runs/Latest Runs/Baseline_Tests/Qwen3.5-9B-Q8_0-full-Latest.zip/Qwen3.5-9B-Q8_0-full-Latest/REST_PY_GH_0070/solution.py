import requests

def solve(inputs):
    """
    Lists branches for a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - page_size (int): The number of results per page (max 100).
            - credential (str): The caller-supplied credential (e.g., Bearer token or OAuth token).
    
    Returns:
        list | None: A list of decoded JSON responses for each page, or None if the response is empty.
    
    Raises:
        requests.exceptions.HTTPError: If the HTTP response status code indicates an error.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    page_size = min(inputs["page_size"], 100)
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/branches"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    all_pages = []
    page = 1
    
    while True:
        params = {"per_page": page_size, "page": page}
        response = requests.get(url, headers=headers, params=params)
        
        if response.status_code != 200:
            raise requests.exceptions.HTTPError(f"Request failed with status code {response.status_code}: {response.text}")
        
        data = response.json()
        
        if not data:
            return None
        
        all_pages.extend(data)
        
        # Check if there are more pages
        if len(data) < page_size:
            break
        
        page += 1
    
    return all_pages