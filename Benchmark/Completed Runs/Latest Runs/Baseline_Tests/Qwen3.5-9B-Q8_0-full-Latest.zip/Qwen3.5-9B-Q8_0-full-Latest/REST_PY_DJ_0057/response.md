```python
import requests

def solve(inputs):
    """
    Submits a new post to DummyJSON API using provided inputs.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_body (str): Value for the body attribute
            - new_title (str): Value for the title attribute
            - new_user_identifier (str): Value for the user Id attribute
    
    Returns:
        str or None: The response's title value, or None if absent or successful empty response.
    
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": inputs["new_title"],
        "body": inputs["new_body"],
        "userId": inputs["new_user_identifier"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise requests.RequestException(f"Failed to create post. Status code: {response.status_code}")
    
    data = response.json()
    
    # Return title if present, otherwise None
    return data.get("title")
```