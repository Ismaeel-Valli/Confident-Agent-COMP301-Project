```python
import requests
from urllib.parse import quote

def solve(inputs):
    """
    Lists branches for a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository without the .git extension.
            - 'credential' (str): The caller-supplied credential (e.g., token or Bearer token).
    
    Returns:
        list | None: A list of branch objects if branches exist, otherwise None for an empty response.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    credential = inputs['credential']
    
    # Construct the API URL with the specific version header
    url = f"https://api.github.com/repos/{quote(owner)}/{quote(repo)}/branches"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare the request with authentication
    response = requests.get(url, headers=headers, auth=("oauth_token", credential))
    
    # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
    response.raise_for_status()
    
    # Decode JSON response
    data = response.json()
    
    # Return None if the list of branches is empty, otherwise return the list
    return data if data else None
```