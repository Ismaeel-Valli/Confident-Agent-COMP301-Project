```python
import requests

def solve(inputs):
    resource_id = inputs.get('resource_id')
    
    try:
        response = requests.get(f"https://dummyjson.com/products/{resource_id}")
        
        if response.status_code != 200:
            raise Exception(f"HTTP error! status: {response.status_code}")
        
        data = response.json()
        
        # Check if the response is empty (e.g., no title field or null)
        if not data.get('title'):
            return None
            
        return data['title']
    
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```