import requests
from urllib.parse import quote_plus

def solve(inputs):
    """
    Updates an organization on GitHub using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The name of the organization to update.
            - 'new_name' (str): The new name for the organization.
            - 'credential' (str): The authentication token or username.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    org_name = inputs['organization']
    new_name = inputs['new_name']
    credential = inputs['credential']
    
    # GitHub API version 2026-03-10
    api_version = "2026-03-10"
    url = f"https://api.github.com/orgs/{quote_plus(org_name)}"
    
    headers = {
        "Accept": f"application/vnd.github.{api_version}+json",
        "Authorization": f"token {credential}" if credential.startswith("token") else f"Bearer {credential}"
    }
    
    data = {
        "name": new_name
    }
    
    response = requests.put(url, json=data, headers=headers)
    
    if response.status_code == 204:
        return None
    
    if response.status_code != 200:
        raise Exception(f"Failed to update organization: {response.status_code} - {response.text}")
    
    return response.json()