```python
import requests

def solve(inputs):
    """
    Deletes a post by identifier using DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (identifier of the post).
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.exceptions.RequestException: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    try:
        response = requests.delete(url)
        response.raise_for_status()
        
        if response.status_code == 204:
            return None
        
        return response.json()
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Failed to delete post: {e}") from e
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}") from e
```