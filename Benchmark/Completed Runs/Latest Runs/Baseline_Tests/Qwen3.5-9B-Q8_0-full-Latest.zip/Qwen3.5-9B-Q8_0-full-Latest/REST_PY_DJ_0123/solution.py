import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (product ID) and 'new_category' (new category value).
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty success response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_category = inputs['new_category']
    
    # DummyJSON API endpoint for updating a product
    url = f"https://dummyjson.com/products/{resource_id}"
    
    # Prepare the payload with only the field to update
    payload = {
        "category": new_category
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code == 200:
        # Successful update with empty body
        return None
    elif response.status_code == 201:
        # Successful update with new data (though PUT usually returns 200 or 204)
        return response.json()
    else:
        raise Exception(f"Failed to update product. Status code: {response.status_code}, Response: {response.text}")