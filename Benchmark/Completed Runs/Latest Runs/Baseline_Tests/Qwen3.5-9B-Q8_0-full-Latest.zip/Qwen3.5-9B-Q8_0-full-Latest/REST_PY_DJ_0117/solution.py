import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the user
            - new_phone (str): New value for the phone attribute
    
    Returns:
        None if successful (empty response)
        dict with decoded JSON response otherwise
    
    Raises:
        Exception: If HTTP response is unsuccessful
    """
    base_url = "https://dummyjson.com"
    resource_id = inputs.get("resource_id")
    new_phone = inputs.get("new_phone")
    
    if not resource_id or not new_phone:
        raise ValueError("Missing required inputs: resource_id and new_phone")
    
    url = f"{base_url}/users/{resource_id}"
    payload = {"phone": new_phone}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user: {response.status_code} - {response.text}")
    
    # DummyJSON returns empty body on successful PUT for this endpoint
    if not response.text.strip():
        return None
    
    return response.json()