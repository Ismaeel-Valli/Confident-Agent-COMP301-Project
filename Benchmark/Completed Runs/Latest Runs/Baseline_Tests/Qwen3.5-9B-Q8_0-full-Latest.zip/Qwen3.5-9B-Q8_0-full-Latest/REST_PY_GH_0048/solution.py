import requests
import json

def solve(inputs):
    """
    Lists stargazers for a GitHub repository using the specified API version.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The caller-supplied credential (e.g., token or Bearer token).
    
    Returns:
        list | None: A list of stargazer data dictionaries if there are results, 
                     None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (status code >= 400).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    credential = inputs['credential']
    
    # GitHub API version endpoint for listing stargazers
    url = f"https://api.github.com/repos/{owner}/{repo}/stargazers"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code >= 400:
        raise Exception(f"GitHub API request failed with status code {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response (empty list)
    if not data:
        return None
    
    return data