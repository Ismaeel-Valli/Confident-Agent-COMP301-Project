import requests

def solve(inputs):
    username = inputs["username"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/users/{username}/repos"
    headers = {
        "Authorization": f"token {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch repositories for user {username}. Status code: {response.status_code}")
    
    data = response.json()
    
    if not data:
        return None
    
    return data