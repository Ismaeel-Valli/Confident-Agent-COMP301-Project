```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id', 'new_completed', and 'new_todo'.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_completed = inputs['new_completed']
    new_todo = inputs['new_todo']
    
    url = f"https://jsonplaceholder.typicode.com/todos/{resource_id}"
    
    payload = {
        'completed': new_completed,
        'title': new_todo
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}, Response: {response.text}")
    
    if response.content:
        return response.json()
    else:
        return None
```