import requests

def solve(inputs):
    """
    Searches for users on DummyJSON using the provided search term.
    
    Args:
        inputs (dict): A dictionary containing 'search_text' key with the search term.
        
    Returns:
        list: Decoded JSON response if successful and non-empty.
        None: If the response is successful but empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com"  # Note: DummyJSON doesn't have a standard public API like this, using JSONPlaceholder as a stable alternative for demonstration, or if strictly DummyJSON is required with specific endpoints not publicly documented, this might need adjustment. However, the prompt asks for DummyJSON specifically. 
    # Correction: The user explicitly asked for "DummyJSON". DummyJSON typically uses https://dummyjson.com/users/search?q={query}
    
    search_text = inputs.get('search_text', '')
    url = f"https://dummyjson.com/users/search?q={search_text}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # DummyJSON structure for search usually returns a dict with 'users' key containing the list.
        # If the result is empty, return None as per instructions.
        if not data.get('users'):
            return None
            
        return data['users']
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"HTTP request failed: {e}")