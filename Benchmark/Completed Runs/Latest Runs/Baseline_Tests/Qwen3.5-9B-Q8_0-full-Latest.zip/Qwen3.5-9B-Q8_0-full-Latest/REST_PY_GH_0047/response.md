```python
import requests

def solve(inputs):
    """
    Deletes a GitHub release using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository.
            - release_id (int): The unique identifier of the release.
            - credential (str): The authentication token or string for the API call.
    
    Returns:
        int: The successful HTTP status code (typically 204).
    
    Raises:
        requests.RequestException: If the HTTP request fails or returns an unsuccessful status code.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    release_id = inputs["release_id"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/releases/{release_id}"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.delete(url, headers=headers)
    
    if response.status_code >= 400:
        raise requests.RequestException(f"Failed to delete release. Status code: {response.status_code}, Response: {response.text}")
    
    return response.status_code
```