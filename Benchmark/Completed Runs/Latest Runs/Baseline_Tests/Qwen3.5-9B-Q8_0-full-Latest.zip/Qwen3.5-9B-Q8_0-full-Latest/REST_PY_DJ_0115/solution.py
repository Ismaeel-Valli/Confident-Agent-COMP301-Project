import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API using provided inputs.
    
    Parameters:
        inputs (dict): Dictionary containing 'new_price' and 'new_title'.
        
    Returns:
        str or None: The title from the response if present, otherwise None for success.
                     Raises an exception on HTTP error.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "title": inputs["new_title"],
        "price": inputs["new_price"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to submit product. Status code: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns an empty object {} on success for POST /products/add
    # So we check if 'title' exists in the response data
    return data.get("title")