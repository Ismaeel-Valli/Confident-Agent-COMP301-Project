```python
import requests
from urllib.parse import quote

def solve(inputs):
    """
    Lists releases for a given GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git extension).
            - 'credential' (str): The Bearer token for authentication.
    
    Returns:
        list or None: A list of decoded JSON release objects, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response status code indicates an error.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    token = inputs["credential"]
    
    url = f"https://api.github.com/repos/{quote(owner)}/{quote(repo)}/releases"
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch releases. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    return None if not data else data
```