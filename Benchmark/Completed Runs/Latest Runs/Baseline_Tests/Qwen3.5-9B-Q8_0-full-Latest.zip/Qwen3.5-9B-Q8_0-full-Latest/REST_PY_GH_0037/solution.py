import requests
from urllib.parse import quote

def solve(inputs):
    """
    Creates a pull request on GitHub using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository.
            - new_base (str): The base branch for the PR.
            - new_head (str): The head branch for the PR.
            - new_title (str): The title for the PR.
            - credential (str): The authentication token or string.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    new_base = inputs["new_base"]
    new_head = inputs["new_head"]
    new_title = inputs["new_title"]
    credential = inputs["credential"]
    
    # Construct the URL for creating a pull request
    url = f"https://api.github.com/repos/{quote(repository_owner, safe='')}/{quote(repository_name, safe='')}/pulls"
    
    # Prepare the headers with authentication
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare the payload for the pull request
    data = {
        "title": new_title,
        "head": new_head,
        "base": new_base
    }
    
    # Send the POST request to create the pull request
    response = requests.post(url, headers=headers, json=data)
    
    # Check if the response is successful
    if response.status_code == 201:
        return None  # Successful creation often returns an empty body or a redirect
    elif response.status_code == 202:
        return None  # Accepted status might also indicate success with no immediate content
    else:
        raise Exception(f"Failed to create pull request. Status code: {response.status_code}, Response: {response.text}")

# Example usage (not executed):
# inputs = {
#     "repository_owner": "octocat",
#     "repository_name": "Hello-World",
#     "new_base": "main",
#     "new_head": "feature-branch",
#     "new_title": "Add new feature",
#     "credential": "your_github_token_here"
# }
# result = solve(inputs)