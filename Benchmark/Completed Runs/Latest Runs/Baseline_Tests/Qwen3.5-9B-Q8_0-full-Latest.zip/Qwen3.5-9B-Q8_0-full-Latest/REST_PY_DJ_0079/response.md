```python
import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on the provided sort_field.
    
    Args:
        inputs (dict): A dictionary containing 'sort_field' for ordering posts.
        
    Returns:
        list or None: The decoded JSON response as a list of posts, or None if the response is empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    sort_field = inputs.get("sort_field")
    
    # Construct the query parameters for sorting
    params = {"_sort": sort_field, "_limit": 1}
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        data = response.json()
        
        # Return None if the response is empty (though with _limit:1 it's unlikely unless no posts exist)
        return data if data else None
        
    except requests.exceptions.RequestException as e:
        raise e
```