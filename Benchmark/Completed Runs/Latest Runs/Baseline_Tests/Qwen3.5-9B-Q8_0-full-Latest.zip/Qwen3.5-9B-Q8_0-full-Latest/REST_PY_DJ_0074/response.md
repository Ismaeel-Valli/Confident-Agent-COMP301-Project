```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (str): Identifier of the product
            - new_description (str): New value for the description attribute
    
    Returns:
        str or None: The response's id value if present, otherwise None.
                     Returns None for a successful empty response.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    new_description = inputs.get('new_description')
    
    if not resource_id or new_description is None:
        raise ValueError("Missing required input fields: resource_id and new_description")
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"description": new_description}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product. Status code: {response.status_code}, Response: {response.text}")
    
    # Check if the response is empty (no content)
    if not response.content:
        return None
    
    data = response.json()
    
    # Return the id from the response if present
    return data.get('id')
```