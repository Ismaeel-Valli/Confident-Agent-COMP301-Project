```python
import requests
from urllib.parse import quote

def solve(inputs):
    """
    Lists repository issues for GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - state (str): Indicates the state of the issues to return (e.g., 'open', 'closed').
            - credential (str): The caller-supplied credential (token or Bearer token).
    
    Returns:
        list | None: A list of decoded JSON response items, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    state = inputs["state"]
    credential = inputs["credential"]
    
    # Construct the URL for listing issues
    url = f"https://api.github.com/repos/{quote(owner)}/{quote(repo)}/issues"
    
    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    # Query parameters
    params = {"state": state}
    
    try:
        response = requests.get(url, headers=headers, params=params)
        
        if response.status_code != 200:
            raise Exception(f"Failed to fetch issues. Status code: {response.status_code}, Response: {response.text}")
        
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
        
        return data
    
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```