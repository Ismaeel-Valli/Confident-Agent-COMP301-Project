import requests

def solve(inputs):
    """
    Deletes a post by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' (post identifier).
        
    Returns:
        int or None: The response's id value if present, otherwise None for successful deletion.
        
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON delete endpoint for posts
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    try:
        response = requests.delete(url)
        response.raise_for_status()  # Raises HTTPError for bad responses (4xx, 5xx)
        
        # Check if the response is empty (successful deletion often returns 204 No Content)
        if response.status_code == 204:
            return None
        
        # Try to extract id from response JSON
        try:
            data = response.json()
            return data.get('id')
        except ValueError:
            # If response is not JSON, return None for successful empty response
            return None
            
    except requests.RequestException as e:
        raise e