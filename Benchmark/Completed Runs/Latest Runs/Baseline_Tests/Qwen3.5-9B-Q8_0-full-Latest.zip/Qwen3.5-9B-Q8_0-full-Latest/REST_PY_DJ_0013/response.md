```python
import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON using the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing API parameters, expected to include 'page'.
        
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty but successful.
                      
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    # Base URL for DummyJSON API
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    # Extract page number from inputs, defaulting to 1 if not provided
    page = inputs.get('page', 1)
    
    # Construct the request URL with query parameters
    url = f"{base_url}?page={page}"
    
    try:
        response = requests.get(url)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None if the response is empty (successful but no data)
        if not data:
            return None
            
        return data
        
    except requests.RequestException as e:
        raise e
```