import requests

def solve(inputs):
    """
    Updates selected fields of a post on DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (int) and 'new_title' (str).
        
    Returns:
        str or None: The title value from the response, or None if absent or successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_title = inputs['new_title']
    
    # Base URL for DummyJSON API
    base_url = "https://jsonplaceholder.typicode.com"
    url = f"{base_url}/posts/{resource_id}"
    
    payload = {
        "title": new_title
    }
    
    try:
        response = requests.put(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (no content)
        if not response.text.strip():
            return None
        
        # Parse the JSON response
        data = response.json()
        
        # Return the title value if present, otherwise None
        return data.get('title')
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")