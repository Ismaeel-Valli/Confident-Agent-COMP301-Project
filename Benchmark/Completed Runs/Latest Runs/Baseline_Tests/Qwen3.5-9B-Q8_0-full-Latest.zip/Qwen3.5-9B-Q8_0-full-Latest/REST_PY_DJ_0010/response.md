```python
import requests

def solve(inputs):
    """
    Deletes a user by identifier using DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with the user identifier.
        
    Returns:
        None if deletion is successful (empty response).
        Decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/users/{resource_id}"
    
    response = requests.delete(url)
    
    if response.status_code != 200:
        raise Exception(f"Failed to delete user: {response.status_code} - {response.text}")
    
    # DummyJSON returns an empty body for successful DELETE operations
    return None
```