import requests

def solve(inputs):
    """
    Submits a new todo to DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'new_completed': value for the completed attribute (bool)
            - 'new_todo': value for the todo attribute (str)
            - 'new_user_identifier': value for the user Id attribute (int)
    
    Returns:
        int or None: The response's id value if present, otherwise None.
                     Returns None for a successful empty response.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    url = "https://dummyjson.com/todos"
    
    payload = {
        "todo": inputs['new_todo'],
        "completed": inputs['new_completed'],
        "userId": inputs['new_user_identifier']
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create todo. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Check if the response is empty (no items in the list)
    if not data.get('todos'):
        return None
    
    # Return the id of the newly created todo
    return data['todos'][0].get('id')