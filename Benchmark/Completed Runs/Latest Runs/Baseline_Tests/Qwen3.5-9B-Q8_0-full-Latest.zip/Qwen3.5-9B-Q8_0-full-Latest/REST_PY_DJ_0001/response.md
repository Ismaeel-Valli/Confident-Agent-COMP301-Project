```python
import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing 'page' key for pagination.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        requests.RequestException: For unsuccessful HTTP responses.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    page = inputs.get('page', 1)
    
    url = f"{base_url}/posts?page={page}"
    
    try:
        response = requests.get(url, timeout=5)
        response.raise_for_status()
        
        data = response.json()
        
        # Return None for successful empty response
        if not data:
            return None
            
        return data
        
    except requests.RequestException as e:
        raise e
```