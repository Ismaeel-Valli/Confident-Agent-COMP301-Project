import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (todo ID) and 'new_completed' (boolean value).
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_completed = inputs['new_completed']
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    payload = {"completed": new_completed}
    
    try:
        response = requests.put(url, json=payload)
        
        if response.status_code == 200:
            return None
        elif response.status_code == 201:
            return response.json()
        else:
            raise Exception(f"Failed to update todo. Status code: {response.status_code}, Response: {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")