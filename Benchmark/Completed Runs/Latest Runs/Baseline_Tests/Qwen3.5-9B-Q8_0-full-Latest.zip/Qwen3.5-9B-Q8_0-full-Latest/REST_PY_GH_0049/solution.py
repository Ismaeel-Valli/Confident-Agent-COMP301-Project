import requests

def solve(inputs):
    """
    Lists watchers for a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The caller-supplied credential (e.g., personal access token).
    
    Returns:
        list or None: A list of watcher objects if watchers exist, otherwise None for an empty response.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    token = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/watchers"
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch watchers: HTTP {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response
    if not data:
        return None
    
    return data