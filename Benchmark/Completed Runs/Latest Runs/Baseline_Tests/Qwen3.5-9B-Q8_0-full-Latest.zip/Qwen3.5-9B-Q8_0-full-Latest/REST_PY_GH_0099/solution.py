import requests

def solve(inputs):
    username = inputs["username"]
    page_size = inputs["page_size"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/users/{username}/following"
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    all_followers = []
    page = 1
    
    while True:
        params = {"per_page": page_size, "page": page}
        response = requests.get(url, headers=headers, params=params)
        
        if response.status_code != 200:
            raise Exception(f"Failed to fetch followers: {response.status_code} - {response.text}")
        
        data = response.json()
        
        if not data:
            break
            
        all_followers.extend(data)
        
        # Check if there are more pages
        if len(data) < page_size:
            break
        
        page += 1
    
    if not all_followers:
        return None
    
    return all_followers