```python
import requests

def solve(inputs):
    """
    Deletes a todo by identifier from DummyJSON and returns the 'isDeleted' value.
    
    Args:
        inputs (dict): A dictionary containing 'resource_id' (str) of the todo to delete.
        
    Returns:
        bool or None: The 'isDeleted' value from the response, or None if absent or on empty success.
        
    Raises:
        requests.exceptions.HTTPError: If the HTTP response status code indicates an error.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON API endpoint for deleting a todo by ID
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    try:
        response = requests.delete(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        # Check if the response is empty (no content)
        if not response.text.strip():
            return None
            
        data = response.json()
        
        # Return 'isDeleted' value if present, otherwise None
        return data.get('isDeleted')
        
    except requests.exceptions.HTTPError as e:
        raise e
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"An error occurred while making the request: {e}")
```