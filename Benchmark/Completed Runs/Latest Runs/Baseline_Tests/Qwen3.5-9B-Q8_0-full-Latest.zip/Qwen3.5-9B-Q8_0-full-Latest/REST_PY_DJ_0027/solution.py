import requests

def solve(inputs):
    """
    Deletes a product by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with the product identifier.
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    resource_id = inputs.get('resource_id')
    
    # Construct the delete URL for DummyJSON API
    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.delete(url)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (successful deletion often returns empty body)
        if not response.text.strip():
            return None
        
        # Try to parse the JSON response and extract the id
        try:
            data = response.json()
            return data.get('id')
        except ValueError:
            # If JSON parsing fails but we have content, return None
            return None
            
    except requests.exceptions.HTTPError as e:
        raise e
    except requests.exceptions.RequestException as e:
        raise e