```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API.
    
    Args:
        inputs (dict): Contains 'new_description' and 'new_title'.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "title": inputs["new_title"],
        "description": inputs["new_description"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code == 201:
            # Successful creation
            return None
        elif response.status_code >= 400:
            raise Exception(f"Failed to add product. Status code: {response.status_code}, Response: {response.text}")
        else:
            # Unexpected success status (e.g., 200) but we expect 201
            return response.json()
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Network error occurred: {str(e)}")
```