```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post in DummyJSON and returns the title.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_user_identifier'.
        
    Returns:
        str or None: The title of the updated post, or None if absent or response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_user_identifier = inputs['new_user_identifier']
    
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    payload = {"userId": new_user_identifier}
    
    try:
        response = requests.put(url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 200 and response.text.strip() == "":
            return None
            
        data = response.json()
        return data.get('title')
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```