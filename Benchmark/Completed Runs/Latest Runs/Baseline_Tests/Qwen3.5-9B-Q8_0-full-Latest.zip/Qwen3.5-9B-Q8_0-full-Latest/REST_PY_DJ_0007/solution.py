import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing input parameters, expected to have 'page' key.
        
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty but successful.
                      
    Raises:
        requests.RequestException: If the HTTP request fails (unsuccessful status code).
    """
    # Extract page number from inputs, default to 1 if not provided
    page = inputs.get('page', 1)
    
    # Construct the API URL for DummyJSON users endpoint
    url = f"https://jsonplaceholder.typicode.com/users?page={page}"
    
    try:
        response = requests.get(url)
        
        # Raise an exception for unsuccessful HTTP responses (status code outside 200-299)
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None if the response is empty, otherwise return the data
        return data if data else None
        
    except requests.RequestException as e:
        raise e