import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'included_fields': Comma-separated string of fields to include.
            - 'sort_field': Field name for sorting the results.
    
    Returns:
        list or None: The decoded JSON response as a list of posts, or None if the response is empty.
    
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/posts"
    
    # Parse included_fields
    included_fields = inputs.get('included_fields', '')
    if included_fields:
        fields_list = [f.strip() for f in included_fields.split(',')]
        params = {'_fields': ','.join(fields_list)}
    else:
        params = {}
    
    # Add sort_field to parameters
    sort_field = inputs.get('sort_field', '')
    if sort_field:
        params['sort'] = sort_field
    
    url = f"{base_url}{endpoint}"
    
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        data = response.json()
        
        # Return None if the response is empty (successful but no data)
        if not data:
            return None
        
        return data
    
    except requests.RequestException as e:
        raise e