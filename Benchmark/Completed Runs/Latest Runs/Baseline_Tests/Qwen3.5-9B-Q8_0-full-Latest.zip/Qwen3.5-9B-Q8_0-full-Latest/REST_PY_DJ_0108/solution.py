import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API using provided email and first name.
    
    Args:
        inputs (dict): Dictionary containing 'new_email' and 'new_firstName'.
        
    Returns:
        int or None: The ID of the created user, or None if response is empty/successful without ID.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    url = "https://dummyjson.com/users/addNewUser"
    
    payload = {
        "email": inputs["new_email"],
        "firstName": inputs["new_firstName"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to create user. Status code: {response.status_code}")
    
    data = response.json()
    
    # Check for 'id' in the response body (some endpoints return it directly, others might not)
    if "id" in data and data["id"] is not None:
        return data["id"]
    
    # If successful but no ID returned (empty or different structure), return None as per spec
    return None