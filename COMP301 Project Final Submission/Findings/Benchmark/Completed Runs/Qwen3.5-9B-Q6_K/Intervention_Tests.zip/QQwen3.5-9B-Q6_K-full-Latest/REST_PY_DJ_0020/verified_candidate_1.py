import requests

def solve(inputs):
    """
    Retrieve a todo by identifier from DummyJSON.
    
    Args:
        inputs (dict): Must contain 'resource_id' (int) - the todo ID.
        
    Returns:
        dict or None: The decoded JSON response, or None for empty successful response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    response = requests.get(url)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    return response.json()