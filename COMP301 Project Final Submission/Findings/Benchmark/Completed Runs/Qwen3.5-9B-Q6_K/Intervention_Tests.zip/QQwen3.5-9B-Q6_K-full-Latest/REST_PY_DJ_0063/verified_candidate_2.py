import requests

def solve(inputs):
    """Delete a product by identifier from DummyJSON and return isDeleted value."""
    resource_id = inputs["resource_id"]
    
    url = "https://dummyjson.com/products/delete"
    params = {"productId": int(resource_id)}
    
    response = requests.get(url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    if "isDeleted" in data:
        return data["isDeleted"]
    elif data == {}:
        return None
    else:
        return None