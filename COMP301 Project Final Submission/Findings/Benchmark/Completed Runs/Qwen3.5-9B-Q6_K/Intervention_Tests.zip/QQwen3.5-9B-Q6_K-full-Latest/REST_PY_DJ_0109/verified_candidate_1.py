import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON.
    
    Parameters:
        inputs (dict): Must contain 'result_limit' and 'sort_field'.
        
    Returns:
        list or None: Decoded JSON response as a list, or None for empty successful response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/posts"
    
    result_limit = inputs.get("result_limit")
    sort_field = inputs.get("sort_field")
    
    if result_limit is None or sort_field is None:
        raise ValueError("Missing required inputs: 'result_limit' and 'sort_field' are required.")
    
    params = {
        "limit": result_limit,
        "sortBy": sort_field
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error occurred: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # DummyJSON returns a dict with 'posts' key; return the list of posts
    return data.get("posts")