import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON and return the response's id value,
    or None if that attribute is absent. Return None for a successful empty response.
    Raise an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_age: value for the age attribute
            - new_firstName: value for the first Name attribute
    
    Returns:
        int or None: The id from the response, or None if absent or empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses (status code != 200)
    """
    base_url = "https://dummyjson.com/users"
    
    payload = {
        "age": inputs["new_age"],
        "firstName": inputs["new_firstName"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to create user. Status code: {response.status_code}")
    
    data = response.json()
    
    # Check for empty response
    if not data or "id" not in data:
        return None
    
    return data["id"]