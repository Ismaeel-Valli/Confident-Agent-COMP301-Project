import requests

def solve(inputs):
    """Update selected fields of a todo in DummyJSON."""
    resource_id = inputs["resource_id"]
    new_user_identifier = inputs["new_user_identifier"]
    
    url = "https://dummyjson.com/todos/" + str(resource_id)
    payload = {"userId": new_user_identifier}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 204:
        return None
    else:
        raise Exception(f"Failed to update todo: {response.status_code} - {response.text}")