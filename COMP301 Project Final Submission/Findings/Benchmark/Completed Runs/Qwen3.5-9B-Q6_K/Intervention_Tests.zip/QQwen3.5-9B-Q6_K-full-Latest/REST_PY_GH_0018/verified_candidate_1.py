import requests

def solve(inputs):
    """
    Get an issue comment from GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git)
            - comment_id (int): Unique identifier of the comment
            - credential (str): Caller-supplied authentication token
    
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    # Build the API URL for getting a single issue comment
    base_url = "https://api.github.com"
    version = "2026-03-10"
    
    # Construct the endpoint path
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    comment_id = inputs["comment_id"]
    credential = inputs["credential"]
    
    url = f"{base_url}/repos/{owner}/{repo}/issues/comments/{comment_id}"
    
    # Prepare headers with authentication
    headers = {
        "Accept": f"application/vnd.github.{version}-preview+json",
        "Authorization": f"token {credential}"
    }
    
    # Make the GET request
    response = requests.get(url, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses
    if not response.ok:
        raise Exception(f"GitHub API request failed with status {response.status_code}: {response.text}")
    
    # Decode and return JSON response
    data = response.json()
    
    # Return None for successful empty response, otherwise return the data
    if data is None or (isinstance(data, dict) and len(data) == 0):
        return None
    
    return data