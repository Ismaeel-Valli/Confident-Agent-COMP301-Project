def solve(inputs):
    """
    Update selected fields of a product on DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_title'.
        
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    import requests
    
    resource_id = inputs['resource_id']
    new_title = inputs['new_title']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"title": new_title}
    
    response = requests.put(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Check for id in different possible locations
    if 'id' in data:
        return data['id']
    elif 'product' in data and isinstance(data['product'], dict) and 'id' in data['product']:
        return data['product']['id']
    else:
        return None