import requests

def solve(inputs):
    """
    Update selected fields of a product on DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_description'.
        
    Returns:
        int or None: The response's id value, or None if absent or for empty successful response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_description = inputs['new_description']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {
        "description": new_description
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Check for empty response
    if not data or 'id' not in data:
        return None
    
    return data['id']