import requests


def solve(inputs):
    """Submit a new product to DummyJSON.
    
    Args:
        inputs (dict): Contains 'new_price' and 'new_title'.
        
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products/add"
    
    payload = {
        "title": inputs["new_title"],
        "price": inputs["new_price"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create product. Status code: {response.status_code}")
    
    return None