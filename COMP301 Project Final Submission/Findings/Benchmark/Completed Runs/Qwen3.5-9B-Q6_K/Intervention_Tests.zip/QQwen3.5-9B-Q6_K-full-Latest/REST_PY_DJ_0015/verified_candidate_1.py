import requests

def solve(inputs):
    """
    Update selected fields of a post on DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_title' (new title).
        
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_title = inputs['new_title']
    
    url = "https://dummyjson.com/posts/{id}".format(id=resource_id)
    payload = {"title": new_title}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 201:
        return response.json()
    else:
        raise Exception(f"Failed to update post: {response.status_code} - {response.text}")