import requests

def solve(inputs):
    """
    Update an issue comment on GitHub using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): The account owner of the repository
            - repository_name (str): The name of the repository without .git extension
            - comment_id (int): The unique identifier of the comment
            - new_body (str): The new body content for the comment
            - credential (str): Bearer token for authentication
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    comment_id = inputs["comment_id"]
    new_body = inputs["new_body"]
    credential = inputs["credential"]
    
    # GitHub API v2026-03-10 endpoint for updating an issue comment
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/comments/{comment_id}"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    data = {
        "body": new_body
    }
    
    response = requests.put(url, json=data, headers=headers)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to update comment: HTTP {response.status_code} - {response.text}")
    
    # Return decoded JSON response, or None for successful empty response
    if response.status_code == 204:
        return None
    
    return response.json()