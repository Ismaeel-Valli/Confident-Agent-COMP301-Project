import requests

def solve(inputs):
    """
    Retrieve one page of products from DummyJSON with pagination and field filtering.
    
    Args:
        inputs (dict): Must contain:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip (for pagination).
            - included_fields (str): Comma-separated list of fields to include.
    
    Returns:
        dict or None: Decoded JSON response, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    base_url = "https://dummyjson.com/products"
    
    # Build query parameters
    params = {
        "limit": inputs["result_limit"],
        "skip": inputs["results_to_skip"],
        "select": inputs["included_fields"]
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code >= 400:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Return None for successful empty response (empty products array)
    if not data.get("products"):
        return None
    
    return data