import requests

def solve(inputs):
    """
    Create a fork of a GitHub repository using the GitHub REST API v2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git extension)
            - new_name (str): New name for the forked repository
            - credential (str): Bearer token for authentication
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    # Build the URL for creating a fork with a custom name
    url = "https://api.github.com/repos/{owner}/{repo}/forks".format(
        owner=inputs["repository_owner"],
        repo=inputs["repository_name"]
    )
    
    headers = {
        "Authorization": f"Bearer {inputs['credential']}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Use POST body for the name parameter instead of query params
    data = {
        "name": inputs["new_name"]
    }
    
    response = requests.post(url, headers=headers, json=data)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create fork. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json()