import requests

def solve(inputs):
    """
    Update selected fields of a product on DummyJSON.
    
    inputs:
        resource_id (int): Identifier of the product.
        new_price (float or int): New value for the price attribute.
    
    Returns:
        dict or None: Decoded JSON response, or None if response is empty.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    resource_id = inputs["resource_id"]
    new_price = inputs["new_price"]
    
    url = f"{base_url}/{resource_id}"
    payload = {"price": new_price}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product: {response.status_code}")
    
    return response.json() if response.content else None