import requests

def solve(inputs):
    """
    Retrieve a product by identifier from DummyJSON.
    
    Args:
        inputs (dict): Must contain 'resource_id' key with the product ID.
        
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/products/{resource_id}"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    # DummyJSON returns empty dict {} for non-existent products (200 OK)
    # Per instructions: return None for successful empty response
    if not data:
        return None
    
    return data