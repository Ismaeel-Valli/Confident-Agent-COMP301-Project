import requests

def solve(inputs):
    """
    Update selected fields of a product on DummyJSON.
    
    Inputs:
        - resource_id (int): Identifier of the product
        - new_title (str): New value for the title attribute
    
    Returns:
        - The decoded JSON response, or None if successful with empty response.
        - Raises an exception for unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    resource_id = inputs["resource_id"]
    new_title = inputs["new_title"]
    
    url = f"{base_url}/{resource_id}"
    
    payload = {
        "title": new_title
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json()