import requests

def solve(inputs):
    """
    Create an issue comment on a GitHub repository using the REST API v2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without .git extension.
            - issue_number (int): The number that identifies the issue.
            - new_body (str): Value for the body attribute.
            - credential (str): Caller-supplied authentication token.
    
    Returns:
        dict or None: Decoded JSON response, or None if successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    body = inputs["new_body"]
    credential = inputs["credential"]
    
    # GitHub API v2026-03-10 endpoint for creating an issue comment
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}/comments"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github.v3+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    payload = {
        "body": body
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code != 200 and response.status_code != 201:
        raise Exception(f"Failed to create issue comment. Status code: {response.status_code}, Response: {response.text}")
    
    # Return decoded JSON response
    return response.json()