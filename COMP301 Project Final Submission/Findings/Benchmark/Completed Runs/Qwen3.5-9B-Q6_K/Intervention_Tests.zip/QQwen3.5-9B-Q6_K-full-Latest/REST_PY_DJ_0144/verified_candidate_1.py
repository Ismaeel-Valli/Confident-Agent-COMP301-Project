import requests

def solve(inputs):
    """
    Update selected fields of a user on DummyJSON.
    
    Args:
        inputs (dict): Must contain 'resource_id' and 'new_username'.
        
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_username = inputs.get('new_username')
    
    if resource_id is None or new_username is None:
        raise ValueError("Missing required inputs: 'resource_id' and 'new_username'")
    
    url = "https://dummyjson.com/users/update/" + str(resource_id)
    
    payload = {
        "username": new_username
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code >= 400:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Check for id in the response
    if 'id' in data and data['id'] is not None:
        return data['id']
    elif data.get('status') == 200 or data.get('status') == "success" or data.get('message'):
        # Successful empty response
        return None
    
    return None