import requests

def solve(inputs):
    """Delete a post by identifier from DummyJSON."""
    resource_id = inputs["resource_id"]
    url = "https://dummyjson.com/posts/{post_id}".format(post_id=resource_id)
    response = requests.delete(url)
    if response.status_code != 200:
        raise Exception(f"Failed to delete post: {response.status_code} - {response.text}")
    return None