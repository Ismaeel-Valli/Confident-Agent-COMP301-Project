import requests

def solve(inputs):
    """
    Update selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id' (todo ID) and 'new_completed' (boolean).
        
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_completed = inputs['new_completed']
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    payload = {
        "completed": new_completed
    }
    
    response = requests.patch(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Check for successful empty response (no content)
    if not data or len(data) == 0:
        return None
    
    # Return the id from the response
    return data.get('id')