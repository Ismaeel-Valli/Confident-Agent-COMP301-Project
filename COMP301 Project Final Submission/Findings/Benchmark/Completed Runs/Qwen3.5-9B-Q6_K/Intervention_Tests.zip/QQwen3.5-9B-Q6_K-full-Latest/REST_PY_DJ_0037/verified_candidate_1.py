import requests

def solve(inputs):
    """Delete a post by identifier from DummyJSON and return its id or None."""
    resource_id = inputs.get("resource_id")
    if resource_id is None:
        return None
    
    url = "https://dummyjson.com/posts"
    try:
        response = requests.delete(url, json={"postId": resource_id})
        response.raise_for_status()
        
        data = response.json()
        # DummyJSON delete returns {"success": true} on success with no id field
        if "id" in data:
            return data["id"]
        else:
            return None
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")