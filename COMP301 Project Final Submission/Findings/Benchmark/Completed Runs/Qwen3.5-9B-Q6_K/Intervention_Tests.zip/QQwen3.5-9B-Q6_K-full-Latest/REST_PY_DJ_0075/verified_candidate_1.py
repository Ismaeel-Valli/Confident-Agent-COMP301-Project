import requests

def solve(inputs):
    """Submit a new product to DummyJSON and return its id, or None if absent."""
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/store/{inputs['store_id']}/products"
    
    payload = {
        "description": inputs["new_description"],
        "title": inputs["new_title"]
    }
    
    try:
        response = requests.post(url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 201:
            data = response.json()
            return data.get("id")
        elif response.status_code == 204:
            return None
        else:
            raise Exception(f"Failed to create product. Status code: {response.status_code}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"HTTP error occurred: {e}")