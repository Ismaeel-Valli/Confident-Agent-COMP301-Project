def solve(inputs):
    """Submit a new product to DummyJSON and return its id, or None if absent."""
    import requests
    
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/add"
    
    payload = {
        "title": inputs["new_title"]
    }
    
    try:
        response = requests.post(url, json=payload)
        response.raise_for_status()
        
        data = response.json()
        
        # DummyJSON returns the created product in the response body
        if "product" in data and isinstance(data["product"], dict):
            return data["product"].get("id")
        elif "id" in data:
            return data["id"]
        else:
            return None
            
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")