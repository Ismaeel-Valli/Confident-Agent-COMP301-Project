def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON, skipping specified results and
    returning only the included fields.
    
    Args:
        inputs (dict): Dictionary with keys:
            - results_to_skip (int): Number of results to skip
            - included_fields (str): Comma-separated list of fields to include
    
    Returns:
        dict or None: Decoded JSON response, or None for empty successful response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    import requests
    
    base_url = "https://dummyjson.com/todos"
    
    # Parse included_fields
    if not inputs.get("included_fields"):
        included_fields = []
    else:
        included_fields = [field.strip() for field in inputs["included_fields"].split(",") if field.strip()]
    
    params = {
        "skip": inputs.get("results_to_skip", 0),
        "limit": 1,  # Retrieve one page
        "_fields": ",".join(included_fields) if included_fields else None
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    # If the response is empty (no todos), return None
    if not data.get("todos") or len(data["todos"]) == 0:
        return None
    
    return data