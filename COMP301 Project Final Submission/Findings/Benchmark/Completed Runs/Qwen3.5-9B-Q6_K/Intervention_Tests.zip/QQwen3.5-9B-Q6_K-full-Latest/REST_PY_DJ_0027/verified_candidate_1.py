import requests

def solve(inputs):
    """Delete a product by identifier from DummyJSON and return its id or None."""
    base_url = "https://dummyjson.com/products"
    resource_id = inputs["resource_id"]
    
    try:
        response = requests.delete(f"{base_url}/{resource_id}")
        
        if response.status_code == 200:
            # Successful deletion, return the id from response or None
            data = response.json()
            return data.get("id")
        elif response.status_code == 204:
            # No content response, return None as per spec
            return None
        else:
            # Unsuccessful HTTP response, raise exception
            raise Exception(f"Failed to delete product. Status code: {response.status_code}")
            
    except requests.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")