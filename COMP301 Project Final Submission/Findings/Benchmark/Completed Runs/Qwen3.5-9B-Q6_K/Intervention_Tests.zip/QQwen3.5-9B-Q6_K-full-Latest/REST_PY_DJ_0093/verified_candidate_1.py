import requests


def solve(inputs):
    """
    Retrieve one page of products from DummyJSON with pagination and field filtering.
    
    Args:
        inputs (dict): Must contain:
            - result_limit (int): Maximum number of results to return.
            - included_fields (str): Comma-separated list of fields to include.
    
    Returns:
        dict or None: Decoded JSON response, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx).
    """
    base_url = "https://dummyjson.com/products"
    limit = inputs["result_limit"]
    fields_str = inputs["included_fields"]
    
    # Build query parameters
    params = {
        "limit": limit,
        "select": fields_str
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"HTTP error: {response.status_code} - {response.reason}")
    
    data = response.json()
    
    if not data.get("products"):
        return None
    
    return data