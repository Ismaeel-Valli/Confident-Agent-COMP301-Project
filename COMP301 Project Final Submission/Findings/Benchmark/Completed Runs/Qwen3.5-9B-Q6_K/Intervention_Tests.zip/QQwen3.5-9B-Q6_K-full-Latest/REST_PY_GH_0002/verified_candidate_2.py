import requests
import json

def solve(inputs):
    """
    Update a GitHub organization using the REST API v2026-03-10.
    
    Args:
        inputs (dict): Must contain:
            - organization (str): The organization name
            - new_name (str): The new name for the organization
            - credential (str): Bearer token for authentication
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty body.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    org_name = inputs["organization"]
    new_name = inputs["new_name"]
    credential = inputs["credential"]
    
    # GitHub API endpoint for updating an organization
    url = f"https://api.github.com/orgs/{org_name}"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    payload = {
        "name": new_name
    }
    
    response = requests.patch(url, headers=headers, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to update organization: {response.status_code} - {response.text}")
    
    return response.json() if response.content else None