import requests

def solve(inputs):
    """
    Submit a new product to DummyJSON using the provided price and title.
    
    Args:
        inputs (dict): Must contain 'new_price' and 'new_title'.
        
    Returns:
        str or None: The title from the response, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    
    payload = {
        "title": inputs["new_title"],
        "price": inputs["new_price"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        if response.status_code != 201 and response.status_code != 200:
            raise Exception(f"Failed to create product. Status code: {response.status_code}")
        
        data = response.json()
        
        # DummyJSON returns the created product directly in the response body for POST /products
        if "product" in data and isinstance(data["product"], dict):
            return data["product"].get("title")
        elif "title" in data:
            return data["title"]
        else:
            return None
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")