import requests

def solve(inputs):
    """Delete a todo by identifier from DummyJSON."""
    resource_id = inputs["resource_id"]
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    response = requests.delete(url)
    
    if response.status_code != 200:
        raise Exception(f"Failed to delete todo. Status code: {response.status_code}")
    
    return None