import requests

def solve(inputs):
    """Delete a todo by identifier from DummyJSON."""
    resource_id = inputs["resource_id"]
    url = "https://dummyjson.com/todos"
    
    response = requests.delete(url, params={"todoId": resource_id})
    
    if response.status_code != 200:
        raise Exception(f"Failed to delete todo. Status code: {response.status_code}")
    
    return None