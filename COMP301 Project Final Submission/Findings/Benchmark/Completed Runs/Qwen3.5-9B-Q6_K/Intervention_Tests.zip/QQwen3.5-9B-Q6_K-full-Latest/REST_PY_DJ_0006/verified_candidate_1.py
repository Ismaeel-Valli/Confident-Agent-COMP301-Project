import requests
import json

def solve(inputs):
    """
    Submit a new product to DummyJSON.
    
    Args:
        inputs (dict): Must contain 'new_title' for the product title.
        
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    url = "https://dummyjson.com/products/add"
    
    payload = {
        "title": inputs["new_title"]
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code == 201:
            # Successful creation with empty response body
            return None
        elif response.status_code == 200:
            # Return decoded JSON for other successful responses
            return response.json()
        else:
            raise Exception(f"HTTP {response.status_code}: {response.text}")
            
    except requests.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")