import requests

def solve(inputs):
    """
    Submit a new post to DummyJSON using the provided inputs.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_body: value for the body attribute
            - new_title: value for the title attribute
            - new_user_identifier: value for the user Id attribute
    
    Returns:
        int or None: The response's id value, or None if that attribute is absent.
                     Returns None for a successful empty response.
    
    Raises:
        Exception: For an unsuccessful HTTP response.
    """
    url = "https://dummyjson.com/posts/add"
    headers = {
        "Content-Type": "application/json"
    }
    payload = {
        "title": inputs["new_title"],
        "body": inputs["new_body"],
        "userId": inputs["new_user_identifier"]
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create post. Status code: {response.status_code}")
    
    data = response.json()
    
    # Check if the response has an 'id' field
    if "id" in data and data["id"] is not None:
        return data["id"]
    else:
        return None