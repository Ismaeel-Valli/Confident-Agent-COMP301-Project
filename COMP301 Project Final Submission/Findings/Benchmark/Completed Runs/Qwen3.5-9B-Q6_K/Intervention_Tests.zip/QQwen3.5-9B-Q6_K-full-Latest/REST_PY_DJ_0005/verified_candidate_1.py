import requests

def solve(inputs):
    """
    Search products on DummyJSON using the provided search term.
    
    Args:
        inputs (dict): Must contain 'search_text' key with the search term.
        
    Returns:
        list or None: Decoded JSON response as a list of products, or None if empty.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/products/search"
    search_text = inputs["search_text"]
    
    params = {
        "q": search_text
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    products = data.get("products", [])
    
    return products if products else None