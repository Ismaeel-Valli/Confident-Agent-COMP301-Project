import requests

def solve(inputs):
    """Submit a new product to DummyJSON and return its id, or None if absent."""
    base_url = "https://dummyjson.com/products"
    
    payload = {
        "title": inputs["new_title"],
        "price": inputs["new_price"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to submit product: HTTP {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns id in the response on success
    return data.get("id")