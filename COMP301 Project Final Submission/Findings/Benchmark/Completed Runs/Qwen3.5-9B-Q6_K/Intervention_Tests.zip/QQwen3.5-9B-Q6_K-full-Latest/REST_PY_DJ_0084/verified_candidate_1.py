import requests

def solve(inputs):
    """
    Update selected fields of a product on DummyJSON.
    
    Inputs:
        - resource_id (int): ID of the product to update.
        - new_description (str): New description value.
    
    Returns:
        - str: The 'title' field from the response, or None if absent.
        - None: If the response is successful but empty.
        - Raises: Exception for unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    resource_id = inputs["resource_id"]
    new_description = inputs["new_description"]
    
    url = f"{base_url}/{resource_id}"
    
    payload = {
        "description": new_description
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product: HTTP {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns the updated product object in the response body
    title = data.get("title")
    
    return title