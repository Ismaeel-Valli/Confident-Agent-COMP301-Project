import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON using the provided first and last name.
    
    Args:
        inputs (dict): Must contain 'new_firstName' and 'new_lastName'.
        
    Returns:
        int or None: The ID of the created user, or None if response is empty.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    base_url = "https://dummyjson.com/users/add"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "lastName": inputs["new_lastName"]
    }
    
    response = requests.post(base_url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 201:
        data = response.json()
        # Check for 'id' in the response
        if "id" in data:
            return data["id"]
        else:
            return None
    else:
        raise requests.RequestException(f"Failed to create user. Status code: {response.status_code}")