import requests

def solve(inputs):
    """
    List commits from a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git extension)
            - credential (str): Bearer token for authentication
    
    Returns:
        list or None: Decoded JSON response as a list, or None if successful but empty.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    token = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/commits"
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch commits. Status code: {response.status_code}")
    
    data = response.json()
    
    # Return None for successful empty response
    if not data:
        return None
    
    return data