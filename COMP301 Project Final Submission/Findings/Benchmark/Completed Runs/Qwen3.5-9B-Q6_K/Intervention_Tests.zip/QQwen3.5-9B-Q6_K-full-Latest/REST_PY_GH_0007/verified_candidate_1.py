import requests

def solve(inputs):
    """
    Update a repository name on GitHub using the REST API v2026-03-10.
    
    Args:
        inputs (dict): Must contain:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git)
            - new_name (str): New name for the repository
            - credential (str): Bearer token for authentication
    
    Returns:
        None if successful (empty response), otherwise decoded JSON response.
    
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    new_name = inputs["new_name"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/rename"
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    response = requests.put(url, json={"name": new_name}, headers=headers)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to rename repository: {response.status_code} - {response.text}")
    
    return None