import requests

def solve(inputs):
    """
    Submit a new post to DummyJSON using the provided inputs.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_body (str): Value for the body attribute
            - new_title (str): Value for the title attribute
            - new_user_identifier (str): Value for the user Id attribute
    
    Returns:
        str or None: The response's title value, or None if absent or successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/posts/add"
    
    payload = {
        "body": inputs["new_body"],
        "title": inputs["new_title"],
        "userId": inputs["new_user_identifier"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create post. Status code: {response.status_code}")
    
    data = response.json()
    
    # Check for successful empty response or absent title
    if not data or "title" not in data:
        return None
    
    return data["title"]