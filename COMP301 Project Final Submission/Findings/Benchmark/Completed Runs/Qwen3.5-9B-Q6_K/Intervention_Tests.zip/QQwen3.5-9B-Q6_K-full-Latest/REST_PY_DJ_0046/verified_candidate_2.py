import requests

def solve(inputs):
    """
    Update selected fields of a product on DummyJSON.
    
    Args:
        inputs (dict): Must contain 'resource_id' and 'new_title'.
        
    Returns:
        str or None: The updated title value, or None if absent or response is empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_title = inputs.get('new_title')
    
    if resource_id is None or new_title is None:
        raise ValueError("Missing required input fields: 'resource_id' and 'new_title'.")
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {
        "title": new_title
    }
    
    response = requests.patch(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error occurred: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Check for empty response or missing title
    if not data or 'title' not in data:
        return None
    
    return data['title']