import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON with pagination and sorting.
    
    Args:
        inputs (dict): Must contain 'results_to_skip' and 'sort_field'.
        
    Returns:
        dict or None: Decoded JSON response, or None if successful but empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/posts"
    
    params = {
        "skip": inputs["results_to_skip"],
        "limit": 1,
        "sort_by": inputs["sort_field"]
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Return None for successful empty response (empty posts array)
    if not data.get("posts"):
        return None
    
    return data