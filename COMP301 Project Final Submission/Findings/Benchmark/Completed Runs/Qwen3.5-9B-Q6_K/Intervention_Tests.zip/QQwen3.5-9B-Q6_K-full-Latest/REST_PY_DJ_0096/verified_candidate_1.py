def solve(inputs):
    """
    Retrieve one page of users from DummyJSON with pagination and field filtering.
    
    Args:
        inputs (dict): Must contain:
            - result_limit (int): Maximum number of results to return.
            - included_fields (str): Comma-separated list of fields to include.
    
    Returns:
        dict or None: Decoded JSON response, or None if successful but empty.
    
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    import requests
    
    base_url = "https://dummyjson.com/users"
    limit = inputs["result_limit"]
    fields_str = inputs["included_fields"]
    
    # Build query params
    params = {
        "limit": limit,
        "select": fields_str.split(",") if fields_str else None
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code}")
    
    data = response.json()
    
    # Return the users list (or None if empty)
    return data.get("users")