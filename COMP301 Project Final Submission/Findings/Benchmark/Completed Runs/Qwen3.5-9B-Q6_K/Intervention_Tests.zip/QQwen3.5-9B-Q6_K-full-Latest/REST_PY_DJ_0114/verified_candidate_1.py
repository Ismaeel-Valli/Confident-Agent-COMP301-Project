import requests

def solve(inputs):
    """
    Update selected fields of a product on DummyJSON.
    
    inputs:
        - resource_id (int): ID of the product to update
        - new_price (float or int): new price value
    
    Returns:
        str: The title from the response, or None if absent or empty response.
        Raises an exception for unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    resource_id = inputs["resource_id"]
    new_price = inputs["new_price"]
    
    url = f"{base_url}/{resource_id}"
    payload = {"price": new_price}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product: {response.status_code}")
    
    data = response.json()
    
    # Handle different possible response structures
    if "product" in data:
        title = data["product"].get("title")
    elif "products" in data and len(data["products"]) > 0:
        title = data["products"][0].get("title")
    else:
        title = None
    
    return title