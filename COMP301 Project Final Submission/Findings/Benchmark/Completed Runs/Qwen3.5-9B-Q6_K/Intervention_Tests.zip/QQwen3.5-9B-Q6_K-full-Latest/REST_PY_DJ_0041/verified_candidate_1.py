import requests

def solve(inputs):
    """
    Update a todo item in DummyJSON and return its id, or None if absent or empty response.
    
    Args:
        inputs (dict): Must contain 'resource_id' (int) and 'new_todo' (str).
    
    Returns:
        int or None: The updated todo's id, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx).
    """
    base_url = "https://dummyjson.com"
    resource_id = inputs["resource_id"]
    new_todo = inputs["new_todo"]
    
    url = f"{base_url}/todos/{resource_id}"
    
    payload = {"todo": new_todo}
    
    response = requests.put(url, json=payload)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    # DummyJSON PUT /todos/{id} returns the updated todo object directly
    if "id" in data:
        return data["id"]
    elif data == {}:
        return None
    else:
        return None