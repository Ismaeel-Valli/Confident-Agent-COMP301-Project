def solve(inputs):
    """
    Retrieve one page of products from DummyJSON with a limit on results.
    
    Args:
        inputs (dict): Must contain 'result_limit' (int).
        
    Returns:
        list or None: Decoded JSON response, or None for empty successful response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    import requests
    
    base_url = "https://dummyjson.com/products"
    limit = inputs.get("result_limit")
    
    if limit is None:
        raise ValueError("Missing required input: result_limit")
    
    params = {"limit": limit}
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns a dict with 'products' key; return the list directly
    return data.get("products")