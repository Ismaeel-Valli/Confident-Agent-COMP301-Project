import requests

def solve(inputs):
    """Submit a new user to DummyJSON and return the response's id or None."""
    url = "https://dummyjson.com/users/add"
    payload = {
        "firstName": inputs["new_firstName"],
        "username": inputs["new_username"]
    }
    
    try:
        response = requests.post(url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 201:
            data = response.json()
            return data.get("id")
        else:
            raise Exception(f"Unexpected status code: {response.status_code}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"HTTP error occurred: {e}")