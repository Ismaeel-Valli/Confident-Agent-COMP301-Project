import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_body = inputs["new_body"]
    new_title = inputs["new_title"]
    
    url = "https://dummyjson.com/posts/" + str(resource_id)
    payload = {
        "body": new_body,
        "title": new_title
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    if "id" in data and data["id"] is not None:
        return data["id"]
    elif response.status_code == 204:
        return None
    else:
        return None