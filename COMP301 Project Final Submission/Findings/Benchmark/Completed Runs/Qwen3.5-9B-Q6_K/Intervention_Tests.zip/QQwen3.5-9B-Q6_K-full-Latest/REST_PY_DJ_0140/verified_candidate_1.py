import requests

def solve(inputs):
    """
    Retrieve one page of products from DummyJSON, sorted by sort_field in sort_direction.
    
    Args:
        inputs (dict): Must contain 'sort_field' and 'sort_direction'.
        
    Returns:
        dict or None: Decoded JSON response. Returns None for empty successful response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    
    # Validate inputs
    if 'sort_field' not in inputs or 'sort_direction' not in inputs:
        raise ValueError("Missing required fields: sort_field and sort_direction")
    
    sort_field = inputs['sort_field']
    sort_direction = inputs['sort_direction']
    
    params = {
        'sort': sort_field,
        'order': sort_direction,
        'skip': 0,
        'limit': 1
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for empty successful response (no products)
    if not data.get('products'):
        return None
    
    return data