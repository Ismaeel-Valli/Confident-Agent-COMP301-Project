import requests
import base64

def solve(inputs):
    """
    Create an organization repository on GitHub REST API v2026-03-10.
    
    Args:
        inputs (dict): Must contain:
            - organization (str): The organization name
            - new_name (str): The name for the new repository
            - credential (str): Base64-encoded username:password string
    
    Returns:
        dict or None: Decoded JSON response. Returns None for successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    org = inputs["organization"]
    repo_name = inputs["new_name"]
    credential = inputs["credential"]
    
    # Decode the credential (assumed to be base64-encoded "username:password")
    try:
        decoded_credential = base64.b64decode(credential).decode('utf-8')
        username, password = decoded_credential.split(':', 1)
    except Exception as e:
        raise ValueError(f"Invalid credential format: {e}")
    
    # GitHub API endpoint for creating a repository in an organization
    url = f"https://api.github.com/orgs/{org}/repos"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Basic {credential}",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    payload = {
        "name": repo_name
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code == 201:
        # Successful creation - GitHub returns empty body for this endpoint
        return None
    elif response.status_code == 202:
        # Accepted (async operation) - return the response as-is
        return response.json()
    else:
        raise Exception(f"Failed to create repository. Status code: {response.status_code}, Response: {response.text}")