import requests

def solve(inputs):
    """
    Create an issue on GitHub using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git)
            - new_title (str): Title for the issue
            - credential (str): Bearer token for authentication
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    title = inputs["new_title"]
    credential = inputs["credential"]
    
    # GitHub REST API v2026-03-10 endpoint for creating issues
    url = f"https://api.github.com/repos/{owner}/{repo}/issues"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    data = {
        "title": title
    }
    
    response = requests.post(url, json=data, headers=headers)
    
    if response.status_code not in [201, 202]:
        raise Exception(f"Failed to create issue: HTTP {response.status_code}, {response.text}")
    
    # GitHub returns empty body for successful issue creation in some cases
    if response.content == b"":
        return None
    
    return response.json()