import requests

def solve(inputs):
    """
    Retrieve one page of users from DummyJSON with a limit on results.
    
    Args:
        inputs (dict): Must contain 'result_limit' (int).
        
    Returns:
        list or None: Decoded JSON response, or None for empty successful response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/users"
    limit = inputs.get("result_limit")
    
    params = {}
    if limit is not None:
        params["limit"] = limit
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()
    
    data = response.json()
    return data.get("users", [])