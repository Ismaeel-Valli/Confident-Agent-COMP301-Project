import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON using the provided first name and phone number.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_phone'.
        
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/users/add"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "phone": inputs["new_phone"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code == 201:
        return None
    
    elif response.status_code in [400, 409]:
        return response.json()
    
    else:
        raise Exception(f"Failed to create user. Status code: {response.status_code}, Response: {response.text}")