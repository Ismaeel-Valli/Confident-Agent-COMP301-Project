import requests

def solve(inputs):
    """Delete a user by identifier from DummyJSON and return the response's id or None."""
    base_url = "https://dummyjson.com/users"
    resource_id = inputs["resource_id"]
    
    try:
        response = requests.delete(f"{base_url}/{resource_id}")
        
        if response.status_code >= 400:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
        
        # Return the id from the response, or None if absent
        data = response.json()
        return data.get("id")
    
    except requests.RequestException as e:
        raise Exception(f"Request failed: {e}")