import requests

def solve(inputs):
    resource_id = inputs.get("resource_id")
    if resource_id is None:
        return None
    
    url = f"https://dummyjson.com/products/{resource_id}"
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"Failed to retrieve product: {response.status_code}")
    
    data = response.json()
    
    if "id" in data and data["id"] is not None:
        return data["id"]
    elif data == {}:
        return None
    else:
        return None