import requests

def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON, skipping a specified number of results.
    
    Args:
        inputs (dict): Must contain 'results_to_skip' (int).
        
    Returns:
        dict or None: Decoded JSON response, or None for empty successful response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com"
    endpoint = "/todos"
    
    params = {
        "skip": inputs["results_to_skip"],
        "limit": 1,
    }
    
    response = requests.get(f"{base_url}{endpoint}", params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for successful empty response (empty todos list)
    if not data.get("todos"):
        return None
    
    return data