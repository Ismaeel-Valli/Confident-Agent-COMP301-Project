import requests

def solve(inputs):
    """
    Update selected fields of a user on DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id (int): Identifier of the user to update.
            - new_phone (str): New phone number value.
    
    Returns:
        int or None: The response's id value, or None if absent or for empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses (status code not 200).
    """
    base_url = "https://dummyjson.com/users"
    resource_id = inputs["resource_id"]
    new_phone = inputs["new_phone"]
    
    url = f"{base_url}/{resource_id}"
    
    payload = {
        "phone": new_phone
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Check for empty response
    if not data or "id" not in data:
        return None
    
    return data["id"]