import requests

def solve(inputs):
    """
    Retrieve one page of products from DummyJSON.
    
    Args:
        inputs (dict): Must contain 'page' key with an integer value.
        
    Returns:
        list or None: The decoded JSON response as a list, or None if the response is empty.
        
    Raises:
        requests.exceptions.RequestException: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    page = inputs.get("page")
    
    if page is None:
        raise ValueError("Missing required 'page' in inputs")
    
    url = f"{base_url}?page={page}"
    
    response = requests.get(url)
    response.raise_for_status()
    
    data = response.json()
    products = data.get("products", [])
    
    if not products:
        return None
    
    return products