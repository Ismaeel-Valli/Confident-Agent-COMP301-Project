import requests
import json

def solve(inputs):
    """
    Update a label on a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): Contains:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without .git extension.
            - name (str): Current label name.
            - new_new_name (str): New label name to update to.
            - credential (str): Bearer token for authentication.
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    current_name = inputs["name"]
    new_name = inputs["new_new_name"]
    token = inputs["credential"]
    
    # GitHub REST API v2026-03-10 endpoint for updating a label using PATCH
    url = f"https://api.github.com/repos/{owner}/{repo}/labels/{current_name}"
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Update the label name using PATCH method
    data = {
        "name": new_name
    }
    
    response = requests.patch(url, json=data, headers=headers)
    
    if response.status_code == 200:
        return None  # Successful empty response
    elif response.status_code == 204:
        return None  # No content on success
    else:
        raise Exception(f"Failed to update label. Status code: {response.status_code}, Response: {response.text}")