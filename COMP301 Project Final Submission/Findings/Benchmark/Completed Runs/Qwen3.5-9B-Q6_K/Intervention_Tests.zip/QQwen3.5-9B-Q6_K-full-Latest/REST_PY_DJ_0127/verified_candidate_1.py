import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON using provided firstName and phone.
    
    Args:
        inputs (dict): Must contain 'new_firstName' and 'new_phone'.
        
    Returns:
        int or None: The response's id if present, otherwise None for success.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/users"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "phone": inputs["new_phone"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to create user: HTTP {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns the created user in 'user' field for POST /users
    if "user" in data and isinstance(data["user"], dict):
        return data["user"].get("id")
    
    # If no 'user' field, check top-level 'id' (unlikely but possible)
    if "id" in data:
        return data["id"]
    
    # Otherwise, return None for successful empty response
    return None