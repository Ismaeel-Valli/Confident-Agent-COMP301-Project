import requests

def solve(inputs):
    """
    Retrieve one page of users from DummyJSON with pagination and field filtering.
    
    Args:
        inputs (dict): Dictionary containing:
            - results_to_skip (int): Number of results to skip for pagination
            - included_fields (str): Comma-separated list of fields to include
    
    Returns:
        dict or None: Decoded JSON response, or None if successful but empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    base_url = "https://dummyjson.com/users"
    
    # Parse included_fields
    included_fields = [f.strip() for f in inputs["included_fields"].split(",")]
    
    # Build query parameters
    params = {
        "skip": inputs["results_to_skip"],
        "limit": 1,  # Retrieve one page
        "_fields": ",".join(included_fields)
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for successful empty response
    if not data.get("users"):
        return None
    
    return data