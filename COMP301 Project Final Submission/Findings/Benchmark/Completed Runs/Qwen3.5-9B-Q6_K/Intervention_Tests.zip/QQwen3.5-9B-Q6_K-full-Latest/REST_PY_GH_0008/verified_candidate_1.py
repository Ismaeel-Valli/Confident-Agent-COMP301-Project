import requests

def solve(inputs):
    """
    Delete a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): Must contain:
            - repository_owner (str): The account owner of the repository
            - repository_name (str): The name of the repository (without .git extension)
            - credential (str): The caller-supplied authentication token
    
    Returns:
        int: The successful HTTP status code (204 No Content for successful deletion)
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    credential = inputs["credential"]
    
    # GitHub API v3 endpoint for deleting a repository
    url = f"https://api.github.com/repos/{owner}/{repo}"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github.v3+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.delete(url, headers=headers)
    
    # Raise an exception for unsuccessful responses
    if response.status_code != 204:
        response.raise_for_status()
    
    return response.status_code