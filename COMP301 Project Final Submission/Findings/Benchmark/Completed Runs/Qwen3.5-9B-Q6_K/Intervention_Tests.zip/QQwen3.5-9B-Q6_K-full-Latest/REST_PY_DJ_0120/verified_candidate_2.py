import requests

def solve(inputs):
    """
    Update selected fields of a post on DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id (int): ID of the post to update
            - new_user_identifier (str): New value for the user Id attribute
    
    Returns:
        str or None: The title from the response, or None if absent or empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs["resource_id"]
    new_user_identifier = inputs["new_user_identifier"]
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    payload = {
        "userId": new_user_identifier
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # DummyJSON PUT returns the updated post directly, not wrapped
    title = data.get("title")
    
    if title is None or title == "":
        return None
    
    return title