import requests

def solve(inputs):
    """
    Update selected fields of a user on DummyJSON.
    
    Inputs:
        inputs['resource_id']: Identifier of the user (e.g., 1)
        inputs['new_lastName']: New value for the last Name attribute
    
    Returns:
        The decoded JSON response, or None if successful with empty response.
    
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_last_name = inputs['new_lastName']
    
    url = f"https://dummyjson.com/users/{resource_id}"
    
    headers = {
        "Content-Type": "application/json"
    }
    
    payload = {
        "lastName": new_last_name
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code not in [200, 201]:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # DummyJSON returns the updated user object on PUT
    # If the response is empty (unlikely for this endpoint), return None
    if not data:
        return None
    
    return data