import requests
import json


def solve(inputs):
    """Delete a GitHub organization using the REST API v2026-03-10."""
    org_name = inputs["organization"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/orgs/{org_name}"
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github.v3+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.delete(url, headers=headers)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    return response.json()