import requests

def solve(inputs):
    """Submit a new user to DummyJSON."""
    base_url = "https://dummyjson.com/users/add"
    
    payload = {
        "email": inputs["new_email"],
        "firstName": inputs["new_firstName"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user: HTTP {response.status_code}")
    
    return None