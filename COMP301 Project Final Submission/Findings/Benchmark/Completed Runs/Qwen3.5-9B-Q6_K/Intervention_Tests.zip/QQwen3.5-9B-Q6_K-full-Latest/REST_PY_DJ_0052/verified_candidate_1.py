import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_firstName (str): First name for the new user
            - new_lastName (str): Last name for the new user
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    base_url = "https://dummyjson.com/users"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "lastName": inputs["new_lastName"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        if response.status_code == 201:
            # Successful creation - return decoded JSON or None for empty response
            data = response.json()
            return data if data else None
        elif response.status_code in [400, 409]:
            # Bad request or conflict - raise exception
            raise Exception(f"Failed to create user: {response.text}")
        else:
            # Other unsuccessful status codes
            raise Exception(f"HTTP error {response.status_code}: {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")