import requests

def solve(inputs):
    """
    Retrieve a user by identifier from DummyJSON.
    
    Args:
        inputs (dict): Must contain 'resource_id' (user ID).
        
    Returns:
        dict or None: Decoded JSON response, or None if empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs["resource_id"]
    url = f"https://dummyjson.com/users/{resource_id}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        
        if response.status_code == 200:
            data = response.json()
            return None if data is None else data
        else:
            raise Exception(f"Unexpected status code: {response.status_code}")
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")