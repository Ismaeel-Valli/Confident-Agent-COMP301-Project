import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON, sorted by sort_field.
    
    Args:
        inputs (dict): Must contain 'sort_field' key with a string value.
        
    Returns:
        list or None: Decoded JSON response as a list, or None if empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    sort_field = inputs.get('sort_field')
    
    if not sort_field:
        raise ValueError("Missing required 'sort_field' in inputs")
    
    base_url = "https://dummyjson.com/posts"
    params = {
        'limit': 1,
        'sortBy': sort_field
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return the posts list, or None if empty
    return data.get('posts')