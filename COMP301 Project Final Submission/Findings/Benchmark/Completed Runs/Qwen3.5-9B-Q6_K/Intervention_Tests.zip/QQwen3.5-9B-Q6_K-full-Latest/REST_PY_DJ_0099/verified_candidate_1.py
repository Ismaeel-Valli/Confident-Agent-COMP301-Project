import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON with pagination support.
    
    Args:
        inputs (dict): Dictionary containing:
            - result_limit (int): Maximum number of results to return
            - included_fields (str): Comma-separated list of fields to include
    
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    base_url = "https://dummyjson.com/posts"
    
    # Parse included_fields
    if inputs.get("included_fields"):
        fields = [f.strip() for f in inputs["included_fields"].split(",")]
        params = {"fields": ",".join(fields)}
    else:
        params = {}
    
    # Add result_limit parameter
    params["limit"] = inputs.get("result_limit", 10)
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()
        
        data = response.json()
        
        # Check if posts array is empty
        if not data.get("posts"):
            return None
        
        return data
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")