import requests

def solve(inputs):
    """
    Update selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id: ID of the todo to update
            - new_todo: value for the 'todo' attribute
            - new_user_identifier: value for the 'userId' attribute
    
    Returns:
        int or None: The response's id value, or None if absent or empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs["resource_id"]
    new_todo = inputs["new_todo"]
    new_user_identifier = inputs["new_user_identifier"]
    
    base_url = "https://dummyjson.com"
    endpoint = f"/todos/{resource_id}"
    url = f"{base_url}{endpoint}"
    
    payload = {
        "todo": new_todo,
        "userId": new_user_identifier
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}")
    
    data = response.json()
    
    # Check for empty response
    if not data:
        return None
    
    # Return the id from the response
    return data.get("id")