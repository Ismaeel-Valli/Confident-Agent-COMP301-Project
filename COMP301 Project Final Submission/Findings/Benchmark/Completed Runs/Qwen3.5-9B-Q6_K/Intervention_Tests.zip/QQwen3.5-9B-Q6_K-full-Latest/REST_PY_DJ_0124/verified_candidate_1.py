import requests

def solve(inputs):
    """
    Submit a new product to DummyJSON.
    
    Args:
        inputs (dict): Contains 'new_category' and 'new_title'.
        
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    
    payload = {
        "category": inputs["new_category"],
        "title": inputs["new_title"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        if response.status_code == 201:
            return None
        
        elif response.status_code == 200:
            return response.json()
        
        else:
            raise Exception(f"Failed to create product. Status code: {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")