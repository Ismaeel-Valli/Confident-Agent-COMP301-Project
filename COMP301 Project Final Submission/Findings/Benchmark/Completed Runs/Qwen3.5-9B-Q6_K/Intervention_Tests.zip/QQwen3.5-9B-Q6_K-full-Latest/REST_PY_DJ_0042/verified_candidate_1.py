import requests

def solve(inputs):
    """Delete a todo by identifier from DummyJSON and return its id or None."""
    base_url = "https://dummyjson.com/todos"
    resource_id = inputs["resource_id"]
    
    try:
        response = requests.delete(f"{base_url}/{resource_id}")
        
        if response.status_code == 200:
            # Successful deletion returns empty body
            return None
        elif response.status_code == 404:
            # Todo not found - attribute absent scenario
            return None
        else:
            # Unsuccessful HTTP response
            raise Exception(f"Failed to delete todo: {response.status_code} {response.text}")
            
    except requests.RequestException as e:
        raise Exception(f"Request failed: {e}")