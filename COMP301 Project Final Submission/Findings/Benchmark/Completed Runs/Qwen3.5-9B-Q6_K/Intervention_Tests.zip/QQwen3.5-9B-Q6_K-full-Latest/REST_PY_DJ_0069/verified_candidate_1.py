import requests

def solve(inputs):
    """Update a post on DummyJSON with new body content."""
    resource_id = inputs["resource_id"]
    new_body = inputs["new_body"]
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    
    response = requests.patch(url, json={"body": new_body})
    
    if response.status_code != 200:
        raise Exception(f"Failed to update post: {response.status_code} - {response.text}")
    
    return None