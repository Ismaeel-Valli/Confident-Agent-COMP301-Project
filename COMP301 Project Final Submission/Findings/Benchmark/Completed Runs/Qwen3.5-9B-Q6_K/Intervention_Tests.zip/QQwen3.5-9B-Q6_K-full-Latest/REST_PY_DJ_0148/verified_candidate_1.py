import requests

def solve(inputs):
    """
    Update selected fields of a todo on DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id (int): Identifier of the todo to update
            - new_completed (bool): New value for completed attribute
            - new_user_identifier (int): New value for user Id attribute
    
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com"
    resource_id = inputs["resource_id"]
    new_completed = inputs["new_completed"]
    new_user_identifier = inputs["new_user_identifier"]
    
    url = f"{base_url}/todos/{resource_id}"
    
    payload = {
        "completed": new_completed,
        "userId": new_user_identifier
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code not in [200, 201]:
        raise Exception(f"Failed to update todo: HTTP {response.status_code}")
    
    data = response.json()
    
    # Check for id in different possible locations
    if "id" in data:
        return data["id"]
    elif "todo" in data and "id" in data["todo"]:
        return data["todo"]["id"]
    else:
        return None