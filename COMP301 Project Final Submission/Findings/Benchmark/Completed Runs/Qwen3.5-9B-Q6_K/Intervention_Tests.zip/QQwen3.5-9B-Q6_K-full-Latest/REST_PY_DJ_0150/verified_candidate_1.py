import requests


def solve(inputs):
    """Update selected fields of a product on DummyJSON."""
    resource_id = inputs["resource_id"]
    new_brand = inputs["new_brand"]

    url = "https://dummyjson.com/products/{0}".format(resource_id)
    payload = {"brand": new_brand}

    response = requests.put(url, json=payload)
    response.raise_for_status()

    if response.status_code == 204:
        return None

    return response.json()