import requests

def solve(inputs):
    """
    Submit a new product to DummyJSON.
    
    Args:
        inputs (dict): Contains 'new_description' and 'new_title'.
        
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    
    payload = {
        "description": inputs["new_description"],
        "title": inputs["new_title"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 201 and len(response.content) == 0:
            return None
        
        return response.json()
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")