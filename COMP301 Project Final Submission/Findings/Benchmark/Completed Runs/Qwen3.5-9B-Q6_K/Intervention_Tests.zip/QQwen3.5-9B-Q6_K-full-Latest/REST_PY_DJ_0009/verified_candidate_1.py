import requests

def solve(inputs):
    """
    Update selected fields of a user on DummyJSON.
    
    Args:
        inputs (dict): Must contain 'resource_id' and 'new_firstName'.
        
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_first_name = inputs['new_firstName']
    
    url = f"https://dummyjson.com/users/{resource_id}"
    
    headers = {
        "Content-Type": "application/json"
    }
    
    payload = {
        "firstName": new_first_name
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code >= 400:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    return response.json()