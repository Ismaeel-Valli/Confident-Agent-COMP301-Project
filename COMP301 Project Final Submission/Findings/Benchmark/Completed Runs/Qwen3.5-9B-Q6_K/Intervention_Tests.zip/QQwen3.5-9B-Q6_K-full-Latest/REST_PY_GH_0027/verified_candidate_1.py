import requests
import json

def solve(inputs):
    """
    Get a label from GitHub REST API v2026-03-10.
    
    Args:
        inputs (dict): Contains:
            - repository_owner: str, account owner of the repository
            - repository_name: str, name of the repository (without .git)
            - name: str, label name to retrieve
            - credential: str, caller-supplied authentication token
    
    Returns:
        dict or None: Decoded JSON response. Returns None for successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    label_name = inputs["name"]
    credential = inputs["credential"]
    
    # GitHub REST API v2026-03-10 endpoint for getting a label by name
    url = f"https://api.github.com/repos/{owner}/{repo}/labels/{label_name}"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        # Successful response with label data
        return response.json()
    elif response.status_code == 404:
        # Label not found - this is a successful empty response per requirements
        return None
    else:
        # Unsuccessful HTTP response
        raise Exception(f"Failed to retrieve label: {response.status_code} - {response.text}")