import requests

def solve(inputs):
    """Retrieve a user by identifier from DummyJSON and return the user's id."""
    resource_id = inputs.get("resource_id")
    
    if resource_id is None:
        return None
    
    try:
        response = requests.get(f"https://dummyjson.com/users/{resource_id}")
        
        if response.status_code != 200:
            raise Exception(f"HTTP error: {response.status_code} - {response.text}")
        
        data = response.json()
        
        if "id" in data and data["id"] is not None:
            return data["id"]
        else:
            return None
            
    except requests.RequestException as e:
        raise Exception(f"Request failed: {e}")