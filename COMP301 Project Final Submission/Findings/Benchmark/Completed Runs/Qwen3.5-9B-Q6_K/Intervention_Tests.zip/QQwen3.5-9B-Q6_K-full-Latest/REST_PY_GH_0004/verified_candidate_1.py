import requests
import json

def solve(inputs):
    """
    List repositories for a GitHub organization using the REST API v2026-03-10.
    
    Args:
        inputs (dict): Must contain 'organization' and 'credential'.
        
    Returns:
        list or None: Decoded JSON response, or None if empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    org = inputs["organization"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/orgs/{org}/repos"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch repositories: HTTP {response.status_code}")
    
    data = response.json()
    
    return data if len(data) > 0 else None