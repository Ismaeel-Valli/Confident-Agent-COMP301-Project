import requests

def solve(inputs):
    """Delete a user by identifier on DummyJSON and return isDeleted or None."""
    resource_id = inputs.get("resource_id")
    if resource_id is None:
        raise ValueError("Missing required input: resource_id")
    
    url = "https://dummyjson.com/users/delete"
    params = {"userId": resource_id}
    
    response = requests.post(url, params=params)
    response.raise_for_status()
    
    data = response.json()
    
    if response.status_code == 200:
        # Successful deletion returns empty JSON {}
        return None
    
    # For non-200 success (e.g., 201), check isDeleted field
    if "isDeleted" in data:
        return data["isDeleted"]
    
    return None