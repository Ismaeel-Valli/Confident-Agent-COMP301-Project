import requests

def solve(inputs):
    """
    Update selected fields of a post on DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_title' (new title).
        
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_title = inputs.get('new_title')
    
    if resource_id is None or new_title is None:
        raise ValueError("Missing required input fields")
    
    base_url = "https://dummyjson.com/posts"
    url = f"{base_url}/{resource_id}"
    
    payload = {
        "title": new_title
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code not in [200, 201]:
        raise Exception(f"Failed to update post: HTTP {response.status_code}")
    
    data = response.json()
    
    # Check for id in response (could be in 'id' field or nested)
    post_id = data.get('id')
    if post_id is not None:
        return post_id
    
    # If successful but no id, return None as per spec
    return None