import requests

def solve(inputs):
    """Retrieve a product by identifier from DummyJSON and return its title."""
    resource_id = inputs.get("resource_id")
    
    if resource_id is None:
        return None
    
    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raise exception for unsuccessful HTTP responses
        
        data = response.json()
        
        # Return title if present, otherwise None
        return data.get("title")
    except requests.exceptions.HTTPError:
        raise
    except Exception as e:
        raise