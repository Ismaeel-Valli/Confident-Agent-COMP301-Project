import requests

def solve(inputs):
    """Delete a post by identifier from DummyJSON and return the title or None."""
    resource_id = inputs.get("resource_id")
    if resource_id is None:
        raise ValueError("Missing required input: resource_id")
    
    url = "https://dummyjson.com/posts/delete"
    params = {"postId": resource_id}
    
    try:
        response = requests.delete(url, params=params)
        response.raise_for_status()
        
        data = response.json()
        # DummyJSON delete returns the deleted post with title if successful
        return data.get("title")
    except requests.exceptions.HTTPError as e:
        raise RuntimeError(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Request failed: {e}")