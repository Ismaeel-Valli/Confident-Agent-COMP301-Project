import requests

def solve(inputs):
    """
    Update selected fields of a post on DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id (int): Identifier of the post to update.
            - new_user_identifier (str): New value for the user Id attribute.
    
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/posts"
    resource_id = inputs["resource_id"]
    new_user_identifier = inputs["new_user_identifier"]
    
    url = f"{base_url}/{resource_id}"
    payload = {"userId": new_user_identifier}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Check for successful empty response (no content)
    if not data or "id" not in data:
        return None
    
    return data.get("id")