import requests

def solve(inputs):
    """
    Retrieve one page of users from DummyJSON and return the decoded JSON response.
    
    Parameters:
        inputs (dict): Must contain 'page' key with an integer value for pagination.
    
    Returns:
        list or None: The decoded JSON response as a list of users, or None if the response is empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://dummyjson.com/users"
    page = inputs.get("page", 1)
    
    params = {"limit": 1, "skip": (page - 1) * 1}
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()
    
    data = response.json()
    users = data.get("users", [])
    
    return users if users else None