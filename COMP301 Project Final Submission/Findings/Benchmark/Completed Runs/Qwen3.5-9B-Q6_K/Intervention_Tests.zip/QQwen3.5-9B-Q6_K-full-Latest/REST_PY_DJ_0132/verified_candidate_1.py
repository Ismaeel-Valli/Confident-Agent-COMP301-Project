import requests

def solve(inputs):
    """
    Update selected fields of a product on DummyJSON.
    
    Inputs:
        - resource_id: Identifier of the product (int)
        - new_category: Value for the category attribute (str)
    
    Returns:
        - The response's id value if present, or None if absent.
        - None for a successful empty response.
        - Raises an exception for unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    resource_id = inputs["resource_id"]
    new_category = inputs["new_category"]
    
    payload = {
        "category": new_category
    }
    
    response = requests.put(f"{base_url}/{resource_id}", json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product: HTTP {response.status_code}")
    
    data = response.json()
    
    # Check for id in the response
    if "id" in data and data["id"] is not None:
        return data["id"]
    elif data == {}:
        return None
    else:
        return None