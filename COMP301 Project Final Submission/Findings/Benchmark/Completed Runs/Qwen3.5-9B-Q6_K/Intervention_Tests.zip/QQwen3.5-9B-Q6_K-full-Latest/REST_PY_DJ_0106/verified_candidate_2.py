import requests

def solve(inputs):
    """
    Retrieve one page of users from DummyJSON with pagination.
    
    Args:
        inputs (dict): Must contain 'result_limit' and 'sort_field'.
        
    Returns:
        list or None: Decoded JSON response, or None for empty successful response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/users"
    
    result_limit = inputs.get("result_limit")
    sort_field = inputs.get("sort_field")
    
    if result_limit is None or sort_field is None:
        raise ValueError("Missing required inputs: 'result_limit' and 'sort_field'")
    
    params = {
        "limit": result_limit,
        "sortBy": sort_field
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # DummyJSON returns a dict with 'users' key and 'total' count
    users = data.get("users", [])
    
    if len(users) == 0:
        return None
    
    return users