import requests

def solve(inputs):
    """
    Submit a new post to DummyJSON using the provided inputs.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_body: value for the body attribute
            - new_title: value for the title attribute
            - new_user_identifier: value for the user Id attribute
    
    Returns:
        dict or None: Decoded JSON response, or None for a successful empty response.
    
    Raises:
        Exception: For an unsuccessful HTTP response.
    """
    base_url = "https://dummyjson.com/posts/add"
    
    payload = {
        "body": inputs["new_body"],
        "title": inputs["new_title"],
        "userId": inputs["new_user_identifier"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        if response.status_code == 201:
            return None
        
        elif response.status_code == 400 or response.status_code == 409:
            # These are expected for validation conflicts (e.g., duplicate title)
            return None
        
        else:
            response.raise_for_status()
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"HTTP request failed: {e}")