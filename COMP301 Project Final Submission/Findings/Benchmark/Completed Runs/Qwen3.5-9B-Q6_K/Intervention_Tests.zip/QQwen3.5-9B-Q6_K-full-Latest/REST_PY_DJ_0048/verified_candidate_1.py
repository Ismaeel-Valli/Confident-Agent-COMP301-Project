import requests

def solve(inputs):
    """
    Submit a new product to DummyJSON and return the response's title value,
    or None if that attribute is absent. Return None for a successful empty response.
    Raise an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Dictionary containing 'new_title' key with the product title.
        
    Returns:
        str or None: The title from the response, or None if absent or empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/add"
    
    payload = {
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # Check if the response has a 'title' attribute
    if "title" in data and data["title"] is not None:
        return data["title"]
    else:
        return None