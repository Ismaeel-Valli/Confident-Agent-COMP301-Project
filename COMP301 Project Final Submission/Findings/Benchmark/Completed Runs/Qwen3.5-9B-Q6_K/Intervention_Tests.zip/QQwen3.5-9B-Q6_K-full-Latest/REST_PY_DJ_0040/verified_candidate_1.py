import requests

def solve(inputs):
    """
    Retrieve a todo by identifier from DummyJSON and return its id value.
    
    Args:
        inputs (dict): Must contain 'resource_id' key with the todo identifier.
        
    Returns:
        int or None: The todo's id if found, None for empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    
    if resource_id is None:
        raise ValueError("Missing 'resource_id' in inputs")
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Check for empty response
    if not data or 'id' not in data:
        return None
    
    return data['id']