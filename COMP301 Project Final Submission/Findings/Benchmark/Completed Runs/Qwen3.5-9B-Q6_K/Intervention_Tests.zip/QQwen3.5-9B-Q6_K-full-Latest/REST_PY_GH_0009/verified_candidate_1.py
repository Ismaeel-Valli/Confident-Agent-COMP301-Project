import requests

def solve(inputs):
    """
    List branches for a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git extension)
            - credential (str): Caller-supplied authentication token
    
    Returns:
        list or None: Decoded JSON response as a list, or None for empty successful response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    credential = inputs["credential"]
    
    # GitHub API endpoint for listing branches (version 2026-03-10)
    url = f"https://api.github.com/repos/{owner}/{repo}/branches"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    # Raise exception for unsuccessful HTTP responses
    if not response.ok:
        raise Exception(f"GitHub API request failed with status {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Return None for successful empty response
    if len(data) == 0:
        return None
    
    return data