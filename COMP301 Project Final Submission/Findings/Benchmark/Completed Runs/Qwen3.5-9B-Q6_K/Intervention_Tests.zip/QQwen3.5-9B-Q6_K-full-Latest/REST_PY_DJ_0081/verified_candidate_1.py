def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON with pagination.
    
    Args:
        inputs (dict): Must contain 'result_limit' and 'results_to_skip'.
        
    Returns:
        dict or None: Decoded JSON response, or None if empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    import requests
    
    base_url = "https://dummyjson.com"
    endpoint = "/todos"
    
    limit = inputs.get("result_limit")
    skip = inputs.get("results_to_skip")
    
    if limit is None or skip is None:
        raise ValueError("Missing required inputs: result_limit and results_to_skip")
    
    url = f"{base_url}{endpoint}?limit={limit}&skip={skip}"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    # DummyJSON returns a dict with 'todos' key; return the decoded JSON as-is
    return data