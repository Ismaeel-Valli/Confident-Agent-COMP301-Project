import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON using the provided first name and username.
    
    Args:
        inputs (dict): Must contain 'new_firstName' and 'new_username'.
        
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/users"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "username": inputs["new_username"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        if response.status_code == 201:
            data = response.json()
            # DummyJSON returns empty body on success, so return None
            return None
        elif response.status_code in (400, 409):
            # Conflict or bad request - might be due to duplicate username
            raise Exception(f"Failed to create user: {response.text}")
        else:
            raise Exception(f"HTTP error: {response.status_code} - {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")