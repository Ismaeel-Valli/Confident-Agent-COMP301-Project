def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON with a limit on results.
    
    Args:
        inputs (dict): Must contain 'result_limit' (int).
        
    Returns:
        list or None: Decoded JSON response, or None if successful but empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    import requests
    
    result_limit = inputs.get('result_limit')
    if result_limit is None:
        raise ValueError("Missing required input: 'result_limit'")
    
    base_url = "https://dummyjson.com/todos"
    params = {'limit': result_limit}
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()
    
    data = response.json()
    return data.get('todos', [])