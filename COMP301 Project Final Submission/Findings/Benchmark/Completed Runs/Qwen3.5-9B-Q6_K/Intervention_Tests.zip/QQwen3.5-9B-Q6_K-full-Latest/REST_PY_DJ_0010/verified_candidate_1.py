import requests

def solve(inputs):
    """Delete a user by identifier from DummyJSON."""
    resource_id = inputs["resource_id"]
    url = "https://dummyjson.com/users/{0}".format(resource_id)
    response = requests.delete(url)
    if response.status_code != 200:
        raise Exception(f"Failed to delete user: {response.status_code} - {response.text}")
    return None