import requests

def solve(inputs):
    """Delete a product by identifier from DummyJSON."""
    resource_id = inputs["resource_id"]
    
    url = "https://dummyjson.com/products"
    response = requests.delete(url, json={"id": resource_id})
    
    if response.status_code == 200:
        return None
    
    response.raise_for_status()