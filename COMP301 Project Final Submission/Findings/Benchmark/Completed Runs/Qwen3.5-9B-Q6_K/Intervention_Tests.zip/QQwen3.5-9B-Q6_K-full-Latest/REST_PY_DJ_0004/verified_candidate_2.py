import requests

def solve(inputs):
    """Delete a product by identifier from DummyJSON."""
    resource_id = inputs["resource_id"]
    
    url = f"https://dummyjson.com/products/{resource_id}"
    response = requests.delete(url)
    
    if response.status_code == 200:
        return None
    
    response.raise_for_status()