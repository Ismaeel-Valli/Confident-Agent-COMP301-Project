def solve(inputs):
    """
    List issue comments for a GitHub repository using the REST API.
    
    Parameters:
        inputs (dict): Dictionary containing:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git)
            - issue_number (int): Issue number to fetch comments for
            - credential (str): Bearer token for authentication
    
    Returns:
        list or None: List of issue comment objects, or None if empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    import requests
    
    # Build the API URL
    base_url = "https://api.github.com"
    url = f"{base_url}/repos/{inputs['repository_owner']}/{inputs['repository_name']}/issues/{inputs['issue_number']}/comments"
    
    # Prepare headers with Bearer token authentication
    headers = {
        "Authorization": f"Bearer {inputs['credential']}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    # Make the GET request
    response = requests.get(url, headers=headers)
    
    # Check for unsuccessful HTTP response
    if response.status_code != 200:
        raise Exception(f"Failed to fetch issue comments. Status code: {response.status_code}, Response: {response.text}")
    
    # Parse JSON response
    data = response.json()
    
    # Return None for empty successful response, otherwise return the list
    if not data:
        return None
    
    return data