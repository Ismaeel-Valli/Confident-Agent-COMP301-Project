import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON and return the response's id value.
    
    Args:
        inputs (dict): Must contain 'new_firstName' key with the first name value.
        
    Returns:
        int or None: The id from the response, or None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/users/add"
    
    payload = {
        "firstName": inputs["new_firstName"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        if response.status_code >= 400:
            raise Exception(f"Failed to create user: HTTP {response.status_code}")
        
        response_data = response.json()
        
        # Check for id in the response
        if "id" in response_data and response_data["id"] is not None:
            return response_data["id"]
        elif response_data == {}:
            return None
        else:
            return None
            
    except requests.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")