def solve(inputs):
    """Retrieve a post by identifier from DummyJSON and return its title."""
    import requests
    
    resource_id = inputs.get("resource_id")
    if resource_id is None:
        raise ValueError("Missing required input: resource_id")
    
    url = "https://dummyjson.com/posts/" + str(resource_id)
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns the post directly, not wrapped in a dict with "posts" key
    title = data.get("title")
    
    return title if title is not None else None