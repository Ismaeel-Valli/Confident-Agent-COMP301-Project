import requests

def solve(inputs):
    page = inputs['page']
    url = f"https://dummyjson.com/todos?page={page}"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code}")
    
    data = response.json()
    
    return data if data else None