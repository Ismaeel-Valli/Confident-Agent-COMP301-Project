import requests

def solve(inputs):
    """Search users on DummyJSON using search_text."""
    base_url = "https://dummyjson.com/users/search"
    params = {"q": inputs["search_text"]}
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()  # Raise exception for unsuccessful HTTP response
    
    data = response.json()
    
    if data["users"]:
        return data
    
    return None