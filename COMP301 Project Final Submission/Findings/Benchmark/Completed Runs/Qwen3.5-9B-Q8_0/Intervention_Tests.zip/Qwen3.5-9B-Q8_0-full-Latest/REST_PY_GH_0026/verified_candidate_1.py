import requests

def solve(inputs):
    """
    Create a label on a GitHub repository using the REST API v2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git)
            - new_name (str): Value for the name attribute of the label
            - credential (str): Bearer token for authentication
    
    Returns:
        dict or None: Decoded JSON response, or None if successful empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    label_name = inputs["new_name"]
    token = inputs["credential"]
    
    # GitHub API endpoint for creating a label
    url = f"https://api.github.com/repos/{owner}/{repo}/labels"
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Create label with name attribute
    data = {
        "name": label_name
    }
    
    response = requests.post(url, json=data, headers=headers)
    
    if response.status_code == 201:
        return None
    elif response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Failed to create label. Status code: {response.status_code}, Response: {response.text}")