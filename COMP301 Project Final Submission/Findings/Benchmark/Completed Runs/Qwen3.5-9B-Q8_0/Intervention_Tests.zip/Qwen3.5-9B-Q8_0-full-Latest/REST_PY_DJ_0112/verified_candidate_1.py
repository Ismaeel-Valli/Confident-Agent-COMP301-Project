import requests

def solve(inputs):
    """
    Update selected fields of a todo on DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id (int): ID of the todo to update
            - new_completed (bool): New value for completed field
            - new_todo (str): New value for todo field
    
    Returns:
        int or None: The response's id, or None if absent. Returns None for empty successful response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/todos"
    resource_id = inputs["resource_id"]
    new_completed = inputs["new_completed"]
    new_todo = inputs["new_todo"]
    
    payload = {
        "completed": new_completed,
        "todo": new_todo
    }
    
    try:
        response = requests.put(f"{base_url}/{resource_id}", json=payload)
        
        if response.status_code >= 400:
            raise Exception(f"HTTP error: {response.status_code} - {response.text}")
        
        # Check if response is empty (no content)
        if not response.content:
            return None
        
        data = response.json()
        
        # Return the id from the response, or None if absent
        return data.get("id")
    
    except requests.RequestException as e:
        raise Exception(f"Request failed: {e}")