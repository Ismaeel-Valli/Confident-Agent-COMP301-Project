import requests

def solve(inputs):
    """
    Retrieve one page of users from DummyJSON with pagination.
    
    Args:
        inputs (dict): Must contain 'result_limit' and 'results_to_skip'.
        
    Returns:
        list or None: Decoded JSON response as a list, or None if empty.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    result_limit = inputs.get('result_limit')
    results_to_skip = inputs.get('results_to_skip')
    
    if result_limit is None or results_to_skip is None:
        raise ValueError("inputs must contain 'result_limit' and 'results_to_skip'")
    
    base_url = "https://dummyjson.com/users"
    params = {
        'limit': result_limit,
        'skip': results_to_skip
    }
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()
    
    data = response.json()
    users = data.get('users', [])
    
    if not users:
        return None
    
    return users