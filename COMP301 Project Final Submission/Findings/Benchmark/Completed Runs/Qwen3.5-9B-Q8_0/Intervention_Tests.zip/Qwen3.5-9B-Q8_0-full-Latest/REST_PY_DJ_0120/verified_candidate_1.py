import requests

def solve(inputs):
    """
    Update selected fields of a post on DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id (int): ID of the post to update
            - new_user_identifier (str): New value for the user_id field
    
    Returns:
        str or None: The title of the updated post, or None if absent.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/posts"
    resource_id = inputs["resource_id"]
    new_user_identifier = inputs["new_user_identifier"]
    
    payload = {
        "user_id": new_user_identifier
    }
    
    try:
        response = requests.put(
            f"{base_url}/{resource_id}",
            json=payload
        )
        
        if response.status_code < 200 or response.status_code >= 300:
            raise Exception(f"HTTP {response.status_code}: {response.text}")
        
        data = response.json()
        
        # DummyJSON PUT returns the updated post directly in the response body
        title = data.get("title")
        return title if title is not None else None
        
    except requests.RequestException as e:
        raise Exception(f"Request failed: {e}")