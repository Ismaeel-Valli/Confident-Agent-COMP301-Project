import requests

def solve(inputs):
    """
    Submit a new product to DummyJSON and return the title from the response.
    
    Args:
        inputs (dict): Dictionary containing 'new_title' for the product title.
        
    Returns:
        str or None: The title from the response, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    
    payload = {
        "title": inputs["new_title"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        if response.status_code != 201:
            raise Exception(f"Failed to create product. Status code: {response.status_code}")
        
        data = response.json()
        
        # Check for title in the response
        if "title" in data and data["title"]:
            return data["title"]
        else:
            return None
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")