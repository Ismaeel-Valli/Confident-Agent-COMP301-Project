import requests

def solve(inputs):
    """Delete a product by identifier from DummyJSON and return isDeleted or None."""
    resource_id = inputs["resource_id"]
    url = "https://dummyjson.com/products/delete"
    
    response = requests.post(url, json={"productId": resource_id})
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    if "isDeleted" in data:
        return data["isDeleted"]
    elif response.text.strip() == "":
        return None
    else:
        return None