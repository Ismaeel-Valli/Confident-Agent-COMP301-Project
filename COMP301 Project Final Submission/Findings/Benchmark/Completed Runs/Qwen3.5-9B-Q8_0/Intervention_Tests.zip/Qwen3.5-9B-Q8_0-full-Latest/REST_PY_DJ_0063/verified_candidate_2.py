import requests

def solve(inputs):
    """Delete a product by identifier from DummyJSON and return isDeleted or None."""
    resource_id = inputs["resource_id"]
    url = f"https://dummyjson.com/products/{resource_id}"
    
    response = requests.delete(url)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    if "isDeleted" in data:
        return data["isDeleted"]
    elif response.text.strip() == "":
        return None
    else:
        return None