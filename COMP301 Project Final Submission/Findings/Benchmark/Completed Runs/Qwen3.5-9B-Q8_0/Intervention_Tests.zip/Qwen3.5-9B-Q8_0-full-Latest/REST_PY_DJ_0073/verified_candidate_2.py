import requests

def solve(inputs):
    """
    Retrieve one page of products from DummyJSON, sorted by sort_field.
    
    Args:
        inputs (dict): Must contain 'sort_field' key with a string value.
        
    Returns:
        list or None: Decoded JSON response as a list, or None if empty.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    sort_field = inputs.get('sort_field')
    
    if not sort_field:
        raise ValueError("inputs must contain 'sort_field'")
    
    base_url = "https://dummyjson.com/products"
    params = {
        "skip": 0,
        "limit": 1
    }
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()
    
    data = response.json()
    products = data.get("products", [])
    
    if not products:
        return None
    
    return products