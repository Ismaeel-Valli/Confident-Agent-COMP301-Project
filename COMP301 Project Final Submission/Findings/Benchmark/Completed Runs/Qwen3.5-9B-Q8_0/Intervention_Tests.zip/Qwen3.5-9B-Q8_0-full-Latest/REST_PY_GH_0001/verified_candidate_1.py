import requests
import json
from urllib.parse import quote

def solve(inputs):
    """
    Get an organization from GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - organization (str): The organization name
            - credential (str): Caller-supplied authentication token
    
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    org_name = inputs["organization"]
    credential = inputs["credential"]
    
    # GitHub REST API v3 endpoint for organizations
    url = f"https://api.github.com/orgs/{quote(org_name)}"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        return data if data else None
    elif response.status_code == 404:
        # Organization not found - treat as empty successful response per instructions
        return None
    else:
        raise Exception(f"Failed to fetch organization: {response.status_code} - {response.text}")