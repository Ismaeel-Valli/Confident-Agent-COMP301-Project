import requests

def solve(inputs):
    """Delete a product by identifier from DummyJSON."""
    resource_id = inputs["resource_id"]
    url = "https://dummyjson.com/products/{0}".format(resource_id)
    
    response = requests.delete(url)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    data = response.json()
    return data