import requests

def solve(inputs):
    """
    Update selected fields of a user on DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (int): Identifier of the user to update.
            - new_email (str): New email value for the user.
    
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com"
    resource_id = inputs["resource_id"]
    new_email = inputs["new_email"]
    
    url = f"{base_url}/users/{resource_id}"
    
    payload = {
        "email": new_email
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        data = response.json()
        return None if not data else data
    elif response.status_code == 204:
        return None
    else:
        raise Exception(f"Failed to update user. Status code: {response.status_code}, Response: {response.text}")