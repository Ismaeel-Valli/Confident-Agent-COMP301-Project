import requests

def solve(inputs):
    """Retrieve a post by identifier from DummyJSON and return its id."""
    try:
        response = requests.get(
            "https://dummyjson.com/posts/get",
            params={"id": inputs["resource_id"]}
        )
        response.raise_for_status()  # Raises exception for unsuccessful HTTP status
        
        if not response.json():
            return None
        
        data = response.json()
        if "id" in data:
            return data["id"]
        else:
            return None
            
    except requests.exceptions.RequestException:
        raise