import requests

def solve(inputs):
    """
    Update selected fields of a user on DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_lastName'.
        
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/users"
    resource_id = inputs["resource_id"]
    new_last_name = inputs["new_lastName"]
    
    url = f"{base_url}/{resource_id}"
    payload = {"lastName": new_last_name}
    
    response = requests.put(url, json=payload)
    
    if response.status_code not in [200, 201]:
        raise Exception(f"Failed to update user: {response.status_code}")
    
    data = response.json()
    
    # Check for id in different possible locations
    if "id" in data:
        return data["id"]
    elif "user" in data and isinstance(data["user"], dict) and "id" in data["user"]:
        return data["user"]["id"]
    else:
        return None