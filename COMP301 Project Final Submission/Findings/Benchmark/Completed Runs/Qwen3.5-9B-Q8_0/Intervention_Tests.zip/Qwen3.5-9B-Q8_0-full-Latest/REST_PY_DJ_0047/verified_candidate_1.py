import requests

def solve(inputs):
    """Delete a product by identifier from DummyJSON and return the title."""
    base_url = "https://dummyjson.com/products"
    
    try:
        response = requests.delete(f"{base_url}/{inputs['resource_id']}")
        
        if response.status_code >= 400:
            raise Exception(f"Failed to delete product: {response.status_code} - {response.text}")
        
        # Return title if present, otherwise None for successful empty response
        data = response.json()
        return data.get('title')
    except requests.RequestException as e:
        raise Exception(f"Request failed: {e}")