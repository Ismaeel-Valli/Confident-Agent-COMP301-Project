import requests

def solve(inputs):
    """
    Update selected fields of a user on DummyJSON.
    
    Args:
        inputs (dict): Must contain 'resource_id' and 'new_firstName'.
        
    Returns:
        dict or None: Decoded JSON response, or None if response is empty.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_first_name = inputs['new_firstName']
    
    # DummyJSON update endpoint for users
    url = f"https://dummyjson.com/users/{resource_id}"
    
    payload = {
        "firstName": new_first_name
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # DummyJSON returns an empty dict {} on successful update
    return data if data else None