import requests

def solve(inputs):
    """Delete a post by identifier from DummyJSON and return the response's id or None."""
    base_url = "https://dummyjson.com/posts"
    
    try:
        response = requests.delete(f"{base_url}/{inputs['resource_id']}")
        
        if response.status_code not in (200, 204):
            raise Exception(f"Failed to delete post: {response.status_code}")
        
        # For successful deletion, return None as per spec for empty response
        # or the id if present in response
        data = response.json() if response.content else None
        
        if data is None:
            return None
            
        if 'id' in data:
            return data['id']
        
        return None
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")