import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON.
    
    Args:
        inputs (dict): Must contain 'page' key with an integer value.
        
    Returns:
        dict or None: Decoded JSON response, or None if the response is empty but successful.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    base_url = "https://dummyjson.com/posts"
    page = inputs.get('page')
    
    if page is None:
        raise ValueError("Missing required parameter 'page' in inputs.")
    
    url = f"{base_url}?page={page}"
    
    response = requests.get(url)
    
    if response.status_code >= 400:
        raise Exception(f"HTTP error {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response (e.g., no posts found, but status is 200)
    if not data.get('posts') or len(data['posts']) == 0:
        return None
    
    return data