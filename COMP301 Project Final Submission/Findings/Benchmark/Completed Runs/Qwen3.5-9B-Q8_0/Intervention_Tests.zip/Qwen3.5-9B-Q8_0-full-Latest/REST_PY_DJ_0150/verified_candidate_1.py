import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_brand = inputs["new_brand"]
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"brand": new_brand}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 201:
        return response.json()
    else:
        raise Exception(f"Failed to update product: {response.status_code} - {response.text}")