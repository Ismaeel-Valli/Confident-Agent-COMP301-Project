import requests

def solve(inputs):
    """
    Update selected fields of a user on DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (int): Identifier of the user to update.
            - new_age (int): New value for the age attribute.
    
    Returns:
        dict or None: Decoded JSON response. Returns None if successful with empty response.
    
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/users"
    resource_id = inputs["resource_id"]
    new_age = inputs["new_age"]
    
    url = f"{base_url}/{resource_id}"
    
    payload = {
        "age": new_age
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    return response.json()