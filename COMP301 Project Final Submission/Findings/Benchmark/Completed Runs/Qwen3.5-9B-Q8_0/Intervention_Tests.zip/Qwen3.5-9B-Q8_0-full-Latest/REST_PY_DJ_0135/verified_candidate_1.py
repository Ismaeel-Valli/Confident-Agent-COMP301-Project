import requests

def solve(inputs):
    """
    Update selected fields of a user on DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_username'.
        
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_username = inputs['new_username']
    
    url = f"https://dummyjson.com/users/{resource_id}"
    
    payload = {
        "username": new_username
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 201:
        return response.json()
    else:
        raise Exception(f"HTTP {response.status_code}: {response.text}")