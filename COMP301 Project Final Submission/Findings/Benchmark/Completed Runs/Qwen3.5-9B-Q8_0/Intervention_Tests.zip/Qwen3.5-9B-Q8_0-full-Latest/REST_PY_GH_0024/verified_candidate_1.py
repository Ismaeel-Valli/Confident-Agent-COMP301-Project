import requests

def solve(inputs):
    """
    Create an issue comment on a GitHub repository using the REST API v2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - issue_number (int): The number that identifies the issue.
            - new_body (str): Value for the body attribute of the comment.
            - credential (str): Caller-supplied authentication token.
    
    Returns:
        dict or None: Decoded JSON response. Returns None for a successful empty response.
    
    Raises:
        Exception: For an unsuccessful HTTP response.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    body = inputs["new_body"]
    credential = inputs["credential"]
    
    url = "https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}/comments".format(
        owner=owner,
        repo=repo,
        issue_number=issue_number
    )
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    payload = {
        "body": body
    }
    
    response = requests.post(url, json=payload, headers=headers)
    response.raise_for_status()
    
    if response.status_code == 201:
        return None
    
    return response.json()