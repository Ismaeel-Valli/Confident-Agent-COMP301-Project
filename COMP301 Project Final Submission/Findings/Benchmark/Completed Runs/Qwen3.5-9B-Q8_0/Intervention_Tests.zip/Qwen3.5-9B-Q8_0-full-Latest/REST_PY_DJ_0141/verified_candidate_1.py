import requests

def solve(inputs):
    """
    Update selected fields of a product in DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (int): Identifier of the product
            - new_category (str): Value for the category attribute
    
    Returns:
        str or None: The response's title value, or None if absent or successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    resource_id = inputs["resource_id"]
    new_category = inputs["new_category"]
    
    url = f"{base_url}/{resource_id}"
    
    payload = {
        "category": new_category
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code not in [200, 201]:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Check for title in the response
    if "title" in data and data["title"] is not None:
        return data["title"]
    elif data.get("statusCode") == 204 or (data.get("status") == 204):
        return None
    
    return None