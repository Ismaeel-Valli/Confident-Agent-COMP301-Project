import requests

def solve(inputs):
    """
    Search products on DummyJSON using the provided search term.
    
    Args:
        inputs (dict): Must contain 'search_text' key with the search term.
        
    Returns:
        list or None: Decoded JSON response as a list, or None if empty.
        
    Raises:
        requests.RequestException: If HTTP request fails.
    """
    base_url = "https://dummyjson.com/products/search"
    search_text = inputs["search_text"]
    
    params = {
        "q": search_text
    }
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()
    
    data = response.json()
    
    if data["products"]:
        return data["products"]
    else:
        return None