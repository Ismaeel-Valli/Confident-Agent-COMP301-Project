import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON and return the response's id value,
    or None if that attribute is absent. Return None for a successful empty response.
    Raise an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_lastName'.
        
    Returns:
        int or None: The id of the created user, or None if absent or on empty response.
        
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/users/add"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "lastName": inputs["new_lastName"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 201:
            data = response.json()
            # DummyJSON returns the created user directly in the response body for POST /users/add
            if "id" in data and data["id"] is not None:
                return data["id"]
            elif data == {}:
                return None
            else:
                # If id is missing but response is not empty, return None as per spec
                return None
        else:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
            
    except requests.RequestException as e:
        raise