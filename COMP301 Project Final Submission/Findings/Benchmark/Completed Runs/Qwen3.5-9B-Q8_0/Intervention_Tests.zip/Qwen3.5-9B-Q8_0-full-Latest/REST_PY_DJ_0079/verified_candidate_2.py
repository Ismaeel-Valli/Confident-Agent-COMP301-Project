import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON, sorted by sort_field.
    
    Args:
        inputs (dict): Must contain 'sort_field' key.
        
    Returns:
        dict or None: Decoded JSON response. None for empty successful response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/posts"
    sort_field = inputs.get("sort_field")
    
    if not sort_field:
        raise ValueError("Missing required 'sort_field' in inputs")
    
    params = {"sortBy": sort_field}
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()
    
    return response.json()