import requests

def solve(inputs):
    """
    Retrieve one page of products from DummyJSON with a limit on results.
    
    Args:
        inputs (dict): Must contain 'result_limit' (int).
        
    Returns:
        list or None: Decoded JSON response as a list, or None if the list is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    limit = inputs.get('result_limit')
    
    # DummyJSON products endpoint with pagination and limit
    url = "https://dummyjson.com/products"
    params = {
        'limit': limit,
        'skip': 0  # Retrieve one page (first page)
    }
    
    response = requests.get(url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    products = data.get('products', [])
    
    # Return None for a successful empty response
    return None if len(products) == 0 else products