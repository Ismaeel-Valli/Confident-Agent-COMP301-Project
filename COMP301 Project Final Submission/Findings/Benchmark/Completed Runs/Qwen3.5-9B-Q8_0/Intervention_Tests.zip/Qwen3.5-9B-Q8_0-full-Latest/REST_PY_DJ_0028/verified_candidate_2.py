import requests

def solve(inputs):
    """
    Submit a new product to DummyJSON and return the response's id value,
    or None if that attribute is absent. Return None for a successful empty response.
    Raise an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Dictionary containing 'new_title' key with the title value.
        
    Returns:
        int or None: The id from the response, or None if absent or response is empty.
        
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/products/add"
    
    # Prepare the payload with the new title
    payload = {
        "title": inputs["new_title"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Check if the response is empty
        if not response.text.strip():
            return None
        
        # Parse the JSON response
        data = response.json()
        
        # Return the id if present, otherwise None
        return data.get("id")
        
    except requests.RequestException as e:
        raise