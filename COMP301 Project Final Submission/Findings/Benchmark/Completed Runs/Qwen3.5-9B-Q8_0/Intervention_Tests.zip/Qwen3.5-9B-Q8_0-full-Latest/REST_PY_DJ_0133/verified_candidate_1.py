import requests

def solve(inputs):
    """
    Submit a new product to DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_category (str): Value for the category attribute
            - new_title (str): Value for the title attribute
    
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/add"
    
    payload = {
        "category": inputs["new_category"],
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Check for id in the response
    if "id" in data and data["id"] is not None:
        return data["id"]
    elif data == {}:
        return None
    else:
        return None