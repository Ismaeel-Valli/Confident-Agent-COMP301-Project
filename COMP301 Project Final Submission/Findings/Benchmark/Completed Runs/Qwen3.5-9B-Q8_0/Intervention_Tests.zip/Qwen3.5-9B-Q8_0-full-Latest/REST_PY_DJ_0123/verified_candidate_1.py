import requests

def solve(inputs):
    """
    Update selected fields of a product on DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (int): Identifier of the product to update.
            - new_category (str): New value for the category attribute.
    
    Returns:
        dict or None: Decoded JSON response, or None if successful and empty.
    
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/products"
    resource_id = inputs["resource_id"]
    new_category = inputs["new_category"]
    
    url = f"{base_url}/{resource_id}"
    payload = {"category": new_category}
    
    response = requests.put(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    return response.json() if response.content else None