import requests

def solve(inputs):
    """
    Submit a new post to DummyJSON using the provided inputs.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_body (str): Value for the body attribute
            - new_title (str): Value for the title attribute
            - new_user_identifier (str): Value for the user Id attribute
    
    Returns:
        str or None: The response's title value, or None if absent or successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/posts/add"
    
    payload = {
        "title": inputs["new_title"],
        "body": inputs["new_body"],
        "userId": inputs["new_user_identifier"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create post. Status code: {response.status_code}")
    
    data = response.json()
    
    # Check if the response has a 'title' attribute in the top-level or nested structure
    if "title" in data:
        return data["title"]
    elif "post" in data and "title" in data["post"]:
        return data["post"]["title"]
    else:
        return None