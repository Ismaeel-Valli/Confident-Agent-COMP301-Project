import requests

def solve(inputs):
    """
    Submit a new product to DummyJSON.
    
    Args:
        inputs (dict): Must contain 'new_description' and 'new_title'.
        
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products/add"
    
    payload = {
        "description": inputs["new_description"],
        "title": inputs["new_title"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        if response.status_code == 201:
            # Successful creation - return decoded JSON or None for empty response
            data = response.json()
            return data if data else None
        elif response.status_code == 400:
            # Bad request - might be missing required fields
            raise Exception(f"Bad request: {response.text}")
        elif response.status_code == 500:
            # Server error
            raise Exception(f"Server error: {response.text}")
        else:
            # Any other unsuccessful status code
            raise Exception(f"HTTP {response.status_code}: {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")