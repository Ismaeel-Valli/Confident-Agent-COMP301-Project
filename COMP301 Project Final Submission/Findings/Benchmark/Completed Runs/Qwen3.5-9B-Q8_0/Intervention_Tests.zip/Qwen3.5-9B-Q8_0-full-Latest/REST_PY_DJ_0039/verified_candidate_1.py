import requests

def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON with a limit on results.
    
    Args:
        inputs (dict): Must contain 'result_limit' (int).
        
    Returns:
        list or None: Decoded JSON response, or None if empty.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/todos"
    result_limit = inputs.get("result_limit")
    
    params = {"limit": result_limit}
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()
    
    data = response.json()
    todos = data.get("todos", [])
    
    if not todos:
        return None
    
    return todos