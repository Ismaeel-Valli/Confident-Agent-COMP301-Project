import requests

def solve(inputs):
    """
    Retrieve one page of products from DummyJSON with pagination.
    
    Args:
        inputs (dict): Dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - included_fields (str): Comma-separated list of fields to include.
    
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    result_limit = inputs.get("result_limit")
    included_fields = inputs.get("included_fields", "")
    
    # Build query parameters
    params = {
        "limit": result_limit,
        "skip": 0,  # First page
        "select": included_fields if included_fields else None
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for successful empty response (products array is empty)
    if not data.get("products"):
        return None
    
    return data