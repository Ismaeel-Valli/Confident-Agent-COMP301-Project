import requests

def solve(inputs):
    """
    Fetches a GitHub issue using the provided credentials and repository details.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository.
            - issue_number (int): The issue number to fetch.
            - credential (str): The caller-supplied authentication token.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    credential = inputs["credential"]
    
    # Construct the API URL for GitHub REST API v2026-03-10
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        return None if not data else data
    elif response.status_code == 404:
        # Issue not found (though problem statement assumes resources exist)
        raise Exception(f"Issue {issue_number} not found")
    else:
        raise Exception(f"Failed to fetch issue: HTTP {response.status_code}")