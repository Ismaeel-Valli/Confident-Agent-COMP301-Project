import requests

def solve(inputs):
    """Delete a user by identifier from DummyJSON and return isDeleted or None."""
    base_url = "https://dummyjson.com/users"
    resource_id = inputs["resource_id"]
    
    url = f"{base_url}/{resource_id}"
    
    try:
        response = requests.delete(url)
        response.raise_for_status()
        
        data = response.json()
        
        if data.get("isDeleted") is not None:
            return data["isDeleted"]
        elif "message" in data or "code" in data:
            # Successful deletion often returns an empty object with a message
            return None
        else:
            # If no isDeleted and no success indicators, assume successful deletion
            return None
            
    except requests.exceptions.HTTPError as e:
        if response.status_code >= 400:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {e}")
        raise