import requests

def solve(inputs):
    """
    Update selected fields of a product on DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id (int): Identifier of the product to update.
            - new_category (str): New value for the category attribute.
    
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/products"
    resource_id = inputs["resource_id"]
    new_category = inputs["new_category"]
    
    url = f"{base_url}/{resource_id}"
    
    payload = {
        "category": new_category
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Check for id in the response
    if "id" in data and data["id"] is not None:
        return data["id"]
    elif data == {}:
        return None
    else:
        return None