import requests

def solve(inputs):
    """
    Retrieve a product by identifier from DummyJSON and return its id.
    
    Args:
        inputs (dict): Must contain 'resource_id' key with the product ID.
        
    Returns:
        int or None: The product's id, or None if absent or response is empty.
        
    Raises:
        requests.RequestException: For unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON products endpoint: https://dummyjson.com/products/<id>
    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises HTTPError for unsuccessful responses
        
        data = response.json()
        
        # Return the id if present, otherwise None
        return data.get('id')
        
    except requests.RequestException as e:
        raise