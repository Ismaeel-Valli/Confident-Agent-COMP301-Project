import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON and return the response's id value,
    or None if that attribute is absent. Return None for a successful empty response.
    Raise an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_username'.
        
    Returns:
        int or None: The id of the created user, or None if absent or empty response.
        
    Raises:
        requests.RequestException: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/users"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "username": inputs["new_username"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if the response is empty
        if not response.text.strip():
            return None
        
        # Try to get the id from the response JSON
        try:
            data = response.json()
            return data.get("id")
        except ValueError:
            # If response is not valid JSON, return None
            return None
            
    except requests.RequestException as e:
        raise e