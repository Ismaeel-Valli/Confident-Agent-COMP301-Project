import requests

def solve(inputs):
    """
    Get a branch from GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git extension)
            - branch (str): Name of the branch
            - credential (str): Caller-supplied authentication token
    
    Returns:
        dict or None: Decoded JSON response. Returns None for successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    branch = inputs["branch"]
    credential = inputs["credential"]
    
    # GitHub API v3 endpoint for getting a specific branch
    url = f"https://api.github.com/repos/{owner}/{repo}/branches/{branch}"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        return None if not data else data
    elif response.status_code == 404:
        raise Exception(f"Branch '{branch}' not found in repository '{repo}'")
    elif response.status_code == 403:
        raise Exception("Authentication failed or insufficient permissions")
    else:
        raise Exception(f"Failed to get branch. Status code: {response.status_code}")