import requests

def solve(inputs):
    """
    Retrieve one page of users from DummyJSON.
    
    Parameters:
        inputs (dict): Must contain 'page' key with an integer value.
        
    Returns:
        dict or None: The decoded JSON response, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/users"
    page = inputs.get("page")
    
    if page is None:
        raise ValueError("Missing 'page' in inputs.")
    
    url = f"{base_url}?page={page}"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error {response.status_code}: {response.text}")
    
    data = response.json()
    
    if not data:
        return None
    
    return data