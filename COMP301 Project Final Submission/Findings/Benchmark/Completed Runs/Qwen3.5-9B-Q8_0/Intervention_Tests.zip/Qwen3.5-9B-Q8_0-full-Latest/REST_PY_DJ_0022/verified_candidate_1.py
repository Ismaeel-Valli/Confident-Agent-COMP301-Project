import requests

def solve(inputs):
    """Delete a todo by identifier from DummyJSON."""
    base_url = "https://dummyjson.com/todos"
    resource_id = inputs["resource_id"]
    
    response = requests.delete(f"{base_url}/{resource_id}")
    
    if response.status_code == 204:
        return None
    elif response.status_code >= 400:
        raise Exception(f"Failed to delete todo: {response.text}")
    else:
        return response.json()