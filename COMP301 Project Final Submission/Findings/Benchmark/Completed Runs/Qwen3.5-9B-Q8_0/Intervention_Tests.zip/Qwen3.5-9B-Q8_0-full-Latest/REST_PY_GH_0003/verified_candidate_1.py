import requests
import json

def solve(inputs):
    """
    Delete a GitHub organization using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - organization (str): The name of the organization to delete.
            - credential (str): The caller-supplied authentication token.
    
    Returns:
        dict or None: Decoded JSON response if unsuccessful, None for successful deletion.
    
    Raises:
        Exception: For unsuccessful HTTP responses (non-2xx status codes).
    """
    base_url = "https://api.github.com"
    version = "2026-03-10"
    organization = inputs["organization"]
    credential = inputs["credential"]
    
    # Construct the API endpoint for deleting an organization
    url = f"{base_url}/orgs/{organization}"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": f"application/vnd.github.{version}-preview+json"
    }
    
    try:
        response = requests.delete(url, headers=headers)
        
        # Raise an exception for unsuccessful HTTP responses (non-2xx status codes)
        response.raise_for_status()
        
        # Decode the JSON response
        if response.status_code == 204:
            # Successful deletion returns an empty response
            return None
        else:
            # For other successful status codes, return the decoded JSON
            return response.json()
            
    except requests.exceptions.HTTPError as e:
        # Raise an exception for unsuccessful HTTP responses
        raise Exception(f"Failed to delete organization: {e}")