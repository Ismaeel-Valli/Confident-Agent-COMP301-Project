import requests

def solve(inputs):
    """Submit a new product to DummyJSON and return its title."""
    base_url = "https://dummyjson.com/products/add"
    
    payload = {
        "title": inputs["new_title"],
        "price": inputs["new_price"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create product. Status code: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns the created product in the response body for POST requests
    if "product" in data and data["product"]:
        return data["product"].get("title")
    elif "products" in data and len(data["products"]) > 0:
        return data["products"][0].get("title")
    else:
        return None