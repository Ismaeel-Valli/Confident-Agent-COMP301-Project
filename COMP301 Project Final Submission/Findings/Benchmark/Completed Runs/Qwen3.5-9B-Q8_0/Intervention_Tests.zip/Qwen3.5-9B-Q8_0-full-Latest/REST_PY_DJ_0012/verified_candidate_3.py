import requests

def solve(inputs):
    """Submit a new user to DummyJSON and return the decoded JSON response."""
    base_url = "https://dummyjson.com/users/add"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "lastName": "Doe",  # Required field, using placeholder
        "email": "user@example.com"  # Required field, using placeholder
    }
    
    try:
        response = requests.post(base_url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 201:
            return None  # Successful creation returns empty response
        
        return response.json()
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")