import requests

def solve(inputs):
    """
    Create a new todo on DummyJSON using the provided inputs.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_completed: value for the 'completed' attribute
            - new_todo: value for the 'todo' attribute
            - new_user_identifier: value for the 'userId' attribute
    
    Returns:
        dict or None: Decoded JSON response, or None if response is empty.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com"
    endpoint = "/todos/add"
    url = f"{base_url}{endpoint}"
    
    payload = {
        "userId": inputs["new_user_identifier"],
        "todo": inputs["new_todo"],
        "completed": inputs["new_completed"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create todo. Status code: {response.status_code}")
    
    return response.json()