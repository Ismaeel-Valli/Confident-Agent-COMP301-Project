import requests
import json

def solve(inputs):
    """
    List contributors for a GitHub repository using the REST API v2026-03-10.
    
    Args:
        inputs (dict): Must contain:
            - repository_owner (str): The account owner of the repository
            - repository_name (str): The name of the repository (without .git)
            - credential (str): Bearer token for authentication
    
    Returns:
        list or None: Decoded JSON response. Returns None if successful but empty.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/contributors"
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch contributors: HTTP {response.status_code}")
    
    data = response.json()
    
    # Return None for successful empty response
    return data if data else None