import requests

def solve(inputs):
    """
    Retrieve one page of products from DummyJSON.
    
    Args:
        inputs (dict): Must contain 'page' key with an integer value.
        
    Returns:
        dict or None: Decoded JSON response, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/products"
    
    # Validate inputs
    if 'page' not in inputs:
        raise ValueError("Missing required input: 'page'")
    
    page = inputs['page']
    if not isinstance(page, int) or page < 1:
        raise ValueError("'page' must be a positive integer")
    
    # Build the URL with query parameters
    params = {'page': page}
    
    try:
        response = requests.get(base_url, params=params)
        
        # Raise an exception for unsuccessful HTTP responses
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None if the response is empty (no products found)
        if not data.get('products'):
            return None
        
        return data
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
    except ValueError as e:
        raise Exception(f"JSON decoding error: {e}")