import requests

def solve(inputs):
    """
    Create a fork of a GitHub repository using the REST API v2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git)
            - new_name (str): New name for the forked repository
            - credential (str): Bearer token for authentication
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    new_name = inputs["new_name"]
    credential = inputs["credential"]
    
    # GitHub API v2026-03-10 endpoint for creating a fork
    url = f"https://api.github.com/repos/{owner}/{repo}/forks"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json"
    }
    
    params = {
        "name": new_name
    }
    
    response = requests.post(url, headers=headers, json=params)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Return None for successful empty response
    if not response.text:
        return None
    
    # Return the decoded JSON response
    return response.json()