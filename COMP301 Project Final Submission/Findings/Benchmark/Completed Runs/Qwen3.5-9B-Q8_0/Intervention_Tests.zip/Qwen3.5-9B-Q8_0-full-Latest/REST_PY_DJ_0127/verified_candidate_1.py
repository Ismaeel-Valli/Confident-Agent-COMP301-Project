import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON using the provided firstName and phone.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and 'new_phone'.
        
    Returns:
        int or None: The ID of the created user, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    base_url = "https://dummyjson.com/users"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "phone": inputs["new_phone"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        if response.status_code != 201:
            raise Exception(f"Failed to create user. Status code: {response.status_code}")
        
        data = response.json()
        
        # DummyJSON returns the created user in 'user' field for POST /users
        if "user" in data and data["user"] is not None:
            return data["user"]["id"]
        elif "id" in data:
            return data["id"]
        else:
            return None
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")