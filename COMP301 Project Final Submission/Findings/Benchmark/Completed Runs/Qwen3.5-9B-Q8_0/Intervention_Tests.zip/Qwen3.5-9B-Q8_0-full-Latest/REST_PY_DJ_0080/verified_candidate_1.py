import requests

def solve(inputs):
    """
    Update selected fields of a post on DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_body' (new body text).
        
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_body = inputs['new_body']
    
    base_url = "https://dummyjson.com/posts"
    url = f"{base_url}/{resource_id}"
    
    payload = {
        "body": new_body
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code >= 400:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    # Check if the response has an 'id' field
    data = response.json()
    
    if 'id' in data and data['id'] is not None:
        return data['id']
    elif response.status_code == 204:  # No Content
        return None
    else:
        return None