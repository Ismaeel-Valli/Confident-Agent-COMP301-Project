import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON with a limit on results.
    
    Args:
        inputs (dict): Must contain 'result_limit' (int).
        
    Returns:
        list or None: Decoded JSON response as a list, or None if empty.
        
    Raises:
        requests.RequestException: If HTTP request fails.
    """
    limit = inputs.get('result_limit')
    if limit is None:
        raise ValueError("Missing required input: result_limit")
    
    base_url = "https://dummyjson.com/posts"
    params = {'limit': limit}
    
    response = requests.get(base_url, params=params)
    response.raise_for_status()
    
    data = response.json()
    posts = data.get('posts', [])
    
    if not posts:
        return None
    
    return posts