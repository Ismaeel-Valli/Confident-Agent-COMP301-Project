import requests

def solve(inputs):
    """
    Submit a new post to DummyJSON using the provided inputs.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_body (str): Value for the body attribute
            - new_title (str): Value for the title attribute
            - new_user_identifier (str): Value for the user Id attribute
    
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/posts"
    
    payload = {
        "body": inputs["new_body"],
        "title": inputs["new_title"],
        "userId": inputs["new_user_identifier"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create post. Status code: {response.status_code}")
    
    data = response.json()
    
    # Check if the response contains an id field
    if "id" in data and data["id"] is not None:
        return data["id"]
    else:
        return None