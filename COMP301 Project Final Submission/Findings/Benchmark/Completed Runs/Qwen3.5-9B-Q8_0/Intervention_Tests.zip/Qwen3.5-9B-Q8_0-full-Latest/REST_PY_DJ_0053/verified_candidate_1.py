import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON, skipping a specified number of results.
    
    Args:
        inputs (dict): A dictionary containing 'results_to_skip' (int).
        
    Returns:
        dict or None: The decoded JSON response if successful, None for an empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/posts"
    
    # Validate inputs
    if 'results_to_skip' not in inputs:
        raise ValueError("Missing required key: results_to_skip")
    
    try:
        skip = int(inputs['results_to_skip'])
    except (ValueError, TypeError):
        raise ValueError("results_to_skip must be an integer")
    
    params = {
        'skip': skip,
        'limit': 10  # Retrieve one page with a reasonable limit
    }
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()
        
        data = response.json()
        
        # Check if the response is empty (no posts found)
        if not data.get('posts') or len(data['posts']) == 0:
            return None
        
        return data
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")