import requests

def solve(inputs):
    """
    Retrieve a post by identifier from DummyJSON and return its title.
    
    Args:
        inputs (dict): Must contain 'resource_id' (int) for the post ID.
        
    Returns:
        str or None: The post's title, or None if absent or response is empty.
        
    Raises:
        requests.RequestException: For unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    if resource_id is None:
        raise ValueError("Missing 'resource_id' in inputs")
    
    url = "https://dummyjson.com/posts/get"
    params = {"id": resource_id}
    
    response = requests.get(url, params=params)
    response.raise_for_status()  # Raises exception for unsuccessful HTTP responses
    
    data = response.json()
    
    # Check if the response is empty (no posts returned)
    if not data:
        return None
    
    # Return title if present, otherwise None
    return data.get('title')