import requests

def solve(inputs):
    """
    Update selected fields of a user in DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - resource_id (int): Identifier of the user to update
            - new_lastName (str): New value for the last Name attribute
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/users"
    resource_id = inputs["resource_id"]
    new_lastName = inputs["new_lastName"]
    
    url = f"{base_url}/{resource_id}"
    payload = {"lastName": new_lastName}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 201:
        return response.json()
    else:
        raise Exception(f"Failed to update user. Status code: {response.status_code}")