import requests

def solve(inputs):
    """
    Delete a GitHub repository using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git extension)
            - credential (str): Caller-supplied authentication token
    
    Returns:
        int: Successful HTTP status code (204 No Content)
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    auth_token = inputs["credential"]
    
    # Construct the API URL for deleting a repository
    url = f"https://api.github.com/repos/{owner}/{repo}"
    
    # Prepare headers with authentication
    headers = {
        "Authorization": f"token {auth_token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Send DELETE request to delete the repository
    response = requests.delete(url, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Return the successful HTTP status code
    return response.status_code