import requests

def solve(inputs):
    """
    Update selected fields of a todo on DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_completed'.
        
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_completed = inputs['new_completed']
    
    base_url = "https://dummyjson.com/todos"
    url = f"{base_url}/{resource_id}"
    
    payload = {
        "completed": new_completed
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 201:
        return response.json()
    else:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}")