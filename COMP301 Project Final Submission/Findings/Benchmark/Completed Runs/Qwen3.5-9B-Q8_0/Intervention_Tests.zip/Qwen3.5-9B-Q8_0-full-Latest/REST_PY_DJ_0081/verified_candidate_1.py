import requests

def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON with pagination.
    
    Args:
        inputs (dict): Dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip.
    
    Returns:
        list or None: Decoded JSON response as a list, or None if empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/todos"
    params = {
        "limit": inputs["result_limit"],
        "skip": inputs["results_to_skip"]
    }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns a dict with 'todos' key containing the list
    todos = data.get("todos", [])
    
    return None if not todos else todos