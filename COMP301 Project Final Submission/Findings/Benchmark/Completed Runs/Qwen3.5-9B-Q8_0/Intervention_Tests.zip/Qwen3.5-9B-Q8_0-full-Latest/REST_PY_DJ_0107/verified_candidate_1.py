import requests

def solve(inputs):
    """
    Update selected fields of a user on DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_email'.
        
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/users"
    resource_id = inputs["resource_id"]
    new_email = inputs["new_email"]
    
    url = f"{base_url}/{resource_id}"
    payload = {"email": new_email}
    
    response = requests.put(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Check for id in different possible locations
    if "id" in data:
        return data["id"]
    elif "user" in data and isinstance(data["user"], dict) and "id" in data["user"]:
        return data["user"]["id"]
    else:
        return None