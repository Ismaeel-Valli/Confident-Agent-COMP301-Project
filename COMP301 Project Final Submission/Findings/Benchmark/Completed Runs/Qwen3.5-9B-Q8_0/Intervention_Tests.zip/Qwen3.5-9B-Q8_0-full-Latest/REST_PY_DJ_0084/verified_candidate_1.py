import requests

def solve(inputs):
    """
    Update selected fields of a product on DummyJSON.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_description'.
        
    Returns:
        str or None: The title from the response, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_description = inputs['new_description']
    
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/{resource_id}"
    
    payload = {
        "description": new_description
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code not in [200, 201]:
        raise Exception(f"Failed to update product: HTTP {response.status_code}")
    
    data = response.json()
    
    # Check for title in the response
    if 'title' in data and data['title'] is not None:
        return data['title']
    elif data.get('message') == "":
        return None
    else:
        return None