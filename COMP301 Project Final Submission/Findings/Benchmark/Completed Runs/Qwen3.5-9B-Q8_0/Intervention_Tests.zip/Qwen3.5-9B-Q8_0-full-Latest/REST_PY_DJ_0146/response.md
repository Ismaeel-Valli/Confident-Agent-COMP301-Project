### Confidence Agent Report

**Decision:** deliver_with_flag
**EWCS:** 0.7308 (signed: 0.7308, applicable weight: 13)

| Layer | State | Tier | Weight | Factor | Positive | Signed |
|---|---|---|---|---|---|---|
| interface | verified_correct | tier_2 | 3 | 0.8 | 2.4 | 2.4 |
| identifier | verified_correct | tier_4 | 3 | 0.5 | 1.5 | 1.5 |
| access_point | verified_correct | tier_2 | 4 | 0.8 | 3.2 | 3.2 |
| input_contract | verified_correct | tier_2 | 2 | 0.8 | 1.6 | 1.6 |
| output_contract | verified_correct | tier_2 | 1 | 0.8 | 0.8 | 0.8 |
| contextual | not_applicable | none | 2 | 0 | 0 | 0 |

Scope: API-claim and static evidence only. EWCS is not a probability of correctness. Task behavior has not been independently checked by this verifier.

Policy 2026-09-25.1: thresholds 0.85/0.6, uncertainty gate on.

Evidence:

- interface: requests maps to requests (2.34.2). Installation/callables checked separately by Pyright.
- identifier: No identifier, attribute or API-call diagnostics in the configured environment (Pyright standard mode). A clean check does not establish REST contracts or task behavior.
- access_point: GET https://dummyjson.com/posts matches the declared server and operation GET /posts.
- input_contract: Required inputs, locations and supported value constraints checked for call_35_15 (/posts). Noncritical: query.sortBy: runtime value inputs.get('sort_field') is not statically known; its value constraints are not checked; query.order: runtime value inputs.get('sort_direction') is not statically known; its value constraints are not checked
- output_contract: Response path ["posts"] is documented for call_35_15 (/posts).
- contextual: No authentication requirement for this operation. Unused security definitions are not requirements.

Flag: some checks rely on supporting static or package metadata evidence; the code was not executed.

```python
import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON, sorted by sort_field in sort_direction.
    
    Args:
        inputs (dict): Must contain 'sort_field' and 'sort_direction'.
        
    Returns:
        dict or None: Decoded JSON response, or None if empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/posts"
    
    # Validate inputs
    if not isinstance(inputs, dict):
        raise ValueError("inputs must be a dictionary")
    
    sort_field = inputs.get('sort_field')
    sort_direction = inputs.get('sort_direction')
    
    if sort_field is None or sort_direction is None:
        raise ValueError("inputs must contain 'sort_field' and 'sort_direction'")
    
    # Build query parameters using documented parameter names
    params = {
        'sortBy': sort_field,
        'order': sort_direction
    }
    
    # Make the request
    response = requests.get(base_url, params=params)
    
    if not response.ok:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for empty posts array
    if not data.get('posts'):
        return None
    
    return data
```