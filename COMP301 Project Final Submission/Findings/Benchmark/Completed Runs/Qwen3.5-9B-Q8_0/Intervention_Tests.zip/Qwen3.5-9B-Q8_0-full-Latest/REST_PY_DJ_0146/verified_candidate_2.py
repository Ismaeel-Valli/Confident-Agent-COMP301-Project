import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON, sorted by sort_field in sort_direction.
    
    Args:
        inputs (dict): Must contain 'sort_field' and 'sort_direction'.
        
    Returns:
        dict or None: Decoded JSON response, or None if empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/posts"
    
    # Validate inputs
    if not isinstance(inputs, dict):
        raise ValueError("inputs must be a dictionary")
    
    sort_field = inputs.get('sort_field')
    sort_direction = inputs.get('sort_direction')
    
    if sort_field is None or sort_direction is None:
        raise ValueError("inputs must contain 'sort_field' and 'sort_direction'")
    
    # Build query parameters using documented parameter names
    params = {
        'sortBy': sort_field,
        'order': sort_direction
    }
    
    # Make the request
    response = requests.get(base_url, params=params)
    
    if not response.ok:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for empty posts array
    if not data.get('posts'):
        return None
    
    return data