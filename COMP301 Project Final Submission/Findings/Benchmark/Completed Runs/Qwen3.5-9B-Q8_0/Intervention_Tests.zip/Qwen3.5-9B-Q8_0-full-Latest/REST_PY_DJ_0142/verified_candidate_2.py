import requests

def solve(inputs):
    """
    Submit a new product to DummyJSON and return the title from the response,
    or None if absent. Raise an exception for unsuccessful HTTP responses.
    
    Args:
        inputs (dict): Must contain 'new_category' and 'new_title'.
        
    Returns:
        str or None: The title from the response, or None if absent.
        
    Raises:
        requests.RequestException: If the HTTP request fails.
    """
    base_url = "https://dummyjson.com/products/add"
    
    payload = {
        "category": inputs["new_category"],
        "title": inputs["new_title"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code != 201:
        raise requests.RequestException(f"Failed to create product: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns the created product in 'product' key for POST
    if "product" in data and data["product"]:
        return data["product"].get("title")
    else:
        return None