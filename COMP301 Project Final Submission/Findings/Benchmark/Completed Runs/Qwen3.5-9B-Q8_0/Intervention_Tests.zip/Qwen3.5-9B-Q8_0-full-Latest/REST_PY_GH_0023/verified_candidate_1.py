import requests

def solve(inputs):
    """
    List issue comments for a GitHub repository using the REST API v2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git)
            - issue_number (int): Issue number to get comments for
            - credential (str): Bearer token for authentication
    
    Returns:
        list or None: Decoded JSON response. Returns None if successful but empty.
    
    Raises:
        Exception: For unsuccessful HTTP responses (non-2xx).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    issue_num = inputs["issue_number"]
    token = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_num}/comments"
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"Failed to fetch issue comments: HTTP {response.status_code}")
    
    data = response.json()
    
    # Return None for successful empty response
    if not data:
        return None
    
    return data