import requests

def solve(inputs):
    """Delete a post by identifier from DummyJSON."""
    resource_id = inputs["resource_id"]
    url = "https://dummyjson.com/posts/{0}".format(resource_id)
    
    response = requests.delete(url)
    
    if response.status_code == 204:
        return None
    else:
        raise Exception(f"Failed to delete post. Status code: {response.status_code}")