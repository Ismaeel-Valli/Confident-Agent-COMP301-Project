import requests

def solve(inputs):
    """Delete a todo by identifier from DummyJSON and return the response's id or None."""
    resource_id = inputs.get("resource_id")
    
    if resource_id is None:
        return None
    
    url = "https://dummyjson.com/todos"
    headers = {
        "Content-Type": "application/json"
    }
    data = {"todoId": resource_id}
    
    try:
        response = requests.delete(url, json=data, headers=headers)
        response.raise_for_status()
        
        if response.status_code == 200:
            # Successful deletion with empty body
            return None
        
        result = response.json()
        
        # Check for id in the response
        if "id" in result:
            return result["id"]
        else:
            return None
            
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")