import requests

def solve(inputs):
    """
    Get a commit from GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git)
            - ref (str): Commit reference
            - credential (str): Caller-supplied authentication token
    
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    # Build the API URL for GitHub REST API v2026-03-10
    base_url = "https://api.github.com"
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    ref = inputs["ref"]
    credential = inputs["credential"]
    
    # Construct the commit URL
    url = f"{base_url}/repos/{owner}/{repo}/commits/{ref}"
    
    # Prepare headers with authentication
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github.v2026-03-10+json"
    }
    
    # Make the GET request
    response = requests.get(url, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses
    if not response.ok:
        raise Exception(f"GitHub API request failed with status {response.status_code}: {response.text}")
    
    # Decode the JSON response
    data = response.json()
    
    # Return None for successful empty response, otherwise return the data
    if data is None or len(data) == 0:
        return None
    
    return data