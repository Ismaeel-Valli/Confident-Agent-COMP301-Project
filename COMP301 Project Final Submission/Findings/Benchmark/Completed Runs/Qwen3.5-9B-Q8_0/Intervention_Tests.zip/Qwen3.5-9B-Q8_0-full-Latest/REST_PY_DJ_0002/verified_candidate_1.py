import requests

def solve(inputs):
    """
    Retrieve a product by identifier from DummyJSON.
    
    Args:
        inputs (dict): Must contain 'resource_id' (int) for the product ID.
        
    Returns:
        dict or None: Decoded JSON response, or None if response is empty.
        
    Raises:
        requests.RequestException: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises HTTPError for bad status codes
        
        data = response.json()
        
        # DummyJSON returns an empty dict {} for non-existent products (200 OK)
        # The task says "Return None for a successful empty response"
        if not data:
            return None
            
        return data
        
    except requests.RequestException as e:
        raise