import requests

def solve(inputs):
    """Submit a new product to DummyJSON and return the title from the response."""
    base_url = "https://dummyjson.com/products"
    
    payload = {
        "title": inputs["new_title"],
        "description": inputs["new_description"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 201:
            data = response.json()
            # DummyJSON returns the created product in the response body for POST
            title = data.get("title")
            return title if title is not None else None
        elif response.status_code == 200:
            # Some endpoints might return 200 with empty body or different structure
            data = response.json()
            title = data.get("title")
            return title if title is not None else None
        else:
            raise Exception(f"Failed to submit product. Status code: {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")