import requests
import json

def solve(inputs):
    """
    Create an organization repository on GitHub REST API v2026-03-10.
    
    Args:
        inputs (dict): Contains 'organization', 'new_name', and 'credential'.
        
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    org = inputs["organization"]
    repo_name = inputs["new_name"]
    credential = inputs["credential"]
    
    # GitHub API endpoint to create a repository in an organization
    url = f"https://api.github.com/orgs/{org}/repos"
    
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    data = {
        "name": repo_name
    }
    
    response = requests.post(url, json=data, headers=headers)
    
    if response.status_code == 201:
        # Successful creation, return None as per requirement for successful empty response
        return None
    elif response.status_code == 422:
        # Validation error or other client error - decode and raise exception
        try:
            error_response = response.json()
            raise Exception(f"Failed to create repository: {error_response}")
        except json.JSONDecodeError:
            raise Exception(f"Failed to create repository: {response.text}")
    elif response.status_code == 403:
        # Forbidden - likely insufficient permissions
        try:
            error_response = response.json()
            raise Exception(f"Permission denied: {error_response}")
        except json.JSONDecodeError:
            raise Exception(f"Permission denied: {response.text}")
    elif response.status_code == 404:
        # Not found - organization doesn't exist
        try:
            error_response = response.json()
            raise Exception(f"Organization not found: {error_response}")
        except json.JSONDecodeError:
            raise Exception(f"Organization not found: {response.text}")
    else:
        # Other errors
        try:
            error_response = response.json()
            raise Exception(f"HTTP {response.status_code}: {error_response}")
        except json.JSONDecodeError:
            raise Exception(f"HTTP {response.status_code}: {response.text}")
