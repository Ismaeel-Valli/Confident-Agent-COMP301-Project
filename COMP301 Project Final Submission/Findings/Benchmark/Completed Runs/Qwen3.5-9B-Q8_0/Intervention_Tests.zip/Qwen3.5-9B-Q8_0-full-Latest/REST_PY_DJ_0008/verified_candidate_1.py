import requests

def solve(inputs):
    """
    Retrieve a user by identifier from DummyJSON.
    
    Args:
        inputs (dict): Must contain 'resource_id' (int) for the user ID.
        
    Returns:
        dict or None: Decoded JSON response, or None if empty.
        
    Raises:
        requests.RequestException: For unsuccessful HTTP responses.
    """
    resource_id = inputs["resource_id"]
    
    url = f"https://dummyjson.com/users/{resource_id}"
    response = requests.get(url)
    
    if response.status_code != 200:
        raise requests.RequestException(f"Failed to retrieve user {resource_id}: HTTP {response.status_code}")
    
    data = response.json()
    
    return data if data else None