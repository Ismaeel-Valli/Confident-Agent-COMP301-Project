import requests

def solve(inputs):
    """
    Submit a new todo to DummyJSON using the provided inputs.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_completed: value for the completed attribute
            - new_todo: value for the todo attribute
            - new_user_identifier: value for the user Id attribute
    
    Returns:
        int or None: The response's id value, or None if absent. Returns None for empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com"
    endpoint = "/todos"
    
    # Build the payload
    payload = {
        "todo": inputs["new_todo"],
        "completed": inputs["new_completed"],
        "userId": inputs["new_user_identifier"]
    }
    
    try:
        response = requests.post(f"{base_url}{endpoint}", json=payload)
        
        # Raise exception for unsuccessful HTTP responses
        response.raise_for_status()
        
        # Check if the response is empty (no content)
        if not response.content:
            return None
        
        data = response.json()
        
        # Return the id from the response, or None if absent
        return data.get("id")
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")