import requests

def solve(inputs):
    """Delete a product by identifier from DummyJSON and return its id or None."""
    resource_id = inputs["resource_id"]
    
    # Delete the product
    response = requests.delete(f"https://dummyjson.com/products/{resource_id}")
    
    # Raise exception for unsuccessful HTTP response
    if not response.ok:
        raise Exception(f"Failed to delete product: {response.status_code} - {response.text}")
    
    # Return id from response, or None if absent
    data = response.json()
    return data.get("id")