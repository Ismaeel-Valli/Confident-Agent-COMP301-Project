import requests

def solve(inputs):
    """
    Update selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id (int): Identifier of the todo to update.
            - new_todo (str): New value for the 'todo' attribute.
            - new_user_identifier (str): New value for the 'userId' attribute.
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/todos"
    resource_id = inputs["resource_id"]
    new_todo = inputs["new_todo"]
    new_user_identifier = inputs["new_user_identifier"]
    
    payload = {
        "todo": new_todo,
        "userId": new_user_identifier
    }
    
    response = requests.put(f"{base_url}/{resource_id}", json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"HTTP error {response.status_code}: {response.text}")
    
    return response.json() if response.content else None