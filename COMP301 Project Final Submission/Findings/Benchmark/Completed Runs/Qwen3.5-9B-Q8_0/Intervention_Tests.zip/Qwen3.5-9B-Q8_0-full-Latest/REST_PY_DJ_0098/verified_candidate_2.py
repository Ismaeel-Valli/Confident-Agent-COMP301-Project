import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_email (str): Email address for the new user
            - new_firstName (str): First name for the new user
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response.
    
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/users/add"
    
    payload = {
        "email": inputs["new_email"],
        "firstName": inputs["new_firstName"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        
        if response.status_code == 201:
            return None
        elif response.status_code >= 400:
            raise Exception(f"Failed to create user. Status code: {response.status_code}, Response: {response.text}")
        else:
            return response.json()
            
    except requests.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")