import requests

def solve(inputs):
    """
    Update a todo item on DummyJSON using PATCH.
    
    Inputs:
        - resource_id: ID of the todo to update
        - new_todo: value for the 'todo' attribute
        - new_user_identifier: value for the 'userId' attribute
    
    Returns:
        - The response's 'id' field if present, otherwise None
        - None for a successful empty response (204)
        - Raises an exception for unsuccessful HTTP responses
    """
    base_url = "https://dummyjson.com/todos"
    
    # Build the payload with the fields to update
    payload = {
        "todo": inputs["new_todo"],
        "userId": inputs["new_user_identifier"]
    }
    
    try:
        response = requests.patch(
            f"{base_url}/{inputs['resource_id']}",
            json=payload,
            timeout=10
        )
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Check if the response is empty (204 No Content)
        if response.status_code == 204:
            return None
        
        # Return the 'id' field from the response if present
        data = response.json()
        return data.get("id")
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")