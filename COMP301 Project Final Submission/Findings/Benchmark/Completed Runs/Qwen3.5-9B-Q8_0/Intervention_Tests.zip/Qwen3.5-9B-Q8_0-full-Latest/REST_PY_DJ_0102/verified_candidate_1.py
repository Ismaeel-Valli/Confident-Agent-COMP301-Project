import requests

def solve(inputs):
    """
    Update selected fields of a todo on DummyJSON.
    
    Inputs:
        - resource_id (int): Identifier of the todo.
        - new_completed (bool): Value for the completed attribute.
        - new_todo (str): Value for the todo attribute.
    
    Returns:
        - The decoded JSON response, or None if successful and empty.
        - Raises an exception for unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/todos"
    resource_id = inputs["resource_id"]
    new_completed = inputs["new_completed"]
    new_todo = inputs["new_todo"]

    payload = {
        "completed": new_completed,
        "todo": new_todo
    }

    try:
        response = requests.put(
            f"{base_url}/{resource_id}",
            json=payload
        )
        
        if response.status_code == 200:
            data = response.json()
            return None if not data else data
        elif response.status_code == 404:
            raise Exception(f"Resource not found: {resource_id}")
        else:
            raise Exception(f"Failed to update todo. Status code: {response.status_code}, Response: {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")