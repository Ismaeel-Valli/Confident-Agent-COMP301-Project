import requests

def solve(inputs):
    """Delete a user by identifier from DummyJSON and return the response's id or None."""
    resource_id = inputs["resource_id"]
    
    url = "https://dummyjson.com/users/{user_id}".format(user_id=resource_id)
    response = requests.delete(url)
    
    if response.status_code >= 400:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    if "id" in data and data["id"] is not None:
        return data["id"]
    elif response.status_code == 200 or response.status_code == 204:
        return None
    else:
        return None