import requests

def solve(inputs):
    """
    Submit a new product to DummyJSON and return the response's id value,
    or None if that attribute is absent. Return None for a successful empty response.
    Raise an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_description (str): Value for the description attribute
            - new_title (str): Value for the title attribute
    
    Returns:
        int or None: The id from the response, or None if absent or empty response
    
    Raises:
        requests.RequestException: For unsuccessful HTTP responses
    """
    base_url = "https://dummyjson.com/products"
    
    payload = {
        "description": inputs["new_description"],
        "title": inputs["new_title"]
    }
    
    try:
        response = requests.post(base_url, json=payload)
        response.raise_for_status()
        
        if response.status_code == 201:
            data = response.json()
            # Check if the response has an id field
            if "id" in data and data["id"] is not None:
                return data["id"]
            else:
                # Empty response or no id field
                return None
        else:
            raise requests.RequestException(f"Failed to create product. Status code: {response.status_code}")
            
    except requests.RequestException as e:
        raise