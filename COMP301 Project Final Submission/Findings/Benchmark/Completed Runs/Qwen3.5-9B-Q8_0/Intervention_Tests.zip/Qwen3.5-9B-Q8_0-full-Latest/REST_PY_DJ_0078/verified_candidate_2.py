import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - new_age (int): Age value for the user
            - new_firstName (str): First name value for the user
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com/users/add"
    
    payload = {
        "age": inputs["new_age"],
        "firstName": inputs["new_firstName"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code == 201:
        return None
    elif response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Failed to create user. Status code: {response.status_code}")