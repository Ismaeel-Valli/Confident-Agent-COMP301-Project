import requests

def solve(inputs):
    """
    Fetch a GitHub issue comment using the provided credentials.
    
    Args:
        inputs (dict): Contains repository_owner, repository_name, comment_id, and credential.
        
    Returns:
        dict or None: The decoded JSON response, or None if successful but empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    comment_id = inputs["comment_id"]
    token = inputs["credential"]
    
    # GitHub API v3 endpoint for getting a single issue comment
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/comments/{comment_id}"
    
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        return data if data else None
    elif response.status_code == 404:
        raise Exception(f"Comment not found (404)")
    elif response.status_code == 403:
        raise Exception("Forbidden - check your credentials or permissions")
    elif response.status_code >= 400:
        raise Exception(f"Failed to fetch comment. Status code: {response.status_code}")
    
    # For any other successful status (e.g., 201, 202), return the JSON
    if response.status_code < 400:
        data = response.json()
        return data if data else None
    
    raise Exception(f"Unexpected HTTP status code: {response.status_code}")