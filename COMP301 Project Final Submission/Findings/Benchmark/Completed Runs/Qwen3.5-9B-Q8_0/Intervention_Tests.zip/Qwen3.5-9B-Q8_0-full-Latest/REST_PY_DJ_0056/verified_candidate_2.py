import requests

def solve(inputs):
    """Delete a post by identifier from DummyJSON and return the title or None."""
    resource_id = inputs["resource_id"]
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    response = requests.delete(url)
    
    if response.status_code != 200:
        raise Exception(f"Failed to delete post: {response.status_code}")
    
    data = response.json()
    
    # According to DummyJSON API, successful deletion returns {"success": true}
    # The title is not in the response for a deleted post
    return None