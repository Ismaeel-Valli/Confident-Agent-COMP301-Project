import requests

def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON and return the decoded JSON response.
    
    Parameters:
        inputs (dict): A dictionary containing 'page' key with an integer value.
        
    Returns:
        list or None: The decoded JSON response as a list, or None if the response is empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    page = inputs.get('page', 1)
    base_url = "https://dummyjson.com"
    endpoint = "/todos"
    
    url = f"{base_url}{endpoint}"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise requests.exceptions.RequestException(f"Failed to retrieve todos. Status code: {response.status_code}")
    
    data = response.json()
    
    if not data.get('todos'):
        return None
    
    return data['todos']