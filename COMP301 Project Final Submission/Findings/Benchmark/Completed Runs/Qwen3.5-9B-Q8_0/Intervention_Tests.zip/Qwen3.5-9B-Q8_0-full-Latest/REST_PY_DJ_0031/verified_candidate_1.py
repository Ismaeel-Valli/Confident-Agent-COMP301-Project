import requests

def solve(inputs):
    """
    Update selected fields of a user on DummyJSON.
    
    Args:
        inputs (dict): Must contain 'resource_id' and 'new_firstName'.
        
    Returns:
        int or None: The response's id value, or None if absent or successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_first_name = inputs['new_firstName']
    
    base_url = "https://dummyjson.com/users"
    url = f"{base_url}/{resource_id}"
    
    payload = {
        "firstName": new_first_name
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code not in [200, 201]:
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Check for id in the response
    if 'id' in data and data['id'] is not None:
        return data['id']
    
    # Return None for successful empty response or missing id
    return None