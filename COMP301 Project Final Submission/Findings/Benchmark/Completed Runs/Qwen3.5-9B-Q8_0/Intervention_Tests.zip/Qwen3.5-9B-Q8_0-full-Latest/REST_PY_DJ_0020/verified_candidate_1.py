import requests

def solve(inputs):
    """
    Retrieve a todo by identifier from DummyJSON.
    
    Args:
        inputs (dict): Must contain 'resource_id' (int).
        
    Returns:
        dict or None: Decoded JSON response, or None if empty.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs["resource_id"]
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    response = requests.get(url)
    response.raise_for_status()
    
    if response.status_code == 200 and not response.content:
        return None
    
    return response.json()