import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_description = inputs["new_description"]
    
    url = "https://dummyjson.com/products/{id}".format(id=resource_id)
    headers = {"Content-Type": "application/json"}
    payload = {"description": new_description}
    
    response = requests.patch(url, json=payload, headers=headers)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    return response.json()