import requests

def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON with pagination and field filtering.
    
    Args:
        inputs (dict): Must contain:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip (for pagination).
            - included_fields (str): Comma-separated list of fields to include.
    
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
    
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com"
    endpoint = "/todos"
    
    # Parse included_fields
    fields_list = [f.strip() for f in inputs["included_fields"].split(",")]
    
    # Build query parameters
    params = {
        "limit": inputs["result_limit"],
        "skip": inputs["results_to_skip"],
        "_fields": ",".join(fields_list)
    }
    
    url = base_url + endpoint
    
    try:
        response = requests.get(url, params=params)
        
        if response.status_code != 200:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
        
        data = response.json()
        
        # DummyJSON returns {"todos": [...], ...}
        return data if data else None
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")