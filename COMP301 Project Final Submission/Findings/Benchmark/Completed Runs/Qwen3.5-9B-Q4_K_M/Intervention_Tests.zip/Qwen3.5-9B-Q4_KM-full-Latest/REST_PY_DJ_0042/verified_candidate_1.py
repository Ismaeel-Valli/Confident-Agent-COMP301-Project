def solve(inputs):
    resource_id = inputs.get("resource_id")
    url = "https://dummyjson.com/todos"
    response = requests.delete(url, json={"todoId": resource_id})
    if response.status_code == 204:
        return None
    elif response.status_code == 404:
        return None
    else:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")