import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_title = inputs["new_title"]
    
    url = "https://dummyjson.com/posts/" + str(resource_id)
    payload = {"title": new_title}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    data = response.json()
    
    if "title" in data:
        return data["title"]
    elif response.status_code == 204:
        return None
    else:
        raise Exception(f"Failed to update post {resource_id}: {response.text}")