def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_todo = inputs["new_todo"]
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    payload = {"todo": new_todo}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    return response.json()