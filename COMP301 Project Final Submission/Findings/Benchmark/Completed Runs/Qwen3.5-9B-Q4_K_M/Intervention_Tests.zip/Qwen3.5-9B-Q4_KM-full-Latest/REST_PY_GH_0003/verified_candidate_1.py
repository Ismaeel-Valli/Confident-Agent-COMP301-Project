import requests
import json

def solve(inputs):
    """
    Delete a GitHub organization using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): Must contain:
            - "organization": str, the organization name to delete
            - "credential": str, caller-supplied credential for authentication
    
    Returns:
        None if successful (empty response), otherwise returns decoded JSON response.
    
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    org_name = inputs["organization"]
    credential = inputs["credential"]
    
    # GitHub API v2026-03-10 delete organization endpoint
    url = f"https://api.github.com/orgs/{org_name}"
    
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.delete(url, headers=headers)
    
    # Raise exception for unsuccessful HTTP responses
    if response.status_code not in [204, 200]:
        response.raise_for_status()
    
    # Return None for successful empty response (204 No Content)
    if response.status_code == 204:
        return None
    
    # For other successful responses, return decoded JSON
    return response.json()