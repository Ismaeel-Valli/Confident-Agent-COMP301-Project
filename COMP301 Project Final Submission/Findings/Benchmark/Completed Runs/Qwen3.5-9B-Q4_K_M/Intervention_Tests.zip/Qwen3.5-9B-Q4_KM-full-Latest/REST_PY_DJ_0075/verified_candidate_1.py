import requests

def solve(inputs):
    """
    Submit a new product to DummyJSON and return its ID, or None if absent.
    
    Args:
        inputs (dict): Contains 'new_description' and 'new_title'.
        
    Returns:
        int or None: The product's ID if present, otherwise None.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/add"
    
    payload = {
        "description": inputs["new_description"],
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    return data.get("id")