import requests

def solve(inputs):
    base_url = "https://dummyjson.com/users"
    params = {
        "limit": inputs["result_limit"]
    }
    response = requests.get(base_url, params=params)
    response.raise_for_status()
    return response.json()