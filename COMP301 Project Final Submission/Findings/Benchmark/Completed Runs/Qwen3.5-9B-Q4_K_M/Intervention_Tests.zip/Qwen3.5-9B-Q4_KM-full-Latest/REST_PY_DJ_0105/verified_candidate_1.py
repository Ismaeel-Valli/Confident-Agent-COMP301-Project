def solve(inputs):
    import requests
    
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/add"
    
    payload = {
        "title": inputs["new_title"],
        "price": inputs["new_price"]
    }
    
    response = requests.post(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 201:
        data = response.json()
        return data.get("id")
    elif response.status_code == 200:
        # Empty response for successful creation in some cases
        return None
    else:
        raise Exception(f"Failed to create product. Status code: {response.status_code}")