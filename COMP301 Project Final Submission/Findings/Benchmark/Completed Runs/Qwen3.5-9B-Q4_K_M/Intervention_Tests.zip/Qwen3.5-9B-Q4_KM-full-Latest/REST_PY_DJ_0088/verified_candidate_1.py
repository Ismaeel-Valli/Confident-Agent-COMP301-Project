import requests

def solve(inputs):
    base_url = "https://dummyjson.com/users"
    new_age = inputs["new_age"]
    new_firstName = inputs["new_firstName"]
    
    payload = {
        "age": new_age,
        "firstName": new_firstName
    }
    
    response = requests.post(base_url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 201:
        data = response.json()
        if data.get("users"):
            return data["users"][0]["id"]
        else:
            return None
    else:
        raise Exception(f"Failed to create user. Status code: {response.status_code}")