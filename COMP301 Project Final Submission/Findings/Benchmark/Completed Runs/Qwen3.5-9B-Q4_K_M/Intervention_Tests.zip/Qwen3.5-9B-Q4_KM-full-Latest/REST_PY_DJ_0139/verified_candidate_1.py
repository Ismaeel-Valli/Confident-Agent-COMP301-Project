import requests

def solve(inputs):
    """
    Update selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id: Identifier of the todo to update
            - new_completed: Value for the completed attribute
            - new_user_identifier: Value for the user Id attribute
    
    Returns:
        The decoded JSON response, or None if the response is empty.
    
    Raises:
        Exception: For unsuccessful HTTP responses (status code != 200).
    """
    base_url = "https://dummyjson.com"
    resource_id = inputs["resource_id"]
    new_completed = inputs["new_completed"]
    new_user_identifier = inputs["new_user_identifier"]
    
    url = f"{base_url}/todos/{resource_id}"
    payload = {
        "completed": new_completed,
        "userId": new_user_identifier
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update todo: HTTP {response.status_code}")
    
    return response.json() if response.text else None