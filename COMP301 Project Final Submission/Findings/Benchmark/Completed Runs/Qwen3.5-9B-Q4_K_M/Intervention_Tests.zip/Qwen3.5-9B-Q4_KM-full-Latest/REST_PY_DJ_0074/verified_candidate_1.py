def solve(inputs):
    """Update a product on DummyJSON and return its id or None."""
    import requests
    
    resource_id = inputs["resource_id"]
    new_description = inputs["new_description"]
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"description": new_description}
    
    response = requests.put(url, json=payload)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 201:
        data = response.json()
        return data.get("id")
    else:
        raise Exception(f"Failed to update product: {response.status_code}")