import requests
import json

def solve(inputs):
    """
    Create a GitHub issue using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): Contains:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git)
            - new_title (str): Title for the issue
            - credential (str): Bearer token for authentication
    
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    base_url = "https://api.github.com"
    
    # Construct the API endpoint for creating an issue
    repo_owner = inputs["repository_owner"]
    repo_name = inputs["repository_name"]
    title = inputs["new_title"]
    credential = inputs["credential"]
    
    url = f"{base_url}/repos/{repo_owner}/{repo_name}/issues"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    data = {
        "title": title
    }
    
    response = requests.post(url, json=data, headers=headers)
    
    if response.status_code == 201:
        # Successful creation - return decoded JSON or None for empty response
        response_data = response.json()
        if not response_data:
            return None
        return response_data
    elif response.status_code == 202:
        # Accepted - wait and then get the result
        response.raise_for_status()
        response_data = response.json()
        if not response_data:
            return None
        return response_data
    else:
        # Unsuccessful response
        raise Exception(f"Failed to create issue. Status code: {response.status_code}, Response: {response.text}")