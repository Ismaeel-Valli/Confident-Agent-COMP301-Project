def solve(inputs):
    resource_id = inputs["resource_id"]
    url = "https://dummyjson.com/posts/" + str(resource_id)
    response = requests.get(url)
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}")
    data = response.json()
    if data is None:
        return None
    title = data.get("title")
    if title is None:
        return None
    return title