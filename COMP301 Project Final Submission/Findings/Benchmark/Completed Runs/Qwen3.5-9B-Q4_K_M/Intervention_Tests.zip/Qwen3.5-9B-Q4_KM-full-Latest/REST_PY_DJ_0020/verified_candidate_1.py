import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    url = "https://dummyjson.com/todos/" + str(resource_id)
    response = requests.get(url)
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    data = response.json()
    if data["length"] == 0:
        return None
    return data