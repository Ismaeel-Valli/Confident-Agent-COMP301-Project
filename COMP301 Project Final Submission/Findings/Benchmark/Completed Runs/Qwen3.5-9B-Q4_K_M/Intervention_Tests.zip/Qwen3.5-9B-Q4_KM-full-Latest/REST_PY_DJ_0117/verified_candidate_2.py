import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_phone = inputs["new_phone"]
    
    url = "https://dummyjson.com/users/{0}".format(resource_id)
    payload = {"phone": new_phone}
    
    response = requests.patch(url, json=payload)
    response.raise_for_status()
    
    return response.json()