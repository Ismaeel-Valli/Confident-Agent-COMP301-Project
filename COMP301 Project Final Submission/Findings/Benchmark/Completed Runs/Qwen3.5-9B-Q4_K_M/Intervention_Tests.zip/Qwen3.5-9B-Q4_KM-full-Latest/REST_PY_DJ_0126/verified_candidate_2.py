import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_phone = inputs["new_phone"]
    
    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {"phone": new_phone}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    data = response.json()
    return data.get("id")