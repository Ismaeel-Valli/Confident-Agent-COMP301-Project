import requests

def solve(inputs):
    """
    Submit a new user to DummyJSON and return the response's id value,
    or None if that attribute is absent. Return None for a successful empty response.
    Raise an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Contains 'new_firstName' and 'new_username'.
        
    Returns:
        int or None: The id of the created user, or None if no id is present.
        
    Raises:
        requests.HTTPError: If the HTTP response status code indicates an error.
    """
    base_url = "https://dummyjson.com/users"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "username": inputs["new_username"]
    }
    
    response = requests.post(base_url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 201:
        data = response.json()
        return data.get("id")
    elif response.status_code == 200:
        # Some endpoints might return 200 for POST, check for empty response
        data = response.json()
        if not data:
            return None
        return data.get("id")
    
    raise requests.HTTPError(f"Failed to create user: {response.status_code}")