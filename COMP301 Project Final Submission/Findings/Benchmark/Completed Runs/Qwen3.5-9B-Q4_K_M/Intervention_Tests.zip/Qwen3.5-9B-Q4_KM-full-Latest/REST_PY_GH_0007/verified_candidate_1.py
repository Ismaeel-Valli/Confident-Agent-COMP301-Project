import requests

def solve(inputs):
    """
    Update a repository name on GitHub using the REST API.
    
    Args:
        inputs (dict): Contains:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Current name of the repository
            - new_name (str): New name for the repository
            - credential (str): Bearer token for authentication
    
    Returns:
        None if successful (empty response), otherwise decoded JSON response.
    
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    new_name = inputs["new_name"]
    credential = inputs["credential"]
    
    base_url = "https://api.github.com"
    url = f"{base_url}/repos/{owner}/{repo}"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json"
    }
    
    response = requests.patch(url, json={"name": new_name}, headers=headers)
    
    if response.status_code != 200:
        response.raise_for_status()
    
    return response.json()