import requests

def solve(inputs):
    result_limit = inputs["result_limit"]
    url = f"https://dummyjson.com/users?limit={result_limit}"
    response = requests.get(url)
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}")
    return response.json()