def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_firstName = inputs["new_firstName"]
    
    base_url = "https://dummyjson.com/users"
    url = f"{base_url}/{resource_id}"
    
    payload = {"firstName": new_firstName}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    return response.json()