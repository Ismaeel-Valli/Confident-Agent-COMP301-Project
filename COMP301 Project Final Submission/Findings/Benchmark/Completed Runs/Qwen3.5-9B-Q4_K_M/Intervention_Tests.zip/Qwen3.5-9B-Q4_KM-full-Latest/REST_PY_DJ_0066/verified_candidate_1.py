def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_lastName = inputs["new_lastName"]
    
    url = "https://dummyjson.com/users/" + str(resource_id)
    payload = {"lastName": new_lastName}
    
    response = requests.patch(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    data = response.json()
    if "id" in data:
        return data["id"]
    return None