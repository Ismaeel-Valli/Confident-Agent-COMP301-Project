import requests

def solve(inputs):
    """Submit a new product to DummyJSON."""
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/add"
    
    headers = {
        "Content-Type": "application/json",
    }
    
    payload = {
        "title": inputs["new_title"],
    }
    
    response = requests.post(url, json=payload, headers=headers)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    return response.json()