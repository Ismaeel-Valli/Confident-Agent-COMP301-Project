def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON, respecting result_limit.
    
    Args:
        inputs (dict): Must contain 'result_limit' (int).
    
    Returns:
        list or None: Decoded JSON response if successful; None for empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    import requests
    
    base_url = "https://dummyjson.com"
    endpoint = "/todos"
    url = f"{base_url}{endpoint}"
    
    params = {
        "limit": inputs["result_limit"]
    }
    
    response = requests.get(url, params=params)
    response.raise_for_status()
    
    data = response.json()
    
    return data.get("todos", None)