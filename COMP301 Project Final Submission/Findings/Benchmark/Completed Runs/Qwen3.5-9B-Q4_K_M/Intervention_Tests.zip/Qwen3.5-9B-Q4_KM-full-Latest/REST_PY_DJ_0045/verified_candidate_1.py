import requests

def solve(inputs):
    """
    Retrieve a product by identifier from DummyJSON and return its title.
    
    Args:
        inputs (dict): Must contain 'resource_id' key with the product identifier.
        
    Returns:
        str or None: The product's title, or None if absent or response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    resource_id = inputs['resource_id']
    url = f"https://dummyjson.com/products/{resource_id}"
    
    try:
        response = requests.get(url)
        
        if response.status_code >= 400:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
        
        data = response.json()
        
        # Return title if present, otherwise None for successful empty response
        return data.get('title')
    except requests.RequestException as e:
        raise Exception(f"Request failed: {e}")