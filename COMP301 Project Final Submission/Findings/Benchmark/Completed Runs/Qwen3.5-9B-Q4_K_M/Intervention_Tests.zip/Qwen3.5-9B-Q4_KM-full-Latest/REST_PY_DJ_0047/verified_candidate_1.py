def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    url = f"https://dummyjson.com/products/{resource_id}"
    
    response = requests.delete(url)
    
    if response.status_code == 200:
        data = response.json()
        title = data.get("title")
        return None if title is None else title
    elif response.status_code == 404:
        data = response.json()
        title = data.get("title")
        return None if title is None else title
    else:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")