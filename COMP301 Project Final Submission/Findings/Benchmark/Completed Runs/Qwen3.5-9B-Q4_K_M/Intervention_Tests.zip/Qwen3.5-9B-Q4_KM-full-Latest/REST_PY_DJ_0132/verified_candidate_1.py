import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_category = inputs["new_category"]
    
    url = "https://dummyjson.com/products/{0}".format(resource_id)
    headers = {"Content-Type": "application/json"}
    data = {"category": new_category}
    
    response = requests.put(url, json=data, headers=headers)
    response.raise_for_status()
    
    if response.status_code == 200:
        return None
    
    try:
        return response.json().get("id")
    except Exception:
        return None