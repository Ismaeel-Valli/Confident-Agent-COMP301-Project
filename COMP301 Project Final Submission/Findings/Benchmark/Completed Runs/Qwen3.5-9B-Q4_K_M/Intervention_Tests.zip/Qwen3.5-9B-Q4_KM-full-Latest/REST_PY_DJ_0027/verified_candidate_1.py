def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    url = "https://dummyjson.com/products/{id}".format(id=resource_id)
    
    response = requests.delete(url)
    
    if response.status_code == 204:
        return None
    elif response.status_code == 404:
        raise Exception(f"Resource not found: {response.json()}")
    else:
        raise Exception(f"Failed to delete product: {response.status_code} - {response.text}")