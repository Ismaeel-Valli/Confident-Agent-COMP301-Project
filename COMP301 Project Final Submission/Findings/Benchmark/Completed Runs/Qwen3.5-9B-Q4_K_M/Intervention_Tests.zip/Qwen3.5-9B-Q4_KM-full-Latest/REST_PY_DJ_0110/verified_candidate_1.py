def solve(inputs):
    """Update a post on DummyJSON and return its new id, or None if absent."""
    import requests
    
    resource_id = inputs["resource_id"]
    new_user_identifier = inputs["new_user_identifier"]
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    payload = {"userId": new_user_identifier}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 200:
        return None
    
    data = response.json()
    return data.get("id")