def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_username = inputs["new_username"]
    
    url = f"https://dummyjson.com/users/{resource_id}"
    headers = {"Content-Type": "application/json"}
    payload = {"username": new_username}
    
    response = requests.put(url, json=payload, headers=headers)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    data = response.json()
    if "id" in data:
        return data["id"]
    return None