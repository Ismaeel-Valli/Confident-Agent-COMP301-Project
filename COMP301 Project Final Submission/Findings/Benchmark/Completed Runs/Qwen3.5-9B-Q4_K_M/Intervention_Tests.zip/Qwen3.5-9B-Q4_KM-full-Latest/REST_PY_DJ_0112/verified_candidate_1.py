import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_completed = inputs["new_completed"]
    new_todo = inputs["new_todo"]
    
    url = "https://dummyjson.com/todos/" + str(resource_id)
    payload = {
        "completed": new_completed,
        "todo": new_todo
    }
    
    response = requests.put(url, json=payload)
    if response.status_code != 200:
        raise Exception(f"Failed to update todo: {response.text}")
    
    data = response.json()
    if "id" in data:
        return data["id"]
    else:
        return None