import requests

def solve(inputs):
    """
    Update selected fields of a user in DummyJSON.
    
    Args:
        inputs (dict): Contains:
            - resource_id: Identifier of the user (int)
            - new_username: New value for the username attribute (str)
    
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    base_url = "https://dummyjson.com/users"
    url = f"{base_url}/{inputs['resource_id']}"
    
    payload = {
        "username": inputs["new_username"]
    }
    
    response = requests.patch(url, json=payload)
    
    if response.status_code == 200:
        return response.json()
    elif response.status_code == 204:
        return None
    else:
        raise Exception(f"Failed to update user: {response.status_code} - {response.text}")