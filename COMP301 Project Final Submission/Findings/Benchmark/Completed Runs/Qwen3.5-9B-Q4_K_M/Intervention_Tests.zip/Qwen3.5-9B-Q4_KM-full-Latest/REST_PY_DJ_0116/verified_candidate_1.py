def solve(inputs):
    """
    Retrieve one page of users from DummyJSON with pagination and field filtering.
    
    Args:
        inputs (dict): Dictionary containing:
            - results_to_skip (int): Number of results to skip (for pagination)
            - included_fields (str): Comma-separated list of fields to include
    
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    import requests
    
    base_url = "https://dummyjson.com/users"
    
    # Parse included_fields
    if inputs["included_fields"]:
        fields_list = [f.strip() for f in inputs["included_fields"].split(",")]
        params = {
            "skip": inputs["results_to_skip"],
            "limit": 1,  # Retrieve one page (one result)
            "select": ",".join(fields_list)
        }
    else:
        params = {
            "skip": inputs["results_to_skip"],
            "limit": 1
        }
    
    response = requests.get(base_url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    return response.json()