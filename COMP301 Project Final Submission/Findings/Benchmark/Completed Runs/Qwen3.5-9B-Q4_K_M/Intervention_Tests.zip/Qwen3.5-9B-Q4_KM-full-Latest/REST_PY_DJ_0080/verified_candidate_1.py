def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_body = inputs["new_body"]
    
    url = "https://dummyjson.com/posts/" + str(resource_id)
    payload = {"body": new_body}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    data = response.json()
    
    if "id" in data:
        return data["id"]
    elif response.status_code == 200:
        return None
    else:
        raise Exception("Failed to update post")