import requests

def solve(inputs):
    """Retrieve one page of posts from DummyJSON and return decoded JSON."""
    base_url = inputs.get("base_url", "https://dummyjson.com")
    endpoint = inputs.get("endpoint", "/posts")
    
    url = f"{base_url}{endpoint}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        
        if response.status_code == 200:
            data = response.json()
            return data if data else None
        else:
            raise Exception(f"Unexpected status code: {response.status_code}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")