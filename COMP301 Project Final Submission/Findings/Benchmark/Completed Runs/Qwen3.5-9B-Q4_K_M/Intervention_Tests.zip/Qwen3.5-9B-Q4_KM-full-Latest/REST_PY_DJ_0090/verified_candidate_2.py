import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_body = inputs["new_body"]
    
    url = "https://dummyjson.com/posts/" + str(resource_id)
    
    response = requests.put(url, json={"body": new_body})
    
    if response.status_code == 200:
        data = response.json()
        return data.get("title")
    elif response.status_code == 204:
        return None
    else:
        raise Exception(f"Failed to update post: {response.status_code}")