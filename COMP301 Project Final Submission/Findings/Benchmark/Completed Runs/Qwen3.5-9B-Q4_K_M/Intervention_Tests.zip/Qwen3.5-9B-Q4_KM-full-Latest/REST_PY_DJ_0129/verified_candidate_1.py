import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_body = inputs["new_body"]
    new_title = inputs["new_title"]
    
    url = "https://dummyjson.com/posts/{id}".format(id=resource_id)
    payload = {
        "body": new_body,
        "title": new_title
    }
    
    response = requests.put(url, json=payload)
    if response.status_code != 200:
        raise Exception(f"Failed to update post: {response.status_code} {response.text}")
    
    return response.json()