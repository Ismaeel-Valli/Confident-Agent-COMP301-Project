import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_email = inputs["new_email"]
    
    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {"email": new_email}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 200:
        return None
    elif response.status_code == 201:
        data = response.json()
        return data.get("id")
    else:
        raise Exception(f"Failed to update user: {response.status_code} {response.text}")