import requests

def solve(inputs):
    """
    Update an organization's name via GitHub REST API v2026-03-10.
    
    Args:
        inputs (dict): Must contain:
            - "organization": str, the organization name
            - "new_name": str, the new name for the organization
            - "credential": str, caller-supplied authentication token
    
    Returns:
        None if successful (empty response), otherwise decoded JSON.
    
    Raises:
        Exception on unsuccessful HTTP responses.
    """
    org = inputs["organization"]
    new_name = inputs["new_name"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/orgs/{org}"
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    payload = {"name": new_name}
    
    response = requests.patch(url, json=payload, headers=headers)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    return response.json()