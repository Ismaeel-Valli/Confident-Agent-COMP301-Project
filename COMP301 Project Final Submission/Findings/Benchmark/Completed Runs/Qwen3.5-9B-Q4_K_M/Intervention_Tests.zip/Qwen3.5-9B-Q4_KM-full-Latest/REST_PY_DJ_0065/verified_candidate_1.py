import requests

def solve(inputs):
    """
    Retrieve one page of users from DummyJSON.
    
    Args:
        inputs (dict): Dictionary containing:
            - included_fields (str): Comma-separated list of fields to return.
    
    Returns:
        dict or None: Decoded JSON response, or None for empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com"
    endpoint = "/users"
    url = f"{base_url}{endpoint}"
    
    headers = {
        "Accept": "application/json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    included_fields = inputs["included_fields"]
    fields_list = [f.strip() for f in included_fields.split(",")]
    
    if not fields_list:
        return None
    
    filtered_data = {}
    for field in fields_list:
        if field in data:
            filtered_data[field] = data[field]
    
    return filtered_data