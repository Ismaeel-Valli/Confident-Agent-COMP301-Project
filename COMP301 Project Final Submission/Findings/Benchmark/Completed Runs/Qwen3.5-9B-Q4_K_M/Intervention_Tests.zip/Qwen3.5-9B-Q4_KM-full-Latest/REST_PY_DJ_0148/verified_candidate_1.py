def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_completed = inputs["new_completed"]
    new_user_identifier = inputs["new_user_identifier"]
    
    url = "https://dummyjson.com/todos"
    payload = {
        "id": resource_id,
        "completed": new_completed,
        "userId": new_user_identifier
    }
    
    response = requests.patch(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    data = response.json()
    return data.get("id")