def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_completed = inputs["new_completed"]
    new_user_identifier = inputs["new_user_identifier"]
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    payload = {
        "completed": new_completed,
        "userId": new_user_identifier
    }
    
    response = requests.patch(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    data = response.json()
    return data.get("id")