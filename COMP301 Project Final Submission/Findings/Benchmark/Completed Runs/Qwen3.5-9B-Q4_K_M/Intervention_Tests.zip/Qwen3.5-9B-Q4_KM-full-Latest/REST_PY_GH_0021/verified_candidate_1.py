import requests

def solve(inputs):
    """
    Fetch a GitHub issue using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): Contains:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git)
            - issue_number (int): Issue number to fetch
            - credential (str): Bearer token for authentication
    
    Returns:
        dict or None: Decoded JSON response, or None if empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    base_url = "https://api.github.com"
    version = "2026-03-10"
    
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    issue_num = inputs["issue_number"]
    token = inputs["credential"]
    
    url = f"{base_url}/repos/{owner}/{repo}/issues/{issue_num}"
    headers = {
        "Accept": f"application/vnd.github.{version}-preview+json",
        "Authorization": f"Bearer {token}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        return data if data else None
    elif response.status_code == 404:
        # Resource not found - but per spec, we assume resources exist
        raise Exception(f"Resource not found: {response.url}")
    else:
        raise Exception(f"HTTP {response.status_code}: {response.text}")