def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    new_age = inputs["new_age"]
    
    url = "https://dummyjson.com/users/{0}".format(resource_id)
    payload = {"age": new_age}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception("HTTP error")
    
    return response.json()