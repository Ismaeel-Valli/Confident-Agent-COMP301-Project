import requests

def solve(inputs):
    search_text = inputs["search_text"]
    url = "https://dummyjson.com/products/search"
    
    response = requests.get(url, params={"q": search_text})
    response.raise_for_status()
    
    data = response.json()
    
    if not data.get("products"):
        return None
    
    return data