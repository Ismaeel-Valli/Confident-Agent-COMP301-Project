def solve(inputs):
    import requests
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/add"
    payload = {
        "category": inputs["new_category"],
        "title": inputs["new_title"]
    }
    response = requests.post(url, json=payload)
    if response.status_code != 200:
        raise Exception(f"Failed to add product: {response.text}")
    data = response.json()
    return data.get("id")