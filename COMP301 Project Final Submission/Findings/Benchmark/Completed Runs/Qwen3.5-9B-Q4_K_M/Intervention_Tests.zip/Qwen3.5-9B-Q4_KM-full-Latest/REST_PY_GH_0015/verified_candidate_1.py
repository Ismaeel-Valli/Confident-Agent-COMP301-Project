import requests

def solve(inputs):
    """
    Create a fork of a GitHub repository using the GitHub REST API v2026-03-10.
    
    Args:
        inputs (dict): Contains:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git)
            - new_name (str): New name for the forked repository
            - credential (str): Bearer token for authentication
    
    Returns:
        dict or None: Decoded JSON response, or None if successful with empty response
    
    Raises:
        Exception: For unsuccessful HTTP responses
    """
    base_url = "https://api.github.com"
    
    # Construct the API endpoint for creating a fork
    url = f"{base_url}/repos/{inputs['repository_owner']}/{inputs['repository_name']}"
    
    headers = {
        "Authorization": f"Bearer {inputs['credential']}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    # Make the POST request to create a fork with the new name
    response = requests.post(
        url,
        headers=headers,
        params={"name": inputs["new_name"]}
    )
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Return decoded JSON response, or None if successful with empty response
    return response.json() if response.text else None