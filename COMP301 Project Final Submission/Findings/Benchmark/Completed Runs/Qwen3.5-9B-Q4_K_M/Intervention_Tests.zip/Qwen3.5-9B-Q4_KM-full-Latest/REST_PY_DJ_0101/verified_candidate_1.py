def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON with pagination and field filtering.
    
    Args:
        inputs (dict): Dictionary containing:
            - results_to_skip (int): Number of results to skip for pagination.
            - included_fields (str): Comma-separated list of fields to include in the response.
    
    Returns:
        dict or None: Decoded JSON response, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    import requests
    
    base_url = "https://dummyjson.com"
    endpoint = "/todos"
    url = f"{base_url}{endpoint}"
    
    params = {
        "skip": inputs["results_to_skip"],
        "limit": 1,
    }
    
    response = requests.get(url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    included_fields = [f.strip() for f in inputs["included_fields"].split(",")]
    
    filtered_data = {}
    for field in included_fields:
        if field in data:
            filtered_data[field] = data[field]
    
    return filtered_data if filtered_data else None