def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON, skipping a number of results.
    
    Args:
        inputs (dict): Dictionary containing 'results_to_skip' key.
        
    Returns:
        dict or None: Decoded JSON response, or None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    import requests
    
    base_url = "https://dummyjson.com"
    todos_endpoint = "/todos"
    
    # Build the URL with skip parameter
    url = f"{base_url}{todos_endpoint}?skip={inputs['results_to_skip']}"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Return None for successful empty response, otherwise return the decoded JSON
    if not data.get('todos'):
        return None
    
    return data