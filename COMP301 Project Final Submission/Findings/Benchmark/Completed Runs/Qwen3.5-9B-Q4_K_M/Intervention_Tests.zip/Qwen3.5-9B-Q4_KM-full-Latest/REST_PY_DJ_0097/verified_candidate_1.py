def solve(inputs):
    resource_id = inputs["resource_id"]
    new_email = inputs["new_email"]
    
    url = "https://dummyjson.com/users/" + str(resource_id)
    payload = {"email": new_email}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    return response.json()