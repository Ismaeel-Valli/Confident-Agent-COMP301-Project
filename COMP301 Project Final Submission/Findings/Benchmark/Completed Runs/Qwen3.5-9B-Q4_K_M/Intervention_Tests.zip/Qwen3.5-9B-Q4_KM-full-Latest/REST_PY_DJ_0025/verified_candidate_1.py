def solve(inputs):
    resource_id = inputs["resource_id"]
    url = f"https://dummyjson.com/products/{resource_id}"
    response = requests.get(url)
    if response.status_code != 200:
        raise Exception(f"Failed to retrieve product {resource_id}: HTTP {response.status_code}")
    data = response.json()
    return data.get("id")