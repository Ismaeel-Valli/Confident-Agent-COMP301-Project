def solve(inputs):
    """Update selected fields of a product in DummyJSON."""
    import requests
    
    resource_id = inputs["resource_id"]
    new_price = inputs["new_price"]
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"price": new_price}
    
    response = requests.put(url, json=payload)
    response.raise_for_status()
    
    data = response.json()
    
    if "id" in data:
        return data["id"]
    elif "message" in data and data["message"] == "No content":
        return None
    else:
        return None