def solve(inputs):
    """Delete a post by identifier using DummyJSON."""
    import requests
    
    resource_id = inputs["resource_id"]
    url = f"https://dummyjson.com/posts/{resource_id}"
    
    response = requests.delete(url)
    
    if response.status_code == 204:
        return None
    else:
        raise Exception(f"Failed to delete post. Status code: {response.status_code}, Response: {response.text}")