import requests
import json

def solve(inputs):
    """
    Get an organization from GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): Dictionary containing:
            - "organization": str, the organization name
            - "credential": str, caller-supplied credential (assumed to have necessary permissions)
    
    Returns:
        dict or None: Decoded JSON response, or None for a successful empty response
    
    Raises:
        Exception: For an unsuccessful HTTP response
    """
    org_name = inputs["organization"]
    credential = inputs["credential"]
    
    # GitHub REST API v3 endpoint for organization
    url = f"https://api.github.com/orgs/{org_name}"
    
    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "Authorization": f"Bearer {credential}"
    }
    
    try:
        response = requests.get(url, headers=headers)
        
        # Raise exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        # Decode JSON response
        data = response.json()
        
        # Return None for empty response (GitHub returns empty object for some cases)
        if not data:
            return None
        
        return data
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")