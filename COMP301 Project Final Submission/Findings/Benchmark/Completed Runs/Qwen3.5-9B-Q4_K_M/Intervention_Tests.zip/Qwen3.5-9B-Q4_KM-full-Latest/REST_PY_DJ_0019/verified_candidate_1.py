import requests

def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON and return the decoded JSON response.
    
    Args:
        inputs (dict): Must contain 'post_id' key with an integer value representing the todo ID.
        
    Returns:
        dict or None: The decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://dummyjson.com"
    endpoint = f"/todos/{inputs['post_id']}"
    url = base_url + endpoint
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        
        data = response.json()
        
        if not data:
            return None
            
        return data
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")