import requests

def solve(inputs):
    """Retrieve one page of products from DummyJSON and return the decoded JSON response."""
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}?skip={inputs.get('skip', 0)}&limit={inputs.get('limit', 10)}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        
        if response.status_code == 200:
            data = response.json()
            return data if data else None
        else:
            raise Exception(f"HTTP {response.status_code}: {response.text}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")