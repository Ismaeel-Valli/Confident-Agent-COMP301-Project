def solve(inputs):
    import requests
    
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/add"
    
    headers = {
        "Content-Type": "application/json",
        "x-api-key": inputs.get("api_key", "")
    }
    
    payload = {
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to add product. Status code: {response.status_code}")
    
    data = response.json()
    
    if "product" in data and "id" in data["product"]:
        return data["product"]["id"]
    elif response.status_code == 201:
        return None
    else:
        return None