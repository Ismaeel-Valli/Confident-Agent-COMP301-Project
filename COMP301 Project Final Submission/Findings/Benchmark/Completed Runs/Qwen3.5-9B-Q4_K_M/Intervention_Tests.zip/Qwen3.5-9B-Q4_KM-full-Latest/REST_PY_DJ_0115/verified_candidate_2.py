def solve(inputs):
    import requests
    
    base_url = "https://dummyjson.com/products"
    url = f"{base_url}/add"
    
    payload = {
        "price": inputs["new_price"],
        "title": inputs["new_title"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    return data.get("title")