import requests

def solve(inputs):
    search_text = inputs.get("search_text")
    if search_text is None:
        raise ValueError("Missing 'search_text' in inputs")
    
    url = "https://dummyjson.com/posts/search"
    params = {"q": search_text}
    
    response = requests.get(url, params=params)
    response.raise_for_status()
    
    data = response.json()
    
    if data["posts"]:
        return data
    
    return None