import requests

def solve(inputs):
    """
    Update a GitHub issue using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): Contains:
            - repository_owner (str): Owner of the repository
            - repository_name (str): Name of the repository
            - issue_number (int): Issue number to update
            - new_title (str): New title for the issue
            - credential (str): Bearer token for authentication
    
    Returns:
        None if successful with empty response, otherwise decoded JSON response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    new_title = inputs["new_title"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}"
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    payload = {"title": new_title}
    
    response = requests.patch(url, json=payload, headers=headers)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    return response.json()