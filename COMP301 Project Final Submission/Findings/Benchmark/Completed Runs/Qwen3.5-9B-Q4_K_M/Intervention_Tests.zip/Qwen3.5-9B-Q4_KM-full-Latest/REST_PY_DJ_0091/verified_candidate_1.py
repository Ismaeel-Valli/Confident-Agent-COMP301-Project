def solve(inputs):
    """
    Retrieve one page of todos from DummyJSON with filtering by fields and limit.
    
    Args:
        inputs (dict): Dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - included_fields (str): Comma-separated list of fields to include in the response.
    
    Returns:
        dict or None: Decoded JSON response, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    import requests
    
    base_url = "https://dummyjson.com"
    endpoint = "/todos"
    url = f"{base_url}{endpoint}"
    
    params = {
        "limit": inputs["result_limit"],
        "fields": inputs["included_fields"]
    }
    
    response = requests.get(url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    return data if data else None