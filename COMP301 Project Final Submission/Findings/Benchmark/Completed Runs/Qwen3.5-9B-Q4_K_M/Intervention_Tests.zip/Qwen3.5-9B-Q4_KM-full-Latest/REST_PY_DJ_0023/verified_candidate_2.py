import requests

def solve(inputs):
    """
    Create a new todo in DummyJSON using the provided inputs:
      - inputs['new_completed']: value for the 'completed' attribute
      - inputs['new_todo']: value for the 'todo' attribute
      - inputs['new_user_identifier']: value for the 'user' attribute (id)

    Returns the decoded JSON response.
    Returns None for a successful empty response.
    Raises an exception for an unsuccessful HTTP response.
    """
    base_url = "https://dummyjson.com"
    url = f"{base_url}/todos/add"
    
    payload = {
        "todo": inputs["new_todo"],
        "completed": inputs["new_completed"],
        "userId": inputs["new_user_identifier"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create todo. Status code: {response.status_code}")
    
    return response.json()