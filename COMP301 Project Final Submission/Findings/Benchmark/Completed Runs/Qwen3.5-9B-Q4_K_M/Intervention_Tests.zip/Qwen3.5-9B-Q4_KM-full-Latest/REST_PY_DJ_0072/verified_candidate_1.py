import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_completed = inputs["new_completed"]
    
    url = "https://dummyjson.com/todos"
    payload = {
        "id": resource_id,
        "completed": new_completed
    }
    
    response = requests.patch(url, json=payload)
    response.raise_for_status()
    
    if response.status_code == 204:
        return None
    
    data = response.json()
    if "id" in data:
        return data["id"]
    return None