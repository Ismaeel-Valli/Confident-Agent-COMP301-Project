def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    url = "https://dummyjson.com/users/{id}".format(id=resource_id)
    
    response = requests.delete(url)
    
    if response.status_code == 200:
        return None
    elif response.status_code == 404:
        return None
    else:
        raise Exception(f"Failed to delete user {resource_id}: {response.status_code} {response.text}")