def solve(inputs):
    import requests
    
    new_title = inputs["new_title"]
    
    url = "https://dummyjson.com/products"
    headers = {"Content-Type": "application/json"}
    payload = {"title": new_title}
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create product: {response.status_code}")
    
    data = response.json()
    
    if "product" in data and "title" in data["product"]:
        return data["product"]["title"]
    else:
        return None