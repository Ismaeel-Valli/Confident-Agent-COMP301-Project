def solve(inputs):
    import requests
    
    base_url = "https://dummyjson.com"
    
    payload = {
        "todo": inputs["new_todo"],
        "completed": inputs["new_completed"],
        "userId": inputs["new_user_identifier"]
    }
    
    response = requests.post(f"{base_url}/todos", json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create todo. Status code: {response.status_code}")
    
    data = response.json()
    
    if "result" in data and data["result"] is not None:
        return data["result"]["id"]
    elif "results" in data and len(data["results"]) > 0:
        return data["results"][0]["id"]
    else:
        return None