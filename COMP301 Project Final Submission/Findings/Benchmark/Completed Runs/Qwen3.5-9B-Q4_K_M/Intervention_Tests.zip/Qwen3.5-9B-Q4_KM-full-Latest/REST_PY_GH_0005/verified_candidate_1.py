import requests
import json

def solve(inputs):
    """
    Create an organization repository on GitHub using the REST API v2026-03-10.
    
    Args:
        inputs (dict): Contains:
            - 'organization': str, The organization name
            - 'new_name': str, The value for the name attribute of the new repo
            - 'credential': str, The caller-supplied credential (token)
    
    Returns:
        dict or None: Decoded JSON response. Returns None for a successful empty response.
    
    Raises:
        Exception: For an unsuccessful HTTP response.
    """
    base_url = "https://api.github.com"
    org = inputs["organization"]
    repo_name = inputs["new_name"]
    token = inputs["credential"]
    
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    url = f"{base_url}/orgs/{org}/repos"
    payload = {"name": repo_name}
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code == 201:
        return None
    elif response.status_code == 202:
        return None
    else:
        raise Exception(f"Failed to create repository. Status code: {response.status_code}, Response: {response.text}")