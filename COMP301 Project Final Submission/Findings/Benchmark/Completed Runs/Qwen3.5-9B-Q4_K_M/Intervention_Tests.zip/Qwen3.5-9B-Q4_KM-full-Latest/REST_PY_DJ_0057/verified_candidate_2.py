def solve(inputs):
    import requests
    
    new_body = inputs["new_body"]
    new_title = inputs["new_title"]
    new_user_identifier = inputs["new_user_identifier"]
    
    url = "https://dummyjson.com/posts/add"
    headers = {"Content-Type": "application/json"}
    payload = {
        "body": new_body,
        "title": new_title,
        "userId": new_user_identifier
    }
    
    response = requests.post(url, json=payload, headers=headers)
    if response.status_code != 201:
        raise Exception(f"Failed to create post: {response.status_code} {response.text}")
    
    data = response.json()
    title = data.get("title")
    if title is None and data.get("posts") == []:
        return None
    return title