def solve(inputs):
    resource_id = inputs["resource_id"]
    url = "https://dummyjson.com/posts/{id}".format(id=resource_id)
    response = requests.delete(url)
    if response.status_code == 204:
        return None
    data = response.json()
    if "isDeleted" in data:
        return data["isDeleted"]
    return None