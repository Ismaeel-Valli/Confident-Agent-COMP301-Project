import requests

def solve(inputs):
    resource_id = inputs["resource_id"]
    new_category = inputs["new_category"]
    
    url = "https://dummyjson.com/products/{id}".format(id=resource_id)
    headers = {"Content-Type": "application/json"}
    payload = {"category": new_category}
    
    response = requests.put(url, json=payload, headers=headers)
    response.raise_for_status()
    
    return response.json() if response.status_code != 204 else None