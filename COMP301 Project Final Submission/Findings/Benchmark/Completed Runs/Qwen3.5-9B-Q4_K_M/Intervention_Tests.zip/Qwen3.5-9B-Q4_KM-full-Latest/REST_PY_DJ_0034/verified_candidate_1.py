import requests

def solve(inputs):
    """
    Retrieve one page of posts from DummyJSON.
    
    Args:
        inputs (dict): Must contain 'result_limit' (int) specifying the maximum number of results.
        
    Returns:
        dict or None: The decoded JSON response, or None for a successful empty response.
        
    Raises:
        Exception: For an unsuccessful HTTP response.
    """
    base_url = "https://dummyjson.com"
    endpoint = "/posts"
    
    url = f"{base_url}{endpoint}"
    
    params = {
        "limit": inputs["result_limit"]
    }
    
    response = requests.get(url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"HTTP error: {response.status_code}")
    
    data = response.json()
    
    return data