import requests

def solve(inputs):
    """
    Delete a GitHub repository using the REST API.
    
    Args:
        inputs (dict): Contains:
            - repository_owner (str): Account owner of the repository
            - repository_name (str): Name of the repository (without .git extension)
            - credential (str): Bearer token for authentication
    
    Returns:
        int: HTTP status code of the successful deletion response (204)
    
    Raises:
        Exception: If the deletion fails (non-2xx status code)
    """
    owner = inputs["repository_owner"]
    repo_name = inputs["repository_name"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo_name}"
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    response = requests.delete(url, headers=headers)
    
    if response.status_code == 204:
        return response.status_code
    
    response.raise_for_status()