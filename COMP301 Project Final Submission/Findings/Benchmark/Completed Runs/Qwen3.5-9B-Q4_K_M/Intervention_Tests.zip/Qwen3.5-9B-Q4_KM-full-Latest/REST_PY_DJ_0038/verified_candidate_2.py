def solve(inputs):
    import requests
    
    base_url = "https://dummyjson.com/posts/add"
    new_body = inputs["new_body"]
    new_title = inputs["new_title"]
    new_user_identifier = inputs["new_user_identifier"]
    
    payload = {
        "body": new_body,
        "title": new_title,
        "userId": new_user_identifier
    }
    
    response = requests.post(base_url, json=payload)
    if response.status_code != 201:
        raise Exception(f"Failed to create post: {response.status_code} - {response.text}")
    
    data = response.json()
    return data.get("id")