import requests

def solve(inputs):
    """Retrieve one page of users from DummyJSON."""
    base_url = "https://dummyjson.com/users"
    url = f"{base_url}?limit={inputs['limit']}&skip={inputs['skip']}"
    
    response = requests.get(url)
    if not response.ok:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    return None if not data else data