def solve(inputs):
    """Retrieve one page of products from DummyJSON, skipping specified results."""
    import requests
    
    base_url = "https://dummyjson.com/products"
    skip = inputs.get("results_to_skip", 0)
    
    url = f"{base_url}?skip={skip}&limit=1"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    if not data.get("products"):
        return None
    
    return data