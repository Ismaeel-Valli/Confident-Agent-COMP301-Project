def solve(inputs):
    import requests
    
    resource_id = inputs["resource_id"]
    url = "https://dummyjson.com/posts/{id}".format(id=resource_id)
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    if "post" in data and data["post"] is not None:
        return data["post"]["id"]
    elif "posts" in data and len(data["posts"]) == 0:
        return None
    else:
        return None