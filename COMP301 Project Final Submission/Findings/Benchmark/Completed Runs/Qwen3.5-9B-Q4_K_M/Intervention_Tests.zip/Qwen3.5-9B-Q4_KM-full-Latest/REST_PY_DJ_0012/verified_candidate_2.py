import requests

def solve(inputs):
    base_url = "https://dummyjson.com/users/add"
    payload = {"firstName": inputs["new_firstName"]}
    response = requests.post(base_url, json=payload)
    if response.status_code != 201:
        raise Exception(f"Failed to create user: {response.status_code}")
    return None