import requests

def solve(inputs):
    base_url = "https://dummyjson.com/users"
    
    payload = {
        "firstName": inputs["new_firstName"],
        "phone": inputs["new_phone"]
    }
    
    response = requests.post(base_url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user: HTTP {response.status_code}")
    
    data = response.json()
    
    if "user" in data and data["user"] is not None:
        return data["user"].get("id")
    
    return None