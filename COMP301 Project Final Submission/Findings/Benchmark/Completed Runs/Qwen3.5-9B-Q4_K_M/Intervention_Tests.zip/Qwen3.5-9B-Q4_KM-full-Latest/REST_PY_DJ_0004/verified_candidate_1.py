import requests

def solve(inputs):
    """Delete a product by identifier from DummyJSON."""
    base_url = "https://dummyjson.com/products"
    resource_id = inputs["resource_id"]
    
    url = f"{base_url}/{resource_id}"
    response = requests.delete(url)
    
    if response.status_code == 204:
        return None
    
    response.raise_for_status()
    return response.json()