def solve(inputs):
    import requests
    
    base_url = "https://dummyjson.com/users"
    
    response = requests.get(base_url)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # Return None for a successful empty response
    if not data.get("users"):
        return None
    
    return data