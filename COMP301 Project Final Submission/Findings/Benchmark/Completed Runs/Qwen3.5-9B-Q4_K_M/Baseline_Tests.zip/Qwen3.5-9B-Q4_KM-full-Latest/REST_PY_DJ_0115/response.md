```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON with the provided price and title.
    
    Args:
        inputs (dict): A dictionary containing 'new_price' and 'new_title'.
        
    Returns:
        str or None: The response's title value if present, otherwise None for a successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": inputs["new_title"],
        "body": inputs.get("new_price", ""),  # Using price as body since DummyJSON doesn't have a 'price' attribute in standard posts, but we'll use it as the body content.
        "userId": 1
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # Return the title value if present, otherwise None for a successful empty response
    return data.get("title")
```