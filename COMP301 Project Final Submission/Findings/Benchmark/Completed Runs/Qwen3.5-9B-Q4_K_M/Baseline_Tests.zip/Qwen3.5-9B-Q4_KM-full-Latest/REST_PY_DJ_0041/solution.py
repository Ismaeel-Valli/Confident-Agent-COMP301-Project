import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON and returns the response's id value,
    or None if that attribute is absent. Returns None for a successful empty response.
    Raises an exception for an unsuccessful HTTP response.
    
    Args:
        inputs (dict): Contains 'resource_id' (todo ID) and 'new_todo' (value to update).
        
    Returns:
        str or None: The updated todo's id, or None if absent or response is empty.
        
    Raises:
        Exception: If the HTTP response status code indicates failure.
    """
    resource_id = inputs.get('resource_id')
    new_todo = inputs.get('new_todo')
    
    # Construct the payload for updating the todo
    payload = {
        "todo": new_todo
    }
    
    # Endpoint to update a specific todo by ID in DummyJSON
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    try:
        response = requests.put(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (4xx or 5xx)
        response.raise_for_status()
        
        # Check if the response is empty
        if not response.text.strip():
            return None
        
        # Parse the JSON response
        data = response.json()
        
        # Return the id if present, otherwise None
        return data.get('id')
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP Error occurred while updating todo: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed while updating todo: {e}")