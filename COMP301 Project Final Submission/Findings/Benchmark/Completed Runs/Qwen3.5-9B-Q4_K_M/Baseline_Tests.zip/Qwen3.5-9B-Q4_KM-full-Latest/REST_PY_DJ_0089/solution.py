import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on pagination parameters.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip (for pagination).
    
    Returns:
        list or None: The decoded JSON response as a list of posts, or None if the response is empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    # Calculate query parameters for pagination
    params = {
        'limit': inputs['result_limit'],
        'skip': inputs['results_to_skip']
    }
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        data = response.json()
        
        # Return None if the response is empty (though unlikely with these parameters)
        return data if data else None
        
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Failed to retrieve posts: {e}") from e