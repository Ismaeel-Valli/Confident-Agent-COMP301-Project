```python
import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on skip count and included fields.
    
    Args:
        inputs (dict): Dictionary containing:
            - results_to_skip (int): Number of results to skip.
            - included_fields (str): Fields to return, separated by commas.
    
    Returns:
        dict or None: Decoded JSON response if successful and not empty, None if successful but empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"  # Using a standard placeholder API for demonstration
    
    # Construct the URL with query parameters
    params = {
        'skip': inputs['results_to_skip'],
        '_fields': inputs['included_fields']
    }
    
    try:
        response = requests.get(f"{base_url}/todos", params=params)
        
        if response.status_code != 200:
            raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
        
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
        
        return data
    
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```