```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the todo.
            - new_completed (bool): New value for the completed attribute.
            - new_todo (str): New value for the todo attribute.
    
    Returns:
        None if the update is successful and the response body is empty.
        The decoded JSON response if the server returns data.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    resource_id = inputs.get("resource_id")
    new_completed = inputs.get("new_completed")
    new_todo = inputs.get("new_todo")

    # Construct the payload for the PATCH request
    payload = {
        "completed": new_completed,
        "todo": new_todo
    }

    url = f"https://dummyjson.com/todos/{resource_id}"
    
    response = requests.patch(url, json=payload)

    if response.status_code != 200:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}, Response: {response.text}")

    # DummyJSON returns an empty body on successful PATCH for this endpoint
    return None
```