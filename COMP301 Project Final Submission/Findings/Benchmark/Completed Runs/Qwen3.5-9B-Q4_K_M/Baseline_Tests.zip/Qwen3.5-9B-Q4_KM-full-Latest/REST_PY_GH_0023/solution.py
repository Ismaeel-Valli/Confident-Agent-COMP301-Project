import requests

def solve(inputs):
    """
    Lists issue comments for a specific GitHub repository issue using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - issue_number (int): The issue number.
            - credential (dict): Caller-supplied credentials (e.g., token in header or auth params).
    
    Returns:
        list | None: A list of decoded JSON comment objects, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    credential = inputs["credential"]

    # Construct the API URL for GitHub REST API version 2026-03-10
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}/comments"

    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Prepare authentication based on common patterns (adjust if credential format differs)
    if isinstance(credential, dict):
        if "token" in credential:
            headers["Authorization"] = f"Bearer {credential['token']}"
        elif "username" in credential and "password" in credential:
            # Basic auth fallback if token not provided
            import base64
            auth_string = f"{credential['username']}:{credential['password']}"
            encoded_auth = base64.b64encode(auth_string.encode()).decode()
            headers["Authorization"] = f"Basic {encoded_auth}"

    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        raise Exception(f"Failed to fetch issue comments. Status code: {response.status_code}, Response: {response.text}")

    data = response.json()

    # Return None for empty list as per requirement
    return data if data else None