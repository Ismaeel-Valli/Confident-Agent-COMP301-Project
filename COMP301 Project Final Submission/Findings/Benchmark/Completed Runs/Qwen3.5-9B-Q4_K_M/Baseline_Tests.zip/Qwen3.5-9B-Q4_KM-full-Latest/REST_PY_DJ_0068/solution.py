import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on included fields.
    
    Args:
        inputs (dict): A dictionary containing 'included_fields' as a comma-separated string.
        
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    included_fields = inputs.get('included_fields', '')
    
    # Construct the URL with query parameters for included fields
    url = "https://jsonplaceholder.typicode.com/posts?_limit=1"
    params = {}
    if included_fields:
        params['fields'] = included_fields
    
    response = requests.get(url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # If the response is empty (e.g., no posts found), return None
    if not data:
        return None
    
    return data