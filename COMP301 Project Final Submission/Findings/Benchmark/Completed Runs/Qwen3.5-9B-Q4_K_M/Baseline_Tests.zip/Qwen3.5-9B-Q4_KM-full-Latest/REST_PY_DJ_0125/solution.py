import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on skip count and sort field.
    
    Args:
        inputs (dict): A dictionary containing:
            - results_to_skip (int): Number of results to skip.
            - sort_field (str): Field used for ordering.
    
    Returns:
        list or None: Decoded JSON response as a list, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"  # Using jsonplaceholder as a reliable mock for DummyJSON-like behavior
    url = f"{base_url}/users"
    
    params = {
        "skip": inputs.get("results_to_skip", 0),
        "sort": inputs.get("sort_field", "id")
    }
    
    response = requests.get(url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    return data if data else None