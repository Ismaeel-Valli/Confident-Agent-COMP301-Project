```python
import requests

def solve(inputs):
    """
    Lists pull requests for a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - state (str): Filter state ('open', 'closed', or 'all').
            - credential (dict): Caller-supplied credentials (assumed to have necessary permissions).
    
    Returns:
        list | None: Decoded JSON response as a list, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    state = inputs["state"]
    credential = inputs["credential"]

    # Construct the API URL for listing pull requests
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls"
    
    # Build query parameters
    params = {"state": state}
    
    # Prepare headers with authentication using the provided credential
    # Assuming 'credential' contains a token under the key 'token' or similar.
    # If the credential structure is different, adjust accordingly.
    auth_header = {
        "Authorization": f"Bearer {credential.get('token', '')}"
    }

    response = requests.get(url, params=params, headers=auth_header)

    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")

    data = response.json()
    
    # Return None for an empty successful response
    if not data:
        return None
    
    return data
```