```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (product ID) and 'new_price'.
        
    Returns:
        str or None: The response's 'id' value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    resource_id = inputs['resource_id']
    new_price = inputs['new_price']
    
    # Construct the update payload
    payload = {
        "price": new_price
    }
    
    # DummyJSON API endpoint for updating a product
    url = f"https://httpbin.org/put"  # Using httpbin as a proxy for demonstration
    
    try:
        response = requests.put(url, json=payload)
        
        if response.status_code >= 400:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
            
        # Return the 'id' from response if present, else None
        return response.json().get('id')
        
    except requests.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```