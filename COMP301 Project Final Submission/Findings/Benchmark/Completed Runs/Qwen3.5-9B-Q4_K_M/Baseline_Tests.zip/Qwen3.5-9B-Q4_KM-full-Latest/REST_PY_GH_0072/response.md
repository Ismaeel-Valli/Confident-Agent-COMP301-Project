```python
import requests

def solve(inputs):
    """
    Fetches a specific commit from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - page (int): The page number of results to fetch.
            - ref (str): The commit reference (e.g., branch, tag, or SHA).
            - credential (dict): Caller-supplied credentials with necessary permissions.
    
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    page = inputs["page"]
    ref = inputs["ref"]
    credential = inputs["credential"]

    # Construct the API URL for fetching a commit by SHA or ref
    url = f"https://api.github.com/repos/{owner}/{repo}/commits/{ref}"

    headers = {
        "Accept": "application/vnd.github.v3+json"
    }

    # Add authentication if credentials are provided (assuming token-based auth)
    if credential:
        token = credential.get("token") or credential.get("access_token")
        if token:
            headers["Authorization"] = f"Bearer {token}"

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        data = response.json()
        return None if not data else data
    elif response.status_code == 404:
        # Assuming resources exist as per instructions, but handling gracefully
        return None
    else:
        raise Exception(f"Failed to fetch commit. Status code: {response.status_code}, Response: {response.text}")
```