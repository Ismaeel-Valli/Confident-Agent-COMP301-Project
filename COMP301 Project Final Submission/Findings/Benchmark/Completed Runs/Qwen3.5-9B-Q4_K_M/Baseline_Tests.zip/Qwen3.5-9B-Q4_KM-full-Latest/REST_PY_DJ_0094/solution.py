import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the product.
            - new_price (float/int): New value for the price attribute.
    
    Returns:
        None if the response is successfully empty (204 No Content).
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    resource_id = inputs.get("resource_id")
    new_price = inputs.get("new_price")

    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"price": new_price}

    response = requests.patch(url, json=payload)

    if response.status_code == 204:
        return None

    if response.status_code != 200:
        raise Exception(f"Failed to update product. Status code: {response.status_code}, Response: {response.text}")

    return response.json()