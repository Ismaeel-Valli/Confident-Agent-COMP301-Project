```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post on DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_user_identifier' (new user ID).
        
    Returns:
        str or None: The response's 'id' value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    resource_id = inputs['resource_id']
    new_user_identifier = inputs['new_user_identifier']
    
    url = f"https://httpbin.org/post/{resource_id}"
    
    payload = {
        "user": new_user_identifier
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    # DummyJSON typically returns an empty body on successful update for this endpoint pattern,
    # but we check if 'id' is present in the JSON response.
    try:
        data = response.json()
        return data.get('id')
    except (ValueError, KeyError):
        # If parsing fails or 'id' is absent, return None as per spec for successful empty responses
        return None
```