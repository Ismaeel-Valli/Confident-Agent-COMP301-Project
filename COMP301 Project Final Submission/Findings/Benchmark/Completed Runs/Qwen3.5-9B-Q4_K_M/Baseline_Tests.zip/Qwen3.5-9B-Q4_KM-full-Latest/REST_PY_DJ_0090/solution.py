import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    new_body = inputs['new_body']
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    payload = {"body": new_body}
    
    response = requests.patch(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP Error: {response.status_code}, Message: {response.text}")
    
    data = response.json()
    
    # DummyJSON returns an empty object on successful update
    if not data or len(data) == 0:
        return None
    
    title = data.get('title')
    return title if title is not None else None