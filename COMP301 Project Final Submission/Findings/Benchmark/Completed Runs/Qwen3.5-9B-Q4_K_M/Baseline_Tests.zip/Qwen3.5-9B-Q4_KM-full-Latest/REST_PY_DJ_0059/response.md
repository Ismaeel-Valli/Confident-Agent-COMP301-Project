```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the todo to update.
            - new_completed (bool): New value for the completed attribute.
    
    Returns:
        None if the response is empty (successful update).
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    resource_id = inputs.get("resource_id")
    new_completed = inputs.get("new_completed")

    url = f"https://jsonplaceholder.typicode.com/todos/{resource_id}"
    payload = {"completed": new_completed}

    response = requests.put(url, json=payload)

    if response.status_code != 200:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}, Response: {response.text}")

    return None
```