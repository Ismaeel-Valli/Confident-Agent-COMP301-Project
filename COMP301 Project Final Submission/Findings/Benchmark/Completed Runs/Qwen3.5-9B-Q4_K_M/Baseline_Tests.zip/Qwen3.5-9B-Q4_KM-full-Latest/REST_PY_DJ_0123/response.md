```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the product.
            - new_category (str): New value for the category attribute.
    
    Returns:
        None if the response is successfully empty (204 No Content).
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response status code indicates an error.
    """
    resource_id = inputs.get("resource_id")
    new_category = inputs.get("new_category")
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {
        "category": new_category
    }
    
    response = requests.patch(url, json=payload)
    
    if response.status_code == 204:
        return None
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json()
```