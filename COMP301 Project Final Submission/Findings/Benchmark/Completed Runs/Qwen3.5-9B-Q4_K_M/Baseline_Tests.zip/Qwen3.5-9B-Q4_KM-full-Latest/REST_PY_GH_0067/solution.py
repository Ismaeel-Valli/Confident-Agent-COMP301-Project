import requests
import json

def solve(inputs):
    """
    Lists repositories for a given GitHub organization based on the specified types.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The name of the organization.
            - 'type' (str): The type of repositories to list ('all', 'public', or 'private').
            - 'credential' (str): The bearer token for authentication.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    organization = inputs.get("organization")
    repo_type = inputs.get("type")
    credential = inputs.get("credential")

    url = f"https://api.github.com/orgs/{organization}/repos"
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json"
    }
    
    params = {"type": repo_type}

    response = requests.get(url, headers=headers, params=params)

    if response.status_code != 200:
        raise Exception(f"Failed to retrieve repositories. Status code: {response.status_code}, Response: {response.text}")

    data = response.json()
    
    # Return None for a successful empty response (empty list)
    if not data:
        return None
    
    return data