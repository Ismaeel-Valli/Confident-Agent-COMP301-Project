```python
import requests
import json

def solve(inputs):
    """
    Creates an organization repository on GitHub using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization': The name of the organization.
            - 'new_name': The desired name for the new repository.
            - 'credential': A dictionary with authentication details (e.g., token).
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response indicates failure (non-2xx status code).
    """
    org = inputs['organization']
    repo_name = inputs['new_name']
    credential = inputs['credential']
    
    # Construct the API URL for creating a repository in an organization
    # Format: https://api.github.com/orgs/{org}/repos
    url = f"https://api.github.com/orgs/{org}/repos"
    
    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential.get('token', '')}"
    }
    
    # Payload for creating the repository
    payload = {
        "name": repo_name
    }
    
    response = requests.post(url, headers=headers, json=payload)
    
    if response.status_code == 201:
        # GitHub typically returns an empty body for successful creation of a repo
        return None
    elif response.status_code in [200, 202]:
        # Some endpoints might return 200 or 202 with data
        return response.json()
    else:
        raise Exception(f"Failed to create repository. Status code: {response.status_code}, Response: {response.text}")
```