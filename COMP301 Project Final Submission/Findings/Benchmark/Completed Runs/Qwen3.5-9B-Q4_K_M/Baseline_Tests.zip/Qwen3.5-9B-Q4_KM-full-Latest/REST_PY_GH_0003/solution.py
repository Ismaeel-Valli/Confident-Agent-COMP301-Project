import requests

def solve(inputs):
    """
    Deletes an organization using the GitHub REST API (version 2026-03-10).
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The name of the organization to delete.
            - 'credential' (str): The authentication token for the API request.
    
    Returns:
        None if the deletion is successful (empty response).
        The decoded JSON response if an error occurs.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    organization = inputs["organization"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/orgs/{organization}"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.delete(url, headers=headers)
    
    if response.status_code == 204:
        return None
    
    if response.status_code >= 400:
        return response.json()
    
    raise Exception(f"Unexpected status code: {response.status_code}")