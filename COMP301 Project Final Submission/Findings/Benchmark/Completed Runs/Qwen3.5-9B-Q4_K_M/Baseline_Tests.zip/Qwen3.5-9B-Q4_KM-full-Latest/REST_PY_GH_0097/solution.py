import requests
import json

def solve(inputs):
    """
    Creates a repository for the authenticated user via GitHub REST API.
    
    Args:
        inputs (dict): Contains 'new_name', 'new_description', and 'credential'.
        
    Returns:
        None if successful (empty response), otherwise decoded JSON response.
        
    Raises:
        Exception on unsuccessful HTTP response.
    """
    new_name = inputs["new_name"]
    new_description = inputs["new_description"]
    credential = inputs["credential"]
    
    # Assuming 'credential' is a dict with 'token' key for Authorization header
    headers = {
        "Authorization": f"Bearer {credential['token']}",
        "Accept": "application/vnd.github+json"
    }
    
    url = "https://api.github.com/user/repos"
    payload = {
        "name": new_name,
        "description": new_description
    }
    
    response = requests.post(url, headers=headers, json=payload)
    
    if response.status_code == 201:
        return None
    elif response.status_code == 403:
        raise Exception(f"Failed to create repository. Status code: {response.status_code}, Response: {response.text}")
    else:
        raise Exception(f"Failed to create repository. Status code: {response.status_code}, Response: {response.text}")