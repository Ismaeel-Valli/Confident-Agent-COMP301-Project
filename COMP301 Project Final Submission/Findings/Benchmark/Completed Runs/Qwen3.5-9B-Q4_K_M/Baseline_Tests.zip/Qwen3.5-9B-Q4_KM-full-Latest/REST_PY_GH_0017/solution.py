import requests
import json

def solve(inputs):
    """
    Creates a new issue in a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - new_title (str): The title for the new issue.
            - credential (dict): Caller-supplied credentials (assumed to have necessary permissions).
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    title = inputs["new_title"]
    credential = inputs["credential"]
    
    # Construct the URL for creating an issue
    url = f"https://api.github.com/repos/{owner}/{repo}/issues"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare the payload for creating an issue
    payload = {
        "title": title
    }
    
    # Send the POST request to create the issue
    response = requests.post(url, headers=headers, json=payload, auth=credential)
    
    # Check if the response is successful
    if response.status_code == 201:
        return None  # Successful creation with empty response body
    elif response.status_code == 202:
        return response.json()  # Accepted status, might have a JSON response
    else:
        raise Exception(f"Failed to create issue. Status code: {response.status_code}, Response: {response.text}")