```python
import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on the provided inputs.

    Args:
        inputs (dict): A dictionary containing 'result_limit' for pagination.

    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.

    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"  # Using a standard placeholder API as 'DummyJSON' isn't a specific public API endpoint without further context.
    
    # Assuming the user wants to fetch users from jsonplaceholder since it's a common test API.
    # If 'DummyJSON' refers to a specific custom endpoint, replace '/users' with that path.
    url = f"{base_url}/users"
    
    params = {
        "_limit": inputs.get("result_limit", 10)
    }

    try:
        response = requests.get(url, params=params)
        
        if response.status_code != 200:
            raise Exception(f"HTTP Error: Status code {response.status_code}")
        
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
            
        return data

    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```