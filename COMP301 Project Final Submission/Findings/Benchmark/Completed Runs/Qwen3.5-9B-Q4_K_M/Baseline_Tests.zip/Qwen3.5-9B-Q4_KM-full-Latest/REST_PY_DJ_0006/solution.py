import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'new_title' for the product title.
        
    Returns:
        None if the request is successful (empty response).
        The decoded JSON response otherwise.
        
    Raises:
        Exception if the HTTP response indicates an error.
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    # Prepare the payload with the new title and other required fields for a post
    payload = {
        "title": inputs["new_title"],
        "body": "Dummy body text",
        "userId": 1
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to submit product. HTTP Status Code: {response.status_code}")
    
    # DummyJSON typically returns an empty body for POST/PUT operations on this endpoint
    if not response.text.strip():
        return None
    
    return response.json()