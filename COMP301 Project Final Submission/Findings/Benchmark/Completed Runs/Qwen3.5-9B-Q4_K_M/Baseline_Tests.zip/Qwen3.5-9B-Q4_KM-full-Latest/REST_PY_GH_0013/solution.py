import requests

def solve(inputs):
    """
    Lists repository contributors for GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository without the .git extension.
            - 'credential' (str): The caller-supplied credential (e.g., token or Bearer string).
    
    Returns:
        list | None: A list of contributor dictionaries if contributors exist, decoded from JSON.
                     Returns None for a successful empty response.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/contributors"
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch contributors: HTTP {response.status_code}, body: {response.text}")
    
    data = response.json()
    
    return None if not data else data