```python
import requests
import json

def solve(inputs):
    """
    Submits a new user to DummyJSON using the provided first and last name.
    
    Args:
        inputs (dict): A dictionary containing 'new_firstName' and 'new_lastName'.
        
    Returns:
        None if the request is successful (empty response body).
        The decoded JSON response if the server returns data.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "name": f"{inputs['new_firstName']} {inputs['new_lastName']}",
        "email": "test@example.com",
        "address": {
            "street": "test street",
            "suite": "test suite",
            "city": "test city",
            "zipcode": "test zip",
            "geo": {
                "lat": "test lat",
                "lng": "test lng"
            }
        },
        "phone": "test phone",
        "website": "test website"
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. Status code: {response.status_code}, Response: {response.text}")
    
    if len(response.text) == 0:
        return None
    
    try:
        return response.json()
    except json.JSONDecodeError:
        raise Exception("Received non-JSON response from server.")
```