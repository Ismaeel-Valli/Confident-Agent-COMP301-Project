```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the user.
            - new_firstName (str): New value for the first name attribute.
    
    Returns:
        None if the response is empty (successful update).
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response status code indicates an error.
    """
    resource_id = inputs.get("resource_id")
    new_firstName = inputs.get("new_firstName")

    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {"firstName": new_firstName}

    response = requests.put(url, json=payload)

    if response.status_code != 200:
        raise Exception(f"Failed to update user: {response.text}")

    return None
```