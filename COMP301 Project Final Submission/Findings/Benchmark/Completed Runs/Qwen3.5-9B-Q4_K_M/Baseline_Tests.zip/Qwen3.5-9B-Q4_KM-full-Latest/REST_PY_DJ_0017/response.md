```python
import requests

def solve(inputs):
    """
    Searches posts using a search term from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'search_text' key with the search term.
        
    Returns:
        list or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    search_text = inputs.get("search_text", "")
    
    # Note: jsonplaceholder doesn't have a real search endpoint, but we'll simulate the logic
    # In a real scenario with DummyJSON that supports search, you would use their specific endpoint
    
    # For demonstration purposes with jsonplaceholder (which doesn't support search):
    # We'll fetch all posts and filter them locally to demonstrate the concept
    try:
        response = requests.get(base_url)
        response.raise_for_status()
        
        posts = response.json()
        
        # Filter posts based on search text (case-insensitive substring match)
        if not search_text:
            return None if len(posts) == 0 else posts
        
        filtered_posts = [post for post in posts if search_text.lower() in post.get("body", "").lower()]
        
        return None if len(filtered_posts) == 0 else filtered_posts
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"HTTP request failed: {str(e)}")
```