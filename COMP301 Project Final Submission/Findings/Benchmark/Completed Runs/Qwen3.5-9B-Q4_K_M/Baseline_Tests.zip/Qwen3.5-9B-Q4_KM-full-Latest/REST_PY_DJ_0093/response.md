```python
import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - included_fields (str): Comma-separated list of fields to include in the response.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"  # Using a stable public API for demonstration
    
    # Construct query parameters
    params = {
        "_limit": inputs["result_limit"],
        "_fields": inputs["included_fields"]
    }
    
    try:
        response = requests.get(f"{base_url}/posts", params=params)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None if the response is empty
        if not data:
            return None
            
        return data
        
    except requests.exceptions.HTTPError as errh:
        raise Exception(f"HTTP Error: {errh}")
    except requests.exceptions.ConnectionError as errc:
        raise Exception(f"Connection Error: {errc}")
    except requests.exceptions.Timeout as errt:
        raise Exception(f"Timeout Error: {errt}")
    except requests.exceptions.RequestException as err:
        raise Exception(f"Request Error: {err}")
```