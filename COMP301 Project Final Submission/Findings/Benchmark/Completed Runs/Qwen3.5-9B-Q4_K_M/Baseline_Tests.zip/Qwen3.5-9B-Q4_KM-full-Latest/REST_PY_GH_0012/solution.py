import requests
import json

def solve(inputs):
    """
    Fetches a specific commit from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'ref' (str): The commit reference (e.g., branch, tag, or SHA).
            - 'credential' (dict): A dictionary containing authentication details, 
                                  expected to have a 'token' key for Bearer token auth.
    
    Returns:
        dict or None: The decoded JSON response if successful. Returns None if the response body is empty.
    
    Raises:
        Exception: If the HTTP response status code indicates an error (non-2xx).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    ref = inputs['ref']
    credential = inputs['credential']
    
    # Construct the API URL for GitHub REST API version 2026-03-10
    url = f"https://api.github.com/repos/{owner}/{repo}/commits/{ref}"
    
    # Prepare headers with Bearer token authentication
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential.get('token', '')}",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"GitHub API request failed with status code {response.status_code}. Response body: {response.text}")
    
    # Decode the JSON response
    try:
        json_response = response.json()
    except json.JSONDecodeError:
        # If it's not valid JSON, treat as an error if there is content
        if response.text:
            raise Exception(f"GitHub API returned invalid JSON for status {response.status_code}. Body: {response.text}")
        else:
            return None
    
    # Return None for a successful empty response (though commits usually have data)
    if json_response == {}:
        return None
        
    return json_response