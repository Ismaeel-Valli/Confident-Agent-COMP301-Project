```python
import requests
import json

def solve(inputs):
    """
    Fetches an organization from the GitHub REST API (version 2026-03-10).
    
    Args:
        inputs (dict): A dictionary containing:
            - "organization" (str): The name of the organization.
            - "credential" (str): The Bearer token for authentication.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    org_name = inputs["organization"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/orgs/{org_name}"
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        return response.json() if response.text else None
    elif response.status_code >= 400:
        raise Exception(f"Failed to fetch organization '{org_name}': HTTP {response.status_code} - {response.text}")
    else:
        raise Exception(f"Unexpected status code for fetching organization '{org_name}': {response.status_code}")
```