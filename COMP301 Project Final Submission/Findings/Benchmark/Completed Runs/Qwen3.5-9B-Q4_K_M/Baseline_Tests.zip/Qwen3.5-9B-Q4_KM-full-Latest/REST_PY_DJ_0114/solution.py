import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' and 'new_price'.
        
    Returns:
        str or None: The response's title value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_price = inputs['new_price']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {"price": new_price}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns a success message in the body for PUT requests on specific resources
    # We check if 'title' exists in the response, otherwise return None
    if 'title' in data:
        return data['title']
    else:
        return None