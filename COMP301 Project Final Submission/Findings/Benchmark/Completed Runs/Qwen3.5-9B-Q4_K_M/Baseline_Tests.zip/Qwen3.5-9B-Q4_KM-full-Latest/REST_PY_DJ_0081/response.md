```python
import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on pagination inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip (for pagination).
    
    Returns:
        list or None: The decoded JSON response as a list of todos, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code outside 200-299).
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/todos"
    
    # Construct query parameters for pagination
    params = {
        "_limit": inputs.get("result_limit"),
        "_skip": inputs.get("results_to_skip")
    }
    
    url = f"{base_url}{endpoint}"
    
    try:
        response = requests.get(url, params=params)
        
        # Raise an exception for unsuccessful HTTP responses
        response.raise_for_status()
        
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
            
        return data
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP Error: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```