```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the user.
            - new_email (str): New value for the email attribute.
    
    Returns:
        None if the response is empty (successful update).
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    resource_id = inputs.get('resource_id')
    new_email = inputs.get('new_email')
    
    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {
        "email": new_email
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user. Status code: {response.status_code}, Response: {response.text}")
    
    return None
```