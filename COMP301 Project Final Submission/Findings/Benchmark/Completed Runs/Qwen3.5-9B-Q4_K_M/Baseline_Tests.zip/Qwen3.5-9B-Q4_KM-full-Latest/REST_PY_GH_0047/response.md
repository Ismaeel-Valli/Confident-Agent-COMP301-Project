```python
import requests

def solve(inputs):
    """
    Deletes a GitHub release using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - release_id (str): The unique identifier of the release.
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        int: The successful HTTP status code (typically 204).
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    release_id = inputs["release_id"]
    credential = inputs["credential"]
    
    # Construct the API URL for deleting a release
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/releases/{release_id}"
    
    # Prepare headers with authentication
    headers = {
        "Authorization": f"token {credential.get('token', '')}",
        "Accept": "application/vnd.github+json"
    }
    
    # Send DELETE request
    response = requests.delete(url, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    return response.status_code
```