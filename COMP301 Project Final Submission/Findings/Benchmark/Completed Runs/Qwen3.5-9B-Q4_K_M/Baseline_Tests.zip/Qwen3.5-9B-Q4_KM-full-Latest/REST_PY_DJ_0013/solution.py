import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON using the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'baseUrl' and optionally 'params'.
                       Example: {'baseUrl': 'https://jsonplaceholder.typicode.com/posts', 
                                'params': {'_limit': 10}}
    
    Returns:
        list or None: The decoded JSON response as a list of posts, or None if the response is empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails (non-2xx status code).
    """
    base_url = inputs.get('baseUrl')
    params = inputs.get('params', {})

    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Return None if the response is empty (e.g., empty list)
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Failed to retrieve posts from {base_url}: {str(e)}")