import requests

def solve(inputs):
    """
    Submits a new post to DummyJSON API with provided body, title, and user identifier.
    
    Args:
        inputs (dict): Contains 'new_body', 'new_title', and 'new_user_identifier'.
        
    Returns:
        int or None: The ID of the created post if present in response, otherwise None for success.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": inputs.get("new_title"),
        "body": inputs.get("new_body"),
        "userId": inputs.get("new_user_identifier")
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create post. Status code: {response.status_code}")
    
    data = response.json()
    
    # Return the id if present in response, otherwise None for successful empty response
    return data.get("id") if data else None