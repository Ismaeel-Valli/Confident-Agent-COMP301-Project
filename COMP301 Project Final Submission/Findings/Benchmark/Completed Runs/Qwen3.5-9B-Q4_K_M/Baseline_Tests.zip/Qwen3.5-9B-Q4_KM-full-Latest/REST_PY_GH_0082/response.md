```python
import requests

def solve(inputs):
    """
    Lists milestones for a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - state (str): The state of the milestone (e.g., 'open', 'closed').
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: Decoded JSON response, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    state = inputs["state"]
    credential = inputs["credential"]
    
    # Construct the API URL for listing milestones
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/milestones"
    
    # Prepare headers with authentication
    headers = {
        "Authorization": f"Bearer {credential['token']}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Add query parameters for filtering by state
    params = {"state": state}
    
    # Send the GET request
    response = requests.get(url, headers=headers, params=params)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Decode the JSON response
    json_response = response.json()
    
    # Return None if the response is empty (successful but no milestones found)
    if not json_response:
        return None
    
    return json_response
```