```python
import requests

def solve(inputs):
    resource_id = inputs.get("resource_id")
    
    url = f"https://dummyjson.com/users/{resource_id}"
    headers = {"Content-Type": "application/json"}
    
    try:
        response = requests.delete(url, headers=headers)
        
        if response.status_code != 200:
            raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
        
        # Check if the response is empty (no content)
        if not response.text.strip():
            return None
        
        # Try to parse JSON and extract 'id'
        try:
            data = response.json()
            return data.get("id")
        except ValueError:
            # If it's not valid JSON but has content, treat as missing id
            return None
            
    except requests.RequestException as e:
        raise Exception(f"Request failed: {e}")
```