import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON and returns the response's id value,
    or None if that attribute is absent or for a successful empty response.
    Raises an exception for an unsuccessful HTTP response.

    Args:
        inputs (dict): Contains 'resource_id' (todo ID) and 'new_completed' (new status).

    Returns:
        str or None: The updated todo's id, or None if absent or response is empty.

    Raises:
        Exception: If the HTTP response indicates failure (non-2xx status).
    """
    resource_id = inputs['resource_id']
    new_completed = inputs['new_completed']

    # DummyJSON API endpoint for updating a todo
    url = f"https://jsonplaceholder.typicode.com/todos/{resource_id}"
    payload = {"completed": new_completed}

    response = requests.put(url, json=payload)

    if response.status_code != 200:
        raise Exception(f"Failed to update todo: {response.status_code} - {response.text}")

    # DummyJSON returns the updated object on PUT for this endpoint
    data = response.json()

    # Return id if present, otherwise None
    return data.get("id")