import requests

def solve(inputs):
    """
    Lists watchers for a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git extension).
            - page_size (int): The number of results per page (max 100).
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        list or None: Decoded JSON response as a list of watchers, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    page_size = inputs["page_size"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{owner}/{repo}/watchers"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Prepare authentication based on credential type (assuming token or basic auth)
    if "token" in credential:
        headers["Authorization"] = f"Bearer {credential['token']}"
    elif "username" in credential and "password" in credential:
        auth = requests.auth.HTTPBasicAuth(credential["username"], credential["password"])
        response = requests.get(url, params={"per_page": page_size}, auth=auth, headers=headers)
    else:
        # Default to token if no other method is specified
        headers["Authorization"] = f"Bearer {credential['token']}"

    response = requests.get(url, params={"per_page": page_size}, headers=headers)

    if response.status_code != 200:
        raise Exception(f"Failed to list watchers. Status code: {response.status_code}, Response: {response.text}")

    data = response.json()
    
    # Return None for a successful empty response
    return data if data else None