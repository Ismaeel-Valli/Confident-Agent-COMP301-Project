```python
import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on included fields.
    
    Args:
        inputs (dict): A dictionary containing 'included_fields' as a comma-separated string.
        
    Returns:
        dict or None: The decoded JSON response if successful, None for an empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    included_fields = inputs.get('included_fields', '')
    
    # Construct the API URL with query parameters for fields and page size (1 page)
    url = "https://jsonplaceholder.typicode.com/users"
    params = {
        '_limit': 1,  # Retrieve one page (one user in this case as per standard pagination)
        '_fields': included_fields if included_fields else 'id,name,email'
    }
    
    response = requests.get(url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # Return None for an empty response
    if not data:
        return None
    
    return data
```