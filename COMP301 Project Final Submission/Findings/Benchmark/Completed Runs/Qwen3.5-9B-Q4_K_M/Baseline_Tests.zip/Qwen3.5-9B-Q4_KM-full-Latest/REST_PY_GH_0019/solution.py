import requests

def solve(inputs):
    """
    Updates an issue comment on GitHub using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - comment_id (int): The unique identifier of the comment.
            - new_body (str): The new content for the comment body.
            - credential (dict): Caller-supplied credentials (e.g., token in 'token' key).
    
    Returns:
        dict or None: Decoded JSON response if successful, None for an empty successful response.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    comment_id = inputs["comment_id"]
    new_body = inputs["new_body"]
    credential = inputs["credential"]

    # Construct the API URL for updating an issue comment
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/issues/comments/{comment_id}"

    # Prepare headers with authentication
    headers = {
        "Authorization": f"Bearer {credential.get('token', '')}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Prepare the payload
    payload = {
        "body": new_body
    }

    # Send PATCH request to update the comment
    response = requests.patch(url, headers=headers, json=payload)

    # Raise an exception for unsuccessful HTTP responses (non-2xx status codes)
    if response.status_code != 200:
        raise Exception(f"Failed to update issue comment. Status code: {response.status_code}, Response: {response.text}")

    # Return decoded JSON response, or None if the response is empty
    return response.json() if response.content else None