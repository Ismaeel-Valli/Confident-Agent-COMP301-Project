```python
import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on sorting criteria.
    
    Args:
        inputs (dict): A dictionary containing:
            - sort_field (str): Field used for ordering.
            - sort_direction (str): Ordering direction ('asc' or 'desc').
    
    Returns:
        list|None: The decoded JSON response as a list of posts, or None if the response is empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/posts"
    
    params = {
        "_limit": 1,
        "sort": inputs["sort_field"],
        "order": inputs["sort_direction"]
    }
    
    response = requests.get(f"{base_url}{endpoint}", params=params)
    
    if response.status_code != 200:
        raise requests.exceptions.RequestException(f"HTTP Error {response.status_code}: {response.text}")
    
    data = response.json()
    
    return data if data else None
```