```python
import requests

def solve(inputs):
    """
    Retrieves a post by identifier from DummyJSON API and returns its ID.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with the post identifier.
        
    Returns:
        str or None: The response's id value, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON endpoint for retrieving a post by ID
    url = f"https://dummyjson.com/posts/{resource_id}"
    
    response = requests.get(url)
    
    # Raise an exception for unsuccessful HTTP responses
    if response.status_code >= 400:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    # Check if the response is empty (no data)
    if not response.json():
        return None
    
    # Return the id value from the response
    return response.json().get('id')
```