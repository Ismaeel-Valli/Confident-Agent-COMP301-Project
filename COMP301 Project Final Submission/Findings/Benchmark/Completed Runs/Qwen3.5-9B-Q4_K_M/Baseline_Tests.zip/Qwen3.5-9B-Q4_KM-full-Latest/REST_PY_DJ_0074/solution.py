import requests

def solve(inputs):
    resource_id = inputs.get('resource_id')
    new_description = inputs.get('new_description')
    
    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {
        "description": new_description
    }
    
    response = requests.patch(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # DummyJSON returns the updated product object on PATCH for a specific resource
    if 'id' in data:
        return data['id']
    elif response.status_code == 204:
        return None
    else:
        return None