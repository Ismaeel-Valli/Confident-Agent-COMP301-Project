import requests

def solve(inputs):
    """
    Creates a fork of a GitHub repository using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner': str, The account owner of the repository.
            - 'repository_name': str, The name of the repository without the .git extension.
            - 'new_name': str, The new name for the forked repository.
            - 'credential': dict, Contains authentication details (e.g., token).
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty (successful), 
                      raises an exception on unsuccessful HTTP responses.
    
    Raises:
        requests.exceptions.RequestException: If the request fails with an error status code.
    """
    owner = inputs['repository_owner']
    repo_name = inputs['repository_name']
    new_name = inputs['new_name']
    credential = inputs['credential']
    
    # Construct the API URL for creating a fork
    url = f"https://api.github.com/repos/{owner}/{repo_name}/forks"
    
    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential.get('token', '')}"
    }
    
    params = {
        'name': new_name
    }
    
    response = requests.post(url, headers=headers, params=params)
    
    if response.status_code == 201:
        # GitHub returns a JSON object with the forked repository details on success
        return response.json()
    elif response.status_code == 204:
        # Some operations might return an empty body for success
        return None
    else:
        raise requests.exceptions.RequestException(
            f"Failed to create fork. Status code: {response.status_code}, Response: {response.text}"
        )