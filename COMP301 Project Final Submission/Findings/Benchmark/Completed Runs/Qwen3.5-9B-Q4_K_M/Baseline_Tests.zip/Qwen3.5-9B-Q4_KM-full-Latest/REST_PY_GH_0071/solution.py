import requests
import json

def solve(inputs):
    """
    Lists commits for a GitHub repository starting from a given SHA or branch.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - sha (str): SHA or branch to start listing commits from.
            - credential (str): Caller-supplied credential (e.g., token).
    
    Returns:
        dict or None: Decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    sha = inputs["sha"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/commits"
    headers = {
        "Authorization": f"token {credential}",
        "Accept": "application/vnd.github+json"
    }
    params = {"sha": sha}
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Failed to list commits. HTTP status code: {response.status_code}")
    
    data = response.json()
    
    return None if not data else data