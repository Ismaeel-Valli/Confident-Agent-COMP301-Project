import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON using the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'new_title' for the product title.
        
    Returns:
        int or None: The response's 'id' value if present, otherwise None for a successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    # Prepare the payload with the new title and other required fields for a post
    payload = {
        "title": inputs.get("new_title"),
        "body": "Dummy body text",  # DummyJSON requires 'body' field for posts
        "userId": 1  # Assuming referenced accounts exist as per instructions
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    # Check for successful empty response (no 'id' in JSON)
    if not response.json():
        return None
    
    # Return the id if present
    data = response.json()
    return data.get("id")