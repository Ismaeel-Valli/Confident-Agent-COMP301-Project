```python
import requests

def solve(inputs):
    """
    Submits a new todo to DummyJSON API.
    
    Args:
        inputs (dict): Contains 'new_completed', 'new_todo', and 'new_user_identifier'.
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    url = "https://dummyjson.com/todos"
    
    payload = {
        "completed": inputs.get("new_completed"),
        "todo": inputs.get("new_todo"),
        "userId": inputs.get("new_user_identifier")
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create todo. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # DummyJSON returns the created todo object directly in the response body for POST requests
    return data.get("id")
```