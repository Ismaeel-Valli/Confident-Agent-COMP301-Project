```python
import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    new_description = inputs['new_description']
    
    url = f"https://dummyjson.com/products/{resource_id}"
    headers = {
        "Content-Type": "application/json"
    }
    data = {
        "description": new_description
    }
    
    response = requests.patch(url, json=data, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
    
    # Check if the response is empty (no content)
    if not response.text.strip():
        return None
    
    # Parse the JSON response
    try:
        json_response = response.json()
    except ValueError:
        raise Exception("Invalid JSON response")
    
    # Return the title value if present, otherwise None
    return json_response.get('title')
```