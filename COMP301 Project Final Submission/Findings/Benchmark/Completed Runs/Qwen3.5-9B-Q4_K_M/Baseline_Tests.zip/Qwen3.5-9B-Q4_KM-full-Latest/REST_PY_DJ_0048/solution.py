import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API with the provided title.
    
    Args:
        inputs (dict): A dictionary containing 'new_title' key with the product title value.
        
    Returns:
        str or None: The response's title value if present, otherwise None for successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    # Prepare the data to be sent
    data = {
        "title": inputs["new_title"],
        "body": "Dummy body",
        "userId": 1
    }
    
    response = requests.post(url, json=data)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    # Check if title is present in the response
    if "title" in response.json():
        return response.json()["title"]
    else:
        return None