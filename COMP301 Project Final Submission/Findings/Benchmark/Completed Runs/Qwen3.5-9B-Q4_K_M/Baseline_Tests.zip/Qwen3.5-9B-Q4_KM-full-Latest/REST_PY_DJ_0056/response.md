```python
import requests

def solve(inputs):
    resource_id = inputs.get("resource_id")
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    headers = {"Content-Type": "application/json"}
    
    response = requests.delete(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to delete post. Status code: {response.status_code}")
    
    data = response.json()
    
    # If the response is empty (no content), return None
    if not data:
        return None
    
    # Return the title value if present, otherwise None
    return data.get("title")
```