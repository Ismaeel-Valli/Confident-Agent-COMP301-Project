import requests

def solve(inputs):
    """
    Lists repository issues for GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository without the .git extension.
            - 'credential' (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    credential = inputs['credential']
    
    # Construct the API URL for listing issues
    url = f"https://api.github.com/repos/{owner}/{repo}/issues"
    
    # Prepare headers with authentication
    headers = {
        'Accept': 'application/vnd.github.v3+json',
        'X-GitHub-Api-Version': '2026-03-10'
    }
    
    # Determine the authorization method based on credential type
    if 'token' in credential:
        headers['Authorization'] = f'token {credential["token"]}'
    elif 'username' in credential and 'password' in credential:
        auth = requests.auth.HTTPBasicAuth(credential['username'], credential['password'])
        response = requests.get(url, headers=headers, auth=auth)
    else:
        # If no standard auth is provided, assume the credential dict might have a custom header or method
        if 'headers' in credential:
            headers.update(credential['headers'])
        else:
            raise ValueError("Invalid credential format. Expected 'token', 'username/password', or 'headers'.")

    response = requests.get(url, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Decode the JSON response
    json_response = response.json()
    
    # Return None for a successful empty response
    if not json_response:
        return None
    
    return json_response