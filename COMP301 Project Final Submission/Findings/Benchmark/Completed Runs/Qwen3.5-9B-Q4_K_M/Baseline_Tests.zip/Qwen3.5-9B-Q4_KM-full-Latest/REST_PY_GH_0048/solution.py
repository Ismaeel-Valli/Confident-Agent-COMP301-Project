import requests
import json

def solve(inputs):
    """
    Lists stargazers for a given GitHub repository using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The caller-supplied credential (e.g., Bearer token or API key).
    
    Returns:
        list|None: A list of stargazer data if there are any, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    credential = inputs["credential"]
    
    url = f"https://api.github.com/repos/{owner}/{repo}/stargazers"
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch stargazers: HTTP {response.status_code}, Body: {response.text}")
    
    data = response.json()
    
    # GitHub API returns an empty list [] for no stargazers, not null.
    # The instruction says "Return None for a successful empty response".
    if len(data) == 0:
        return None
    
    return data