import requests

def solve(inputs):
    """
    Updates selected fields of a post on DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_body' (new body content).
        
    Returns:
        str or None: The response's 'id' value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_body = inputs['new_body']
    
    url = f"https://httpbin.org/post/{resource_id}"
    
    payload = {
        "body": new_body
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
    
    # Check if 'id' is present in the response JSON
    if 'id' in response.json():
        return response.json()['id']
    else:
        return None