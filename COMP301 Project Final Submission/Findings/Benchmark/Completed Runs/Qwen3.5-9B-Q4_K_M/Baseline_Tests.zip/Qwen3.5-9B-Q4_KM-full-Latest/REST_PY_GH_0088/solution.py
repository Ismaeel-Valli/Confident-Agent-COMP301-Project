import requests

def solve(inputs):
    """
    Lists commits on a GitHub pull request using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - pull_number (int): The pull request number.
            - page_size (int): Number of results per page (max 100).
            - credential (dict): Caller-supplied credentials (e.g., token or auth headers).
    
    Returns:
        dict or None: Decoded JSON response, or None if the response is empty but successful.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    pr_number = inputs["pull_number"]
    page_size = inputs["page_size"]
    credential = inputs["credential"]

    # Construct the API URL for GitHub REST API version 2026-03-10
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}/commits"
    
    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Add authentication based on credential type (assuming token in 'token' key for simplicity)
    if isinstance(credential, dict):
        if "token" in credential:
            headers["Authorization"] = f"Bearer {credential['token']}"
        elif "headers" in credential:
            headers.update(credential["headers"])

    params = {"per_page": page_size}

    response = requests.get(url, headers=headers, params=params)

    if response.status_code != 200:
        raise Exception(f"Failed to fetch commits: HTTP {response.status_code}, Response: {response.text}")

    data = response.json()

    # Return None for an empty list (successful but no results)
    if not data:
        return None

    return data