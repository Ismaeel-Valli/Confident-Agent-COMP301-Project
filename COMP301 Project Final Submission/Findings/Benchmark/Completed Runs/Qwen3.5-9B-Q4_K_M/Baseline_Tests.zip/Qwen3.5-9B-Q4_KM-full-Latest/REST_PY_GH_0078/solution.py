import requests

def solve(inputs):
    """
    Lists issue comments for a specific GitHub repository issue using the GitHub REST API.
    
    Parameters:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git extension).
            - 'issue_number' (int): The issue number to fetch comments for.
            - 'since' (str, optional): ISO 8601 timestamp string; only returns comments updated after this time.
            - 'credential' (dict): Contains authentication details (e.g., token in 'token' key).
    
    Returns:
        dict or None: The decoded JSON response containing the list of issue comments, or None if empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    issue_number = inputs['issue_number']
    since = inputs.get('since')
    credential = inputs['credential']
    
    # Construct the API URL for listing comments on an issue
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}/comments"
    
    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "Authorization": f"Bearer {credential.get('token', '')}"
    }
    
    params = {}
    if since:
        params['since'] = since
    
    response = requests.get(url, headers=headers, params=params)
    
    if response.status_code == 200:
        data = response.json()
        return None if len(data) == 0 else data
    elif response.status_code == 404:
        raise Exception(f"Resource not found: {response.url}")
    else:
        error_msg = f"HTTP Error {response.status_code}: {response.text}"
        raise Exception(error_msg)