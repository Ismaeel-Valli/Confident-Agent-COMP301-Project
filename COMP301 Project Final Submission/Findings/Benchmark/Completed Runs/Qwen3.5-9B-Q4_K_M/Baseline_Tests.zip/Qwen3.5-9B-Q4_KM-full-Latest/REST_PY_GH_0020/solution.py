import requests

def solve(inputs):
    """
    Deletes a GitHub issue comment using the GitHub REST API.
    
    Parameters:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - comment_id (int): The unique identifier of the comment to delete.
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        int: The successful HTTP status code (e.g., 204).
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    comment_id = inputs["comment_id"]
    credential = inputs["credential"]

    # Construct the API URL for deleting a comment
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/comments/{comment_id}"

    headers = {
        "Accept": "application/vnd.github+json"
    }

    # Prepare authentication based on credential type (assuming token or similar)
    if isinstance(credential, str):
        auth_header = f"token {credential}"
    elif isinstance(credential, dict):
        token = credential.get("token") or credential.get("access_token")
        if not token:
            raise ValueError("Credential must contain a 'token' or 'access_token'.")
        auth_header = f"token {token}"
    else:
        raise ValueError("Credential must be a string or dict containing a token.")

    headers["Authorization"] = auth_header

    response = requests.delete(url, headers=headers)
    
    if response.status_code == 204:
        return response.status_code
    else:
        raise Exception(f"Failed to delete comment. Status code: {response.status_code}, Response: {response.text}")