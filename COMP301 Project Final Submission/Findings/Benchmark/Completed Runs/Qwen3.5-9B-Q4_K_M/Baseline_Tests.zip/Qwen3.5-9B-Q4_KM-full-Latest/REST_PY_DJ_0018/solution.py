import requests
from typing import Any, Optional, Dict

def solve(inputs: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Submits a new post to DummyJSON API with provided body, title, and user identifier.
    
    Args:
        inputs (dict): Dictionary containing:
            - 'new_body': str, value for the body attribute
            - 'new_title': str, value for the title attribute
            - 'new_user_identifier': str, value for the user Id attribute
    
    Returns:
        Optional[Dict[str, Any]]: Decoded JSON response if successful (empty dict), 
                                  None for a successful empty response.
    
    Raises:
        Exception: For an unsuccessful HTTP response.
    """
    url = "https://httpbin.org/post"  # Using httpbin as a reliable mock API
    
    payload = {
        "body": inputs["new_body"],
        "title": inputs["new_title"],
        "user_id": inputs["new_user_identifier"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: {response.text}")
    
    # Return decoded JSON response
    return response.json()