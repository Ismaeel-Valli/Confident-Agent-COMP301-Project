import requests

def solve(inputs):
    """
    Lists stargazers for a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - page_size (int): Number of results per page (max 100).
            - credential (str): Bearer token for authentication.
    
    Returns:
        list or None: Decoded JSON response as a list of stargazers, or None if empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    page_size = inputs["page_size"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{owner}/{repo}/stargazers"
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github.v3+json"
    }

    params = {"per_page": page_size}

    response = requests.get(url, headers=headers, params=params)

    if response.status_code != 200:
        raise Exception(f"Failed to fetch stargazers. Status code: {response.status_code}, Response: {response.text}")

    data = response.json()
    
    # Return None for a successful empty response
    return data if data else None