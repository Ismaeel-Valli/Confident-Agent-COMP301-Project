import requests

def solve(inputs):
    """
    Deletes a milestone from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'milestone_number' (int): The number identifying the milestone.
            - 'credential' (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        int: The successful HTTP status code (e.g., 204).
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful operation.
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    milestone_number = inputs['milestone_number']
    credential = inputs['credential']
    
    # Construct the API URL for deleting a milestone (GitHub v2026-03-10)
    url = f"https://api.github.com/repos/{owner}/{repo}/milestones/{milestone_number}"
    
    headers = {
        'Accept': 'application/vnd.github+json'
    }
    
    # If the credential contains a token, include it in the Authorization header.
    if 'token' in credential:
        headers['Authorization'] = f"Bearer {credential['token']}"
    
    response = requests.delete(url, headers=headers)
    
    if response.status_code == 204:
        return response.status_code
    
    # Raise an exception for any unsuccessful HTTP response
    response.raise_for_status()