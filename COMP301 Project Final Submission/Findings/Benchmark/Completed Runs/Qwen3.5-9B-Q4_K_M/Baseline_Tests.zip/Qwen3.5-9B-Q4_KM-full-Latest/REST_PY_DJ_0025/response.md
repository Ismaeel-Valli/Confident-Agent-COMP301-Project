```python
import requests

def solve(inputs):
    """
    Retrieve a product by identifier from DummyJSON and return its 'id' value.
    
    Args:
        inputs (dict): A dictionary containing 'resource_id' as the product identifier.
        
    Returns:
        str or None: The 'id' of the product if present, or None for an empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON endpoint to get a single item by ID
    url = f"https://dummyjson.com/products/{resource_id}"
    
    response = requests.get(url)
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    # Check for empty response (no product found, though status might be 200 with empty body)
    if not response.json():
        return None
    
    data = response.json()
    
    # Return the 'id' attribute if it exists, otherwise None
    return data.get('id')
```