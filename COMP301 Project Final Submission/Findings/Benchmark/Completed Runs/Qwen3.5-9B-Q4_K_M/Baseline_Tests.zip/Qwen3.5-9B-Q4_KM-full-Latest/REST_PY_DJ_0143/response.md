```python
import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on sorting criteria.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'sort_field' (str): Field used for ordering.
            - 'sort_direction' (str): Ordering direction ('asc' or 'desc').
    
    Returns:
        list|None: The decoded JSON response as a list of users, or None if the response is empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com/users"
    
    # Construct query parameters
    params = {
        '_sort': inputs['sort_field'],
        '_order': inputs['sort_direction']
    }
    
    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        data = response.json()
        
        # Return None if the response is empty (though this endpoint typically returns a list)
        return data if data else None
        
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Failed to retrieve users: {e}") from e
```