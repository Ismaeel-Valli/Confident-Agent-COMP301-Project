```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id', 'new_todo', and 'new_user_identifier'.
        
    Returns:
        str or None: The response's id value, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_todo = inputs['new_todo']
    new_user_identifier = inputs['new_user_identifier']
    
    # Construct the update payload
    payload = {
        "todo": new_todo,
        "user_id": new_user_identifier
    }
    
    # Endpoint for updating a todo (assuming standard DummyJSON structure)
    url = f"https://jsonplaceholder.typicode.com/todos/{resource_id}"
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: Update failed")
    
    # DummyJSON typically returns the updated object or an empty object {}
    data = response.json()
    
    if not data:
        return None
    
    return data.get("id")
```