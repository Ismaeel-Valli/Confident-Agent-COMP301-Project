import requests

def solve(inputs):
    """
    Updates a pull request on GitHub using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - pull_number (int): The number that identifies the pull request.
            - new_title (str): The new title for the pull request.
            - credential (dict): Caller-supplied credentials (e.g., token in 'token' key).
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response indicates an error (status code >= 400).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    pr_number = inputs["pull_number"]
    new_title = inputs["new_title"]
    credential = inputs["credential"]

    # Construct the API URL for updating a pull request
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}"

    headers = {
        "Accept": "application/vnd.github.v3+json",
        "Authorization": f"Bearer {credential.get('token', '')}"
    }

    data = {
        "title": new_title
    }

    response = requests.put(url, json=data, headers=headers)

    if response.status_code >= 400:
        raise Exception(f"Failed to update pull request. Status code: {response.status_code}, Response: {response.text}")

    return response.json() if response.text else None