import requests
import json

def solve(inputs):
    """
    Creates a label in a GitHub repository using the REST API version 2026-03-10.
    
    Note: The 'new_name' parameter in the inputs dictionary is ambiguous for creating a label.
    Typically, creating a label requires 'name', 'color', and optionally 'description'.
    Assuming 'new_name' refers to the 'name' of the new label based on the context of creating something new.
    
    Parameters:
    inputs (dict): A dictionary containing:
        - repository_owner (str): The account owner of the repository.
        - repository_name (str): The name of the repository without the .git extension.
        - credential (str): The caller-supplied credential (e.g., token).
        - new_name (str): The name for the new label to be created.
    
    Returns:
    dict or None: The decoded JSON response if successful, or None for an empty successful response.
    
    Raises:
    Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    credential = inputs["credential"]
    new_label_name = inputs["new_name"]  # Assuming 'new_name' is the name of the label to create
    
    # Construct the API URL for creating a label in version 2026-03-10
    # The standard endpoint for creating a label is: /repos/{owner}/{repo}/labels
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/labels"
    
    headers = {
        "Accept": "application/vnd.github.v3+json",  # Standard GitHub API version header
        "Authorization": f"token {credential}"       # Using token-based authentication
    }
    
    data = {
        "name": new_label_name,
        "color": "FF0000"  # Default color (red) if not specified; you might want to allow this as an input or use a default
    }
    
    response = requests.post(url, headers=headers, json=data)
    
    if response.status_code == 201:
        # Successful creation
        return None if response.text.strip() == "" else response.json()
    elif response.status_code == 422:
        # Validation error (e.g., label name already exists or invalid format)
        raise Exception(f"Validation Error: {response.json().get('message', 'Unknown validation error')}")
    else:
        # Other errors (e.g., 403 Forbidden, 404 Not Found, etc.)
        raise Exception(f"HTTP {response.status_code}: {response.text}")