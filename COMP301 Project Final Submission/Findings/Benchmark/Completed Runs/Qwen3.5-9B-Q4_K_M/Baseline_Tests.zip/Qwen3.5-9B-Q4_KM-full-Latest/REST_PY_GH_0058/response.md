```python
import requests

def solve(inputs):
    """
    Checks if a repository is starred by the authenticated user using GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner': str, The account owner of the repository.
            - 'repository_name': str, The name of the repository without the .git extension.
            - 'credential': dict, Caller-supplied credential with necessary permissions 
              (assumed to contain 'token' key for Authorization header).
    
    Returns:
        int: The successful HTTP status code (e.g., 204 No Content if not starred, 
             or 200 OK if starred, depending on implementation; typically 204 for unstarred check).
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo_name = inputs["repository_name"]
    credential = inputs["credential"]
    
    # Construct the API endpoint for checking if a repository is starred by the authenticated user
    url = f"https://api.github.com/user/starred/{owner}/{repo_name}"
    
    headers = {
        "Accept": "application/vnd.github+json"
    }
    
    # Add authorization header using the token from credential
    auth_token = credential.get("token")
    if auth_token:
        headers["Authorization"] = f"Bearer {auth_token}"
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 204:
        # Repository is not starred by the authenticated user
        return 204
    elif response.status_code == 200:
        # Repository is starred by the authenticated user
        return 200
    else:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
```