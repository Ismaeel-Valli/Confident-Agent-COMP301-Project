```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_user_identifier' (new user ID).
        
    Returns:
        str or None: The title from the response if present, otherwise None for empty success responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_user_identifier = inputs['new_user_identifier']
    
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    payload = {
        "userId": new_user_identifier
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
    
    # DummyJSON typically returns an empty object {} on successful PUT for this endpoint
    data = response.json()
    
    if not data:
        return None
    
    return data.get("title")
```