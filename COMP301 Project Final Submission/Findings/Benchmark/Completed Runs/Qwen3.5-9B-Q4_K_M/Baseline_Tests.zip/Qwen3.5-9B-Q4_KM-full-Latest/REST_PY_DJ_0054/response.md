```python
import requests

def solve(inputs):
    resource_id = inputs.get("resource_id")
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"Failed to retrieve post: {response.status_code}")
    
    data = response.json()
    
    if not data.get("title"):
        return None
    
    return data["title"]
```