```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API using the provided inputs.
    
    Args:
        inputs (dict): Contains 'new_description' and 'new_title'.
        
    Returns:
        int or None: The ID of the created product, or None if response is empty/None.
        
    Raises:
        Exception: If the HTTP response indicates an error (status code >= 400).
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": inputs.get("new_title"),
        "body": inputs.get("new_description")
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Failed to submit product. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # DummyJSON posts endpoint returns the created object with an 'id' field
    return data.get("id") if data else None
```