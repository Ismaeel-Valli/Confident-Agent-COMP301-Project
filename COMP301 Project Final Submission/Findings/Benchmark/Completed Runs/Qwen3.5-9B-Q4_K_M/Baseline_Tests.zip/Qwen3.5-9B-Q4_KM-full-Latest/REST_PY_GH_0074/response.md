```python
import requests

def solve(inputs):
    """
    Lists forks for a given GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - sort (str): The sort order for the forks list.
            - credential (str): The caller-supplied credential (e.g., Bearer token or API key).
    
    Returns:
        dict or None: The decoded JSON response if successful, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    sort_order = inputs["sort"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{owner}/{repo}/forks"
    
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "Authorization": f"Bearer {credential}"
    }

    params = {"sort": sort_order}

    response = requests.get(url, headers=headers, params=params)

    if response.status_code != 200:
        raise Exception(f"Failed to list forks: HTTP {response.status_code}, Response: {response.text}")

    data = response.json()

    # Return None for a successful empty response
    return data if data else None
```