```python
import requests
import json

def solve(inputs):
    """
    Lists files changed in a specific pull request for a GitHub repository.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - pull_number (int): The number that identifies the pull request.
            - credential (dict): Caller-supplied credentials (e.g., token in 'token' key).
    
    Returns:
        dict or None: Decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not 200-299).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    pr_number = inputs["pull_number"]
    credential = inputs["credential"]

    # Construct the API URL for GitHub REST API version 2026-03-10
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}/files"

    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Prepare authentication header from the provided credential
    if isinstance(credential, dict):
        token = credential.get("token") or credential.get("access_token")
        if not token:
            raise ValueError("Credential must contain a 'token' or 'access_token'.")
        headers["Authorization"] = f"Bearer {token}"
    else:
        raise ValueError("Credential must be a dictionary containing authentication details.")

    response = requests.get(url, headers=headers)

    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")

    data = response.json()

    # Return None for a successful empty response (e.g., no files changed)
    if not data:
        return None

    return data
```