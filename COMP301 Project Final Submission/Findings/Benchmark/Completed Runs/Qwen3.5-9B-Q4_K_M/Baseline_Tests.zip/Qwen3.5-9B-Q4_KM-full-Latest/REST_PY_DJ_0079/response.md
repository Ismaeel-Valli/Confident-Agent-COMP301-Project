```python
import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on the provided sort field.
    
    Args:
        inputs (dict): A dictionary containing 'sort_field' for ordering posts.
        
    Returns:
        list or None: The decoded JSON response as a list of posts, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code outside 200-299).
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/posts"
    
    # Construct the request URL with the sort parameter
    url = f"{base_url}{endpoint}?sort={inputs['sort_field']}"
    
    try:
        response = requests.get(url)
        
        # Raise an exception for unsuccessful HTTP responses (status code outside 200-299)
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None for a successful empty response
        if not data:
            return None
            
        return data
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```