import requests

def solve(inputs):
    """
    Unfollow a GitHub user using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The handle for the GitHub user account to unfollow.
            - 'credential' (dict): Caller-supplied credentials with necessary permissions.
    
    Returns:
        int: The successful HTTP status code (typically 204 No Content).
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    username = inputs['username']
    credential = inputs['credential']
    
    # Construct the URL to unfollow a user
    url = f"https://api.github.com/user/{username}/following{/}"
    
    # Prepare headers with authentication
    headers = {
        'Authorization': f'Bearer {credential.get("token", "")}',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2026-03-10'
    }
    
    # Make the DELETE request to unfollow the user
    response = requests.delete(url, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    return response.status_code