import requests

def solve(inputs):
    resource_id = inputs.get('resource_id')
    new_email = inputs.get('new_email')
    
    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {
        "email": new_email
    }
    
    response = requests.patch(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Check for 'id' in the response
    if 'id' in data:
        return data['id']
    elif response.status_code == 204:  # Successful empty response
        return None
    else:
        return None