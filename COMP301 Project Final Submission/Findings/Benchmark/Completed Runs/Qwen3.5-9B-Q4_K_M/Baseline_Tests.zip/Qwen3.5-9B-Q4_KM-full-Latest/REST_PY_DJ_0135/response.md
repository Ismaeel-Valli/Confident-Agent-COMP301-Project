```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the user to update.
            - new_username (str): New value for the username attribute.
    
    Returns:
        None if the HTTP response is empty (successful update).
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    resource_id = inputs.get("resource_id")
    new_username = inputs.get("new_username")
    
    url = f"https://httpbin.org/put"
    payload = {
        "resource_id": resource_id,
        "new_username": new_username
    }
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user: HTTP {response.status_code} - {response.text}")
    
    return None
```