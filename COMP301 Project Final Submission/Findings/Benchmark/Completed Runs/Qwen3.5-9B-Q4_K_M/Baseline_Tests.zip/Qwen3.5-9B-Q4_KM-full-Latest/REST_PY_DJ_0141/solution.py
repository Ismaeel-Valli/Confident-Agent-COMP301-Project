import requests

def solve(inputs):
    resource_id = inputs.get("resource_id")
    new_category = inputs.get("new_category")
    
    url = f"https://dummyjson.com/products/{resource_id}"
    headers = {
        "Content-Type": "application/json"
    }
    payload = {
        "category": new_category
    }
    
    response = requests.patch(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update product: HTTP {response.status_code}, Body: {response.text}")
    
    data = response.json()
    
    if not data.get("title"):
        return None
    
    return data["title"]