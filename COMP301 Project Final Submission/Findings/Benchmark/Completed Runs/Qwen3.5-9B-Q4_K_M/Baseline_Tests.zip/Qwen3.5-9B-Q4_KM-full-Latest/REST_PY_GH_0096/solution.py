import requests

def solve(inputs):
    """
    Lists repositories for the authenticated user using GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'credential': The caller-supplied credential (e.g., token or auth tuple).
            - 'visibility': Optional string to limit results ('public', 'private', or 'all').
    
    Returns:
        dict or None: Decoded JSON response if successful. Returns None for an empty list.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status).
    """
    url = "https://api.github.com/user/repos"
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    params = {}
    if inputs.get("visibility"):
        visibility = inputs["visibility"].lower()
        if visibility not in ("public", "private", "all"):
            raise ValueError(f"Invalid visibility: {inputs['visibility']}. Must be 'public', 'private', or 'all'.")
        params["visibility"] = visibility

    response = requests.get(url, headers=headers, params=params, auth=inputs["credential"])

    if not response.ok:
        raise Exception(f"GitHub API request failed with status {response.status_code}: {response.text}")

    data = response.json()

    # Return None for an empty list of repositories
    if not data:
        return None

    return data