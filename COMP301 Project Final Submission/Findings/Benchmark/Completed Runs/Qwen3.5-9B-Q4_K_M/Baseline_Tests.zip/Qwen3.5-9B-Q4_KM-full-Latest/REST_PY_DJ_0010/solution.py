import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    
    url = f"https://dummyjson.com/users/{resource_id}"
    response = requests.delete(url)
    
    if response.status_code != 200:
        raise Exception(f"Failed to delete user. Status code: {response.status_code}, Response: {response.text}")
    
    return None