import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    new_title = inputs['new_title']
    
    url = f"https://dummyjson.com/posts/{resource_id}"
    payload = {"title": new_title}
    
    response = requests.patch(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP Error: {response.status_code}")
    
    data = response.json()
    
    if 'title' in data and data['title'] is not None:
        return data['title']
    elif response.status_code == 204:
        return None
    else:
        return None