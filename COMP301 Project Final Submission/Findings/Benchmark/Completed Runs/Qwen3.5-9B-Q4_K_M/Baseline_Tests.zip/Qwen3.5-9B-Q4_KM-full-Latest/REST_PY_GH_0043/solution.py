import requests
import json

def solve(inputs):
    """
    Creates a release on GitHub using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - new_tag_name (str): Value for the tag name attribute.
            - credential (dict): Caller-supplied credentials with necessary permissions.
    
    Returns:
        dict or None: Decoded JSON response if successful, None for an empty successful response.
    
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    new_tag_name = inputs["new_tag_name"]
    credential = inputs["credential"]
    
    # Construct the API URL for creating a release
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/releases"
    
    # Prepare headers with authentication
    headers = {
        "Authorization": f"token {credential.get('token', '')}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare the payload for creating a release
    data = {
        "tag_name": new_tag_name,
        "name": new_tag_name,  # Optional: name of the release
        "draft": False         # Optional: set to True if you want a draft release
    }
    
    try:
        response = requests.post(url, headers=headers, json=data)
        
        # Raise an exception for unsuccessful HTTP responses
        response.raise_for_status()
        
        # Return decoded JSON response
        return response.json()
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Failed to create release: {e}")