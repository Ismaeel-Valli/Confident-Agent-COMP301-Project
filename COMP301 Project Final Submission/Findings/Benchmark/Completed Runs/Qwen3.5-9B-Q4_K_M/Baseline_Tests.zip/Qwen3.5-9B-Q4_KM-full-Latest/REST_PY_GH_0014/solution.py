import requests

def solve(inputs):
    """
    Lists forks for a given GitHub repository using the specified API version.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The caller-supplied credential (e.g., Authorization token or Bearer token).
    
    Returns:
        list | None: Decoded JSON response as a list of fork objects, or None if the response is empty.
    
    Raises:
        requests.exceptions.HTTPError: If the HTTP response status code indicates an error (4xx or 5xx).
    """
    owner = inputs["repository_owner"]
    repo_name = inputs["repository_name"]
    credential = inputs["credential"]
    
    # GitHub REST API endpoint for listing forks
    url = f"https://api.github.com/repos/{owner}/{repo_name}/forks"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code >= 400:
        raise requests.exceptions.HTTPError(f"HTTP {response.status_code}: {response.text}")
    
    data = response.json()
    
    # Return None for a successful empty response
    if not data:
        return None
    
    return data