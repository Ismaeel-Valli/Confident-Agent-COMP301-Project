```python
import requests

def solve(inputs):
    """
    Lists labels for a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - page_size (int): Number of results per page (max 100).
            - credential (str): Bearer token or OAuth token for authentication.
    
    Returns:
        dict or None: Decoded JSON response if labels exist, None if empty list.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx/3xx).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    page_size = inputs["page_size"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{owner}/{repo}/labels"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json"
    }

    params = {
        "per_page": min(page_size, 100)
    }

    response = requests.get(url, headers=headers, params=params)

    if not (200 <= response.status_code < 400):
        raise Exception(f"Failed to fetch labels: HTTP {response.status_code} - {response.text}")

    data = response.json()

    # GitHub returns an empty list [] for no labels, which is a successful response.
    if not data:
        return None

    return data
```