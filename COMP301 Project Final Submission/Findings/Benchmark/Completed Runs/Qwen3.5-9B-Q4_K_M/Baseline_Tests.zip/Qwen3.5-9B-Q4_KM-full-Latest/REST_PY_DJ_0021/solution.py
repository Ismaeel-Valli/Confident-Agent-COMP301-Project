import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    new_todo = inputs['new_todo']
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    headers = {
        "Content-Type": "application/json"
    }
    payload = {"todo": new_todo}
    
    response = requests.patch(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"HTTP Error: {response.status_code}, Message: {response.text}")
    
    return None