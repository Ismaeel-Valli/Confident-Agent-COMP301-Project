import requests

def solve(inputs):
    """
    Updates an issue in a GitHub repository using the REST API.
    
    Parameters:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'issue_number' (int): The issue number to update.
            - 'new_body' (str): The new body content for the issue.
            - 'credential' (dict): Contains authentication details, assumed to have necessary permissions.
    
    Returns:
        dict or None: Decoded JSON response if successful and non-empty; None if the response is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    issue_number = inputs['issue_number']
    new_body = inputs['new_body']
    credential = inputs['credential']

    # Construct the API URL for updating an issue
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}"

    # Prepare headers with authentication
    headers = {
        "Authorization": f"Bearer {credential.get('token', '')}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Prepare the payload for updating the issue body
    payload = {
        "body": new_body
    }

    # Send PATCH request to update the issue
    response = requests.patch(url, headers=headers, json=payload)

    # Check if the request was successful
    if response.status_code == 200:
        return response.json() if response.text else None
    elif response.status_code == 404:
        raise Exception(f"Resource not found: {response.url}")
    elif response.status_code == 403:
        raise Exception("Forbidden: Insufficient permissions or invalid token.")
    else:
        raise Exception(f"Failed to update issue. Status code: {response.status_code}, Response: {response.text}")