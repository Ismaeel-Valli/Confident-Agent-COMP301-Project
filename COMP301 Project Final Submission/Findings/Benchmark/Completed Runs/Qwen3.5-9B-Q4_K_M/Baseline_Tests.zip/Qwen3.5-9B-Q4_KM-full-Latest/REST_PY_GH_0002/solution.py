import requests
from requests.exceptions import RequestException, HTTPError


def solve(inputs):
    """
    Updates an organization's name via the GitHub REST API (version 2026-03-10).
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The organization name.
            - 'new_name' (str): The new name for the organization.
            - 'credential' (str): The bearer token or authentication string.
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, 
                      None if the response is empty (success).
    
    Raises:
        Exception: If the HTTP response indicates an error.
    """
    organization = inputs['organization']
    new_name = inputs['new_name']
    credential = inputs['credential']
    
    url = f"https://api.github.com/orgs/{organization}"
    headers = {
        'Accept': 'application/vnd.github+json',
        'Authorization': f'Bearer {credential}'
    }
    
    payload = {'name': new_name}
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code == 204:
        return None
    
    if response.status_code != 200:
        raise Exception(f"Failed to update organization: {response.status_code} - {response.text}")
    
    try:
        return response.json()
    except ValueError as e:
        raise Exception(f"Invalid JSON response from GitHub API: {e}")