```python
import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - results_to_skip (int): Number of results to skip (for pagination).
            - included_fields (str): Comma-separated list of fields to include in the response.
    
    Returns:
        list or None: A list of todo items if results are found, None for an empty successful response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code 4xx or 5xx).
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/todos"
    
    # Parse included_fields
    fields = [f.strip() for f in inputs["included_fields"].split(",")]
    
    # Construct query parameters
    params = {
        "_limit": inputs["result_limit"],
        "_skip": inputs["results_to_skip"],
        "_fields": ",".join(fields)
    }
    
    url = f"{base_url}{endpoint}"
    
    try:
        response = requests.get(url, params=params)
        
        # Raise an exception for unsuccessful HTTP responses
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None if the response is empty (successful empty response)
        if not data:
            return None
        
        return data
    
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")
```