import requests

def solve(inputs):
    """
    Lists branches for a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - page_size (int): Number of results per page (max 100).
            - credential (str): Bearer token for authentication.
    
    Returns:
        dict or None: Decoded JSON response, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    page_size = inputs["page_size"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{owner}/{repo}/branches"
    
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    params = {
        "per_page": page_size
    }

    response = requests.get(url, headers=headers, params=params)

    if response.status_code != 200:
        raise Exception(f"Failed to list branches. Status code: {response.status_code}, Response: {response.text}")

    data = response.json()

    # Return None for a successful empty response (i.e., no branches found)
    if not data:
        return None

    return data