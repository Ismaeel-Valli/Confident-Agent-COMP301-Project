import requests

def solve(inputs):
    """
    Lists repository issues for GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - state (str): Indicates the state of the issues to return ('open', 'closed', or 'all').
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response, or None for a successful empty response.
    
    Raises:
        Exception: For an unsuccessful HTTP response.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    state = inputs["state"]
    credential = inputs["credential"]
    
    # Construct the API URL for listing issues
    url = f"https://api.github.com/repos/{owner}/{repo}/issues"
    
    # Prepare headers with authentication using the provided credential
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "Authorization": f"Bearer {credential['token']}"
    }
    
    # Build query parameters
    params = {"state": state}
    
    # Send GET request
    response = requests.get(url, headers=headers, params=params)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Decode the JSON response
    result = response.json()
    
    # Return None for a successful empty response
    if not result:
        return None
    
    return result