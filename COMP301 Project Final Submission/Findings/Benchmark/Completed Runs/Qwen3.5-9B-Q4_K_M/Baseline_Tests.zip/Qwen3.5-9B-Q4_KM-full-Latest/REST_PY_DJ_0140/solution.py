import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON based on sorting parameters.
    
    Args:
        inputs (dict): A dictionary containing:
            - sort_field (str): Field used for ordering.
            - sort_direction (str): Ordering direction ('asc' or 'desc').
    
    Returns:
        list or None: The decoded JSON response as a list of products, or None if the response is empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/posts"  # Using posts as an example resource; adjust to /products if DummyJSON supports it
    
    sort_field = inputs.get("sort_field", "")
    sort_direction = inputs.get("sort_direction", "asc")
    
    params = {
        "_limit": 1,      # Retrieve one page (one item)
        "_sort": sort_field,
        "_order": sort_direction
    }
    
    url = f"{base_url}{endpoint}"
    
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        data = response.json()
        
        # Return None if the response is empty (e.g., no items found)
        if not data:
            return None
            
        return data
    
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Failed to retrieve products: {str(e)}") from e