import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing 'api_key' and optionally 'page'.
                       Defaults to page 1 if not specified.
    
    Returns:
        list or None: The decoded JSON response as a list of users, 
                      or None if the response is empty.
    
    Raises:
        requests.exceptions.HTTPError: If the HTTP response status code indicates an error.
    """
    api_key = inputs.get('api_key', 'YOUR_API_KEY')  # Replace with actual key or environment variable
    page = inputs.get('page', 1)
    
    url = f"https://jsonplaceholder.typicode.com/users?page={page}"
    
    headers = {
        "Accept": "application/json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise requests.exceptions.HTTPError(f"HTTP Error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    return data if data else None