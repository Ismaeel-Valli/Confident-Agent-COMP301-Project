import requests

def solve(inputs):
    """
    Fetches a specific branch from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'branch' (str): The name of the branch to fetch.
            - 'credential' (str): The bearer token for authentication.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None if the response body is empty.
    
    Raises:
        Exception: If the HTTP response status code indicates an error.
    """
    repository_owner = inputs['repository_owner']
    repository_name = inputs['repository_name']
    branch = inputs['branch']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/branches/{branch}"
    
    headers = {
        'Accept': 'application/vnd.github+json',
        'Authorization': f'Bearer {credential}'
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch branch. Status code: {response.status_code}, Response: {response.text}")
    
    return response.json() if response.text else None