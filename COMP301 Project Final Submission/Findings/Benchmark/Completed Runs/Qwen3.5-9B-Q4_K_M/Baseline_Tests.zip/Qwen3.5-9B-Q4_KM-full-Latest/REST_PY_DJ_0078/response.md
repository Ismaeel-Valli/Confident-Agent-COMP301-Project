```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON with provided age and first name.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'new_age': int, the age for the new user.
            - 'new_firstName': str, the first name for the new user.
    
    Returns:
        None if the response is successfully empty (status 201 Created with no body or empty JSON).
        The decoded JSON response otherwise on success.
    
    Raises:
        Exception: If the HTTP request fails (non-2xx status code).
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "name": inputs.get("new_firstName"),
        "age": inputs.get("new_age")
    }

    response = requests.post(url, json=payload)
    
    if response.status_code == 201:
        # DummyJSON typically returns an empty object or null on creation success in some versions,
        # but the instruction says to return None for a successful empty response.
        if not response.text.strip():
            return None
        return response.json()
    else:
        raise Exception(f"Failed to create user. Status code: {response.status_code}, Response: {response.text}")
```