```python
import requests

def solve(inputs):
    """
    Updates a GitHub issue using the REST API (version 2026-03-10).
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - issue_number (int): The number that identifies the issue.
            - new_title (str): The new value for the title attribute.
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    new_title = inputs["new_title"]
    credential = inputs["credential"]
    
    # Construct the URL for updating an issue
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential['token']}",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare the payload with only the title field to update
    payload = {
        "title": new_title
    }
    
    response = requests.patch(url, json=payload, headers=headers)
    
    if response.status_code == 200:
        return response.json() if response.text else None
    elif response.status_code == 404:
        raise Exception(f"Resource not found: {response.url}")
    elif response.status_code == 403:
        raise Exception("Forbidden: Insufficient permissions or invalid token.")
    else:
        raise Exception(f"Failed to update issue. Status code: {response.status_code}, Response: {response.text}")
```