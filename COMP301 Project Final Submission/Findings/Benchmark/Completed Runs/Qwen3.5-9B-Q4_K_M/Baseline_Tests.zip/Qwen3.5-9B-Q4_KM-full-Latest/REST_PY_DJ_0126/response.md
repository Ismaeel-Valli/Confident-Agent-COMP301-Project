```python
import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_phone' (new phone number).
        
    Returns:
        str or None: The response's 'id' value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    resource_id = inputs['resource_id']
    new_phone = inputs['new_phone']
    
    url = f"https://dummyjson.com/users/{resource_id}"
    payload = {
        "phone": new_phone
    }
    
    response = requests.patch(url, json=payload)
    
    if response.status_code >= 400:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    # DummyJSON returns the updated user object on PATCH success
    data = response.json()
    
    # Return the id if present, otherwise None for successful empty responses
    return data.get('id')
```