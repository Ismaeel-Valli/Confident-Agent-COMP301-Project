```python
import requests

def solve(inputs):
    """
    Update selected fields of a todo using DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id', 'new_completed', and 'new_user_identifier'.
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    resource_id = inputs.get('resource_id')
    new_completed = inputs.get('new_completed')
    new_user_identifier = inputs.get('new_user_identifier')
    
    url = f"https://dummyjson.com/todos/{resource_id}"
    
    payload = {
        "completed": new_completed,
        "userId": new_user_identifier
    }
    
    response = requests.patch(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}, Response: {response.text}")
    
    # DummyJSON returns the updated todo object on PATCH success
    data = response.json()
    
    # Check if 'id' is present in the response
    if 'id' in data:
        return data['id']
    else:
        # Return None for a successful empty response (though DummyJSON typically returns the full object)
        return None
```