import requests

def solve(inputs):
    """
    Lists pull requests for a given GitHub repository using the specified API version.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - credential (dict): Caller-supplied credentials (assumed to have necessary permissions).
    
    Returns:
        dict or None: The decoded JSON response, or None if the response is successfully empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    credential = inputs["credential"]
    
    # Construct the API URL for listing pull requests
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/pulls"
    
    # Prepare headers with authentication using the provided credential
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Add authorization header if credentials include a token or other auth mechanism
    if "token" in credential:
        headers["Authorization"] = f"Bearer {credential['token']}"
    elif "username" in credential and "password" in credential:
        # Basic auth fallback if token is not present
        import base64
        auth_string = f"{credential['username']}:{credential['password']}"
        encoded_auth = base64.b64encode(auth_string.encode()).decode()
        headers["Authorization"] = f"Basic {encoded_auth}"
    
    # Send the GET request to list pull requests
    response = requests.get(url, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Decode the JSON response
    json_response = response.json()
    
    # Return None if the response is successfully empty (i.e., no pull requests found)
    if not json_response:
        return None
    
    return json_response