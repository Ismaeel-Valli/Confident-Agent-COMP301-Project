```python
import requests

def solve(inputs):
    """
    Retrieves a user by identifier from DummyJSON and returns the user's 'id'.
    
    Args:
        inputs (dict): A dictionary containing 'resource_id' as the user identifier.
        
    Returns:
        int or None: The user's ID if present, None for successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON endpoint to get a single item by ID
    url = f"https://dummyjson.com/users/{resource_id}"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # Check for empty response (e.g., no users found or empty object)
    if not data:
        return None
    
    # Return the 'id' attribute if present, otherwise None
    return data.get('id')
```