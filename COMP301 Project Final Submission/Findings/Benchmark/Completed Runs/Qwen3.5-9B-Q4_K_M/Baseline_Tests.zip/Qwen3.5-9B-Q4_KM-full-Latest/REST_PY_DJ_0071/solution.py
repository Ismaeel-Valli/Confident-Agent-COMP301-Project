import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on included fields.
    
    Args:
        inputs (dict): A dictionary containing 'included_fields' as a comma-separated string.
        
    Returns:
        dict or None: The decoded JSON response, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    included_fields = inputs.get('included_fields', '')
    
    # Construct the API URL with query parameters for fields and page size (1)
    url = "https://jsonplaceholder.typicode.com/todos"
    params = {
        '_limit': 1,
        '_fields': included_fields
    }
    
    response = requests.get(url, params=params)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # Return None for a successful empty response (though _limit=1 usually prevents this unless filtered out)
    if not data:
        return None
        
    return data