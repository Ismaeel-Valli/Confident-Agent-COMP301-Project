import requests

def solve(inputs):
    """
    Updates a release on GitHub using the REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - release_id (str): The unique identifier of the release.
            - new_target_commitish (str): The value for the target commitish attribute.
            - credential (dict): Caller-supplied credential information (e.g., token).
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    release_id = inputs["release_id"]
    new_target_commitish = inputs["new_target_commitish"]
    credential = inputs["credential"]

    # Construct the API URL for updating a release
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/releases/{release_id}"

    # Prepare headers with authentication
    headers = {
        "Authorization": f"Bearer {credential.get('token', '')}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Prepare the payload for updating the release
    data = {
        "target_commitish": new_target_commitish
    }

    # Send the PATCH request to update the release
    response = requests.patch(url, headers=headers, json=data)

    # Check if the response is successful (2xx status codes)
    if response.status_code < 300:
        # Return None for a successful empty response
        if not response.text.strip():
            return None
        # Otherwise, return the decoded JSON response
        try:
            return response.json()
        except ValueError:
            # If the response is not valid JSON but still successful, return the text
            return response.text
    else:
        # Raise an exception for an unsuccessful HTTP response
        raise Exception(f"Failed to update release. Status code: {response.status_code}, Response: {response.text}")