import requests

def solve(inputs):
    """
    Searches for products using a search term from the inputs dictionary.
    
    Args:
        inputs (dict): A dictionary containing 'search_text' as the search term.
        
    Returns:
        dict or None: The decoded JSON response if successful, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://dummyjson.com/products/search"
    search_text = inputs.get("search_text")
    
    if not search_text:
        raise ValueError("Search text is required.")

    response = requests.get(base_url, params={"q": search_text})
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # If the response contains no products (empty list), return None as per instructions.
    if not data.get("products"):
        return None
    
    return data