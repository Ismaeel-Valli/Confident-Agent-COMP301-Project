import requests
from urllib.parse import quote

def solve(inputs):
    """
    Creates a pull request on GitHub using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - new_base (str): Value for the base attribute.
            - new_head (str): Value for the head attribute.
            - new_title (str): Value for the title attribute.
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    new_base = inputs["new_base"]
    new_head = inputs["new_head"]
    new_title = inputs["new_title"]
    credential = inputs["credential"]
    
    # Construct the URL for creating a pull request
    url = f"https://api.github.com/repos/{quote(repository_owner, safe='')}/{quote(repository_name, safe='')}/pulls"
    
    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "Authorization": f"Bearer {credential['token']}" if credential.get("type") == "token" else f"Basic {credential['basic_auth']}"
    }
    
    # Prepare the payload for the pull request
    payload = {
        "title": new_title,
        "head": new_head,
        "base": new_base
    }
    
    # Send the POST request to create the pull request
    response = requests.post(url, headers=headers, json=payload)
    
    # Check if the response is successful
    if response.status_code == 201:
        # GitHub typically returns an empty body for a successful creation of a pull request
        return None
    elif response.status_code >= 400:
        raise Exception(f"Failed to create pull request. Status code: {response.status_code}, Response: {response.text}")
    
    # Handle other unexpected status codes
    raise Exception(f"Unexpected status code: {response.status_code}, Response: {response.text}")