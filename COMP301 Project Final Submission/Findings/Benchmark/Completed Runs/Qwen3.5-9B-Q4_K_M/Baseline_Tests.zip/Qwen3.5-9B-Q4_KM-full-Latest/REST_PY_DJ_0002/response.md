```python
import requests

def solve(inputs):
    """
    Retrieves a product by identifier from DummyJSON API.
    
    Args:
        inputs (dict): Dictionary containing 'resource_id' key with the product identifier.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: If HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON endpoint to get a product by ID
    url = f"https://dummyjson.com/products/{resource_id}"
    
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    # DummyJSON returns empty dict {} for successful empty response
    return None if not data else data
```