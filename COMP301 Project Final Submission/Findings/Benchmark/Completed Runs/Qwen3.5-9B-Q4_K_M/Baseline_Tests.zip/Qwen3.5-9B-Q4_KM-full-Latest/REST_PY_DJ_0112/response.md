```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON API.
    
    Inputs:
        inputs['resource_id']: Identifier of the todo (e.g., '/todos/1')
        inputs['new_completed']: Value for the 'completed' attribute
        inputs['new_todo']: Value for the 'todo' attribute
    
    Returns:
        The response's 'id' value if present, otherwise None.
        Returns None for a successful empty response (204 No Content).
        Raises an exception for unsuccessful HTTP responses (non-2xx).
    """
    resource_id = inputs['resource_id']
    new_completed = inputs['new_completed']
    new_todo = inputs['new_todo']
    
    # Construct the URL to update the todo
    url = f"https://jsonplaceholder.typicode.com{resource_id}"
    
    payload = {
        "completed": new_completed,
        "title": new_todo
    }
    
    response = requests.put(url, json=payload)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Check if the response is empty (204 No Content)
    if response.status_code == 204:
        return None
    
    # Return the 'id' from the response if present, otherwise None
    return response.json().get('id')
```