```python
import requests

def solve(inputs):
    """
    Creates a pull request on GitHub using the REST API.
    
    Args:
        inputs (dict): A dictionary containing the following keys:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - new_base (str): Value for the base attribute.
            - new_body (str): Value for the body attribute.
            - new_head (str): Value for the head attribute.
            - new_title (str): Value for the title attribute.
            - credential (str): The caller-supplied credential (e.g., token).
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    new_base = inputs["new_base"]
    new_body = inputs["new_body"]
    new_head = inputs["new_head"]
    new_title = inputs["new_title"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/pulls"
    
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    data = {
        "title": new_title,
        "body": new_body,
        "head": new_head,
        "base": new_base
    }

    response = requests.post(url, json=data, headers=headers)

    if response.status_code != 201:
        raise Exception(f"Failed to create pull request. Status code: {response.status_code}, Response: {response.text}")

    return response.json() if response.content else None
```