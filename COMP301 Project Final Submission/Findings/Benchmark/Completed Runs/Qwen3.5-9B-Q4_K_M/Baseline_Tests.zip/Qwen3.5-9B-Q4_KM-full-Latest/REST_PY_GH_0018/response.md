```python
import requests

def solve(inputs):
    """
    Fetches a specific issue comment from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'comment_id' (int): The unique identifier of the comment.
            - 'credential' (dict): Caller-supplied credential containing 'token'.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    comment_id = inputs['comment_id']
    token = inputs['credential']['token']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/comments/{comment_id}"
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        return None if not data else data
    elif response.status_code >= 400:
        raise Exception(f"Failed to fetch issue comment. Status code: {response.status_code}, Response: {response.text}")
    
    # This part should theoretically not be reached given the logic above, but for completeness
    raise Exception(f"Unexpected response status code: {response.status_code}")
```