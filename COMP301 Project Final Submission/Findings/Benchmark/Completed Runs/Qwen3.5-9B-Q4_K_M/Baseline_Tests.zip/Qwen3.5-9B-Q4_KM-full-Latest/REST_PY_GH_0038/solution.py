import requests

def solve(inputs):
    """
    Fetches a pull request from the GitHub REST API (version 2026-03-10).
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - pull_number (int): The number that identifies the pull request.
            - credential (str): The caller-supplied credential (e.g., Bearer token or OAuth token).
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code outside 2xx range).
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    pull_number = inputs["pull_number"]
    credential = inputs["credential"]

    # Construct the API URL for version 2026-03-10
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/pulls/{pull_number}"

    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential}",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        return response.json()
    elif response.status_code == 204:
        return None
    else:
        raise Exception(f"Failed to fetch pull request. Status code: {response.status_code}, Response: {response.text}")