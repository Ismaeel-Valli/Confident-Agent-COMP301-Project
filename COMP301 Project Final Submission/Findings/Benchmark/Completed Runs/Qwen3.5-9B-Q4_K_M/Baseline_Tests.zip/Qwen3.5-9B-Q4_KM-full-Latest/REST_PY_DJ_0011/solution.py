import requests

def solve(inputs):
    """
    Searches for users using a search term provided in the inputs dictionary.
    
    Args:
        inputs (dict): A dictionary containing 'search_text' key with the search term.
        
    Returns:
        list or None: Decoded JSON response as a list of users, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    search_text = inputs.get('search_text')
    
    # Construct the API endpoint for searching users
    url = "https://dummyjson.com/users/search"
    
    params = {
        'q': search_text
    }
    
    response = requests.get(url, params=params)
    
    if response.status_code == 200:
        data = response.json()
        # DummyJSON returns a list of users in the 'users' key
        return data.get('users', []) or None
    else:
        raise Exception(f"HTTP error occurred: {response.status_code}")