```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing:
            - resource_id (str): Identifier of the product.
            - new_brand (str): New value for the brand attribute.
    
    Returns:
        None if the response is empty (successful update).
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status).
    """
    resource_id = inputs.get("resource_id")
    new_brand = inputs.get("new_brand")

    url = f"https://dummyjson.com/products/{resource_id}"
    payload = {
        "brand": new_brand
    }

    response = requests.patch(url, json=payload)

    if response.status_code != 200:
        raise Exception(f"Failed to update product. Status code: {response.status_code}, Response: {response.text}")

    return None if response.json() == {} else response.json()
```