import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'resource_id': Identifier of the user.
            - 'new_lastName': New value for the last Name attribute.
    
    Returns:
        None if the response is empty (successful update).
        The decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    resource_id = inputs.get('resource_id')
    new_last_name = inputs.get('new_lastName')
    
    url = f"https://dummyjson.com/users/{resource_id}"
    data = {
        "lastName": new_last_name
    }
    
    response = requests.patch(url, json=data)
    
    if response.status_code != 200:
        raise Exception(f"Failed to update user: HTTP {response.status_code}, Response: {response.text}")
    
    return None if not response.json() else response.json()