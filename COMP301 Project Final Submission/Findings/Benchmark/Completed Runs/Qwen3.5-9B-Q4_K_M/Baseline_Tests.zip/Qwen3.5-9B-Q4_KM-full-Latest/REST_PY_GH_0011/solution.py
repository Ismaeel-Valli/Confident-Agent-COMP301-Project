import requests

def solve(inputs):
    """
    Lists commits for a GitHub repository using the specified credentials.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'credential' (str): The caller-supplied credential (e.g., token or Bearer string).
    
    Returns:
        dict or None: Decoded JSON response if commits exist, None if the list is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    owner = inputs['repository_owner']
    repo = inputs['repository_name']
    credential = inputs['credential']
    
    url = f"https://api.github.com/repos/{owner}/{repo}/commits"
    headers = {
        "Authorization": f"Bearer {credential}",
        "Accept": "application/vnd.github+json"
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to list commits. Status code: {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # GitHub returns an empty list [] when there are no commits, which is a successful response.
    if not data:
        return None
    
    return data