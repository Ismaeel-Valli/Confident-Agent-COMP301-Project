```python
import requests

def solve(inputs):
    """
    Fetches a GitHub user by username using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The GitHub username to fetch.
            - 'credential' (dict): Contains authentication details (e.g., token).
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    username = inputs["username"]
    credential = inputs["credential"]
    
    # Construct the API URL for fetching a user by username
    url = f"https://api.github.com/users/{username}"
    
    # Prepare headers with authentication using the provided credential
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential.get('token', '')}"
    }
    
    # Make the GET request to the GitHub API
    response = requests.get(url, headers=headers)
    
    # Raise an exception for unsuccessful HTTP responses
    response.raise_for_status()
    
    # Decode the JSON response
    data = response.json()
    
    # Return None if the response is empty (though this is unlikely for a user endpoint)
    if not data:
        return None
    
    return data
```