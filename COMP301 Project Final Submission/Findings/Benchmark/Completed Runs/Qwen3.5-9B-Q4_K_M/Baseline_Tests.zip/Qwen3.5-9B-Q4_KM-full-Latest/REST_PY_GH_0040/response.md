```python
import requests

def solve(inputs):
    """
    Lists commits on a pull request using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - pull_number (int): The number that identifies the pull request.
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        list or None: A list of commit objects if commits exist, None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    pr_number = inputs["pull_number"]
    credential = inputs["credential"]
    
    # Construct the API URL for listing commits on a pull request
    url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}/commits"
    
    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Add authentication based on the credential type (assuming token for simplicity)
    if "token" in credential:
        headers["Authorization"] = f"Bearer {credential['token']}"
    elif "username" in credential and "password" in credential:
        auth = requests.auth.HTTPBasicAuth(credential["username"], credential["password"])
        response = requests.get(url, headers=headers, auth=auth)
    else:
        # If no valid auth method is found, assume token-based for now
        if "token" not in credential:
            raise ValueError("Credential must contain 'token' or 'username' and 'password'.")
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to fetch commits: HTTP {response.status_code}, Response: {response.text}")
    
    data = response.json()
    
    # Return None for an empty list of commits
    return data if data else None
```