```python
import requests

def solve(inputs):
    resource_id = inputs['resource_id']
    new_body = inputs['new_body']
    new_title = inputs['new_title']
    
    url = f"https://httpbin.org/post/{resource_id}"
    
    payload = {
        "body": new_body,
        "title": new_title
    }
    
    response = requests.patch(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP request failed with status code: {response.status_code}")
    
    return None
```