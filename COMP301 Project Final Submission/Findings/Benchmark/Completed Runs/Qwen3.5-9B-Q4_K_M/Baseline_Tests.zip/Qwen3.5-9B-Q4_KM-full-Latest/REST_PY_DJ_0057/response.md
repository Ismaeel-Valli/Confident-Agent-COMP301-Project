```python
import requests

def solve(inputs):
    """
    Submits a new post to DummyJSON API using provided inputs.
    
    Args:
        inputs (dict): Contains 'new_body', 'new_title', and 'new_user_identifier'.
        
    Returns:
        str or None: The title from the response if present, otherwise None for empty success.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": inputs["new_title"],
        "body": inputs["new_body"],
        "userId": inputs["new_user_identifier"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create post. Status code: {response.status_code}")
    
    data = response.json()
    
    # Return title if present in response, otherwise None for empty response
    return data.get("title")
```