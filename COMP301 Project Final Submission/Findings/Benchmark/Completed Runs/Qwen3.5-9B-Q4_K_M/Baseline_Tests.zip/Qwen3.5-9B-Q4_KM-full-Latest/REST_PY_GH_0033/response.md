```python
import requests

def solve(inputs):
    """
    Fetches a specific milestone from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - milestone_number (int): The number identifying the milestone.
            - credential (str): The caller-supplied credential (e.g., Bearer token or API key).
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    milestone = inputs["milestone_number"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{owner}/{repo}/milestones/{milestone}"
    
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "Authorization": f"Bearer {credential}"
    }

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        data = response.json()
        return None if not data else data
    elif response.status_code == 404:
        # Assuming resources exist as per instructions, but handling gracefully if needed
        raise Exception(f"Resource not found. Status code: {response.status_code}")
    else:
        raise Exception(f"Failed to fetch milestone. Status code: {response.status_code}, Response: {response.text}")
```