import requests

def solve(inputs):
    """
    Lists followers of a GitHub user using the GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The GitHub username.
            - 'page_size' (int): Number of results per page (max 100).
            - 'credential' (dict): Contains authentication details (e.g., token or Bearer info).
    
    Returns:
        dict or None: Decoded JSON response if followers exist, None if the list is empty.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    username = inputs['username']
    page_size = inputs['page_size']
    credential = inputs['credential']

    # Construct the API URL for listing followers
    url = f"https://api.github.com/users/{username}/followers"
    
    # Prepare headers with authentication
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential.get('token', '')}" if credential.get('type') == 'token' else f"{credential.get('auth_header_name', 'Authorization')}={credential.get('token', '')}",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    params = {
        "per_page": page_size
    }

    response = requests.get(url, headers=headers, params=params)

    if response.status_code != 200:
        raise Exception(f"Failed to retrieve followers for user '{username}': HTTP {response.status_code}, Response: {response.text}")

    data = response.json()

    # Return None if the list is empty (successful but no followers)
    if not data:
        return None

    return data