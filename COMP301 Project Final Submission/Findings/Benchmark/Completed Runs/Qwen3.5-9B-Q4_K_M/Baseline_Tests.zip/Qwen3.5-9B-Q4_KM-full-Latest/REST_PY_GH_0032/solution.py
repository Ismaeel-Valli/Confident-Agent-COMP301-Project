import requests

def solve(inputs):
    """
    Creates a milestone in a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository without the .git extension.
            - new_title (str): The title for the new milestone.
            - credential (dict): Caller-supplied credentials (e.g., token in 'token' key).
    
    Returns:
        dict or None: Decoded JSON response, or None if the response is empty on success.
    
    Raises:
        Exception: If the HTTP response indicates an error (status code >= 400).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    title = inputs["new_title"]
    credential = inputs["credential"]
    
    # Construct the API URL for creating a milestone
    url = f"https://api.github.com/repos/{owner}/{repo}/milestones"
    
    # Prepare headers with authentication
    headers = {
        "Authorization": f"Bearer {credential.get('token', '')}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }
    
    # Prepare the payload for creating a milestone
    payload = {
        "title": title
    }
    
    # Send POST request to create the milestone
    response = requests.post(url, headers=headers, json=payload)
    
    # Check if the request was successful
    if response.status_code >= 400:
        raise Exception(f"Failed to create milestone. Status code: {response.status_code}, Response: {response.text}")
    
    # Decode and return the JSON response
    response_json = response.json()
    
    # Return None for a successful empty response (though GitHub usually returns an object)
    if not response_json:
        return None
    
    return response_json