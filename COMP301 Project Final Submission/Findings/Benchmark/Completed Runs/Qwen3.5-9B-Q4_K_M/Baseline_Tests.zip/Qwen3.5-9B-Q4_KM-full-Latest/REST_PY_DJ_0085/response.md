```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API using provided description and title.
    
    Args:
        inputs (dict): Contains 'new_description' and 'new_title'.
        
    Returns:
        str or None: The response's title value if present, otherwise None for success with empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    payload = {
        "title": inputs["new_title"],
        "body": inputs["new_description"]
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code != 201:
        raise Exception(f"Failed to submit product. Status code: {response.status_code}")
    
    # DummyJSON for posts returns the created object in the response body
    data = response.json()
    
    return data.get("title")
```