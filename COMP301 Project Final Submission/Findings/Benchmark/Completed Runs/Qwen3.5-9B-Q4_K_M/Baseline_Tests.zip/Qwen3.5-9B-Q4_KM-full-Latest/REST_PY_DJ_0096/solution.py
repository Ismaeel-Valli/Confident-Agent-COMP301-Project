import requests
from typing import Any, Dict, Optional

def solve(inputs: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Retrieves one page of users from DummyJSON based on provided inputs.

    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - included_fields (str): Comma-separated list of fields to include in the response.

    Returns:
        Optional[Dict[str, Any]]: The decoded JSON response if successful and non-empty,
                                  None if the response is successfully empty.

    Raises:
        Exception: If the HTTP response is unsuccessful (status code outside 200-299).
    """
    base_url = "https://jsonplaceholder.typicode.com"
    
    # Parse included_fields
    fields_list = [f.strip() for f in inputs["included_fields"].split(",")]
    
    # Construct query parameters
    params = {
        "_limit": inputs["result_limit"],
        "_fields": ",".join(fields_list)
    }
    
    url = f"{base_url}/users"
    
    response = requests.get(url, params=params)
    
    if not (200 <= response.status_code < 300):
        raise Exception(f"HTTP error: {response.status_code} - {response.text}")
    
    data = response.json()
    
    # Return None for empty list, otherwise return the data
    return data if data else None