```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_title' (new title value).
        
    Returns:
        str or None: The response's 'id' value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs.get('resource_id')
    new_title = inputs.get('new_title')
    
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    payload = {"title": new_title}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP {response.status_code}: Update failed")
    
    # DummyJSON (and similar APIs like jsonplaceholder) often return the updated object or an empty response
    data = response.json()
    
    if isinstance(data, dict):
        return data.get('id')
    else:
        return None
```