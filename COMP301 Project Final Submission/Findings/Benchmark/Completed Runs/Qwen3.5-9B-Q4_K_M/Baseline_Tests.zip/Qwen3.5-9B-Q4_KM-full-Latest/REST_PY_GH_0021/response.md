```python
import requests

def solve(inputs):
    """
    Fetches a specific issue from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - issue_number (int): The issue number to fetch.
            - credential (str): The caller-supplied credential (e.g., Bearer token or API key).
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    repository_owner = inputs["repository_owner"]
    repository_name = inputs["repository_name"]
    issue_number = inputs["issue_number"]
    credential = inputs["credential"]

    # Construct the API URL for GitHub REST API version 2026-03-10
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/issues/{issue_number}"

    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # If the credential is a Bearer token, include it in the Authorization header
    if credential.startswith("Bearer "):
        headers["Authorization"] = f"Bearer {credential}"
    elif credential:
        # Assume API key format for other cases
        headers["Authorization"] = f"token {credential}"

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        data = response.json()
        return None if not data else data
    elif response.status_code == 404:
        # Issue not found (though the problem states resources exist, handle gracefully)
        return None
    else:
        raise Exception(f"Failed to fetch issue: HTTP {response.status_code}, Response: {response.text}")
```