import requests

def solve(inputs):
    """
    Retrieves a post by identifier from DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing 'resource_id' as the post identifier.
        
    Returns:
        dict or None: The decoded JSON response if successful and data exists, 
                      None if the response is successfully empty.
                      
    Raises:
        Exception: If the HTTP response is unsuccessful (non-2xx status code).
    """
    resource_id = inputs.get('resource_id')
    
    # DummyJSON endpoint for getting a post by ID
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    
    try:
        response = requests.get(url)
        
        # Raise an exception for unsuccessful HTTP responses (non-2xx status codes)
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None for a successful empty response, otherwise return the data
        if not data:
            return None
            
        return data
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"Unsuccessful HTTP response: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")