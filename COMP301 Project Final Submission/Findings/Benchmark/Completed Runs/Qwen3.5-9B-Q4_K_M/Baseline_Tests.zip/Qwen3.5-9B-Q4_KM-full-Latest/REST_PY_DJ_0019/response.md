```python
import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON and returns the decoded JSON response.
    
    - Returns None if the response is an empty list (successful but no data).
    - Raises an exception for unsuccessful HTTP responses (e.g., 4xx, 5xx).
    
    :param inputs: A dictionary containing API parameters (e.g., {'page': 1}).
    :return: The decoded JSON response or None if the list is empty.
    :raises requests.RequestException: If the HTTP request fails.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/todos"
    
    # Construct the full URL with query parameters from inputs
    params = inputs.get("params", {})
    url = f"{base_url}{endpoint}"
    
    try:
        response = requests.get(url, params=params)
        
        # Raise an exception for unsuccessful HTTP responses (4xx, 5xx)
        response.raise_for_status()
        
        data = response.json()
        
        # Return None if the list is empty
        if not data:
            return None
        
        return data
    
    except requests.exceptions.HTTPError as e:
        raise RuntimeError(f"HTTP error occurred: {e}")
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Request failed: {e}")
```