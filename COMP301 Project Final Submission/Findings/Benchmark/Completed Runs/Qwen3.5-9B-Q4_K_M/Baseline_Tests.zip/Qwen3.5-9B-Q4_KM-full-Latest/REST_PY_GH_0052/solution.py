import requests

def solve(inputs):
    """
    Updates the authenticated user's name via GitHub REST API version 2026-03-10.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'new_name': The new name for the authenticated user.
            - 'credential': The authentication credential (e.g., token or username/password).
    
    Returns:
        None if the response is empty (success), otherwise returns the decoded JSON response.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    new_name = inputs['new_name']
    credential = inputs['credential']
    
    # GitHub API endpoint for updating user information
    url = "https://api.github.com/user"
    
    headers = {
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2026-03-10'
    }
    
    # Prepare authentication based on credential type (assuming token for simplicity)
    if isinstance(credential, str) and credential.startswith('ghp_'):
        auth = {'token': credential}
    elif isinstance(credential, dict):
        # If credential is a dict, assume it contains 'username' and 'password' or 'token'
        if 'token' in credential:
            auth = {'token': credential['token']}
        else:
            auth = {'username': credential.get('username'), 'password': credential.get('password')}
    else:
        raise ValueError("Unsupported credential format. Expected a token string or dict with 'token'.")
    
    params = {'name': new_name}
    
    response = requests.put(url, headers=headers, auth=auth, json=params)
    
    if response.status_code == 204:
        return None
    elif response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Failed to update user name. Status code: {response.status_code}, Response: {response.text}")