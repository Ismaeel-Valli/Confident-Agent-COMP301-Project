import requests

def solve(inputs):
    """
    Checks if a person is followed by the authenticated user using GitHub REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'username' (str): The handle for the GitHub user account to check.
            - 'credential' (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        int: The successful HTTP status code (e.g., 200).
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    username = inputs['username']
    credential = inputs['credential']
    
    # Construct the API URL for checking if the authenticated user follows a specific user
    url = f"https://api.github.com/user/{username}"
    
    headers = {
        'Accept': 'application/vnd.github.v3+json'
    }
    
    # Make the GET request using the provided credential (assumed to be an auth token or similar)
    response = requests.get(url, headers=headers, auth=(credential.get('token'), ''))
    
    if response.status_code == 200:
        return response.status_code
    else:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")