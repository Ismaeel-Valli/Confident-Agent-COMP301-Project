import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on skip count and included fields.
    
    Args:
        inputs (dict): A dictionary containing:
            - results_to_skip (int): Number of results to skip.
            - included_fields (str): Comma-separated list of fields to return.
    
    Returns:
        dict or None: The decoded JSON response, or None if the response is empty but successful.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    # Parse included_fields
    fields = [f.strip() for f in inputs["included_fields"].split(",")]
    
    # Build query parameters
    params = {
        "_skip": inputs["results_to_skip"],
        "_limit": 1,
        "_fields": ",".join(fields)
    }
    
    try:
        response = requests.get(base_url, params=params)
        
        if response.status_code != 200:
            raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
        
        data = response.json()
        
        # If the list is empty, return None as per requirement for successful empty response
        if not data:
            return None
        
        return data

    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")