import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API with provided age and first name.
    
    Args:
        inputs (dict): Dictionary containing 'new_age' and 'new_firstName'.
        
    Returns:
        int or None: The ID of the created user, or None if response is empty.
        
    Raises:
        Exception: If HTTP response status indicates failure.
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "name": inputs.get("new_firstName"),
        "age": inputs.get("new_age")
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code != 201:
            raise Exception(f"Failed to create user. Status code: {response.status_code}")
            
        data = response.json()
        
        # Return ID if present in response, otherwise None for empty/successful response
        return data.get("id") if data else None
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")