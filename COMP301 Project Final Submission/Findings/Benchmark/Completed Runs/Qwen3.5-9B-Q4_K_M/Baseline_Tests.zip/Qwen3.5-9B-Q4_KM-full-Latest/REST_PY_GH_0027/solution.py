import requests

def solve(inputs):
    """
    Retrieves a specific label from a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner' (str): The account owner of the repository.
            - 'repository_name' (str): The name of the repository (without .git).
            - 'name' (str): The name of the label to retrieve.
            - 'credential' (dict): Caller-supplied credential information (assumed to have necessary permissions).
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response indicates an unsuccessful status code.
    """
    repository_owner = inputs['repository_owner']
    repository_name = inputs['repository_name']
    name = inputs['name']
    credential = inputs['credential']

    # Construct the API URL for retrieving a label by name
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/labels/{name}"

    headers = {
        "Accept": "application/vnd.github+json"
    }

    # Prepare authentication based on the provided credential structure.
    # Assuming 'credential' contains a token in 'token' key for Bearer auth, 
    # or potentially other standard GitHub API auth methods if structured differently.
    # Given the prompt implies 'caller-supplied credential', we'll assume a common pattern:
    # {'token': 'ghs_xxx'} or similar. If it's an OAuth token or PAT, it goes in Authorization header.
    
    auth_header = None
    if isinstance(credential, dict):
        if 'token' in credential:
            auth_header = f"Bearer {credential['token']}"
        elif 'username' in credential and 'password' in credential:
            # Basic auth fallback if token isn't present
            auth_header = f"Basic {requests.utils.quote(f'{credential['username']}:{credential['password']}')}"
    
    response = requests.get(url, headers=headers, auth=auth_header)

    if response.status_code == 200:
        return response.json()
    elif response.status_code == 404:
        # Label not found is a specific case, but the prompt says "Raise an exception for an unsuccessful HTTP response".
        # So we treat 404 as unsuccessful here unless specified otherwise.
        pass
    else:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")

    # If we reach here, it means status code was not 200 but also didn't raise (e.g., 404).
    # However, the instruction says "Raise an exception for an unsuccessful HTTP response".
    # So any non-2xx should ideally raise. Let's adjust logic slightly to be strict.
    
    if response.status_code < 200 or response.status_code >= 300:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")

    return None