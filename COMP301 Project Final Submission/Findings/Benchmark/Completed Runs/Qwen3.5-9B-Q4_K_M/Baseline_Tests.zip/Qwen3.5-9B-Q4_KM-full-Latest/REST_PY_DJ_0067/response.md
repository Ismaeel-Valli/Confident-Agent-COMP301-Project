```python
import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API.
    
    Args:
        inputs (dict): Contains 'new_firstName' and 'new_lastName'.
        
    Returns:
        str or None: The response's id value if present, otherwise None for successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    url = "https://jsonplaceholder.typicode.com/users"
    
    payload = {
        "name": f"{inputs['new_firstName']} {inputs['new_lastName']}",
        "email": "test@example.com",  # Dummy email as required by API
        "address": {
            "street": "Test Street",
            "suite": "Apt. 1234",
            "city": "New York",
            "zipcode": "10001",
            "geo": {
                "lat": "47.668379",
                "lng": "-122.353352"
            }
        },
        "phone": "555-555-5555",
        "website": "example.com",
        "company": {
            "name": "Test Corp",
            "catchPhrase": "Test Phrase",
            "bs": "test"
        }
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create user. Status code: {response.status_code}")
    
    # DummyJSON returns the created object in the response body
    data = response.json()
    
    return data.get('id')
```