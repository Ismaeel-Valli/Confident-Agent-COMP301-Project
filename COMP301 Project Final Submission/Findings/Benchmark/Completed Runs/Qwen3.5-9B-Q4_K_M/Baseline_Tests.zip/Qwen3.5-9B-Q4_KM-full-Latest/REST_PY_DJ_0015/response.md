```python
import requests

def solve(inputs):
    """
    Updates selected fields of a post in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (post ID) and 'new_title' (new title value).
        
    Returns:
        None if the update is successful (empty response body).
        The decoded JSON response otherwise.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    resource_id = inputs['resource_id']
    new_title = inputs['new_title']
    
    url = f"https://jsonplaceholder.typicode.com/posts/{resource_id}"
    payload = {"title": new_title}
    
    response = requests.put(url, json=payload)
    
    if response.status_code != 200:
        raise Exception(f"HTTP Error {response.status_code}: {response.text}")
        
    return None
```