import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - result_limit (int): Maximum number of results to return.
            - sort_field (str): Field used for ordering the results.
    
    Returns:
        list or None: The decoded JSON response as a list of users, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code outside 200-299).
    """
    base_url = "https://jsonplaceholder.typicode.com"
    endpoint = "/users"
    
    params = {
        "_limit": inputs.get("result_limit", 10),
        "_sort": inputs.get("sort_field", "id"),
        "_order": "asc"  # Default order, can be adjusted if needed
    }
    
    response = requests.get(f"{base_url}{endpoint}", params=params)
    
    if not (200 <= response.status_code < 300):
        raise Exception(f"Unsuccessful HTTP response: {response.status_code}")
    
    data = response.json()
    
    return None if len(data) == 0 else data