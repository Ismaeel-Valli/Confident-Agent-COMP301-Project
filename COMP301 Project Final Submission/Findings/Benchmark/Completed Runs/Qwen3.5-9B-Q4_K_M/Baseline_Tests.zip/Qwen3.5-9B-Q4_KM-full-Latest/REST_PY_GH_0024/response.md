```python
import requests

def solve(inputs):
    """
    Creates an issue comment on a GitHub repository using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'repository_owner': str, The account owner of the repository.
            - 'repository_name': str, The name of the repository without the .git extension.
            - 'issue_number': int, The number that identifies the issue.
            - 'new_body': str, The value for the body attribute of the comment.
            - 'credential': dict, Caller-supplied credential (assumed to have necessary permissions).
    
    Returns:
        dict or None: The decoded JSON response if successful and non-empty, otherwise None.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    repository_owner = inputs['repository_owner']
    repository_name = inputs['repository_name']
    issue_number = inputs['issue_number']
    new_body = inputs['new_body']
    credential = inputs['credential']
    
    # Construct the URL for creating an issue comment
    url = f"https://api.github.com/repos/{repository_owner}/{repository_name}/issues/{issue_number}/comments"
    
    # Prepare headers with authentication
    headers = {
        'Authorization': f'Bearer {credential["token"]}',
        'Accept': 'application/vnd.github.v3+json',
        'Content-Type': 'application/json'
    }
    
    # Prepare the payload
    data = {
        'body': new_body
    }
    
    # Send POST request to create the comment
    response = requests.post(url, headers=headers, json=data)
    
    # Check if the response is successful
    if response.status_code == 201:
        # GitHub typically returns a 201 Created with an empty body for this endpoint
        return None
    elif response.status_code >= 400:
        raise Exception(f"Failed to create issue comment. Status code: {response.status_code}, Response: {response.text}")
    
    # Decode and return the JSON response if it's not a successful empty response
    try:
        return response.json()
    except ValueError:
        raise Exception(f"Unexpected response format for status code {response.status_code}: {response.text}")
```