```python
import requests

def solve(inputs):
    """
    Retrieves one page of todos from DummyJSON based on the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'result_limit' (int) specifying 
                       the maximum number of results to return.
    
    Returns:
        list or None: The decoded JSON response as a list of todos, or None if the 
                      response is successfully empty.
    
    Raises:
        requests.exceptions.RequestException: If the HTTP request fails.
    """
    # Extract the limit from inputs, defaulting to 10 if not provided or invalid
    result_limit = inputs.get('result_limit', 10)
    
    # Construct the API URL with the limit parameter
    url = f"https://jsonplaceholder.typicode.com/todos?limit={result_limit}"
    
    try:
        response = requests.get(url)
        
        # Raise an exception for unsuccessful HTTP responses (status code not in 2xx or 3xx range)
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None if the response is successfully empty, otherwise return the data
        return data if data else None
        
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Failed to retrieve todos: {str(e)}") from e
```