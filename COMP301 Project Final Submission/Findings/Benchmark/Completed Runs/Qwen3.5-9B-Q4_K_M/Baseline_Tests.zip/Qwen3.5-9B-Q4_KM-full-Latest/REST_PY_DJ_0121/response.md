```python
import requests

def solve(inputs):
    """
    Updates selected fields of a todo in DummyJSON.
    
    Inputs:
        inputs['resource_id']: Identifier of the todo (e.g., '1')
        inputs['new_todo']: New value for the 'todo' attribute
        inputs['new_user_identifier']: New value for the 'userId' attribute
    
    Returns:
        None if the response is empty (successful update).
        The decoded JSON response otherwise.
    
    Raises:
        Exception if the HTTP response indicates failure (non-2xx status).
    """
    resource_id = inputs['resource_id']
    new_todo = inputs['new_todo']
    new_user_identifier = inputs['new_user_identifier']

    # Construct the payload for the update request
    payload = {
        "todo": new_todo,
        "userId": new_user_identifier
    }

    url = f"https://jsonplaceholder.typicode.com/todos/{resource_id}"

    response = requests.put(url, json=payload)

    if response.status_code != 200:
        raise Exception(f"Failed to update todo. Status code: {response.status_code}, Response: {response.text}")

    # DummyJSON (and JSONPlaceholder for todos) typically returns an empty object or null on successful PUT
    if not response.json():
        return None

    return response.json()
```