import requests

def solve(inputs):
    """
    Updates selected fields of a user in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (user ID) and 'new_username'.
        
    Returns:
        str or None: The response's 'id' value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code >= 400).
    """
    resource_id = inputs['resource_id']
    new_username = inputs['new_username']
    
    url = f"https://jsonplaceholder.typicode.com/users/{resource_id}"
    
    payload = {
        "username": new_username
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.put(url, json=payload, headers=headers)
    
    if response.status_code >= 400:
        raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
    
    # DummyJSON typically returns the updated object or an empty response on success
    data = response.json()
    
    if 'id' in data:
        return data['id']
    else:
        return None