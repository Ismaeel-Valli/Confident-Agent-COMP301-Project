import requests

def solve(inputs):
    """
    Retrieves one page of users from DummyJSON based on the provided sort field.
    
    Args:
        inputs (dict): A dictionary containing 'sort_field' for ordering users.
        
    Returns:
        list or None: The decoded JSON response as a list of users, or None if the response is empty.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    sort_field = inputs.get('sort_field')
    
    # Construct the URL with query parameters for sorting
    url = f"https://jsonplaceholder.typicode.com/users?_limit=1&sort={sort_field}"
    
    try:
        response = requests.get(url)
        
        # Raise an exception for unsuccessful HTTP responses (status code outside 200-299)
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None if the response is empty, otherwise return the list of users
        return data if data else None
        
    except requests.exceptions.HTTPError as errh:
        raise Exception(f"HTTP Error: {errh}")
    except requests.exceptions.RequestException as err:
        raise Exception(f"Request Error: {err}")