import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on provided inputs.
    
    Args:
        inputs (dict): A dictionary containing:
            - 'included_fields': A comma-separated string of fields to include in the response.
            - 'sort_field': The field name used for sorting the results.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None if the response is empty.
    
    Raises:
        Exception: If the HTTP response is unsuccessful (status code 4xx or 5xx).
    """
    base_url = "https://jsonplaceholder.typicode.com/posts"
    
    # Parse included_fields from comma-separated string into a list
    included_fields = [field.strip() for field in inputs['included_fields'].split(',')]
    sort_field = inputs['sort_field']
    
    # Construct query parameters
    params = {
        '_limit': 1,  # Retrieve one page (one post)
        '_include_fields': ','.join(included_fields),
        'sort': sort_field
    }
    
    try:
        response = requests.get(base_url, params=params)
        
        # Raise an exception for unsuccessful HTTP responses
        response.raise_for_status()
        
        # Decode the JSON response
        data = response.json()
        
        # Return None if the response is empty (though unlikely with _limit=1)
        return data if data else None
        
    except requests.exceptions.HTTPError as e:
        raise Exception(f"HTTP Error: {e}")
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {e}")