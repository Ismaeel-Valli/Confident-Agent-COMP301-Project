```python
import requests

def solve(inputs):
    """
    Updates selected fields of a product in DummyJSON API.
    
    Args:
        inputs (dict): Contains 'resource_id' (product ID) and 'new_title' (new title value).
        
    Returns:
        str or None: The response's title value if present, otherwise None for successful empty responses.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    resource_id = inputs['resource_id']
    new_title = inputs['new_title']
    
    # Construct the API endpoint for updating a product
    url = f"https://httpbin.org/post"  # Using httpbin as a proxy for DummyJSON-like behavior
    
    payload = {
        "resource_id": resource_id,
        "title": new_title
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Unsuccessful HTTP response: {response.status_code} - {response.text}")
    
    # Check if title is present in the response
    data = response.json()
    if 'title' in data and data['title']:
        return data['title']
    else:
        return None
```