import requests

def solve(inputs):
    """
    Updates a GitHub repository's description using the REST API.
    
    Args:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - new_description (str): The new description for the repository.
            - credential (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    owner = inputs["repository_owner"]
    repo_name = inputs["repository_name"]
    new_description = inputs["new_description"]
    credential = inputs["credential"]

    url = f"https://api.github.com/repos/{owner}/{repo_name}"
    
    headers = {
        "Authorization": f"token {credential.get('token', '')}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    payload = {
        "description": new_description
    }

    response = requests.patch(url, json=payload, headers=headers)

    if response.status_code != 200:
        raise Exception(f"Failed to update repository description. Status code: {response.status_code}, Response: {response.text}")

    return None