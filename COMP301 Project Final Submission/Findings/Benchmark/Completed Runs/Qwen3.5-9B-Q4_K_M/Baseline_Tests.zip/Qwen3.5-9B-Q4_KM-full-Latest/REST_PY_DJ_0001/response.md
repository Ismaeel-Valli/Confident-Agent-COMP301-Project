```python
import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON API.
    
    Args:
        inputs (dict): A dictionary containing 'page' key for pagination.
        
    Returns:
        dict: Decoded JSON response if successful and non-empty.
        None: If successful but empty response.
        
    Raises:
        Exception: For unsuccessful HTTP responses.
    """
    base_url = "https://jsonplaceholder.typicode.com"
    page = inputs.get('page', 1)
    
    try:
        response = requests.get(f"{base_url}/products?page={page}")
        
        if response.status_code != 200:
            raise Exception(f"HTTP Error: {response.status_code} - {response.text}")
            
        data = response.json()
        
        # Check if the response is empty (no products)
        if not data or len(data) == 0:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"Request failed: {str(e)}")
```