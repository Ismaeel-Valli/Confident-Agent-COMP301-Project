```python
import requests

def solve(inputs):
    """
    Submits a new product to DummyJSON API with updated price and title.
    
    Args:
        inputs (dict): Contains 'new_price' and 'new_title' values.
        
    Returns:
        None if the request is successful (empty response body).
        The decoded JSON response if the server returns data.
        
    Raises:
        Exception for unsuccessful HTTP responses.
    """
    url = "https://jsonplaceholder.typicode.com/posts"
    
    # Prepare the payload using the provided inputs
    payload = {
        "title": inputs["new_title"],
        "body": inputs.get("new_price", ""),  # Using price as body content per typical DummyJSON structure if needed, or just title update
        "userId": 1  # Assuming referenced resources exist as per instructions
    }
    
    try:
        response = requests.post(url, json=payload)
        
        if response.status_code == 201:  # Created
            if not response.text.strip():
                return None
            return response.json()
        else:
            raise Exception(f"Failed to create product. Status code: {response.status_code}, Response: {response.text}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"Network error occurred: {str(e)}")
```