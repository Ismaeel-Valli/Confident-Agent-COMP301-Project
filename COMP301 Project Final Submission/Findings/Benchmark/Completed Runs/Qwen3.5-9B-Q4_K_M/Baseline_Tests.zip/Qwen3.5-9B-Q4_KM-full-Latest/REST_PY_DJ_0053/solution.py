import requests

def solve(inputs):
    """
    Retrieves one page of posts from DummyJSON based on the number of results to skip.
    
    Args:
        inputs (dict): A dictionary containing 'results_to_skip' key.
        
    Returns:
        list or None: The decoded JSON response as a list of posts, or None if the response is empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP response is unsuccessful.
    """
    results_to_skip = inputs.get('results_to_skip', 0)
    
    # DummyJSON endpoint to retrieve posts with pagination
    url = f"https://jsonplaceholder.typicode.com/posts?skip={results_to_skip}"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raise an exception for unsuccessful HTTP responses
        
        data = response.json()
        
        # Return None if the response is empty
        if not data:
            return None
            
        return data
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"HTTP request failed: {e}")