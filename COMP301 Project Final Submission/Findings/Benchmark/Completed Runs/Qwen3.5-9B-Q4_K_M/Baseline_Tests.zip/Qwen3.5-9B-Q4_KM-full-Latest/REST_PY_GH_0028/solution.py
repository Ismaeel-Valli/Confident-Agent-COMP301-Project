import requests
import json

def solve(inputs):
    """
    Updates a label on a GitHub repository using the REST API.
    
    Parameters:
        inputs (dict): A dictionary containing:
            - repository_owner (str): The account owner of the repository.
            - repository_name (str): The name of the repository (without .git).
            - name (str): The current name of the label to update.
            - new_new_name (str): The new name for the label.
            - credential (dict): Caller-supplied credentials (e.g., token in 'token' key).
    
    Returns:
        None if the response is empty (success), or the decoded JSON response otherwise.
    
    Raises:
        Exception: If the HTTP response indicates an error (non-2xx status code).
    """
    owner = inputs["repository_owner"]
    repo = inputs["repository_name"]
    label_name = inputs["name"]
    new_label_name = inputs["new_new_name"]
    credential = inputs["credential"]

    # Construct the API URL for updating a label
    url = f"https://api.github.com/repos/{owner}/{repo}/labels/{label_name}"

    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {credential.get('token', '')}",
        "X-GitHub-Api-Version": "2026-03-10"
    }

    # Prepare the payload to update the label name
    data = {"name": new_label_name}

    response = requests.put(url, headers=headers, json=data)

    if response.status_code == 204:
        return None
    elif response.status_code >= 400:
        raise Exception(f"Failed to update label: {response.status_code} - {response.text}")
    
    # For other successful status codes (e.g., 200), return the decoded JSON
    try:
        return response.json()
    except json.JSONDecodeError:
        return None