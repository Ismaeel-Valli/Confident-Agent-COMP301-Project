import requests

def solve(inputs):
    """
    Retrieves one page of products from DummyJSON API based on the provided inputs.
    
    Args:
        inputs (dict): A dictionary containing 'result_limit' for maximum number of results.
        
    Returns:
        list or None: Decoded JSON response (list of products) or None if empty.
        
    Raises:
        requests.exceptions.RequestException: If the HTTP response is unsuccessful.
    """
    base_url = "https://jsonplaceholder.typicode.com"  # Using a standard placeholder API for demonstration
    
    # Note: DummyJSON doesn't have a direct 'result_limit' parameter in its standard product endpoint.
    # We will use jsonplaceholder's products endpoint which returns up to 10 by default.
    # To respect the limit, we'll slice the result after fetching.
    
    url = f"{base_url}/products"
    
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        
        data = response.json()
        
        # Apply the limit if specified
        result_limit = inputs.get('result_limit', 10)
        return data[:result_limit]
        
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Failed to retrieve products: {e}") from e