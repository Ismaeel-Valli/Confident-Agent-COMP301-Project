```python
import requests

def solve(inputs):
    """
    Updates an organization's description via the GitHub REST API (version 2026-03-10).
    
    Args:
        inputs (dict): A dictionary containing:
            - 'organization' (str): The name of the organization.
            - 'new_description' (str): The new description for the organization.
            - 'credential' (dict): Caller-supplied credential with necessary permissions.
    
    Returns:
        dict or None: The decoded JSON response if successful, or None for an empty response.
    
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    organization = inputs['organization']
    new_description = inputs['new_description']
    credential = inputs['credential']
    
    # Construct the URL for updating an organization
    url = f"https://api.github.com/orgs/{organization}"
    
    # Prepare headers with authentication
    headers = {
        'Authorization': f"token {credential.get('token', '')}",
        'Accept': 'application/vnd.github+json'
    }
    
    # Prepare the payload for updating the organization
    payload = {
        'description': new_description
    }
    
    # Send the PUT request to update the organization
    response = requests.put(url, headers=headers, json=payload)
    
    # Check if the response is successful (status code 200-299)
    if response.status_code < 300:
        return response.json() if response.text else None
    else:
        raise Exception(f"Failed to update organization: {response.status_code} - {response.text}")
```