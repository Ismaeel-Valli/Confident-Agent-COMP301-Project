import requests

def solve(inputs):
    """
    Submits a new todo to DummyJSON API with provided inputs.
    
    Args:
        inputs (dict): Contains 'new_completed', 'new_todo', and 'new_user_identifier'.
        
    Returns:
        dict or None: Decoded JSON response if successful, None for empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful.
    """
    url = "https://jsonplaceholder.typicode.com/todos"
    
    payload = {
        "userId": inputs["new_user_identifier"],
        "id": len([t for t in requests.get(url, params={"userId": inputs["new_user_identifier"]}).json()]) + 1,
        "title": inputs["new_todo"],
        "completed": inputs["new_completed"]
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code != 201:
        raise Exception(f"Failed to create todo. Status code: {response.status_code}")
    
    return None