import requests

def solve(inputs):
    """
    Submits a new user to DummyJSON API using provided inputs.
    
    Args:
        inputs (dict): Dictionary containing 'new_firstName' and other required fields.
        
    Returns:
        str or None: The response's 'id' value if present, otherwise None for successful empty response.
        
    Raises:
        Exception: If the HTTP response is unsuccessful (status code not in 2xx range).
    """
    # DummyJSON typically requires a POST request to /users endpoint
    url = "https://dummyjson.com/users"
    
    # Prepare the payload with the new user data
    payload = {
        "firstName": inputs.get("new_firstName"),
        # Assuming other required fields might be needed, but we only have firstName from inputs
        # In a real scenario, you might need to add lastName, email, etc.
        # For this exercise, we'll just use what's provided and let the API handle defaults or errors
    }
    
    try:
        response = requests.post(url, json=payload)
        
        # Raise an exception for unsuccessful HTTP responses (non-2xx status codes)
        response.raise_for_status()
        
        # Check if the response is empty (successful but no data returned)
        if not response.text.strip():
            return None
        
        # Try to extract the 'id' from the response JSON
        try:
            response_data = response.json()
            
            # DummyJSON typically returns a single user object in the root for POST requests
            if isinstance(response_data, dict) and "id" in response_data:
                return response_data["id"]
            elif isinstance(response_data, list) and len(response_data) > 0 and "id" in response_data[0]:
                return response_data[0]["id"]
            
            # If 'id' is not found in the expected structure, return None
            return None
            
        except (ValueError, KeyError):
            # If response.json() fails or 'id' key is missing
            return None
            
    except requests.exceptions.RequestException as e:
        # Re-raise any request exceptions as a generic exception as per requirements
        raise Exception(f"Failed to submit new user: {str(e)}")